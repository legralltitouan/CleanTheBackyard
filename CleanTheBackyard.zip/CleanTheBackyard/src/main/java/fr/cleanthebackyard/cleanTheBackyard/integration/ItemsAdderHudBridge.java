package fr.cleanthebackyard.cleanTheBackyard.integration;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

/**
 * Bridge vers le HUD ItemsAdder.
 *
 * Le rendu et le positionnement (top-left) sont gérés côté config IA
 * (fichier contents/ctb/configs/hud.yml). Côté Java, on se contente de :
 *   - vérifier qu'IA est présent et que le HUD est activé,
 *   - forcer un refresh des placeholders pour les joueurs concernés.
 *
 * Les valeurs proviennent de l'expansion PlaceholderAPI %ctb_*% (BetterHudBridge),
 * réutilisée telle quelle par IA.
 */
public class ItemsAdderHudBridge {

    private final CleanTheBackyard plugin;
    private boolean active = false;

    public ItemsAdderHudBridge(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean tryRegister() {
        if (!plugin.getPluginConfig().isItemsAdderHudEnabled()) {
            plugin.getLogger().info("[CTB] HUD ItemsAdder désactivé dans la config.");
            return false;
        }
        if (Bukkit.getPluginManager().getPlugin("ItemsAdder") == null) {
            plugin.getLogger().info("[CTB] ItemsAdder absent — HUD IA inactif.");
            return false;
        }
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") == null) {
            plugin.getLogger().warning("[CTB] PlaceholderAPI requis pour le HUD IA (placeholders %ctb_*%).");
            return false;
        }
        active = true;
        plugin.getLogger().info("[CTB] HUD ItemsAdder actif (top-left, placeholders %ctb_*%).");
        return true;
    }

    public boolean isActive() { return active; }

    /** Rafraîchit le HUD pour tous les joueurs en monde de jeu. */
    public void pushAll() {
        String hub = plugin.getPluginConfig().getHubWorldName();
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getWorld() != null && p.getWorld().getName().equals(hub)) continue;
            refresh(p);
        }
    }

    /**
     * Force le refresh d'un joueur. ItemsAdder rafraîchit automatiquement ses
     * HUD, mais on peut déclencher un update via l'API si besoin (réflexion,
     * pour ne pas dépendre durement d'IA).
     */
    public void refresh(Player player) {
        // ItemsAdder gère le rafraîchissement automatique des placeholders.
        // Rien d'obligatoire ici, mais on garde le hook pour usage futur.
    }
}
