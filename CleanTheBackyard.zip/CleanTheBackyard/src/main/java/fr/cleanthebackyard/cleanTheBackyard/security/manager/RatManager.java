package fr.cleanthebackyard.cleanTheBackyard.security.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.security.entity.RatEntity;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
public class RatManager {
    private final CleanTheBackyard plugin;
    private final Map<UUID, RatEntity> activeRats = new ConcurrentHashMap<>();
    private final Map<UUID, BukkitTask> scheduledSpawns = new ConcurrentHashMap<>();
    public RatManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public void onPlayerEnterWorld(Player player) {
        if (!plugin.core().config().isRatsEnabled()) {
            plugin.getLogger().info("[CTB-Rats] Rats désactivés dans la config, skip " + player.getName());
            return;
        }
        // Si déjà planifié, on ne refait pas
        if (scheduledSpawns.containsKey(player.getUniqueId())) {
            plugin.getLogger().info("[CTB-Rats] Spawn déjà planifié pour " + player.getName());
            return;
        }
        plugin.getLogger().info("[CTB-Rats] Planification du premier rat pour " + player.getName());
        scheduleNextRat(player);
    }
    public void onPlayerLeaveWorld(Player player) {
        UUID uuid = player.getUniqueId();
        BukkitTask t = scheduledSpawns.remove(uuid);
        if (t != null) {
            t.cancel();
            plugin.getLogger().info("[CTB-Rats] Spawn annulé pour " + player.getName() + " (quit world)");
        }
        RatEntity rat = activeRats.remove(uuid);
        if (rat != null) rat.stop(false);
    }
    private void scheduleNextRat(Player player) {
        UUID uuid = player.getUniqueId();
        BukkitTask existing = scheduledSpawns.remove(uuid);
        if (existing != null) existing.cancel();
        PluginConfig cfg = plugin.core().config();
        int min = Math.max(1, cfg.getRatsMinSpawnSec());
        int max = Math.max(min + 1, cfg.getRatsMaxSpawnSec());
        int delay = min + ThreadLocalRandom.current().nextInt(max - min);
        // Talent Charisme : moins de rats
        PlayerData data = plugin.core().playerData().get(player);
        if (data != null) {
            double charismaMul = plugin.progression().talent().getRatFrequencyMultiplier(data);
            if (charismaMul > 0) {
                // mul < 1 = moins fréquent → on rallonge le délai
                delay = (int) Math.round(delay / charismaMul);
            }
        }

        plugin.getLogger().info("[CTB-Rats] Prochain rat pour " + player.getName() + " dans " + delay + "s");
        BukkitTask task = new BukkitRunnable() {
            @Override
            public void run() {
                scheduledSpawns.remove(uuid);
                if (!player.isOnline()) return;
                trySpawnRat(player);
                if (player.isOnline()) scheduleNextRat(player);
            }
        }.runTaskLater(plugin, delay * 20L);
        scheduledSpawns.put(uuid, task);
    }
    private void trySpawnRat(Player player) {
        if (!plugin.core().config().isRatsEnabled()) {
            plugin.getLogger().info("[CTB-Rats] Skip spawn: rats désactivés");
            return;
        }
        String expected = plugin.core().config().getPlayerWorldName(player.getUniqueId());
        if (!player.getWorld().getName().equals(expected)) {
            plugin.getLogger().info("[CTB-Rats] Skip spawn pour " + player.getName()
                    + " : pas dans son monde (actuellement dans " + player.getWorld().getName()
                    + ", attendu " + expected + ")");
            return;
        }
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) {
            plugin.getLogger().info("[CTB-Rats] Skip spawn pour " + player.getName() + " : PlayerData null");
            return;
        }
        PluginConfig cfg = plugin.core().config();
        if (data.getBalance() < cfg.getRatsMinBalanceToTrigger()) {
            plugin.getLogger().info("[CTB-Rats] Skip spawn pour " + player.getName()
                    + " : balance trop basse (" + (long) data.getBalance()
                    + " < " + cfg.getRatsMinBalanceToTrigger() + ")");
            return;
        }
        if (activeRats.containsKey(player.getUniqueId())) {
            plugin.getLogger().info("[CTB-Rats] Skip spawn pour " + player.getName() + " : rat déjà actif");
            return;
        }
        spawnRatForPlayer(player, data);
    }
    public boolean forceSpawnRat(Player player) {
        String expected = plugin.core().config().getPlayerWorldName(player.getUniqueId());
        if (!player.getWorld().getName().equals(expected)) return false;
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        if (activeRats.containsKey(player.getUniqueId())) return false;
        spawnRatForPlayer(player, data);
        return true;
    }
    private void spawnRatForPlayer(Player player, PlayerData data) {
        PluginConfig cfg = plugin.core().config();
        double balance = data.getBalance();
        double pct = cfg.getRatsStealPercentMin()
                + ThreadLocalRandom.current().nextDouble() * (cfg.getRatsStealPercentMax() - cfg.getRatsStealPercentMin());
        long stealAmount = Math.min(cfg.getRatsStealCap(), Math.max(1L, (long) (balance * pct)));
        World w = player.getWorld();
        Location stashLoc = cfg.getStashLocation(w).clone().add(0.5, 0, 0.5);
        RatEntity rat = new RatEntity(player, stashLoc, stealAmount);
        activeRats.put(player.getUniqueId(), rat);
        plugin.getLogger().info("[CTB-Rats] Rat spawn pour " + player.getName()
                + " (steal=" + stealAmount + "$ depuis balance=" + (long) balance + "$)");
    }
    public void unregister(RatEntity rat) {
        activeRats.values().removeIf(r -> r == rat);
    }
    public RatEntity findByEntity(Entity bukkitEntity) {
        if (bukkitEntity == null) return null;
        if (!plugin.providers().entity().isCtbEntity(bukkitEntity, "rat")) return null;
        for (RatEntity r : activeRats.values()) {
            if (r.getHandle().getBukkitEntity().getUniqueId().equals(bukkitEntity.getUniqueId())) {
                return r;
            }
        }
        return null;
    }
    public void shutdown() {
        scheduledSpawns.values().forEach(BukkitTask::cancel);
        scheduledSpawns.clear();
        activeRats.values().forEach(r -> r.stop(false));
        activeRats.clear();
        for (World w : Bukkit.getWorlds()) {
            for (org.bukkit.entity.Rabbit rabbit : w.getEntitiesByClass(org.bukkit.entity.Rabbit.class)) {
                if (plugin.providers().entity().isCtbEntity(rabbit, "rat")) {
                    rabbit.remove();
                }
            }
        }
    }
}