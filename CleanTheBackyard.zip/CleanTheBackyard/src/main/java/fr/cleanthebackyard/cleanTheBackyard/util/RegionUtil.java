package fr.cleanthebackyard.cleanTheBackyard.util;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.plugin.Plugin;
import org.bukkit.util.BoundingBox;

public final class RegionUtil {

    private RegionUtil() {}

    /**
     * Copie une région cubique depuis un monde source vers un monde destination.
     * Les coordonnées du rectangle sont identiques dans les deux mondes.
     * Exécution synchrone, à appeler depuis le thread principal.
     */
    public static int copyRegion(World source, World dest, BoundingBox region) {
        if (source == null || dest == null || region == null) return 0;

        int minX = (int) Math.floor(region.getMinX());
        int minY = (int) Math.floor(region.getMinY());
        int minZ = (int) Math.floor(region.getMinZ());
        int maxX = (int) Math.floor(region.getMaxX());
        int maxY = (int) Math.floor(region.getMaxY());
        int maxZ = (int) Math.floor(region.getMaxZ());

        int count = 0;
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    Block src = source.getBlockAt(x, y, z);
                    Block dst = dest.getBlockAt(x, y, z);
                    BlockData srcData = src.getBlockData();
                    if (!dst.getBlockData().matches(srcData)) {
                        dst.setBlockData(srcData, false);
                        count++;
                    }
                }
            }
        }
        return count;
    }

    /**
     * Variante : ne copie QUE les blocs d'un type donné (utile pour ne re-placer
     * que les cartons sans toucher au reste du décor).
     */
    public static int copyRegionFiltered(World source, World dest, BoundingBox region, Material filterMaterial) {
        if (source == null || dest == null || region == null || filterMaterial == null) return 0;

        int minX = (int) Math.floor(region.getMinX());
        int minY = (int) Math.floor(region.getMinY());
        int minZ = (int) Math.floor(region.getMinZ());
        int maxX = (int) Math.floor(region.getMaxX());
        int maxY = (int) Math.floor(region.getMaxY());
        int maxZ = (int) Math.floor(region.getMaxZ());

        int count = 0;
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    Block src = source.getBlockAt(x, y, z);
                    if (src.getType() != filterMaterial) continue;
                    Block dst = dest.getBlockAt(x, y, z);
                    if (dst.getType() != filterMaterial) {
                        dst.setBlockData(src.getBlockData(), false);
                        count++;
                    }
                }
            }
        }
        return count;
    }
}
