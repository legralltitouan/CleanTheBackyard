package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;

public class QuestGui {

    private static final String TITLE = ChatUtil.color("&8[&6Quêtes Journalières&8]");
    private final CleanTheBackyard plugin;

    public QuestGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        build(inv, player);
        player.openInventory(inv);
    }

    private void build(Inventory inv, Player player) {
        ItemStack glass = new ItemBuilder(Material.YELLOW_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        plugin.getQuestManager().checkAndResetQuests(data);

        List<DailyQuest> quests = data.getDailyQuests();
        int[] slots = {11, 13, 15};

        for (int i = 0; i < quests.size() && i < slots.length; i++) {
            DailyQuest q = quests.get(i);
            Material mat = q.isClaimed() ? Material.LIME_DYE
                    : q.isCompleted() ? Material.EXPERIENCE_BOTTLE
                    : Material.PAPER;

            List<String> lore = new ArrayList<>();
            lore.add(ChatUtil.color("&7Progression : &f" + q.getProgress() + " / " + q.getTarget()));
            lore.add(ChatUtil.color("&7Récompense : &a$" + q.getReward()));
            lore.add(" ");
            if (q.isClaimed()) lore.add(ChatUtil.color("&aRécompense récupérée"));
            else if (q.isCompleted()) lore.add(ChatUtil.color("&eClic pour récupérer la récompense !"));
            else lore.add(ChatUtil.color("&7En cours..."));

            inv.setItem(slots[i], new ItemBuilder(mat)
                    .name("&6" + q.getFormattedDescription())
                    .lore(lore).build());
        }

        // Timer avant reset (minuit local)
        inv.setItem(22, new ItemBuilder(Material.CLOCK)
                .name("&eReset dans &f" + getTimeUntilReset())
                .lore(List.of(
                        ChatUtil.color("&7Les quêtes se réinitialisent à minuit."),
                        ChatUtil.color("&7Heure locale du serveur : &f" + LocalTime.now(ZoneId.systemDefault()).withNano(0))
                ))
                .build());
    }

    private String getTimeUntilReset() {
        LocalDateTime now = LocalDateTime.now(ZoneId.systemDefault());
        LocalDateTime nextMidnight = LocalDate.now(ZoneId.systemDefault()).plusDays(1).atStartOfDay();
        Duration d = Duration.between(now, nextMidnight);
        long h = d.toHours();
        long m = d.toMinutesPart();
        long s = d.toSecondsPart();
        return String.format("%02dh %02dm %02ds", h, m, s);
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        int slot = event.getRawSlot();
        int[] slots = {11, 13, 15};
        for (int i = 0; i < slots.length; i++) {
            if (slot == slots[i]) {
                plugin.getQuestManager().claimReward(player, i);
                build(event.getInventory(), player);
                return true;
            }
        }
        return true;
    }
}
