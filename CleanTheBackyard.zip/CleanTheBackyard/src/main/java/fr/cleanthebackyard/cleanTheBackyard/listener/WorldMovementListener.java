package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import net.kyori.adventure.text.Component;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.BoundingBox;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
/**
 * Listener unique pour tout le traitement de mouvement dans le monde de jeu :
 *   ─ mur de zone de cartons (ex-CardboardWallListener),
 *   ─ confinement player-bounds (ex-GameWorldProtectionListener.onMove),
 *   ─ effets d'énergie (ex-PlayerListener.onMove).
 *
 * Fusionner évite trois récupérations indépendantes de PlayerData et trois
 * reconstructions de régions à chaque pas. PlayerData et la région sont
 * résolus une seule fois.
 */
public class WorldMovementListener implements Listener {
    private final CleanTheBackyard plugin;
    private static final double MARGIN = 0.30;
    public WorldMovementListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private boolean isPlayerGameWorld(World world) {
        if (world == null) return false;
        String hub = plugin.core().config().getHubWorldName();
        if (world.getName().equals(hub)) return false;
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        if (world.getName().startsWith(housePrefix)) return false;
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        return world.getName().startsWith(prefix);
    }
    private boolean isBypass(Player p) {
        return p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR;
    }
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!isPlayerGameWorld(player.getWorld())) return;
        Location to = event.getTo();
        if (to == null) return;
        Location from = event.getFrom();
        // Filtre commun : aucun changement de bloc → rien à faire.
        boolean sameBlock = from.getBlockX() == to.getBlockX()
                && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ();
        if (sameBlock) return;
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return;
        boolean bypass = isBypass(player);
        var cfg = plugin.core().config();
        // ── 1. Effets d'énergie (toujours, même en créatif) ──
        updateEnergyEffects(player, data);
        if (player.isSprinting() && data.getCurrentEnergy() <= 0) {
            plugin.gameplay().box().applyFatigue(player, data);
        }
        if (bypass) return; // créatif/spectateur ignore confinement + mur
        // Région de zone résolue une seule fois (clone caché).
        BoundingBox region = cfg.getBoxRainRegion(data.getCardboardZoneLevel());
        // ── 2. Confinement player-bounds ──
        if (cfg.isPlayerBoundsEnabled()) {
            BoundingBox b = cfg.getPlayerBounds();
            double x = to.getX(), y = to.getY(), z = to.getZ();
            boolean outside = x < b.getMinX() + MARGIN || x > b.getMaxX() + 1 - MARGIN
                    || z < b.getMinZ() + MARGIN || z > b.getMaxZ() + 1 - MARGIN
                    || y < b.getMinY() || y > b.getMaxY() + 2;
            if (outside) {
                Location corrected = to.clone();
                corrected.setX(clamp(x, b.getMinX() + MARGIN, b.getMaxX() + 1 - MARGIN));
                corrected.setZ(clamp(z, b.getMinZ() + MARGIN, b.getMaxZ() + 1 - MARGIN));
                corrected.setY(clamp(y, b.getMinY(), b.getMaxY() + 2));
                corrected.setYaw(to.getYaw());
                corrected.setPitch(to.getPitch());
                event.setTo(corrected);
                return; // la correction prime, inutile de tester le mur ce tick
            }
        }
        // ── 3. Mur de zone de cartons ──
        if (cfg.isCardboardZoneEnabled()) {
            String axis = cfg.getCardboardZoneAxis();
            Location corrected = null;
            if ("X".equalsIgnoreCase(axis)) {
                double limit = region.getMaxX() + 1.0;
                if (to.getX() > limit + MARGIN) {
                    corrected = to.clone();
                    corrected.setX(limit + MARGIN);
                }
            } else {
                double limit = region.getMaxZ() + 1.0;
                if (to.getZ() > limit + MARGIN) {
                    corrected = to.clone();
                    corrected.setZ(limit + MARGIN);
                }
            }
            if (corrected != null) {
                corrected.setYaw(to.getYaw());
                corrected.setPitch(to.getPitch());
                event.setTo(corrected);
            }
        }
    }
    private void updateEnergyEffects(Player player, PlayerData data) {
        double currentEnergy = data.getCurrentEnergy();
        if (currentEnergy < 5) {
            if (!player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
                player.addPotionEffect(new PotionEffect(
                        PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 2, false, false, false));
            }
            if (!player.hasPotionEffect(PotionEffectType.BLINDNESS)) {
                player.addPotionEffect(new PotionEffect(
                        PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false));
            }
        } else if (currentEnergy > 25) {
            if (player.hasPotionEffect(PotionEffectType.SLOWNESS)) player.removePotionEffect(PotionEffectType.SLOWNESS);
            if (player.hasPotionEffect(PotionEffectType.BLINDNESS)) player.removePotionEffect(PotionEffectType.BLINDNESS);
        }
    }
    private double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}