package fr.cleanthebackyard.cleanTheBackyard.progression;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.progression.manager.DailyRewardManager;
import fr.cleanthebackyard.cleanTheBackyard.progression.manager.OfflineEarningsManager;
import fr.cleanthebackyard.cleanTheBackyard.progression.manager.PrestigeManager;
import fr.cleanthebackyard.cleanTheBackyard.progression.manager.QuestManager;
import fr.cleanthebackyard.cleanTheBackyard.progression.manager.TalentManager;

/**
 * Avancement long terme : quêtes, prestige, talents, récompenses
 * quotidiennes et revenus offline.
 */
public record ProgressionSystem(
        QuestManager           quest,
        PrestigeManager        prestige,
        TalentManager          talent,
        DailyRewardManager     dailyReward,
        OfflineEarningsManager offlineEarnings) {

    public static ProgressionSystem create(CleanTheBackyard plugin) {
        return new ProgressionSystem(
                new QuestManager(plugin),
                new PrestigeManager(plugin),
                new TalentManager(plugin),
                new DailyRewardManager(plugin),
                new OfflineEarningsManager(plugin));
    }
}
