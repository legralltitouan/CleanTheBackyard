package fr.cleanthebackyard.cleanTheBackyard.gameplay.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class BoxManager {
    private final CleanTheBackyard plugin;
    private final Set<UUID> fatiguedPlayers = ConcurrentHashMap.newKeySet();
    private final Set<String> blocksBeingCollected = ConcurrentHashMap.newKeySet();
    private record CollectionState(Location location, long startTime, long durationMs, BukkitTask task) {}
    private final Map<UUID, CollectionState> activeCollections = new HashMap<>();

    public BoxManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean startCollection(Player player, Location boxLocation) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        double maxDist = plugin.core().config().getMaxBreakDistance();
        if (player.getLocation().distance(boxLocation) > maxDist) {
            player.sendMessage(ChatUtil.color("&cVous êtes trop loin de ce carton !"));
            return false;
        }
        if (!data.hasUnlimitedEnergy() && data.getCurrentEnergy() <= 0) {
            applyFatigue(player, data);
            player.sendActionBar(Component.text(
                    ChatUtil.color("&c[Énergie épuisée] Reposez-vous ou achetez une boisson !")
            ));
            return false;
        }
        int maxCapacity = getBagCapacity(data.getBagLevel());
        if (data.getCurrentBoxes() >= maxCapacity) {
            plugin.progression().quest().onProgress(player, DailyQuest.Type.REACH_BAG_FULL, 0);
            player.sendActionBar(Component.text(
                    ChatUtil.color("&eSac plein ! Va vendre tes cartons dans la zone de vente.")
            ));
            return false;
        }
        CollectionState existing = activeCollections.get(player.getUniqueId());
        if (existing != null) {
            String existingKey = LocationUtil.locKey(existing.location());
            String newKey = LocationUtil.locKey(boxLocation);
            if (existingKey.equals(newKey)) return false;
            cancelCollection(player);
        }
        String blockKey = LocationUtil.locKey(boxLocation);
        if (blocksBeingCollected.contains(blockKey)) {
            player.sendActionBar(Component.text(ChatUtil.color("&eCe carton est déjà en cours de collecte !")));
            return false;
        }
        blocksBeingCollected.add(blockKey);

        long durationMs = getToolCooldown(data.getToolLevel());
        long startTime = System.currentTimeMillis();
        player.playSound(player.getLocation(), Sound.BLOCK_CHISELED_BOOKSHELF_BREAK, 0.5f, 0.8f);

        BlockRef boxRef = plugin.core().config().getBoxBlockRef();

        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            long elapsed = System.currentTimeMillis() - startTime;
            float progress = Math.min(1.0f, (float) elapsed / durationMs);

            Block target = boxLocation.getBlock();
            if (!plugin.providers().block().isCarton(target, boxRef)) {
                blocksBeingCollected.remove(blockKey);
                CollectionState s = activeCollections.remove(player.getUniqueId());
                if (s != null) s.task().cancel();
                return;
            }
            if (player.getLocation().distance(boxLocation) > maxDist + 1.0) {
                blocksBeingCollected.remove(blockKey);
                cancelCollection(player);
                player.sendActionBar(Component.text(ChatUtil.color("&cCollecte annulée ! Trop loin.")));
                return;
            }
            if (progress >= 1.0f) {
                blocksBeingCollected.remove(blockKey);
                CollectionState done = activeCollections.remove(player.getUniqueId());
                if (done != null) done.task().cancel();
                finalizeCollection(player, boxLocation, data);
            } else {
                player.sendActionBar(Component.text(
                        ChatUtil.color("&b" + buildProgressBar(progress) + " &fCollecte en cours...")
                ));
            }
        }, 0L, 2L);
        activeCollections.put(player.getUniqueId(), new CollectionState(boxLocation, startTime, durationMs, task));
        return true;
    }

    private void finalizeCollection(Player player, Location boxLocation, PlayerData data) {
        if (!data.hasUnlimitedEnergy() && data.getCurrentEnergy() <= 0) {
            applyFatigue(player, data);
            return;
        }
        int maxCapacity = getBagCapacity(data.getBagLevel());
        if (data.getCurrentBoxes() >= maxCapacity) {
            player.sendActionBar(Component.text(ChatUtil.color("&eSac plein !")));
            return;
        }

        int boxesToCollect = calculateBoxesWithProbability(data);
        BlockRef boxRef = plugin.core().config().getBoxBlockRef();

        List<Location> targets = new ArrayList<>();
        targets.add(boxLocation);
        if (boxesToCollect > 1 && boxLocation.getWorld() != null) {
            outer:
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        if (targets.size() >= boxesToCollect) break outer;
                        Location nearby = boxLocation.clone().add(dx, dy, dz);
                        if (plugin.providers().block().isCarton(nearby.getBlock(), boxRef)
                                && !blocksBeingCollected.contains(LocationUtil.locKey(nearby))) {
                            targets.add(nearby);
                        }
                    }
                }
            }
        }

        int collected = 0;
        double costPerBox = getEnergyCostForLevel(data.getToolLevel());
        for (Location loc : targets) {
            if (data.getCurrentBoxes() >= maxCapacity) break;
            if (!data.hasUnlimitedEnergy() && data.getCurrentEnergy() < costPerBox) break;
            String key = LocationUtil.locKey(loc);
            blocksBeingCollected.add(key);
            if (!data.hasUnlimitedEnergy()) data.removeEnergy(costPerBox);
            plugin.providers().block().breakCarton(loc.getBlock(), boxRef);
            plugin.events().onBoxBroken(loc);
            data.addBox();
            data.incrementBoxesBroken();
            collected++;
            blocksBeingCollected.remove(key);

            // ── ROLL pour drop de collectible
            plugin.gameplay().collectible().rollDrop(player, loc);
        }
        if (collected == 0) {
            player.sendActionBar(Component.text(ChatUtil.color("&eSac plein !")));
            return;
        }
        plugin.progression().quest().onProgress(player, DailyQuest.Type.BREAK_BOXES, collected);
        if (data.getCurrentBoxes() >= maxCapacity) {
            plugin.progression().quest().onProgress(player, DailyQuest.Type.REACH_BAG_FULL, 1);
        }
        removeFatigue(player, data);
        player.playSound(player.getLocation(), Sound.BLOCK_CHISELED_BOOKSHELF_BREAK, 1.0f, 1.2f);
        String msg = collected > 1
                ? ChatUtil.color("&a+" + collected + " cartons collectés !")
                : ChatUtil.color("&aSac: &f" + data.getCurrentBoxes() + "/" + maxCapacity
                + " &7| &7Énergie: &f" + String.format("%.0f", data.getCurrentEnergy()));
        player.sendActionBar(Component.text(msg));
    }

    /** Calcule le nombre de cartons collectés en tenant compte du talent Botanique. */
    private int calculateBoxesWithProbability(PlayerData data) {
        PluginConfig.ToolUpgrade current = plugin.core().config().getToolUpgrade(data.getToolLevel());
        if (current == null) return 1;
        int baseBoxes = current.boxesPerCollection();
        // Talent Botanique : ajoute un bonus de chance de cartons supplémentaires
        double extraChance = current.extraBoxChance()
                + plugin.progression().talent().getBotanyBonus(data);
        int guaranteedExtra = (int) Math.floor(extraChance);
        double remainder = extraChance - guaranteedExtra;
        return baseBoxes + guaranteedExtra + (Math.random() < remainder ? 1 : 0);
    }

    public double getEnergyCostForLevel(int toolLevel) {
        double base = plugin.core().config().getEnergyCostPerBox();
        return base + (toolLevel - 1) * 0.5;
    }

    public void cancelCollection(Player player) {
        CollectionState state = activeCollections.remove(player.getUniqueId());
        if (state != null) {
            blocksBeingCollected.remove(LocationUtil.locKey(state.location()));
            state.task().cancel();
        }
    }
    public boolean isCollecting(UUID uuid) { return activeCollections.containsKey(uuid); }
    public float getCollectionProgress(UUID uuid) {
        CollectionState state = activeCollections.get(uuid);
        if (state == null) return -1f;
        long elapsed = System.currentTimeMillis() - state.startTime();
        return Math.min(1.0f, (float) elapsed / state.durationMs());
    }
    private String buildProgressBar(float progress) {
        int total = 20;
        int filled = Math.round(progress * total);
        StringBuilder bar = new StringBuilder("&b[");
        for (int i = 0; i < total; i++) {
            bar.append(i < filled ? "&b█" : "&8░");
        }
        bar.append("&b]");
        return bar.toString();
    }
    public void applyFatigue(Player player, PlayerData data) {
        UUID uuid = player.getUniqueId();
        if (fatiguedPlayers.add(uuid)) {
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 2, false, false, false
            ));
        }
    }
    public void removeFatigue(Player player, PlayerData data) {
        UUID uuid = player.getUniqueId();
        if (fatiguedPlayers.remove(uuid) && data.getCurrentEnergy() > 0) {
            player.removePotionEffect(PotionEffectType.SLOWNESS);
        }
    }
    public boolean isFatigued(UUID uuid) { return fatiguedPlayers.contains(uuid); }
    public int getBagCapacity(int level) {
        PluginConfig.BagUpgrade u = plugin.core().config().getBagUpgrade(level);
        return u != null ? u.capacity() : 10;
    }
    public long getToolCooldown(int level) {
        PluginConfig.ToolUpgrade u = plugin.core().config().getToolUpgrade(level);
        return u != null ? u.cooldownMs() : 1000L;
    }
    public int getMaxEnergyForLevel(int level) {
        var cfg = plugin.core().config().getEnergyUpgrade(level);
        return cfg != null ? cfg.maxEnergy() : 100;
    }

    /** Régénération d'énergie par seconde pour un niveau donné. */
    public double getEnergyRegenForLevel(int level) {
        PluginConfig.EnergyUpgrade u = plugin.core().config().getEnergyUpgrade(level);
        return u != null ? u.regenPerSec() : 1.0;
    }

    /** Variante qui applique le talent Endurance du joueur. */
    public int getMaxEnergyForPlayer(PlayerData data) {
        int base = getMaxEnergyForLevel(data.getEnergyLevel());
        double mul = plugin.progression().talent().getEnergyMaxMultiplier(data);
        return (int) Math.round(base * mul);
    }
}
