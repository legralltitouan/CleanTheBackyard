package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.CollectibleItem;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
public class CollectibleListener implements Listener {
    private final CleanTheBackyard plugin;
    public CollectibleListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        // ── Priorité absolue : si le joueur est en mini-jeu, on intercepte TOUT
        if (plugin.gameplay().cleaningGame().isPlaying(player.getUniqueId())) {
            event.setCancelled(true);
            // Seul le clic gauche compte comme "hit"
            if (event.getHand() == EquipmentSlot.HAND
                    && (event.getAction() == Action.LEFT_CLICK_AIR
                    || event.getAction() == Action.LEFT_CLICK_BLOCK)) {
                plugin.gameplay().cleaningGame().onPlayerClick(player);
            }
            return;
        }
        if (event.getHand() != EquipmentSlot.HAND) return;
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) return;
        if (!plugin.gameplay().collectible().isCollectible(item)) return;
        // Clic droit : nettoyer un item sale OU déposer un item propre
        if (event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK) {
            event.setCancelled(true);
            String key = plugin.gameplay().collectible().getCollectibleKey(item);
            CollectibleItem ci = plugin.gameplay().collectible().get(key);
            if (ci == null) return;
            if (plugin.gameplay().collectible().isDirty(item)) {
                int handSlot = player.getInventory().getHeldItemSlot();
                plugin.gameplay().cleaningGame().start(player, ci, handSlot);
            } else {
                if (plugin.gameplay().collectionBoard().depositItem(player, key)) {
                    item.setAmount(item.getAmount() - 1);
                }
            }
        }
    }
    /** Annule le drop d'item pendant le mini-jeu pour éviter de perdre l'objet sale. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onDrop(PlayerDropItemEvent event) {
        if (plugin.gameplay().cleaningGame().isPlaying(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatUtil.color("&cTu ne peux pas lâcher l'objet pendant le nettoyage."));
        }
    }
    /** Annule le changement de slot pendant le mini-jeu pour ne pas perdre la main sur l'item. */
    @EventHandler(priority = EventPriority.LOWEST)
    public void onSlotChange(PlayerItemHeldEvent event) {
        if (plugin.gameplay().cleaningGame().isPlaying(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }
    @EventHandler(priority = EventPriority.LOWEST)
    public void onSwap(PlayerSwapHandItemsEvent event) {
        if (plugin.gameplay().cleaningGame().isPlaying(event.getPlayer().getUniqueId())) {
            event.setCancelled(true);
        }
    }
}