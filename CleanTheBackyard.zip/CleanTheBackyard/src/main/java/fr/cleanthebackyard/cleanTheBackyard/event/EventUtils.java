package fr.cleanthebackyard.cleanTheBackyard.event;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

final class EventUtils {

    private EventUtils() {}

    static List<Player> getAllCtbPlayers(CleanTheBackyard plugin) {
        String hub = plugin.getPluginConfig().getHubWorldName();
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            World w = p.getWorld();
            if (w == null || w.getName().equals(hub)) continue;
            if (w.getName().startsWith(prefix)) list.add(p);
        }
        return list;
    }

    static boolean isInOwnWorld(CleanTheBackyard plugin, Player p) {
        if (p == null || p.getWorld() == null) return false;
        String expected = plugin.getPluginConfig().getPlayerWorldName(p.getUniqueId());
        return p.getWorld().getName().equals(expected);
    }
}
