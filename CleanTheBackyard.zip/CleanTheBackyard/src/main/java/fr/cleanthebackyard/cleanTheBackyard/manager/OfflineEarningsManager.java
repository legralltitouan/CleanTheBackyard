package fr.cleanthebackyard.cleanTheBackyard.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.entity.Player;
/**
 * Calcule les revenus offline (sleep mode) :
 *   - débloqué à partir du prestige configuré
 *   - 30% des revenus drones théoriques
 *   - capé à N heures
 */
public class OfflineEarningsManager {
    private final CleanTheBackyard plugin;
    private final boolean debug = false; // passe à false en prod
    public OfflineEarningsManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private void log(String msg) {
        if (debug) plugin.getLogger().info("[CTB-Sleep] " + msg);
    }
    /**
     * Doit être appelée APRÈS loadPlayer mais avant que le joueur ne joue.
     * Retourne le montant crédité (0 si rien).
     */
    public long applyOnJoin(Player player, PlayerData data) {
        if (data == null) return 0;
        PluginConfig cfg = plugin.getPluginConfig();
        int unlock = cfg.getSleepUnlockPrestige();
        if (data.getPrestigeLevel() < unlock) {
            log(player.getName() + " : sleep verrouillé (prestige " + data.getPrestigeLevel()
                    + " < " + unlock + ").");
            data.setLastSeenMs(System.currentTimeMillis());
            return 0;
        }
        long lastSeen = data.getLastSeenMs();
        if (lastSeen <= 0) {
            log(player.getName() + " : pas de last-seen enregistré (première session sleep).");
            data.setLastSeenMs(System.currentTimeMillis());
            return 0;
        }
        long now = System.currentTimeMillis();
        long offlineSec = (now - lastSeen) / 1000L;
        log(player.getName() + " : offline " + offlineSec + "s (min requis "
                + cfg.getSleepMinOfflineSec() + "s).");
        if (offlineSec < cfg.getSleepMinOfflineSec()) {
            data.setLastSeenMs(now);
            return 0;
        }
        long capSec = cfg.getSleepCapHours() * 3600L;
        long effectiveSec = Math.min(offlineSec, capSec);
        double droneTheoreticalPerSec = computeDroneIncomePerSec(data);
        log(player.getName() + " : revenu drone théorique = "
                + String.format("%.4f", droneTheoreticalPerSec) + " $/s ("
                + data.getOwnedDrones().size() + " drone(s)).");
        if (droneTheoreticalPerSec <= 0) {
            // Débloqué mais aucun drone : on informe le joueur pour éviter la confusion.
            player.sendMessage(ChatUtil.color(
                    "&7💤 Sleep Mode actif, mais tu n'as &caucun drone&7 produisant des revenus."));
            data.setLastSeenMs(now);
            return 0;
        }
        double efficiency = cfg.getSleepEfficiency();
        long earned = Math.round(droneTheoreticalPerSec * effectiveSec * efficiency);
        if (earned <= 0) {
            data.setLastSeenMs(now);
            return 0;
        }
        data.addBalance(earned);
        data.setLastSeenMs(now);
        long hours = effectiveSec / 3600L;
        long minutes = (effectiveSec % 3600L) / 60L;
        boolean capped = offlineSec > capSec;
        player.sendMessage(ChatUtil.color("&8┌──────────────────────────────"));
        player.sendMessage(ChatUtil.color("&8│ &6💤 Sleep Mode"));
        player.sendMessage(ChatUtil.color("&8│ &7Durée offline : &f"
                + hours + "h" + String.format("%02d", minutes)
                + (capped ? " &c(capé à " + cfg.getSleepCapHours() + "h)" : "")));
        player.sendMessage(ChatUtil.color("&8│ &7Drones (×" + String.format("%.0f", efficiency * 100) + "%) : &a+"
                + NumberFormatUtil.money(earned)));
        player.sendMessage(ChatUtil.color("&8└──────────────────────────────"));
        log(player.getName() + " : crédité +" + earned + "$ (offline).");
        return earned;
    }
    /** Calcule le revenu théorique des drones par seconde (en tenant compte tiers, modules, talents). */
    private double computeDroneIncomePerSec(PlayerData data) {
        double total = 0.0;
        double talentMul = plugin.getTalentManager().getDroneIncomeMultiplier(data);
        for (String key : data.getOwnedDrones()) {
            PluginConfig.DroneConfig dc = plugin.getPluginConfig().getDroneConfig(key);
            if (dc == null) continue;
            int[] tiers = data.getDroneUpgrades(key);
            double incomeMult = 1.0 + tiers[2] * plugin.getPluginConfig().getDroneIncomeTierBonus();
            double perCycle = dc.income() * incomeMult * talentMul;
            int interval = Math.max(1, dc.intervalSec());
            total += perCycle / interval;
        }
        return total;
    }
}