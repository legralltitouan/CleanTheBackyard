package fr.cleanthebackyard.cleanTheBackyard.ui.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class HouseExitGui {

    private static final String TITLE = ChatUtil.color("&8[&6Maison&8] &7Que faire ?");
    private final CleanTheBackyard plugin;

    public HouseExitGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.HOUSE_EXIT);
        Inventory inv = Bukkit.createInventory(holder, 27, TITLE);
        holder.setInventory(inv);
        build(inv);
        player.openInventory(inv);
    }

    private void build(Inventory inv) {
        ItemStack glass = new ItemBuilder(Material.ORANGE_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        inv.setItem(11, new ItemBuilder(Material.CHEST)
                .name("&6🛋 Magasin de meubles")
                .lore(List.of(
                        ChatUtil.color("&7Achète des meubles pour décorer ta maison."),
                        " ",
                        ChatUtil.color("&aClic pour ouvrir")
                ))
                .build());

        inv.setItem(13, new ItemBuilder(Material.ENDER_CHEST)
                .name("&b📦 Mes meubles")
                .lore(List.of(
                        ChatUtil.color("&7Consulte ton stock et récupère un"),
                        ChatUtil.color("&7exemplaire en main pour le poser."),
                        " ",
                        ChatUtil.color("&aClic pour ouvrir")
                ))
                .build());

        inv.setItem(15, new ItemBuilder(Material.IRON_DOOR)
                .name("&c🚪 Quitter la maison")
                .lore(List.of(
                        ChatUtil.color("&7Retourne dans ton jardin."),
                        " ",
                        ChatUtil.color("&aClic pour sortir")
                ))
                .build());
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        int slot = event.getRawSlot();
        switch (slot) {
            case 11 -> {
                player.closeInventory();
                plugin.getGuiManager().openFurnitureShop(player);
            }
            case 13 -> {
                player.closeInventory();
                plugin.getGuiManager().openFurnitureInventory(player);
            }
            case 15 -> {
                player.closeInventory();
                plugin.getHouseManager().exitHouse(player);
            }
        }
        return true;
    }
}
