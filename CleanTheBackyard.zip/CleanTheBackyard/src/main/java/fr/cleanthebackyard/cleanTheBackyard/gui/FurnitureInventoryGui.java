package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * Inventaire des meubles possédés :
 *  ─ Clic sur un meuble du GUI (haut) : récupère un/des exemplaires en main.
 *  ─ Clic sur un meuble du shop dans son propre inventaire (bas) : le restocke.
 */
public class FurnitureInventoryGui {

    private static final String TITLE = ChatUtil.color("&8[&6Mes Meubles&8]");
    private final CleanTheBackyard plugin;
    private final Map<UUID, Map<Integer, String>> slotMap = new HashMap<>();

    public FurnitureInventoryGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.FURNITURE_INVENTORY);
        Inventory inv = Bukkit.createInventory(holder, 36, TITLE);
        holder.setInventory(inv);
        build(inv, player);
        player.openInventory(inv);
    }

    private void build(Inventory inv, Player player) {
        ItemStack glass = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        PlayerData data = plugin.getPlayerDataManager().get(player);
        Map<Integer, String> map = new HashMap<>();
        slotMap.put(player.getUniqueId(), map);

        if (data == null) return;

        int slot = 10;
        boolean hasAny = false;
        for (Map.Entry<String, Integer> e : data.getOwnedFurniture().entrySet()) {
            if (slot >= inv.getSize() - 9) break;
            if (slot % 9 == 8) { slot += 2; continue; }
            if (e.getValue() <= 0) continue;

            PluginConfig.FurnitureShopItem fi = plugin.getPluginConfig().getFurnitureShopItem(e.getKey());
            if (fi == null) continue;

            ItemStack icon = new ItemBuilder(fi.iconMaterial())
                    .name("&6" + fi.name())
                    .lore(List.of(
                            ChatUtil.color("&7En stock : &f" + e.getValue()),
                            " ",
                            ChatUtil.color("&eClic gauche : récupérer 1"),
                            ChatUtil.color("&eShift + clic : récupérer 5")
                    ))
                    .build();
            inv.setItem(slot, icon);
            map.put(slot, e.getKey());
            slot++;
            hasAny = true;
        }

        if (!hasAny) {
            inv.setItem(22, new ItemBuilder(Material.BARRIER)
                    .name("&cAucun meuble en stock")
                    .lore(List.of(ChatUtil.color("&7Achète des meubles au magasin.")))
                    .build());
        }

        // Bouton retour
        inv.setItem(inv.getSize() - 9, new ItemBuilder(Material.ARROW)
                .name("&7← Retour").build());

        // Indication restock
        inv.setItem(inv.getSize() - 1, new ItemBuilder(Material.HOPPER)
                .name("&aRestocker un meuble")
                .lore(List.of(
                        ChatUtil.color("&7Clique sur un meuble dans &fton inventaire"),
                        ChatUtil.color("&7(en bas) pour le remettre en stock.")
                ))
                .build());
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        int rawSlot = event.getRawSlot();
        Inventory top = event.getView().getTopInventory();
        int topSize = top.getSize();

        // ── Clic dans l'inventaire du joueur (partie basse) → tentative de restock ──
        if (rawSlot >= topSize) {
            return handleRestock(player, event);
        }

        // ── Bouton retour ──
        if (rawSlot == topSize - 9) {
            player.closeInventory();
            plugin.getGuiManager().openHouseExit(player);
            return true;
        }

        // ── Récupération d'un meuble depuis le stock ──
        Map<Integer, String> map = slotMap.get(player.getUniqueId());
        if (map == null) return true;
        String key = map.get(rawSlot);
        if (key == null) return true;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        int qty = event.isShiftClick() ? 5 : 1;
        int available = data.getFurnitureCount(key);
        if (available < qty) qty = available;
        if (qty <= 0) {
            player.sendMessage(ChatUtil.color("&cStock vide pour ce meuble."));
            return true;
        }

        PluginConfig.FurnitureShopItem fi = plugin.getPluginConfig().getFurnitureShopItem(key);
        if (fi == null) return true;

        ItemStack base = plugin.getFurnitureProvider().getItemStack(fi.furnitureId());
        if (base == null) {
            player.sendMessage(ChatUtil.color("&cMeuble ItemsAdder introuvable : " + fi.furnitureId()));
            return true;
        }

        int given = 0;
        for (int i = 0; i < qty; i++) {
            ItemStack stack = base.clone();
            stack.setAmount(1);
            stack = plugin.getFurnitureShopManager().tagFurnitureItem(stack, fi.key());
            var leftover = player.getInventory().addItem(stack);
            if (!leftover.isEmpty()) {
                leftover.values().forEach(it -> player.getWorld().dropItemNaturally(player.getLocation(), it));
            }
            given++;
        }
        data.removeFurniture(key, given);

        player.sendMessage(ChatUtil.color("&aTu as récupéré &f" + given + "x " + fi.name() + " &aen main !"));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ITEM_PICKUP, 0.7f, 1.2f);
        build(top, player);
        return true;
    }

    /**
     * Restock : si le joueur clique sur un meuble du shop dans son propre inventaire,
     * on l'ajoute à son stock et on retire l'item.
     */
    private boolean handleRestock(Player player, InventoryClickEvent event) {
        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) return true;

        String shopKey = plugin.getFurnitureShopManager().getShopKey(clicked);
        if (shopKey == null) {
            // Item non-meuble : on n'autorise pas son déplacement dans la GUI
            return true;
        }

        PluginConfig.FurnitureShopItem fi = plugin.getPluginConfig().getFurnitureShopItem(shopKey);
        if (fi == null) return true;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        int qty = event.isShiftClick() ? clicked.getAmount() : 1;
        qty = Math.min(qty, clicked.getAmount());
        if (qty <= 0) return true;

        // Ajoute au stock
        data.addFurniture(shopKey, qty);

        // Retire de l'inventaire
        int remaining = clicked.getAmount() - qty;
        if (remaining <= 0) {
            event.setCurrentItem(null);
        } else {
            clicked.setAmount(remaining);
        }

        player.sendMessage(ChatUtil.color("&aRemis en stock : &f" + qty + "x " + fi.name()));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ITEM_PICKUP, 0.7f, 0.9f);
        build(event.getView().getTopInventory(), player);
        return true;
    }

    public void forceClear(Player player) {
        slotMap.remove(player.getUniqueId());
    }
}
