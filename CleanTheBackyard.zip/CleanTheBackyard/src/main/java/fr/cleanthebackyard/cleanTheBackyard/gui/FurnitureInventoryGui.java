package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/**
 * Inventaire des meubles possédés : permet de "sortir" un meuble en main
 * pour le poser dans la maison.
 */
public class FurnitureInventoryGui {

    private static final String TITLE = ChatUtil.color("&8[&6Mes Meubles&8]");
    private final CleanTheBackyard plugin;
    private final Map<UUID, Map<Integer, String>> slotMap = new HashMap<>();

    public FurnitureInventoryGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.FURNITURE_INVENTORY);
        Inventory inv = Bukkit.createInventory(holder, 36, TITLE);
        holder.setInventory(inv);
        build(inv, player);
        player.openInventory(inv);
    }

    private void build(Inventory inv, Player player) {
        ItemStack glass = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        PlayerData data = plugin.getPlayerDataManager().get(player);
        Map<Integer, String> map = new HashMap<>();
        slotMap.put(player.getUniqueId(), map);

        if (data == null) return;

        int slot = 10;
        boolean hasAny = false;
        for (Map.Entry<String, Integer> e : data.getOwnedFurniture().entrySet()) {
            if (slot >= inv.getSize() - 9) break;
            if (slot % 9 == 8) { slot += 2; continue; }
            if (e.getValue() <= 0) continue;

            PluginConfig.FurnitureShopItem fi = plugin.getPluginConfig().getFurnitureShopItem(e.getKey());
            if (fi == null) continue;

            ItemStack icon = new ItemBuilder(fi.iconMaterial())
                    .name("&6" + fi.name())
                    .lore(List.of(
                            ChatUtil.color("&7En stock : &f" + e.getValue()),
                            " ",
                            ChatUtil.color("&eClic gauche : récupérer 1"),
                            ChatUtil.color("&eShift + clic : récupérer 5")
                    ))
                    .build();
            inv.setItem(slot, icon);
            map.put(slot, e.getKey());
            slot++;
            hasAny = true;
        }

        if (!hasAny) {
            inv.setItem(22, new ItemBuilder(Material.BARRIER)
                    .name("&cAucun meuble en stock")
                    .lore(List.of(ChatUtil.color("&7Achète des meubles au magasin.")))
                    .build());
        }

        // Bouton retour
        inv.setItem(inv.getSize() - 9, new ItemBuilder(Material.ARROW)
                .name("&7← Retour").build());
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        int slot = event.getRawSlot();
        Inventory inv = event.getInventory();

        if (slot == inv.getSize() - 9) {
            player.closeInventory();
            plugin.getGuiManager().openHouseExit(player);
            return true;
        }

        Map<Integer, String> map = slotMap.get(player.getUniqueId());
        if (map == null) return true;
        String key = map.get(slot);
        if (key == null) return true;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        int qty = event.isShiftClick() ? 5 : 1;
        int available = data.getFurnitureCount(key);
        if (available < qty) qty = available;
        if (qty <= 0) {
            player.sendMessage(ChatUtil.color("&cStock vide pour ce meuble."));
            return true;
        }

        PluginConfig.FurnitureShopItem fi = plugin.getPluginConfig().getFurnitureShopItem(key);
        if (fi == null) return true;

        ItemStack base = plugin.getFurnitureProvider().getItemStack(fi.furnitureId());
        if (base == null) {
            player.sendMessage(ChatUtil.color("&cMeuble ItemsAdder introuvable : " + fi.furnitureId()));
            return true;
        }

        int given = 0;
        for (int i = 0; i < qty; i++) {
            ItemStack stack = base.clone();
            stack.setAmount(1);
            stack = plugin.getFurnitureShopManager().tagFurnitureItem(stack, fi.key());
            var leftover = player.getInventory().addItem(stack);
            if (!leftover.isEmpty()) {
                // Plus de place : on stoppe pour ne pas perdre les exemplaires restants
                leftover.values().forEach(it -> player.getWorld().dropItemNaturally(player.getLocation(), it));
            }
            given++;
        }
        data.removeFurniture(key, given);

        player.sendMessage(ChatUtil.color("&aTu as récupéré &f" + given + "x " + fi.name() + " &aen main !"));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ITEM_PICKUP, 0.7f, 1.2f);
        build(inv, player);
        return true;
    }

    public void forceClear(Player player) {
        slotMap.remove(player.getUniqueId());
    }
}
