package fr.cleanthebackyard.cleanTheBackyard.ui.gui;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.CollectibleItem;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import java.util.*;
public class CollectionGui {
    private static final String TITLE = ChatUtil.color("&8[&6Tableau de Collection&8]");
    private final CleanTheBackyard plugin;
    public CollectionGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.COLLECTION);
        Collection<CollectibleItem> all = plugin.gameplay().collectible().getAll();
        int size = Math.max(27, ((all.size() / 9) + 2) * 9);
        if (size > 54) size = 54;
        Inventory inv = Bukkit.createInventory(holder, size, TITLE);
        holder.setInventory(inv);
        build(inv, player);
        player.openInventory(inv);
    }
    private void build(Inventory inv, Player player) {
        ItemStack glass = new ItemBuilder(Material.BLACK_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return;
        Set<String> collected = data.getCollectedItems();
        Collection<CollectibleItem> all = plugin.gameplay().collectible().getAll();
        int slot = 10;
        for (CollectibleItem item : all) {
            if (slot >= inv.getSize() - 9) break;
            // Skip slots de bordure
            if (slot % 9 == 8) { slot += 2; continue; }
            boolean owned = collected.contains(item.getKey());
            List<String> lore = new ArrayList<>();
            lore.add(ChatUtil.color("&7Rareté : " + item.getRarity().getDisplayName()));
            lore.add(ChatUtil.color("&7Valeur : &a" + NumberFormatUtil.money(item.getSellValue())));
            lore.add(" ");
            lore.add(ChatUtil.color(owned ? "&a✔ Possédé" : "&c✘ Non collecté"));
            ItemStack icon = new ItemBuilder(owned ? Material.GOLD_INGOT : Material.GRAY_DYE)
                    .name((owned ? "&a" : "&8") + item.getDisplayName())
                    .lore(lore)
                    .build();
            inv.setItem(slot, icon);
            slot++;
        }
        // Stats
        int total = all.size();
        int owned = collected.size();
        inv.setItem(inv.getSize() - 5, new ItemBuilder(Material.BOOK)
                .name("&6Progression")
                .lore(List.of(
                        ChatUtil.color("&7Collectés : &f" + owned + "/" + total),
                        ChatUtil.color("&7Complétion : &a" + String.format("%.1f%%",
                                total == 0 ? 0 : (owned * 100.0 / total)))
                )).build());
    }
    public boolean handleClick(Player player, InventoryClickEvent event) {
        event.setCancelled(true);
        return true;
    }
}