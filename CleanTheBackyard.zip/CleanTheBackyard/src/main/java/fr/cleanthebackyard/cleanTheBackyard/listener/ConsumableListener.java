package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public class ConsumableListener implements Listener {

    private final CleanTheBackyard plugin;

    public ConsumableListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) return;

        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        NamespacedKey key = new NamespacedKey(plugin, "energy-restore");
        if (!meta.getPersistentDataContainer().has(key, PersistentDataType.INTEGER)) return;

        event.setCancelled(true);

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        int energyRestore = meta.getPersistentDataContainer().get(key, PersistentDataType.INTEGER);
        int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());

        double restored;
        if (energyRestore == -1) {
            restored = maxEnergy - data.getCurrentEnergy();
            data.setCurrentEnergy(maxEnergy);
        } else {
            restored = Math.min(energyRestore, maxEnergy - data.getCurrentEnergy());
            data.addEnergy(energyRestore);
            if (data.getCurrentEnergy() > maxEnergy) data.setCurrentEnergy(maxEnergy);
        }

        plugin.getBoxManager().removeFatigue(player, data);

        // Consomme l'item
        item.setAmount(item.getAmount() - 1);

        player.sendMessage(ChatUtil.colored(
                "&aConsommé ! &f+" + String.format("%.0f", restored) + " &aénergie restorée."
        ));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_GENERIC_EAT, 1.0f, 1.2f);
    }
}