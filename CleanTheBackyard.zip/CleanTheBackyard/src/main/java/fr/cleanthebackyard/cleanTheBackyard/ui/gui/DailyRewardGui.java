package fr.cleanthebackyard.cleanTheBackyard.ui.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import java.util.ArrayList;
import java.util.List;

public class DailyRewardGui {

    private static final String TITLE = ChatUtil.color("&f:offset_-8:∏");
    private final CleanTheBackyard plugin;

    public DailyRewardGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.DAILY_REWARD);
        Inventory inv = Bukkit.createInventory(holder, 27, TITLE);
        holder.setInventory(inv);
        build(inv, player);
        player.openInventory(inv);
    }

    private void build(Inventory inv, Player player) {

        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return;
        int currentDay = plugin.progression().dailyReward().getCurrentDay(data);
        boolean alreadyClaimed = plugin.progression().dailyReward().alreadyClaimedToday(data);

        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        for (int i = 0; i < 7; i++) {
            int day = i + 1;
            PluginConfig.DailyReward reward = plugin.core().config().getDailyReward(day);
            if (reward == null) continue;

            Material icon;
            String prefix;
            if (day < currentDay) { icon = Material.LIME_DYE; prefix = "&a✓ "; }
            else if (day == currentDay && !alreadyClaimed) { icon = Material.GOLD_INGOT; prefix = "&6▶ "; }
            else if (day == currentDay) { icon = Material.LIME_DYE; prefix = "&a✓ "; }
            else { icon = Material.GRAY_DYE; prefix = "&7✦ "; }

            List<String> lore = new ArrayList<>();
            lore.add(ChatUtil.color("&7Récompense :"));
            if (reward.money() > 0) lore.add(ChatUtil.color("  &a+" + NumberFormatUtil.money(reward.money())));
            if (reward.doubleSellSeconds() > 0)
                lore.add(ChatUtil.color("  &ex2 vente pendant " + (reward.doubleSellSeconds() / 60) + "min"));
            lore.add(" ");
            if (day == currentDay && !alreadyClaimed) lore.add(ChatUtil.color("&eClic pour réclamer !"));
            else if (day == currentDay) lore.add(ChatUtil.color("&aDéjà réclamé aujourd'hui."));
            else if (day < currentDay) lore.add(ChatUtil.color("&7Déjà passé."));
            else lore.add(ChatUtil.color("&7Encore " + (day - currentDay) + " jour(s) à patienter."));

            inv.setItem(slots[i], new ItemBuilder(icon)
                    .name(prefix + "&6Jour " + day)
                    .lore(lore).build());
        }

        inv.setItem(22, new ItemBuilder(Material.BOOK)
                .name("&7Streak actuelle : &f" + data.getDailyStreak() + " jour(s)")
                .lore(List.of(
                        ChatUtil.color("&7Reviens chaque jour pour accumuler !"),
                        ChatUtil.color("&cManquer un jour = retour au jour 1.")
                )).build());
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return true;
        int currentDay = plugin.progression().dailyReward().getCurrentDay(data);
        int[] slots = {10, 11, 12, 13, 14, 15, 16};
        int slot = event.getRawSlot();
        for (int i = 0; i < slots.length; i++) {
            if (slots[i] == slot) {
                int day = i + 1;
                if (day == currentDay && !plugin.progression().dailyReward().alreadyClaimedToday(data)) {
                    plugin.progression().dailyReward().claim(player);
                    build(event.getInventory(), player);
                }
                return true;
            }
        }
        return true;
    }
}
