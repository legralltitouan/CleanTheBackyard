package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class FurnitureShopGui {

    private static final String TITLE = ChatUtil.color("&8[&6Magasin de Meubles&8]");
    private final CleanTheBackyard plugin;
    private final Map<UUID, Map<Integer, String>> slotMap = new HashMap<>();

    public FurnitureShopGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.FURNITURE_SHOP);
        List<PluginConfig.FurnitureShopItem> items = plugin.getPluginConfig().getFurnitureShopItems();
        int rows = Math.max(3, Math.min(6, ((items.size() - 1) / 7) + 3));
        int size = rows * 9;
        Inventory inv = Bukkit.createInventory(holder, size, TITLE);
        holder.setInventory(inv);
        build(inv, player);
        player.openInventory(inv);
    }

    private void build(Inventory inv, Player player) {
        ItemStack glass = new ItemBuilder(Material.YELLOW_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        PlayerData data = plugin.getPlayerDataManager().get(player);
        Map<Integer, String> map = new HashMap<>();
        slotMap.put(player.getUniqueId(), map);

        List<PluginConfig.FurnitureShopItem> items = plugin.getPluginConfig().getFurnitureShopItems();
        int[] slots = computeSlots(inv.getSize(), items.size());
        for (int i = 0; i < items.size() && i < slots.length; i++) {
            PluginConfig.FurnitureShopItem item = items.get(i);
            int owned = data != null ? data.getFurnitureCount(item.key()) : 0;
            List<String> lore = new ArrayList<>();
            lore.add(ChatUtil.color("&7Prix : &a" + NumberFormatUtil.money(item.cost())));
            lore.add(ChatUtil.color("&7En stock : &f" + owned));
            lore.add(" ");
            lore.add(ChatUtil.color("&eClic gauche : acheter 1"));
            lore.add(ChatUtil.color("&eClic droit : acheter 10"));

            ItemStack icon = new ItemBuilder(item.iconMaterial())
                    .name("&6" + item.name())
                    .lore(lore)
                    .build();
            inv.setItem(slots[i], icon);
            map.put(slots[i], item.key());
        }

        if (data != null) {
            inv.setItem(inv.getSize() - 5, new ItemBuilder(Material.GOLD_INGOT)
                    .name("&aSolde : &f" + NumberFormatUtil.money(data.getBalance())).build());
        }
        inv.setItem(inv.getSize() - 9, new ItemBuilder(Material.ARROW)
                .name("&7← Retour").build());
    }

    private int[] computeSlots(int invSize, int itemCount) {
        List<Integer> usable = new ArrayList<>();
        int rows = invSize / 9;
        for (int row = 1; row < rows - 1; row++) {
            for (int col = 1; col <= 7; col++) {
                usable.add(row * 9 + col);
            }
        }
        int[] arr = new int[Math.min(itemCount, usable.size())];
        for (int i = 0; i < arr.length; i++) arr[i] = usable.get(i);
        return arr;
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        int slot = event.getRawSlot();
        Inventory inv = event.getInventory();

        if (slot == inv.getSize() - 9) {
            player.closeInventory();
            plugin.getGuiManager().openHouseExit(player);
            return true;
        }

        Map<Integer, String> map = slotMap.get(player.getUniqueId());
        if (map == null) return true;
        String key = map.get(slot);
        if (key == null) return true;

        PluginConfig.FurnitureShopItem item = plugin.getPluginConfig().getFurnitureShopItem(key);
        if (item == null) return true;

        int qty = event.isRightClick() ? 10 : 1;
        long totalCost = item.cost() * qty;
        if (!plugin.getEconomyManager().debit(player, totalCost, item.name() + " x" + qty)) return true;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data != null) {
            data.addFurniture(key, qty);
            player.sendMessage(ChatUtil.color("&a+" + qty + " &f" + item.name()
                    + " &aajouté(s) à ton stock."));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ITEM_PICKUP, 0.7f, 1.2f);
        }
        build(inv, player);
        return true;
    }

    public void forceClear(Player player) {
        slotMap.remove(player.getUniqueId());
    }
}
