package fr.cleanthebackyard.cleanTheBackyard.service;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil.inRadius;

/**
 * Détecte la zone du joueur via un tick périodique (toutes les 5 ticks = 4Hz)
 * au lieu d'un check sur chaque PlayerMoveEvent (coûteux).
 * Cache la dernière zone pour ne déclencher qu'à la transition.
 */
public class ZoneService {
    public enum Zone { NONE, GARAGE, VENDING_MACHINE, DRONE_SHOP, SELL_ZONE, QUEST_BOARD, PRESTIGE_ALTAR, STASH }
    private final CleanTheBackyard plugin;
    private final Map<UUID, Zone> currentZone = new HashMap<>();
    private BukkitRunnable task;
    public ZoneService(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public void start() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                tick();
            }
        };
        task.runTaskTimer(plugin, 10L, 5L);
    }
    public void stop() {
        if (task != null && !task.isCancelled()) task.cancel();
        currentZone.clear();
    }
    public void forget(UUID uuid) {
        currentZone.remove(uuid);
    }
    private void tick() {
        String hubName = plugin.getPluginConfig().getHubWorldName();
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        for (Player p : plugin.getServer().getOnlinePlayers()) {
            World w = p.getWorld();
            if (w == null || w.getName().equals(hubName) || !w.getName().startsWith(prefix)) {
                if (currentZone.remove(p.getUniqueId()) != null) {
                    // joueur a quitté une zone en sortant du monde
                }
                continue;
            }
            Zone newZone = detectZone(p.getLocation());
            Zone oldZone = currentZone.get(p.getUniqueId());
            if (newZone == oldZone) continue;
            // Si on est dans un GUI ouvert, on ne re-déclenche pas sauf pour SELL_ZONE
            if (newZone != Zone.SELL_ZONE && plugin.getGuiManager().hasOpenGui(p)) continue;
            if (newZone == Zone.NONE) {
                currentZone.remove(p.getUniqueId());
                continue;
            }
            currentZone.put(p.getUniqueId(), newZone);
            triggerZoneAction(p, newZone);
        }
    }
    private void triggerZoneAction(Player p, Zone zone) {
        switch (zone) {
            case GARAGE -> plugin.getGuiManager().openUpgradeGui(p);
            case VENDING_MACHINE -> plugin.getGuiManager().openVendingMachine(p);
            case DRONE_SHOP -> plugin.getGuiManager().openDroneShop(p);
            case SELL_ZONE -> plugin.getEconomyManager().sellBag(p);
            case QUEST_BOARD -> plugin.getGuiManager().openQuestGui(p);
            case PRESTIGE_ALTAR -> plugin.getGuiManager().openPrestigeGui(p);
            case STASH -> plugin.getGuiManager().openSecurityGui(p);
            default -> {}
        }
    }
    private Zone detectZone(Location loc) {
        PluginConfig cfg = plugin.getPluginConfig();
        World world = loc.getWorld();
        if (world == null) return Zone.NONE;
        if (inRadius(loc, cfg.getGarageLocation(world), cfg.getGarageRadius())) return Zone.GARAGE;
        if (inRadius(loc, cfg.getVendingMachineLocation(world), cfg.getVendingMachineRadius())) return Zone.VENDING_MACHINE;
        if (inRadius(loc, cfg.getDroneShopLocation(world), cfg.getDroneShopRadius())) return Zone.DRONE_SHOP;
        if (inRadius(loc, cfg.getSellZoneCenter(world), cfg.getSellZoneRadius())) return Zone.SELL_ZONE;
        if (inRadius(loc, cfg.getQuestBoardLocation(world), cfg.getQuestBoardRadius())) return Zone.QUEST_BOARD;
        if (inRadius(loc, cfg.getPrestigeAltarLocation(world), cfg.getPrestigeAltarRadius())) return Zone.PRESTIGE_ALTAR;
        if (inRadius(loc, cfg.getStashLocation(world), cfg.getStashRadius())) return Zone.STASH;
        return Zone.NONE;
    }
}