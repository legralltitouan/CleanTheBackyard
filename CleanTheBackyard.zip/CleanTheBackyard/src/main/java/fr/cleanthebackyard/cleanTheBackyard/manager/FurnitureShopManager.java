package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * Gère le tagging des items de meubles pour les distinguer des items vanilla
 * et autoriser leur pose dans la maison.
 */
public class FurnitureShopManager {

    private final CleanTheBackyard plugin;
    private final NamespacedKey furnitureKey;

    public FurnitureShopManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.furnitureKey = new NamespacedKey(plugin, "shop-furniture-key");
    }

    public ItemStack tagFurnitureItem(ItemStack stack, String furnitureShopKey) {
        if (stack == null) return null;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;
        meta.getPersistentDataContainer().set(furnitureKey, PersistentDataType.STRING, furnitureShopKey);
        stack.setItemMeta(meta);
        return stack;
    }

    public String getShopKey(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) return null;
        return stack.getItemMeta().getPersistentDataContainer()
                .get(furnitureKey, PersistentDataType.STRING);
    }

    public boolean isShopFurniture(ItemStack stack) {
        return getShopKey(stack) != null;
    }
}
