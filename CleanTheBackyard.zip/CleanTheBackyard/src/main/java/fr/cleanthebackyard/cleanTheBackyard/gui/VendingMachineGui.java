package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class VendingMachineGui {

    private static final String TITLE = ChatUtil.color("&8[&bDistributeur&8] &7Recharges Énergie");
    private final CleanTheBackyard plugin;

    public VendingMachineGui(CleanTheBackyard plugin) { this.plugin = plugin; }

    public void open(Player player) {
        List<PluginConfig.VendingItem> items = plugin.getPluginConfig().getVendingItems();
        int size = 9 * (int) Math.ceil(Math.max(1, items.size()) / 9.0 + 1);
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.VENDING_MACHINE);
        Inventory inv = Bukkit.createInventory(holder, Math.min(size, 27), TITLE);
        holder.setInventory(inv);
        buildGui(inv, player);
        player.openInventory(inv);
    }

    private void buildGui(Inventory inv, Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        ItemStack glass = new ItemBuilder(Material.CYAN_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        List<PluginConfig.VendingItem> items = plugin.getPluginConfig().getVendingItems();
        int slot = 2;
        for (PluginConfig.VendingItem vi : items) {
            String restoreStr = (vi.energyRestore() == -1) ? "Maximum" : "+" + vi.energyRestore();
            int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data != null ? data.getEnergyLevel() : 1);
            double currentEnergy = data != null ? data.getCurrentEnergy() : 0;

            ItemStack item = new ItemBuilder(getMaterialForVending(vi.key()))
                    .name("&b" + vi.name())
                    .lore(List.of(
                            ChatUtil.color("&7Énergie restaurée : &a" + restoreStr),
                            ChatUtil.color("&7Votre énergie : &f" + String.format("%.0f", currentEnergy) + "/" + maxEnergy),
                            " ",
                            ChatUtil.color("&ePrix : &f" + NumberFormatUtil.money(vi.cost())),
                            ChatUtil.color("&aCliquez pour acheter !")
                    ))
                    .build();
            inv.setItem(slot, item);
            slot += 2;
        }

        if (data != null) {
            inv.setItem(inv.getSize() - 5, new ItemBuilder(Material.GOLD_INGOT)
                    .name("&aSolde : &f" + NumberFormatUtil.money(data.getBalance())).build());
        }
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        List<PluginConfig.VendingItem> items = plugin.getPluginConfig().getVendingItems();
        int slot = event.getRawSlot();
        List<Integer> itemSlots = new ArrayList<>();
        int s = 2;
        for (int i = 0; i < items.size(); i++) { itemSlots.add(s); s += 2; }

        int idx = itemSlots.indexOf(slot);
        if (idx < 0 || idx >= items.size()) return true;

        PluginConfig.VendingItem vi = items.get(idx);
        if (!plugin.getEconomyManager().debit(player, vi.cost(), vi.name())) return true;

        ItemStack consumable = createConsumableItem(vi);
        HashMap<Integer, ItemStack> leftover = player.getInventory().addItem(consumable);
        if (!leftover.isEmpty()) {
            leftover.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
            player.sendMessage(ChatUtil.colored("&eInventaire plein ! L'item est tombé à vos pieds."));
        }

        plugin.getQuestManager().onProgress(player, DailyQuest.Type.BUY_VENDING, 1);

        player.sendMessage(ChatUtil.colored("&aAchat réussi ! &f" + vi.name() + " &a-> clic droit pour consommer."));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_GENERIC_EAT, 1.0f, 1.2f);
        buildGui(event.getInventory(), player);
        return true;
    }

    private ItemStack createConsumableItem(PluginConfig.VendingItem vi) {
        String restoreStr = (vi.energyRestore() == -1) ? "Maximum" : "+" + vi.energyRestore();
        ItemStack item = new ItemBuilder(getMaterialForVending(vi.key()))
                .name("&b" + vi.name())
                .lore(List.of(
                        ChatUtil.color("&7Énergie restaurée : &a" + restoreStr),
                        " ",
                        ChatUtil.color("&eClic droit pour consommer !")
                ))
                .build();
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            NamespacedKey key = new NamespacedKey(plugin, "energy-restore");
            meta.getPersistentDataContainer().set(key, PersistentDataType.INTEGER, vi.energyRestore());
            item.setItemMeta(meta);
        }
        return item;
    }

    private Material getMaterialForVending(String key) {
        return switch (key) {
            case "soda" -> Material.POTION;
            case "chocolate" -> Material.COOKIE;
            case "energy-drink" -> Material.HONEY_BOTTLE;
            case "coffee" -> Material.BREWING_STAND;
            case "energy-bar" -> Material.GOLDEN_APPLE;
            default -> Material.SUGAR;
        };
    }
}
