package fr.cleanthebackyard.cleanTheBackyard.world.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.BoundingBox;

/**
 * Affiche un TextDisplay à la frontière de la zone de cartons débloquée
 * par le joueur, l'invitant à l'agrandir au garage.
 *
 * Un seul display par monde joueur, repositionné selon le niveau de zone.
 */
public class ZoneBorderManager {

    private final CleanTheBackyard plugin;
    private final NamespacedKey borderKey;

    public ZoneBorderManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.borderKey = new NamespacedKey(plugin, "zone-border");
    }

    /** Rafraîchit (crée/déplace) le display de frontière pour le monde du joueur. */
    public void refresh(Player player) {
        if (!plugin.getPluginConfig().isZoneBorderDisplayEnabled()) return;
        if (player == null || !player.isOnline()) return;

        World world = player.getWorld();
        if (world == null) return;

        String expected = plugin.getPluginConfig().getPlayerWorldName(player.getUniqueId());
        if (!world.getName().equals(expected)) return; // uniquement dans le monde de jeu du joueur

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        // Nettoie les anciens displays de frontière du monde.
        removeExisting(world);

        BoundingBox region = plugin.getPluginConfig().getBoxRainRegion(data.getCardboardZoneLevel());
        String axis = plugin.getPluginConfig().getCardboardZoneAxis();
        double y = plugin.getPluginConfig().getZoneBorderDisplayY();

        boolean maxed = data.getCardboardZoneLevel()
                >= plugin.getPluginConfig().getMaxCardboardZoneLevel();
        String text = maxed
                ? plugin.getPluginConfig().getZoneBorderTextMax()
                : plugin.getPluginConfig().getZoneBorderText();

        double centerX;
        double centerZ;
        if ("X".equalsIgnoreCase(axis)) {
            centerX = region.getMaxX() + 1.0;
            centerZ = (region.getMinZ() + region.getMaxZ()) / 2.0;
        } else { // Z par défaut
            centerX = (region.getMinX() + region.getMaxX()) / 2.0;
            centerZ = region.getMaxZ() + 1.0;
        }

        Location loc = new Location(world, centerX + 0.5, y, centerZ + 0.5);
        spawnDisplay(world, loc, text);
    }

    private void spawnDisplay(World world, Location loc, String text) {
        TextDisplay td = world.spawn(loc, TextDisplay.class);
        td.setBillboard(Display.Billboard.CENTER);
        td.setSeeThrough(true);
        td.setShadowed(true);
        td.setDefaultBackground(false);
        td.setPersistent(false);
        td.setText(ChatUtil.color(text));
        td.getPersistentDataContainer().set(borderKey, PersistentDataType.BYTE, (byte) 1);
    }

    /** Supprime tous les displays de frontière présents dans le monde. */
    public void removeExisting(World world) {
        if (world == null) return;
        for (Entity e : world.getEntities()) {
            if (e instanceof TextDisplay td
                    && td.getPersistentDataContainer().has(borderKey, PersistentDataType.BYTE)) {
                td.remove();
            }
        }
    }

    /** Nettoie le display du monde du joueur (ex : à la déconnexion / changement de monde). */
    public void clearForPlayerWorld(Player player) {
        if (player == null) return;
        World w = player.getWorld();
        String expected = plugin.getPluginConfig().getPlayerWorldName(player.getUniqueId());
        if (w != null && w.getName().equals(expected)) {
            removeExisting(w);
        }
    }
}
