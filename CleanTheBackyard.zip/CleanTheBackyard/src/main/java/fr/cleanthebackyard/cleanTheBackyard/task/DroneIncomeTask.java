package fr.cleanthebackyard.cleanTheBackyard.task;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.manager.DroneManager;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Tâche responsable de l'application des revenus passifs des drones.
 */
public class DroneIncomeTask extends BukkitRunnable {

    private final CleanTheBackyard plugin;
    private final DroneManager droneManager;

    public DroneIncomeTask(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.droneManager = plugin.getDroneManager();
    }

    @Override
    public void run() {
        droneManager.applyDroneIncome(); // Applique les revenus de tous les drones
    }
}
