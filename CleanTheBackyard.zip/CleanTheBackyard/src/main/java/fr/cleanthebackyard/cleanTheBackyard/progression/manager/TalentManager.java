package fr.cleanthebackyard.cleanTheBackyard.progression.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;
/**
 * Calcule les bonus issus de l'arbre de talents.
 * Clés de talents reconnues : botany, mechanics, charisma, economy, endurance, fortune.
 */
public class TalentManager {
    public static final String KEY_BOTANY    = "botany";
    public static final String KEY_MECHANICS = "mechanics";
    public static final String KEY_CHARISMA  = "charisma";
    public static final String KEY_ECONOMY   = "economy";
    public static final String KEY_ENDURANCE = "endurance";
    public static final String KEY_FORTUNE   = "fortune";
    private final CleanTheBackyard plugin;
    public TalentManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public double getBonus(PlayerData data, String talentKey) {
        if (data == null) return 0.0;
        PluginConfig.TalentDef def = plugin.core().config().getTalent(talentKey);
        if (def == null) return 0.0;
        return data.getTalentTier(talentKey) * def.bonusPerTier();
    }
    /** Multiplicateur de gains de vente (somme du global + économie talent). */
    public double getSellMultiplier(PlayerData data) {
        return 1.0 + getBonus(data, KEY_ECONOMY);
    }
    /** Bonus de revenus drones. */
    public double getDroneIncomeMultiplier(PlayerData data) {
        return 1.0 + getBonus(data, KEY_MECHANICS);
    }
    /** Chance bonus de casser un carton supplémentaire / drop. */
    public double getBotanyBonus(PlayerData data) { return getBonus(data, KEY_BOTANY); }
    /** Multiplicateur de drop collectible additionnel. */
    public double getFortuneBonus(PlayerData data) { return getBonus(data, KEY_FORTUNE); }
    /** Multiplicateur de fréquence de spawn des rats (capé à 0.3 = 70% de réduction). */
    public double getRatFrequencyMultiplier(PlayerData data) {
        return Math.max(0.30, 1.0 - getBonus(data, KEY_CHARISMA));
    }
    /** Multiplicateur d'énergie max. */
    public double getEnergyMaxMultiplier(PlayerData data) {
        return 1.0 + getBonus(data, KEY_ENDURANCE);
    }
    public boolean spendPoint(Player player, String talentKey) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        PluginConfig.TalentDef def = plugin.core().config().getTalent(talentKey);
        if (def == null) {
            player.sendMessage(ChatUtil.color("&cTalent inconnu : " + talentKey));
            return false;
        }
        if (data.getTalentPoints() <= 0) {
            player.sendMessage(ChatUtil.color("&cAucun point de talent disponible."));
            return false;
        }
        int current = data.getTalentTier(talentKey);
        if (current >= def.maxTier()) {
            player.sendMessage(ChatUtil.color("&cTalent au maximum (" + def.maxTier() + ")."));
            return false;
        }
        data.setTalentTier(talentKey, current + 1);
        data.addTalentPoints(-1);
        player.sendMessage(ChatUtil.color("&a✦ &f" + def.name() + " &a-> niveau &f" + (current + 1) + "&a !"));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.4f);
        return true;
    }
    /** Reset complet des talents : restitue tous les points. */
    public void resetAndRefund(PlayerData data) {
        int total = data.getAllTalentTiers().values().stream().mapToInt(Integer::intValue).sum();
        data.resetTalents();
        data.addTalentPoints(total);
    }
}