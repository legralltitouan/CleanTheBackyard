package fr.cleanthebackyard.cleanTheBackyard.command;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.mvplugins.multiverse.core.MultiverseCoreApi;
import org.mvplugins.multiverse.core.world.MultiverseWorld;
import org.mvplugins.multiverse.core.world.WorldManager;
import org.mvplugins.multiverse.core.world.options.CloneWorldOptions;
import java.io.File;
import java.util.UUID;
public class PlayCommand implements CommandExecutor {
    private final CleanTheBackyard plugin;
    public PlayCommand(CleanTheBackyard plugin) {
        this.plugin = plugin;
        if (Bukkit.getPluginManager().getPlugin("Multiverse-Core") == null) {
            plugin.getLogger().severe("[CTB] Multiverse-Core introuvable !");
        }
    }
    private WorldManager getWorldManager() {
        try { return MultiverseCoreApi.get().getWorldManager(); }
        catch (Throwable t) {
            plugin.getLogger().severe("[CTB] MultiverseCoreApi inaccessible : " + t.getMessage());
            return null;
        }
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatUtil.color("&cCommande joueur uniquement."));
            return true;
        }
        String name = label.toLowerCase();
        String sub;
        if (name.equals("ctbplay")) {
            if (args.length == 0) { sendHelp(player); return true; }
            sub = args[0].toLowerCase();
        } else {
            sub = name;
        }
        switch (sub) {
            case "create" -> handleCreate(player);
            case "go" -> handleGo(player);
            case "spawn" -> handleSpawn(player);
            case "setspawn" -> handleSetSpawn(player);
            case "setplayerspawn" -> handleSetPlayerSpawn(player);
            default -> sendHelp(player);
        }
        return true;
    }
    private void sendHelp(Player player) {
        player.sendMessage(ChatUtil.color("&8══ &aClean The Backyard &8══"));
        player.sendMessage(ChatUtil.color("&e/create &7- Créer ton monde personnel"));
        player.sendMessage(ChatUtil.color("&e/go &7- Aller dans ton monde personnel"));
        player.sendMessage(ChatUtil.color("&e/spawn &7- Retourner au hub"));
        if (player.hasPermission("ctb.admin.setspawn")) {
            player.sendMessage(ChatUtil.color("&e/setspawn &7- Définir le spawn du hub (admin)"));
            player.sendMessage(ChatUtil.color("&e/setplayerspawn &7- Définir le spawn dans le monde joueur (admin)"));
        }
        player.sendMessage(ChatUtil.color("&8══════════════════"));
    }
    private void handleCreate(Player player) {
        WorldManager wm = getWorldManager();
        if (wm == null) { player.sendMessage(ChatUtil.color("&cMultiverse inaccessible.")); return; }
        UUID uuid = player.getUniqueId();
        String worldName = plugin.getPluginConfig().getPlayerWorldName(uuid);
        if (Bukkit.getWorld(worldName) != null || worldFolderExists(worldName)) {
            player.sendMessage(ChatUtil.color("&eTon monde existe déjà. Utilise &f/go&e."));
            return;
        }
        String templateName = plugin.getPluginConfig().getTemplateWorldName();
        MultiverseWorld template = wm.getWorld(templateName).getOrNull();
        if (template == null) {
            player.sendMessage(ChatUtil.color("&cTemplate &f" + templateName + " &cnon chargé."));
            return;
        }
        player.sendMessage(ChatUtil.color("&aCréation du monde depuis le template..."));
        var result = wm.cloneWorld(CloneWorldOptions.fromTo(template, worldName));
        if (!result.isSuccess()) {
            player.sendMessage(ChatUtil.color("&cClonage échoué. Voir la console."));
            plugin.getLogger().warning("[CTB] cloneWorld failed: " + result);
            return;
        }
        World newWorld = Bukkit.getWorld(worldName);
        if (newWorld == null) {
            player.sendMessage(ChatUtil.color("&cMonde cloné mais introuvable. Redémarre si besoin."));
            return;
        }
        Location spawn = plugin.getPluginConfig().getPlayerWorldSpawn(newWorld);
        player.teleport(spawn != null ? spawn : newWorld.getSpawnLocation());
        player.sendMessage(ChatUtil.color("&aTon monde &f" + worldName + " &aest prêt !"));
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> plugin.getDroneManager().respawnPlayerDrones(player), 20L);
    }
    private void handleGo(Player player) {
        UUID uuid = player.getUniqueId();
        String worldName = plugin.getPluginConfig().getPlayerWorldName(uuid);
        World w = Bukkit.getWorld(worldName);
        if (w == null) {
            WorldManager wm = getWorldManager();
            if (wm != null && worldFolderExists(worldName)) {
                wm.loadWorld(worldName);
                w = Bukkit.getWorld(worldName);
            }
        }
        if (w == null) {
            player.sendMessage(ChatUtil.color("&cTon monde n'existe pas. Utilise &f/create&c."));
            return;
        }
        Location spawn = plugin.getPluginConfig().getPlayerWorldSpawn(w);
        player.teleport(spawn != null ? spawn : w.getSpawnLocation());
        player.sendMessage(ChatUtil.color("&aTéléporté dans &f" + w.getName() + "&a."));
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> plugin.getDroneManager().respawnPlayerDrones(player), 10L);
    }
    private void handleSpawn(Player player) {
        Location spawn = plugin.getPluginConfig().getHubSpawnLocation();
        if (spawn == null || spawn.getWorld() == null) {
            player.sendMessage(ChatUtil.color("&cSpawn du hub introuvable."));
            return;
        }
        plugin.getDroneManager().despawnPlayerDrones(player);
        player.teleport(spawn);
        player.sendMessage(ChatUtil.color("&aRetour au hub."));
    }
    private void handleSetSpawn(Player player) {
        if (!player.hasPermission("ctb.admin.setspawn")) {
            player.sendMessage(ChatUtil.color("&cPermission manquante (ctb.admin.setspawn)."));
            return;
        }
        World hub = plugin.getPluginConfig().getHubWorld();
        if (hub == null || !player.getWorld().equals(hub)) {
            player.sendMessage(ChatUtil.color("&cTu dois être dans le monde hub (&f"
                    + plugin.getPluginConfig().getHubWorldName() + "&c) pour définir le spawn."));
            return;
        }
        plugin.getPluginConfig().setHubSpawn(player.getLocation());
        player.sendMessage(ChatUtil.color("&aSpawn du hub défini sur ta position."));
    }
    private void handleSetPlayerSpawn(Player player) {
        if (!player.hasPermission("ctb.admin.setspawn")) {
            player.sendMessage(ChatUtil.color("&cPermission manquante (ctb.admin.setspawn)."));
            return;
        }
        String templateName = plugin.getPluginConfig().getTemplateWorldName();
        if (!player.getWorld().getName().equals(templateName)) {
            player.sendMessage(ChatUtil.color("&cTu dois être dans le monde template (&f"
                    + templateName + "&c) pour définir le spawn joueur."));
            return;
        }
        plugin.getPluginConfig().setPlayerWorldSpawn(player.getLocation());
        player.sendMessage(ChatUtil.color("&aSpawn des mondes joueurs défini sur ta position."));
    }
    private boolean worldFolderExists(String worldName) {
        File worldFolder = new File(Bukkit.getWorldContainer(), worldName);
        return worldFolder.exists() && worldFolder.isDirectory();
    }
}