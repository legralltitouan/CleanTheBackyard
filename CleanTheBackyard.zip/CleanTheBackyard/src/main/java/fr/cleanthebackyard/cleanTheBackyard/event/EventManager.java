package fr.cleanthebackyard.cleanTheBackyard.event;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.event.BlackMarketEvent;
import fr.cleanthebackyard.cleanTheBackyard.event.BoxRainEvent;
import fr.cleanthebackyard.cleanTheBackyard.event.GoldenDroneEvent;
import fr.cleanthebackyard.cleanTheBackyard.event.UfoEvent;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import java.util.UUID;
/**
 * Façade qui délègue aux 4 événements de jeu.
 * Conserve l'API publique utilisée par le reste du plugin.
 */
public class EventManager {
    private final CleanTheBackyard plugin;
    private final UfoEvent ufoEvent;
    private final GoldenDroneEvent goldenDroneEvent;
    private final BoxRainEvent boxRainEvent;
    private final BlackMarketEvent blackMarketEvent;
    public EventManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.ufoEvent = new UfoEvent(plugin);
        this.goldenDroneEvent = new GoldenDroneEvent(plugin);
        this.boxRainEvent = new BoxRainEvent(plugin);
        this.blackMarketEvent = new BlackMarketEvent(plugin);
    }
    public void scheduleNextUfoEvent() { ufoEvent.scheduleNext(); }
    public void scheduleNextGoldenDrone() { goldenDroneEvent.scheduleNext(); }
    public void scheduleNextBoxRain() { boxRainEvent.scheduleNext(); }
    public void scheduleNextBlackMarket() { blackMarketEvent.scheduleNext(); }
    public void triggerBoxRainNow() { boxRainEvent.trigger(); }
    public void triggerBlackMarketNow() { blackMarketEvent.trigger(); }
    public void spawnGoldenDrone() { goldenDroneEvent.trigger(); }
    public void forceStartUfoEvent() { ufoEvent.forceStart(); }
    public boolean isUfoBox(Location loc) { return ufoEvent.isUfoBox(loc); }
    public boolean tryClaimUfoBox(Player player, Location loc) { return ufoEvent.tryClaimUfoBox(player, loc); }
    public void onBoxBroken(Location loc) { ufoEvent.onBoxBroken(loc); }
    public boolean isUfoEventActive() { return ufoEvent.isActive(); }
    public boolean isUfoMultiplierActive() { return ufoEvent.isMultiplierActive(); }
    public int getUfoBoxCount() { return ufoEvent.getBoxCount(); }
    public int getUfoQuota() { return ufoEvent.getQuota(); }
    public boolean isGoldenDroneSpawned() { return goldenDroneEvent.isSpawned(); }
    public boolean claimGoldenDrone(Player p, UUID entityUUID) { return goldenDroneEvent.claim(p, entityUUID); }
}