package fr.cleanthebackyard.cleanTheBackyard.ui.gui;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;
/**
 * Holder marker pour identifier de manière fiable les inventaires CTB,
 * sans comparer les titres (qui peuvent contenir des codes couleur variables).
 */
public class CtbHolder implements InventoryHolder {
    private final GuiManager.GuiType type;
    private Inventory inventory;
    public CtbHolder(GuiManager.GuiType type) {
        this.type = type;
    }
    public GuiManager.GuiType getType() {
        return type;
    }
    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }
    @NotNull
    @Override
    public Inventory getInventory() {
        return inventory;
    }
}