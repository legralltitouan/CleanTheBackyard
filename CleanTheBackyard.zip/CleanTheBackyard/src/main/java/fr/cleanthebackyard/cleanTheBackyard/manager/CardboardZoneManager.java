package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.RegionUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

/**
 * Gère le déblocage progressif de la zone de cartons.
 * Chaque palier étend la région et restaure les nouveaux cartons depuis le template.
 */
public class CardboardZoneManager {

    private final CleanTheBackyard plugin;

    public CardboardZoneManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    /** Achète le palier suivant de zone pour le joueur. */
    public boolean purchaseNext(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;

        if (!plugin.getPluginConfig().isCardboardZoneEnabled()) {
            player.sendMessage(ChatUtil.color("&cLe déblocage de zone est désactivé."));
            return false;
        }

        int current = data.getCardboardZoneLevel();
        int max = plugin.getPluginConfig().getMaxCardboardZoneLevel();
        if (current >= max) {
            player.sendMessage(ChatUtil.color("&eZone déjà au maximum (" + max + ")."));
            return false;
        }

        PluginConfig.CardboardZoneUpgrade next =
                plugin.getPluginConfig().getCardboardZoneUpgrade(current + 1);
        if (next == null) {
            player.sendMessage(ChatUtil.color("&cPalier de zone introuvable."));
            return false;
        }

        if (!plugin.getEconomyManager().debit(player, next.cost(),
                "Extension de zone niveau " + next.level())) {
            return false;
        }

        data.setCardboardZoneLevel(next.level());

        // Restaure les cartons de la nouvelle bande (entre l'ancienne et la nouvelle région).
        restoreNewZoneBoxes(player, current, next.level());

        // Replace le display de frontière selon la nouvelle zone.
        plugin.getZoneBorderManager().refresh(player);

        player.sendMessage(ChatUtil.color("&a✦ Zone de cartons agrandie ! &7Niveau &f"
                + next.level() + " &7(+&f" + next.depthBonus() + " &7blocs)."));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.0f);
        return true;
    }

    /** Copie depuis le template uniquement les cartons de la zone nouvellement débloquée. */
    private void restoreNewZoneBoxes(Player player, int oldLevel, int newLevel) {
        String templateName = plugin.getPluginConfig().getTemplateWorldName();
        World template = Bukkit.getWorld(templateName);
        if (template == null) {
            plugin.getLogger().warning("[CTB] Template '" + templateName + "' non chargé (extension zone).");
            return;
        }
        World playerWorld = plugin.getPluginConfig().getPlayerWorld(player.getUniqueId());
        if (playerWorld == null) return;

        // On restaure toute la région du nouveau niveau (idempotent : ne touche que les blocs manquants).
        BoundingBox region = plugin.getPluginConfig().getPrestigeResetRegion(newLevel);
        BlockRef boxRef = plugin.getPluginConfig().getBoxBlockRef();
        Material boxMat = plugin.getBlockProvider().getFallbackMaterial(boxRef);
        int copied = RegionUtil.copyRegionFiltered(template, playerWorld, region, boxMat);
        plugin.getLogger().info("[CTB] Extension zone " + player.getName()
                + " (niv " + oldLevel + "→" + newLevel + ") : " + copied + " carton(s) ajouté(s).");
    }

    public long getNextCost(PlayerData data) {
        PluginConfig.CardboardZoneUpgrade next =
                plugin.getPluginConfig().getCardboardZoneUpgrade(data.getCardboardZoneLevel() + 1);
        return next != null ? next.cost() : -1;
    }

    public String describeStatus(PlayerData data) {
        int current = data.getCardboardZoneLevel();
        int max = plugin.getPluginConfig().getMaxCardboardZoneLevel();
        if (current >= max) return ChatUtil.color("&aZone maximale (" + max + ")");
        long cost = getNextCost(data);
        return ChatUtil.color("&7Zone niv &f" + current + "&7/&f" + max
                + " &7| Prochain : &f" + NumberFormatUtil.money(cost));
    }
}
