package fr.cleanthebackyard.cleanTheBackyard.event;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class UfoEvent {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    private boolean active = false;
    private boolean multiplierActive = false;
    private final AtomicInteger boxCount = new AtomicInteger(0);
    private int quota = 0;
    private final Map<String, UfoBoxReward> ufoBoxes = new HashMap<>();
    private final List<Location> ufoBoxLocations = new ArrayList<>();
    private BukkitTask timeoutTask = null;

    public enum UfoBoxReward { BONUS_MONEY, DOUBLE_SELL, UNLIMITED_ENERGY, BLACK_MARKET }

    public UfoEvent(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void scheduleNext() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getUfoMin() + random.nextInt(Math.max(1, cfg.getUfoMax() - cfg.getUfoMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::start, delay * 20L);
    }

    public void forceStart() {
        if (active) end(false, true);
        start();
    }

    private void start() {
        List<Player> ctbPlayers = EventUtils.getAllCtbPlayers(plugin);
        if (ctbPlayers.isEmpty()) {
            scheduleNext();
            return;
        }
        active = true;
        boxCount.set(0);
        quota = Math.max(1, ctbPlayers.size()) * 10;
        spawnUfoBoxes(ctbPlayers);

        Title title = Title.title(
                Component.text(ChatUtil.color("&5ALERTE OVNI !")),
                Component.text(ChatUtil.color("&dDes caisses spéciales sont apparues !")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(5), Duration.ofMillis(1000))
        );
        String msg = ChatUtil.color("&5[ALERTE] &dUn OVNI ! Détruisez &f" + quota + " &dcartons pour activer le &fx2 vente &dglobal !");
        for (Player p : ctbPlayers) {
            p.sendMessage(msg);
            p.showTitle(title);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.5f);
        }

        new BukkitRunnable() {
            @Override public void run() { if (active) end(false); }
        }.runTaskLater(plugin, 20L * 600);

        scheduleBoxTimeout();
    }

    private void scheduleBoxTimeout() {
        if (timeoutTask != null) timeoutTask.cancel();
        timeoutTask = new BukkitRunnable() {
            @Override public void run() {
                if (!active) return;
                List<Location> toRemove = new ArrayList<>();
                for (Location loc : ufoBoxLocations) {
                    if (loc.getBlock().getType() == Material.GLOWSTONE) {
                        loc.getBlock().setType(Material.AIR, false);
                        toRemove.add(loc);
                    }
                }
                toRemove.forEach(loc -> ufoBoxes.remove(LocationUtil.locKey(loc)));
                ufoBoxLocations.removeAll(toRemove);
                end(false);
            }
        }.runTaskLater(plugin, 20L * 30);
    }

    private void spawnUfoBoxes(List<Player> ctbPlayers) {
        ufoBoxes.clear();
        ufoBoxLocations.clear();
        if (ctbPlayers.isEmpty()) return;

        UfoBoxReward[] rewards = UfoBoxReward.values();
        for (Player target : ctbPlayers) {
            if (!EventUtils.isInOwnWorld(plugin, target)) continue;
            for (int i = 0; i < 5; i++) {
                Location base = target.getLocation();
                double angle = random.nextDouble() * Math.PI * 2;
                double dist = 8 + random.nextInt(8);
                Location spawnLoc = base.clone().add(Math.cos(angle) * dist, 0, Math.sin(angle) * dist);
                spawnLoc.setY(spawnLoc.getWorld().getHighestBlockYAt(spawnLoc));
                if (spawnLoc.getBlock().getType() != Material.AIR) spawnLoc.add(0, 1, 0);
                UfoBoxReward reward = rewards[random.nextInt(rewards.length)];
                spawnLoc.getBlock().setType(Material.GLOWSTONE, false);
                ufoBoxes.put(LocationUtil.locKey(spawnLoc), reward);
                ufoBoxLocations.add(spawnLoc.clone());
            }
        }
    }

    public boolean tryClaimUfoBox(Player player, Location loc) {
        String key = LocationUtil.locKey(loc);
        UfoBoxReward reward = ufoBoxes.remove(key);
        if (reward == null) return false;

        ufoBoxLocations.removeIf(l -> LocationUtil.locKey(l).equals(key));
        loc.getBlock().setType(Material.AIR, false);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        int avgLevel = Math.max(1, (data.getBagLevel() + data.getToolLevel() + data.getEnergyLevel()) / 3);

        switch (reward) {
            case BONUS_MONEY -> {
                int bonus = 20 + avgLevel * 15 + random.nextInt(Math.max(1, avgLevel * 10));
                plugin.getEconomyManager().credit(player, bonus);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &fCaisse mystérieuse ! &a+$" + bonus));
            }
            case DOUBLE_SELL -> {
                int duration = Math.min(60, 10 + avgLevel * 2);
                data.setDoubleSell(duration);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &ex2 VENTE perso pendant &f" + duration + "s"));
            }
            case UNLIMITED_ENERGY -> {
                int duration = Math.min(60, 15 + avgLevel * 3);
                data.setUnlimitedEnergy(duration);
                plugin.getBoxManager().removeFatigue(player, data);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &bÉnergie illimitée pendant &f" + duration + "s"));
            }
            case BLACK_MARKET -> {
                int duration = Math.min(30, 10 + avgLevel);
                data.setBlackMarket(duration);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &5Marché noir x3 pendant &f" + duration + "s"));
            }
        }
        return true;
    }

    public boolean isUfoBox(Location loc) { return ufoBoxes.containsKey(LocationUtil.locKey(loc)); }

    public void onBoxBroken(Location loc) {
        if (!active) return;
        int count = boxCount.incrementAndGet();
        if (count % 50 == 0) {
            EventUtils.getAllCtbPlayers(plugin).forEach(p ->
                    p.sendMessage(ChatUtil.colored("&d[OVNI] &f" + count + " / " + quota))
            );
        }
        if (count >= quota) end(true);
    }

    private void end(boolean success, boolean skipNextSchedule) {
        active = false;
        if (timeoutTask != null) { timeoutTask.cancel(); timeoutTask = null; }
        ufoBoxLocations.forEach(l -> {
            if (l.getBlock().getType() == Material.GLOWSTONE) l.getBlock().setType(Material.AIR, false);
        });
        ufoBoxes.clear();
        ufoBoxLocations.clear();

        if (success) activateSellMultiplier();
        if (!skipNextSchedule) scheduleNext();
    }

    private void end(boolean success) { end(success, false); }

    private void activateSellMultiplier() {
        multiplierActive = true;
        plugin.getPluginConfig().setGlobalSellMultiplier(2.0);
        final int DURATION = plugin.getPluginConfig().getUfoMultiplierDuration();
        EventUtils.getAllCtbPlayers(plugin).forEach(p -> {
            p.sendMessage(ChatUtil.colored("&6[SUCCÈS] &ex2 GLOBAL pendant &f1 heure &e!"));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        });
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getPluginConfig().setGlobalSellMultiplier(1.0);
            multiplierActive = false;
        }, DURATION * 20L);
    }

    public boolean isActive() { return active; }
    public boolean isMultiplierActive() { return multiplierActive; }
    public int getBoxCount() { return boxCount.get(); }
    public int getQuota() { return quota; }
}
