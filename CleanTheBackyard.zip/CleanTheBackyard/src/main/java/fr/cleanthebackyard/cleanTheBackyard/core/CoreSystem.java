package fr.cleanthebackyard.cleanTheBackyard.core;

import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.core.manager.EconomyManager;
import fr.cleanthebackyard.cleanTheBackyard.core.manager.PlayerDataManager;

/**
 * Fondations réutilisées partout : configuration, données joueurs, économie.
 */
public record CoreSystem(
        PluginConfig      config,
        PlayerDataManager playerData,
        EconomyManager    economy) {
}
