package fr.cleanthebackyard.cleanTheBackyard.security;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.security.manager.RatManager;

/**
 * Rats voleurs et défenses (caméras, pièges). Extensible pour de futurs
 * systèmes anti-vol.
 */
public record SecuritySystem(
        RatManager rat) {

    public static SecuritySystem create(CleanTheBackyard plugin) {
        return new SecuritySystem(new RatManager(plugin));
    }
}
