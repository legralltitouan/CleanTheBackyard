package fr.cleanthebackyard.cleanTheBackyard.gameplay;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.manager.BoxManager;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.manager.CleaningGameManager;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.manager.CollectibleManager;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.manager.CollectionBoardManager;

/**
 * Boucle de jeu : casser des cartons, nettoyer des collectibles, collectionner.
 * EnergyRegenTask reste gérée à part (cycle de vie de tâche répétée distinct).
 */
public record GameplaySystem(
        BoxManager             box,
        CollectibleManager     collectible,
        CleaningGameManager    cleaningGame,
        CollectionBoardManager collectionBoard) {

    public static GameplaySystem create(CleanTheBackyard plugin) {
        return new GameplaySystem(
                new BoxManager(plugin),
                new CollectibleManager(plugin),
                new CleaningGameManager(plugin),
                new CollectionBoardManager(plugin));
    }
}
