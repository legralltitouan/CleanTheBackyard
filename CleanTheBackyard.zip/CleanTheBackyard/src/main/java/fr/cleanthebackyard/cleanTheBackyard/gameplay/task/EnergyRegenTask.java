package fr.cleanthebackyard.cleanTheBackyard.gameplay.task;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class EnergyRegenTask extends BukkitRunnable {

    private final CleanTheBackyard plugin;

    public EnergyRegenTask(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        final String hub = plugin.core().config().getHubWorldName();
        final var boxManager = plugin.gameplay().box();

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerData data = plugin.core().playerData().get(player);
            if (data == null) continue;

            boolean inHub = player.getWorld().getName().equals(hub);
            int maxEnergy = boxManager.getMaxEnergyForPlayer(data);

            if (inHub) {
                if (data.getCurrentEnergy() < maxEnergy) {
                    data.setCurrentEnergy(maxEnergy);
                    boxManager.removeFatigue(player, data);
                }
                continue;
            }

            // Déjà au max : rien à régénérer, on évite tout calcul superflu.
            if (data.getCurrentEnergy() >= maxEnergy) continue;

            double regen = boxManager.getEnergyRegenForLevel(data.getEnergyLevel());
            data.addEnergy(regen);

            if (data.getCurrentEnergy() > maxEnergy) {
                data.setCurrentEnergy(maxEnergy);
            }

            if (data.getCurrentEnergy() > 10 && boxManager.isFatigued(player.getUniqueId())) {
                boxManager.removeFatigue(player, data);
            }
        }
    }
}
