package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * GUI de la boutique de Drones.
 */
public class ShopGui {

    private static final String TITLE = ChatUtil.color("&8[&dBoutique&8] &7Drones Assistants");

    private final CleanTheBackyard plugin;

    public ShopGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 36, TITLE);
        buildGui(inv, player);
        player.openInventory(inv);
    }

    private void buildGui(Inventory inv, Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);

        ItemStack glass = new ItemBuilder(Material.PURPLE_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < 36; i++) inv.setItem(i, glass);

        List<PluginConfig.DroneConfig> drones = plugin.getPluginConfig().getDroneConfigs();
        int slot = 2;

        for (PluginConfig.DroneConfig dc : drones) {
            boolean owned = data != null && data.hasDrone(dc.key());
            boolean unlocked = data != null
                    && data.getBagLevel() >= dc.bagLevelRequired()
                    && data.getToolLevel() >= dc.toolLevelRequired()
                    && data.getEnergyLevel() >= dc.energyLevelRequired();

            Material mat = owned ? Material.BEACON :
                    unlocked ? Material.COMPARATOR : Material.BARRIER;

            String status = owned ? "&a[POSSEDE]" :
                    unlocked ? "&eDisponible" : "&cVerrouille";

            ItemStack item = new ItemBuilder(mat)
                    .name("&d" + dc.name())
                    .lore(List.of(
                            ChatUtil.color("&7Revenu passif : &a+$" + dc.income() + " / " + dc.intervalSec() + "s"),
                            ChatUtil.color("&7Cout : &f$" + dc.cost()),
                            " ",
                            ChatUtil.color("&7Requis : Sac Niv&f " + dc.bagLevelRequired()
                                    + "&7, Outil Niv&f " + dc.toolLevelRequired()
                                    + "&7, Energie Niv&f " + dc.energyLevelRequired()),
                            " ",
                            ChatUtil.color(status),
                            ChatUtil.color(owned ? "" : unlocked ? "&aCliquez pour acheter !" : "&cAmeliorez vos stats !")
                    ))
                    .build();
            inv.setItem(slot, item);
            slot += 3;
        }

        if (data != null) {
            ItemStack bal = new ItemBuilder(Material.GOLD_INGOT)
                    .name("&aSolde : &f$" + String.format("%.0f", data.getBalance()))
                    .build();
            inv.setItem(31, bal);
        }
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        List<PluginConfig.DroneConfig> drones = plugin.getPluginConfig().getDroneConfigs();
        int slot = event.getRawSlot();

        int idx = 0;
        int s = 2;
        for (PluginConfig.DroneConfig dc : drones) {
            if (slot == s) {
                plugin.getDroneManager().purchaseDrone(player, dc.key());
                buildGui(event.getInventory(), player);
                return true;
            }
            s += 3;
            idx++;
        }
        return true;
    }
}
