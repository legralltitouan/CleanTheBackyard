package fr.cleanthebackyard.cleanTheBackyard.gui;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.entity.DroneEntity;
import fr.cleanthebackyard.cleanTheBackyard.manager.DroneManager;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import java.util.*;
public class ShopGui {
    public static final String TITLE_SHOP = ChatUtil.color("&8[&dBoutique&8] &7Drones Assistants");
    public static final String TITLE_UPGRADE_PREFIX = ChatUtil.color("&8[&bUpgrade&8] &f");
    private final CleanTheBackyard plugin;
    // Mémorise quel drone le joueur est en train d'améliorer
    private final Map<UUID, String> upgradingDrone = new HashMap<>();
    // Mémorise quel slot correspond à quel drone dans le shop principal
    private final Map<UUID, Map<Integer, String>> shopSlotToDrone = new HashMap<>();
    // Slots utilisables dans un inventaire 54 (3 lignes de 7 emplacements + colonnes vides)
    private static final int[] SHOP_SLOTS = {
            10, 11, 12, 13, 14, 15, 16,
            19, 20, 21, 22, 23, 24, 25,
            28, 29, 30, 31, 32, 33, 34
    };
    public ShopGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public void open(Player player) {
        upgradingDrone.remove(player.getUniqueId());
        Inventory inv = Bukkit.createInventory(null, 54, TITLE_SHOP);
        buildShop(inv, player);
        player.openInventory(inv);
    }
    public void openUpgradeMenu(Player player, String droneKey) {
        upgradingDrone.put(player.getUniqueId(), droneKey);
        PluginConfig.DroneConfig dc = plugin.getPluginConfig().getDroneConfigs().stream()
                .filter(d -> d.key().equals(droneKey)).findFirst().orElse(null);
        if (dc == null) return;
        Inventory inv = Bukkit.createInventory(null, 27, TITLE_UPGRADE_PREFIX + dc.name());
        buildUpgrade(inv, player, dc);
        player.openInventory(inv);
    }
    private void buildShop(Inventory inv, Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        ItemStack glass = new ItemBuilder(Material.PURPLE_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);
        Map<Integer, String> slotMap = new HashMap<>();
        shopSlotToDrone.put(player.getUniqueId(), slotMap);
        List<PluginConfig.DroneConfig> drones = plugin.getPluginConfig().getDroneConfigs();
        int i = 0;
        for (PluginConfig.DroneConfig dc : drones) {
            if (i >= SHOP_SLOTS.length) break;
            int slot = SHOP_SLOTS[i++];
            boolean owned = data != null && data.hasDrone(dc.key());
            boolean unlocked = data != null
                    && data.getBagLevel()    >= dc.bagLevelRequired()
                    && data.getToolLevel()   >= dc.toolLevelRequired()
                    && data.getEnergyLevel() >= dc.energyLevelRequired();
            Material mat = owned ? Material.BEACON : unlocked ? Material.COMPARATOR : Material.BARRIER;
            String stateLine = "";
            String statsLine = "";
            if (owned && data != null) {
                DroneEntity de = plugin.getDroneManager().getDroneByKey(player, dc.key());
                if (de != null) {
                    stateLine = "&7État : " + stateLabel(de.getState());
                }
                long[] stats = data.getDroneStats(dc.key());
                statsLine = "&7Stats : &f" + stats[0] + " cartons &7| &a$" + stats[1];
            }
            String status = owned ? "&a[POSSÉDÉ - Clic pour upgrade]" :
                    unlocked ? "&eClic pour acheter" : "&cVerrouillé";
            int[] tiers = (owned && data != null) ? data.getDroneUpgrades(dc.key()) : new int[]{0, 0, 0};
            String tierStr = owned ? "&7Tiers : &eVit " + tiers[0] + "&7/&eRayon " + tiers[1] + "&7/&eRev " + tiers[2] : "";
            List<String> lore = new ArrayList<>();
            lore.add(ChatUtil.color("&7Revenu : &a+$" + dc.income() + " / " + dc.intervalSec() + "s"));
            lore.add(ChatUtil.color("&7Vitesse : &f" + dc.speed() + " &7| Rayon : &f" + dc.pickupRange()));
            lore.add(ChatUtil.color("&7Coût : &f$" + dc.cost()));
            lore.add(" ");
            lore.add(ChatUtil.color("&7Requis : Sac &f" + dc.bagLevelRequired()
                    + " &7| Outil &f" + dc.toolLevelRequired()
                    + " &7| Énergie &f" + dc.energyLevelRequired()));
            if (!stateLine.isEmpty()) { lore.add(" "); lore.add(ChatUtil.color(stateLine)); }
            if (!statsLine.isEmpty()) lore.add(ChatUtil.color(statsLine));
            if (!tierStr.isEmpty())   lore.add(ChatUtil.color(tierStr));
            lore.add(" ");
            lore.add(ChatUtil.color(status));
            ItemStack item = new ItemBuilder(mat).name("&d" + dc.name()).lore(lore).build();
            inv.setItem(slot, item);
            slotMap.put(slot, dc.key());
        }
        if (data != null) {
            inv.setItem(49, new ItemBuilder(Material.GOLD_INGOT)
                    .name("&aSolde : &f$" + String.format("%.0f", data.getBalance()))
                    .build());
        }
    }
    private String stateLabel(DroneEntity.State state) {
        return switch (state) {
            case IDLE -> "&7RECHERCHE";
            case MOVING_TO_BOX -> "&eCHASSE";
            case MOVING_TO_SELL -> "&aTRANSPORT";
            case NO_TARGET -> "&cINACTIF (0 carton)";
        };
    }
    private void buildUpgrade(Inventory inv, Player player, PluginConfig.DroneConfig dc) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        int[] tiers = data.getDroneUpgrades(dc.key());
        ItemStack glass = new ItemBuilder(Material.LIGHT_BLUE_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);
        inv.setItem(11, buildUpgradeIcon(dc, tiers[DroneManager.SPEED], dc.maxSpeedTier(), "speed",
                Material.FEATHER, "&bVitesse",
                "Augmente la vitesse de déplacement",
                "+" + (int)(plugin.getPluginConfig().getDroneSpeedTierBonus()*100) + "% par tier"));
        inv.setItem(13, buildUpgradeIcon(dc, tiers[DroneManager.RANGE], dc.maxRangeTier(), "range",
                Material.SPYGLASS, "&eRayon d'action",
                "Augmente la portée de détection",
                "+" + (int)(plugin.getPluginConfig().getDroneRangeTierBonus()*100) + "% par tier"));
        inv.setItem(15, buildUpgradeIcon(dc, tiers[DroneManager.INCOME], dc.maxIncomeTier(), "income",
                Material.EMERALD, "&aRevenu",
                "Augmente le gain par carton",
                "+" + (int)(plugin.getPluginConfig().getDroneIncomeTierBonus()*100) + "% par tier"));
        inv.setItem(22, new ItemBuilder(Material.ARROW).name("&7← Retour à la boutique").build());
        inv.setItem(4, new ItemBuilder(Material.BEACON)
                .name("&d" + dc.name())
                .lore(List.of(ChatUtil.color("&7Améliore les caractéristiques de ce drone.")))
                .build());
        inv.setItem(8, new ItemBuilder(Material.GOLD_INGOT)
                .name("&aSolde : &f$" + String.format("%.0f", data.getBalance()))
                .build());
    }
    private ItemStack buildUpgradeIcon(PluginConfig.DroneConfig dc, int currentTier, int maxTier,
                                       String upgradeKey, Material mat, String title,
                                       String description, String bonusInfo) {
        boolean isMax = currentTier >= maxTier;
        long cost = isMax ? 0 : plugin.getPluginConfig().getDroneUpgradeCost(dc.cost(), upgradeKey, currentTier);
        return new ItemBuilder(mat)
                .name(title + " &8(" + currentTier + "/" + maxTier + ")")
                .lore(List.of(
                        ChatUtil.color("&7" + description),
                        ChatUtil.color("&7" + bonusInfo),
                        " ",
                        ChatUtil.color(isMax ? "&aMAXIMUM" : "&eCoût : &f$" + cost),
                        ChatUtil.color(isMax ? "" : "&aClic pour améliorer")
                ))
                .build();
    }
    public boolean handleClick(Player player, InventoryClickEvent event) {
        String upgrading = upgradingDrone.get(player.getUniqueId());
        if (upgrading != null) {
            return handleUpgradeClick(player, event, upgrading);
        }
        return handleShopClick(player, event);
    }
    private boolean handleShopClick(Player player, InventoryClickEvent event) {
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return true;
        Map<Integer, String> slotMap = shopSlotToDrone.get(player.getUniqueId());
        if (slotMap == null) return true;
        String droneKey = slotMap.get(slot);
        if (droneKey == null) return true;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;
        if (data.hasDrone(droneKey)) {
            openUpgradeMenu(player, droneKey);
        } else {
            plugin.getDroneManager().purchaseDrone(player, droneKey);
            buildShop(event.getInventory(), player);
        }
        return true;
    }
    private boolean handleUpgradeClick(Player player, InventoryClickEvent event, String droneKey) {
        int slot = event.getRawSlot();
        if (slot < 0 || slot >= event.getInventory().getSize()) return true;
        switch (slot) {
            case 11 -> plugin.getDroneManager().upgradeDroneAttribute(player, droneKey, DroneManager.SPEED);
            case 13 -> plugin.getDroneManager().upgradeDroneAttribute(player, droneKey, DroneManager.RANGE);
            case 15 -> plugin.getDroneManager().upgradeDroneAttribute(player, droneKey, DroneManager.INCOME);
            case 22 -> {
                // Retour : on retire d'abord la marque d'upgrade
                upgradingDrone.remove(player.getUniqueId());
                open(player);
                return true;
            }
            default -> { return true; }
        }
        PluginConfig.DroneConfig dc = plugin.getPluginConfig().getDroneConfigs().stream()
                .filter(d -> d.key().equals(droneKey)).findFirst().orElse(null);
        if (dc != null) buildUpgrade(event.getInventory(), player, dc);
        return true;
    }
    /** Appelé seulement à la fermeture totale (pas lors d'un swap d'inventaire). */
    public void onClose(Player player) {
        // Ne rien faire : la transition vers le sous-menu déclenche aussi close ;
        // on garde upgradingDrone tant que GuiManager n'est pas notifié d'une vraie fermeture.
    }
    public void forceClear(Player player) {
        upgradingDrone.remove(player.getUniqueId());
        shopSlotToDrone.remove(player.getUniqueId());
    }
}