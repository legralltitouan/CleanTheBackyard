package fr.cleanthebackyard.cleanTheBackyard.data;
public class CollectibleItem {
    private final String key;
    private final String displayName;
    private final String furnitureNamespacedId;
    private final String dirtyFurnitureNamespacedId;
    private final long sellValue;
    private final double dropChance;
    private final Rarity rarity;
    private final int cleaningDifficulty;
    public enum Rarity {
        COMMON("&7Commun", 1),
        UNCOMMON("&aPeu commun", 2),
        RARE("&9Rare", 3),
        EPIC("&5Épique", 4),
        LEGENDARY("&6Légendaire", 5);
        private final String displayName;
        private final int tier;
        Rarity(String displayName, int tier) {
            this.displayName = displayName;
            this.tier = tier;
        }
        public String getDisplayName() { return displayName; }
        public int getTier() { return tier; }
    }
    public CollectibleItem(String key, String displayName, String furnitureNamespacedId,
                           String dirtyFurnitureNamespacedId, long sellValue, double dropChance,
                           Rarity rarity, int cleaningDifficulty) {
        this.key = key;
        this.displayName = displayName;
        this.furnitureNamespacedId = furnitureNamespacedId;
        this.dirtyFurnitureNamespacedId = dirtyFurnitureNamespacedId;
        this.sellValue = sellValue;
        this.dropChance = dropChance;
        this.rarity = rarity;
        this.cleaningDifficulty = cleaningDifficulty;
    }
    public String getKey() { return key; }
    public String getDisplayName() { return displayName; }
    public String getFurnitureNamespacedId() { return furnitureNamespacedId; }
    public String getDirtyFurnitureNamespacedId() { return dirtyFurnitureNamespacedId; }
    public long getSellValue() { return sellValue; }
    public double getDropChance() { return dropChance; }
    public Rarity getRarity() { return rarity; }
    public int getCleaningDifficulty() { return cleaningDifficulty; }
}