package fr.cleanthebackyard.cleanTheBackyard.world;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.world.manager.CardboardZoneManager;
import fr.cleanthebackyard.cleanTheBackyard.world.manager.FurnitureShopManager;
import fr.cleanthebackyard.cleanTheBackyard.world.manager.HouseManager;
import fr.cleanthebackyard.cleanTheBackyard.world.manager.ZoneBorderManager;
import fr.cleanthebackyard.cleanTheBackyard.world.service.ZoneService;

/**
 * Mondes, zones d'interaction, extension de terrain, maisons et meubles.
 */
public record WorldSystem(
        ZoneService          zone,
        CardboardZoneManager cardboardZone,
        ZoneBorderManager    zoneBorder,
        HouseManager         house,
        FurnitureShopManager furnitureShop) {

    public static WorldSystem create(CleanTheBackyard plugin) {
        // Ordre indolore : tous résolvent leurs dépendances paresseusement
        // via les ponts du plugin. ZoneService.start() reste appelé séparément.
        return new WorldSystem(
                new ZoneService(plugin),
                new CardboardZoneManager(plugin),
                new ZoneBorderManager(plugin),
                new HouseManager(plugin),
                new FurnitureShopManager(plugin));
    }
}
