package fr.cleanthebackyard.cleanTheBackyard.gameplay.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.CollectibleItem;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
/**
 * Mini-jeu de timing : une barre défile, le joueur doit cliquer (left-click)
 * quand le curseur est sur la zone verte. Plusieurs réussites consécutives
 * sont requises selon la difficulté.
 */
public class CleaningGameManager {
    private final CleanTheBackyard plugin;
    private final Map<UUID, CleaningSession> activeSessions = new HashMap<>();
    public CleaningGameManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public boolean isPlaying(UUID uuid) {
        return activeSessions.containsKey(uuid);
    }
    public void start(Player player, CollectibleItem item, int handSlot) {
        if (activeSessions.containsKey(player.getUniqueId())) {
            player.sendMessage(ChatUtil.color("&eTu nettoies déjà un objet."));
            return;
        }
        CleaningSession session = new CleaningSession(player, item, handSlot);
        activeSessions.put(player.getUniqueId(), session);
        session.start();
    }
    public void onPlayerClick(Player player) {
        CleaningSession s = activeSessions.get(player.getUniqueId());
        if (s != null) s.tryHit();
    }
    public void cancel(Player player) {
        CleaningSession s = activeSessions.remove(player.getUniqueId());
        if (s != null) s.stop(false);
    }
    private void finish(Player player, CleaningSession session, boolean success) {
        activeSessions.remove(player.getUniqueId());
        if (success) {
            // Remplace l'item sale par l'item propre
            ItemStack handItem = player.getInventory().getItem(session.handSlot);
            if (handItem != null && plugin.getCollectibleManager().isCollectible(handItem)
                    && plugin.getCollectibleManager().isDirty(handItem)) {
                ItemStack cleanStack = plugin.getFurnitureProvider().getItemStack(
                        session.item.getFurnitureNamespacedId());
                if (cleanStack != null) {
                    cleanStack = plugin.getCollectibleManager().tagItem(cleanStack, session.item, false);
                    cleanStack.setAmount(1);
                    handItem.setAmount(handItem.getAmount() - 1);
                    var leftover = player.getInventory().addItem(cleanStack);
                    if (!leftover.isEmpty()) {
                        leftover.values().forEach(i -> player.getWorld()
                                .dropItemNaturally(player.getLocation(), i));
                    }
                }
            }
            player.sendMessage(ChatUtil.color("&a✦ Nettoyage réussi ! &fL'objet est maintenant propre."));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 0.8f, 1.4f);
        } else {
            player.sendMessage(ChatUtil.color("&cRaté ! L'objet reste sale. Réessaie."));
            player.playSound(player.getLocation(), Sound.BLOCK_ANVIL_LAND, 0.5f, 0.7f);
        }
    }
    private class CleaningSession {
        private final Player player;
        private final CollectibleItem item;
        private final int handSlot;
        private final int requiredHits;
        private int successfulHits = 0;
        private int cursor = 0;
        private boolean movingRight = true;
        private final int barLength = 20;
        private int zoneStart;
        private int zoneEnd;
        private final int zoneSize;
        private final int speed;
        private BukkitTask task;
        private boolean canHit = false;
        private int totalTicks = 0;
        private final int maxTicks;
        // Cooldown anti double-click (en ticks)
        private int hitCooldown = 0;
        CleaningSession(Player player, CollectibleItem item, int handSlot) {
            this.player = player;
            this.item = item;
            this.handSlot = handSlot;
            this.requiredHits = item.getCleaningDifficulty();
            int difficulty = item.getCleaningDifficulty();
            this.zoneSize = Math.max(2, 6 - difficulty);
            this.zoneStart = ThreadLocalRandom.current().nextInt(barLength - zoneSize);
            this.zoneEnd = zoneStart + zoneSize;
            this.speed = Math.max(1, 4 - difficulty / 2);
            this.maxTicks = 600; // 30s max
        }
        void start() {
            player.sendMessage(ChatUtil.color("&6=== Nettoyage : " + item.getDisplayName() + " ==="));
            player.sendMessage(ChatUtil.color("&7Frappe (clic gauche) quand le curseur est sur la &azone verte&7."));
            player.sendMessage(ChatUtil.color("&7Réussites requises : &f" + requiredHits));
            task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 0L, speed);
        }
        private void tick() {
            totalTicks += speed;
            if (totalTicks > maxTicks) {
                finish(player, this, false);
                task.cancel();
                return;
            }
            if (hitCooldown > 0) hitCooldown--;
            if (movingRight) {
                cursor++;
                if (cursor >= barLength - 1) movingRight = false;
            } else {
                cursor--;
                if (cursor <= 0) movingRight = true;
            }
            canHit = (cursor >= zoneStart && cursor <= zoneEnd);
            renderBar();
        }
        private void renderBar() {
            StringBuilder bar = new StringBuilder("&6[Nettoyage] &8[");
            for (int i = 0; i < barLength; i++) {
                if (i == cursor) {
                    bar.append("&f▮");
                } else if (i >= zoneStart && i <= zoneEnd) {
                    bar.append("&a▬");
                } else {
                    bar.append("&7▬");
                }
            }
            bar.append("&8] &7(&a").append(successfulHits).append("&7/&f").append(requiredHits).append("&7)");
            player.sendActionBar(Component.text(ChatUtil.color(bar.toString())));
        }
        void tryHit() {
            if (hitCooldown > 0) return;
            hitCooldown = 3; // évite double-déclenchement
            if (canHit) {
                successfulHits++;
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 0.7f, 1.5f);
                if (successfulHits >= requiredHits) {
                    finish(player, this, true);
                    task.cancel();
                    return;
                }
                // Nouvelle zone pour le prochain hit
                this.zoneStart = ThreadLocalRandom.current().nextInt(barLength - zoneSize);
                this.zoneEnd = zoneStart + zoneSize;
            } else {
                player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BASS, 0.5f, 0.5f);
                successfulHits = Math.max(0, successfulHits - 1);
            }
        }
        void stop(boolean success) {
            if (task != null && !task.isCancelled()) task.cancel();
        }
    }
}