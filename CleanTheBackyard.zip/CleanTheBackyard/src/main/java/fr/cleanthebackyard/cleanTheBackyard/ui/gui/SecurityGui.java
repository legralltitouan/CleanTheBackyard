package fr.cleanthebackyard.cleanTheBackyard.ui.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class SecurityGui {
    private static final String TITLE = ChatUtil.color("&8[&6Sécurité du Coffre&8]");
    private final CleanTheBackyard plugin;

    public SecurityGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.SECURITY);
        Inventory inv = Bukkit.createInventory(holder, 45, TITLE);
        holder.setInventory(inv);
        build(inv, player);
        player.openInventory(inv);
    }

    public void forceClear(Player player) { /* rien à nettoyer */ }

    private void build(Inventory inv, Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        ItemStack glass = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        inv.setItem(4, new ItemBuilder(Material.GOLD_BLOCK)
                .name("&6💰 Ton argent")
                .lore(List.of(
                        ChatUtil.color("&7Solde actuel : &a" + NumberFormatUtil.money(data.getBalance())),
                        ChatUtil.color("&cVolé par les rats : &c" + NumberFormatUtil.money(data.getTotalStolenByRats())),
                        ChatUtil.color("&7Rats éliminés : &f" + data.getTotalRatsKilled()),
                        ChatUtil.color("&7Rats effrayés : &f" + data.getTotalRatsScared()),
                        " ",
                        ChatUtil.color("&eAméliore tes défenses ci-dessous pour"),
                        ChatUtil.color("&eprotéger ton argent des rats voleurs !")
                ))
                .build());

        inv.setItem(20, buildSecurityIcon(data));
        inv.setItem(24, buildTrapIcon(data));

        inv.setItem(40, new ItemBuilder(Material.BOOK)
                .name("&eComment ça marche ?")
                .lore(List.of(
                        ChatUtil.color("&7Des rats apparaissent périodiquement"),
                        ChatUtil.color("&7et volent un % de ton argent."),
                        " ",
                        ChatUtil.color("&b📷 Caméras &7: chance de te prévenir"),
                        ChatUtil.color("&c🪤 Pièges &7: chance d'éliminer le rat"),
                        " ",
                        ChatUtil.color("&aTu peux aussi frapper le rat à mains nues !")
                ))
                .build());
    }

    private ItemStack buildSecurityIcon(PlayerData data) {
        int level = data.getSecurityLevel();
        PluginConfig.SecurityUpgrade current = level > 0 ? plugin.getPluginConfig().getSecurityUpgrade(level) : null;
        PluginConfig.SecurityUpgrade next = plugin.getPluginConfig().getSecurityUpgrade(level + 1);
        List<String> lore = new ArrayList<>();
        lore.add(ChatUtil.color("&7Niveau actuel : &f" + level
                + (current != null ? " (" + current.name() + ")" : " (Aucune)")));
        if (current != null) {
            lore.add(ChatUtil.color("&7Chance de détection : &b"
                    + String.format("%.0f%%", current.detectionChance() * 100)));
        }
        lore.add(" ");
        if (next != null) {
            lore.add(ChatUtil.color("&eProchain : &f" + next.name()));
            lore.add(ChatUtil.color("&eDétection : &b"
                    + String.format("%.0f%%", next.detectionChance() * 100)));
            lore.add(ChatUtil.color("&ePrix : &f" + NumberFormatUtil.money(next.cost())));
            lore.add(" ");
            lore.add(ChatUtil.color(data.getBalance() >= next.cost() ? "&aClic pour acheter" : "&cFonds insuffisants"));
        } else {
            lore.add(ChatUtil.color("&aNiveau maximum atteint"));
        }
        return new ItemBuilder(Material.SPYGLASS).name("&b📷 Caméra de surveillance").lore(lore).build();
    }

    private ItemStack buildTrapIcon(PlayerData data) {
        int level = data.getTrapLevel();
        PluginConfig.TrapUpgrade current = level > 0 ? plugin.getPluginConfig().getTrapUpgrade(level) : null;
        PluginConfig.TrapUpgrade next = plugin.getPluginConfig().getTrapUpgrade(level + 1);
        List<String> lore = new ArrayList<>();
        lore.add(ChatUtil.color("&7Niveau actuel : &f" + level
                + (current != null ? " (" + current.name() + ")" : " (Aucun)")));
        if (current != null) {
            lore.add(ChatUtil.color("&7Chance d'élimination : &a"
                    + String.format("%.0f%%", current.killChance() * 100)));
        }
        lore.add(" ");
        if (next != null) {
            lore.add(ChatUtil.color("&eProchain : &f" + next.name()));
            lore.add(ChatUtil.color("&eÉlimination : &a"
                    + String.format("%.0f%%", next.killChance() * 100)));
            lore.add(ChatUtil.color("&ePrix : &f" + NumberFormatUtil.money(next.cost())));
            lore.add(" ");
            lore.add(ChatUtil.color(data.getBalance() >= next.cost() ? "&aClic pour acheter" : "&cFonds insuffisants"));
        } else {
            lore.add(ChatUtil.color("&aNiveau maximum atteint"));
        }
        return new ItemBuilder(Material.TRIPWIRE_HOOK).name("&c🪤 Piège à rats").lore(lore).build();
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        event.setCancelled(true);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;
        int slot = event.getRawSlot();
        switch (slot) {
            case 20 -> upgradeSecurity(player, data);
            case 24 -> upgradeTrap(player, data);
            default -> { return true; }
        }
        build(event.getInventory(), player);
        return true;
    }

    private void upgradeSecurity(Player player, PlayerData data) {
        int level = data.getSecurityLevel();
        PluginConfig.SecurityUpgrade next = plugin.getPluginConfig().getSecurityUpgrade(level + 1);
        if (next == null) {
            player.sendMessage(ChatUtil.color("&eNiveau maximum atteint."));
            return;
        }
        if (!plugin.getEconomyManager().debit(player, next.cost(), next.name())) return;
        data.setSecurityLevel(level + 1);
        player.sendMessage(ChatUtil.color("&aCaméra améliorée : &f" + next.name()));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.2f);
    }

    private void upgradeTrap(Player player, PlayerData data) {
        int level = data.getTrapLevel();
        PluginConfig.TrapUpgrade next = plugin.getPluginConfig().getTrapUpgrade(level + 1);
        if (next == null) {
            player.sendMessage(ChatUtil.color("&eNiveau maximum atteint."));
            return;
        }
        if (!plugin.getEconomyManager().debit(player, next.cost(), next.name())) return;
        data.setTrapLevel(level + 1);
        player.sendMessage(ChatUtil.color("&aPiège amélioré : &f" + next.name()));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.2f);
    }
}
