package fr.cleanthebackyard.cleanTheBackyard.ui.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.*;

public class TalentGui {

    private static final String TITLE = ChatUtil.color("&8[&d✦ ARBRE DE TALENTS&8]");
    private final CleanTheBackyard plugin;
    private final Map<UUID, Map<Integer, String>> slotMap = new HashMap<>();

    public TalentGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.TALENT);
        Inventory inv = Bukkit.createInventory(holder, 45, TITLE);
        holder.setInventory(inv);
        build(inv, player);
        player.openInventory(inv);
    }

    private void build(Inventory inv, Player player) {
        ItemStack glass = new ItemBuilder(Material.PURPLE_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return;
        Map<Integer, String> map = new HashMap<>();
        slotMap.put(player.getUniqueId(), map);

        int[] talentSlots = {10, 12, 14, 16, 19, 21};
        List<PluginConfig.TalentDef> talents = plugin.core().config().getTalents();
        for (int i = 0; i < talents.size() && i < talentSlots.length; i++) {
            PluginConfig.TalentDef def = talents.get(i);
            int tier = data.getTalentTier(def.key());
            double bonus = tier * def.bonusPerTier() * 100;
            double nextBonus = (tier + 1) * def.bonusPerTier() * 100;
            List<String> lore = new ArrayList<>();
            lore.add(ChatUtil.color("&7Niveau : &f" + tier + "/" + def.maxTier()));
            lore.add(ChatUtil.color("&7Bonus actuel : &a+" + String.format("%.0f", bonus) + "%"));
            lore.add(ChatUtil.color("&7" + describeEffect(def.key())));
            lore.add(" ");
            if (tier >= def.maxTier()) {
                lore.add(ChatUtil.color("&6✦ Maxé"));
            } else {
                lore.add(ChatUtil.color("&7Prochain : &a+" + String.format("%.0f", nextBonus) + "%"));
                lore.add(ChatUtil.color("&eClic pour investir 1 point"));
            }
            ItemStack icon = new ItemBuilder(def.icon())
                    .name("&d" + def.name())
                    .lore(lore).build();
            inv.setItem(talentSlots[i], icon);
            map.put(talentSlots[i], def.key());
        }

        inv.setItem(40, new ItemBuilder(Material.NETHER_STAR)
                .name("&d✦ Points disponibles : &f" + data.getTalentPoints())
                .lore(List.of(
                        ChatUtil.color("&7Gagne 1 point à chaque prestige."),
                        ChatUtil.color("&7Investis-les dans une spécialisation.")
                )).build());

        inv.setItem(36, new ItemBuilder(Material.BARRIER)
                .name("&cRéinitialiser mes talents")
                .lore(List.of(
                        ChatUtil.color("&7Te rend tous tes points investis."),
                        ChatUtil.color("&eClic droit pour confirmer")
                )).build());
        map.put(36, "__reset__");
    }

    private String describeEffect(String key) {
        return switch (key) {
            case "botany"    -> "+cartons cassés en bonus";
            case "mechanics" -> "+revenus drones";
            case "charisma"  -> "Rats moins fréquents";
            case "economy"   -> "+multiplicateur de vente";
            case "endurance" -> "+énergie max";
            case "fortune"   -> "+drop de collectibles";
            default          -> "Effet spécial";
        };
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        Map<Integer, String> map = slotMap.get(player.getUniqueId());
        if (map == null) return true;
        String key = map.get(event.getRawSlot());
        if (key == null) return true;

        if (key.equals("__reset__")) {
            if (!event.isRightClick()) {
                player.sendMessage(ChatUtil.color("&7Fais un &cclic droit &7pour confirmer le reset."));
                return true;
            }
            PlayerData data = plugin.core().playerData().get(player);
            if (data == null) return true;
            plugin.progression().talent().resetAndRefund(data);
            player.sendMessage(ChatUtil.color("&aTalents réinitialisés. Points restitués : &f" + data.getTalentPoints()));
            build(event.getInventory(), player);
            return true;
        }

        plugin.progression().talent().spendPoint(player, key);
        build(event.getInventory(), player);
        return true;
    }

    public void forceClear(Player player) {
        slotMap.remove(player.getUniqueId());
    }
}
