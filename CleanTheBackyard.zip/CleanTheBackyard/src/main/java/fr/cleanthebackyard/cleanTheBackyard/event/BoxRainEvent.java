package fr.cleanthebackyard.cleanTheBackyard.event;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BoxRainEvent {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    public BoxRainEvent(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void scheduleNext() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getBoxRainMin()
                + random.nextInt(Math.max(1, cfg.getBoxRainMax() - cfg.getBoxRainMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::trigger, delay * 20L);
        plugin.getLogger().info("[CTB] Prochaine pluie de cartons dans " + delay + "s.");
    }

    public void trigger() {
        List<Player> targets = EventUtils.getAllCtbPlayers(plugin);
        if (targets.isEmpty()) {
            scheduleNext();
            return;
        }

        Material boxMat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        if (boxMat == null) boxMat = Material.NOTE_BLOCK;
        final Material finalBoxMat = boxMat;
        final BlockData fallingData = Bukkit.createBlockData(boxMat);

        final BoundingBox region = plugin.getPluginConfig().getBoxRainRegion();
        final int boxesPerIteration = plugin.getPluginConfig().getBoxRainBoxesPerIteration();
        final int maxIterations = plugin.getPluginConfig().getBoxRainIterations();
        final long intervalTicks = plugin.getPluginConfig().getBoxRainIntervalTicks();

        // Hauteur de spawn : 15 blocs au-dessus du max Y de la région
        final double spawnHeight = region.getMaxY() + 15;

        List<Player> participants = new ArrayList<>();
        for (Player p : targets) {
            if (!EventUtils.isInOwnWorld(plugin, p)) continue;
            participants.add(p);
            int durationSec = (int) (maxIterations * intervalTicks / 20);
            p.sendMessage(ChatUtil.color("&3[PLUIE DE CARTONS] &fDes cartons tombent du ciel pendant "
                    + durationSec + " secondes !"));
            p.playSound(p.getLocation(), Sound.WEATHER_RAIN, 1.0f, 1.0f);
        }

        if (participants.isEmpty()) {
            scheduleNext();
            return;
        }

        new BukkitRunnable() {
            int iteration = 0;

            @Override
            public void run() {
                if (iteration >= maxIterations) {
                    cancel();
                    return;
                }
                iteration++;

                for (Player p : participants) {
                    if (!p.isOnline() || !EventUtils.isInOwnWorld(plugin, p)) continue;
                    World w = p.getWorld();

                    int spawned = 0;
                    int attempts = 0;
                    while (spawned < boxesPerIteration && attempts < 30) {
                        attempts++;
                        Location spawnLoc = randomSpawnLocation(w, region, spawnHeight);
                        if (spawnLoc == null) continue;

                        // Vérifie qu'il y a bien de l'air à la position de spawn
                        if (!spawnLoc.getBlock().getType().isAir()) continue;

                        // Vérifie qu'il existe au moins un emplacement valide en dessous
                        if (!hasValidLandingBelow(w, region, spawnLoc, finalBoxMat)) continue;

                        try {
                            FallingBlock fb = w.spawnFallingBlock(spawnLoc, fallingData);
                            fb.setDropItem(false);
                            fb.setHurtEntities(false);
                            fb.setVelocity(new Vector(0, -0.1, 0));
                            // Marqueur pour le listener : c'est une "box rain"
                            fb.getPersistentDataContainer().set(
                                    new NamespacedKey(plugin, "box-rain"),
                                    org.bukkit.persistence.PersistentDataType.BYTE,
                                    (byte) 1
                            );
                            w.spawnParticle(Particle.CLOUD, spawnLoc, 5, 0.2, 0, 0.2, 0.01);
                            spawned++;
                        } catch (Throwable ignored) {
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, intervalTicks);

        scheduleNext();
    }

    /**
     * Génère une position XZ aléatoire dans la région, à la hauteur de spawn fixe.
     */
    private Location randomSpawnLocation(World w, BoundingBox region, double spawnHeight) {
        double rangeX = region.getMaxX() - region.getMinX();
        double rangeZ = region.getMaxZ() - region.getMinZ();
        if (rangeX <= 0 || rangeZ <= 0) return null;

        double x = region.getMinX() + random.nextDouble() * rangeX;
        double z = region.getMinZ() + random.nextDouble() * rangeZ;

        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        return new Location(w, bx + 0.5, spawnHeight, bz + 0.5);
    }

    /**
     * Vérifie qu'il y a au moins un bloc d'air dans la région verticale en dessous
     * du spawn (pour que le FallingBlock puisse se poser quelque part).
     */
    private boolean hasValidLandingBelow(World w, BoundingBox region, Location spawnLoc, Material boxMat) {
        int x = spawnLoc.getBlockX();
        int z = spawnLoc.getBlockZ();
        int minY = (int) Math.floor(region.getMinY());
        int maxY = (int) Math.floor(region.getMaxY());

        for (int y = maxY; y >= minY; y--) {
            Block b = w.getBlockAt(x, y, z);
            if (b.getType().isAir() || b.getType() == boxMat) {
                return true;
            }
        }
        return false;
    }
}
