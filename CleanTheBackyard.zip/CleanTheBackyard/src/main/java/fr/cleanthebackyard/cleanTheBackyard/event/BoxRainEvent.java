package fr.cleanthebackyard.cleanTheBackyard.event;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BoxRainEvent {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    public BoxRainEvent(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void scheduleNext() {
        PluginConfig cfg = plugin.core().config();
        int delay = cfg.getBoxRainMin()
                + random.nextInt(Math.max(1, cfg.getBoxRainMax() - cfg.getBoxRainMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::trigger, delay * 20L);
        plugin.getLogger().info("[CTB] Prochaine pluie de cartons dans " + delay + "s.");
    }

    public void trigger() {
        List<Player> targets = EventUtils.getAllCtbPlayers(plugin);
        if (targets.isEmpty()) {
            scheduleNext();
            return;
        }

        BlockRef boxRef = plugin.core().config().getBoxBlockRef();
        Material fallbackMat = plugin.providers().block().getFallbackMaterial(boxRef);
        final BlockData fallingData = Bukkit.createBlockData(fallbackMat);

        final int boxesPerIteration = plugin.core().config().getBoxRainBoxesPerIteration();
        final int maxIterations = plugin.core().config().getBoxRainIterations();
        final long intervalTicks = plugin.core().config().getBoxRainIntervalTicks();

        List<Player> participants = new ArrayList<>();
        for (Player p : targets) {
            if (!EventUtils.isInOwnWorld(plugin, p)) continue;
            participants.add(p);
            int durationSec = (int) (maxIterations * intervalTicks / 20);
            p.sendMessage(ChatUtil.color("&3[PLUIE DE CARTONS] &fDes cartons tombent du ciel pendant "
                    + durationSec + " secondes !"));
            p.playSound(p.getLocation(), Sound.WEATHER_RAIN, 1.0f, 1.0f);
        }

        if (participants.isEmpty()) {
            scheduleNext();
            return;
        }

        new BukkitRunnable() {
            int iteration = 0;

            @Override
            public void run() {
                if (iteration >= maxIterations) {
                    cancel();
                    return;
                }
                iteration++;

                for (Player p : participants) {
                    if (!p.isOnline() || !EventUtils.isInOwnWorld(plugin, p)) continue;
                    World w = p.getWorld();

                    // ── Région propre au joueur, étendue selon son niveau de zone ──
                    int zoneLevel = 0;
                    PlayerData data = plugin.core().playerData().get(p);
                    if (data != null) zoneLevel = data.getCardboardZoneLevel();
                    final BoundingBox region = plugin.core().config().getBoxRainRegion(zoneLevel);
                    final double spawnHeight = region.getMaxY() + 15;

                    int spawned = 0;
                    int attempts = 0;
                    while (spawned < boxesPerIteration && attempts < 30) {
                        attempts++;
                        Location spawnLoc = randomSpawnLocation(w, region, spawnHeight);
                        if (spawnLoc == null) continue;

                        if (!spawnLoc.getBlock().getType().isAir()) continue;
                        if (!hasValidLandingBelow(w, region, spawnLoc, fallbackMat)) continue;

                        try {
                            FallingBlock fb = w.spawnFallingBlock(spawnLoc, fallingData);
                            fb.setDropItem(false);
                            fb.setHurtEntities(false);
                            fb.setVelocity(new Vector(0, -0.1, 0));
                            fb.getPersistentDataContainer().set(
                                    new NamespacedKey(plugin, "box-rain"),
                                    org.bukkit.persistence.PersistentDataType.BYTE,
                                    (byte) 1
                            );
                            w.spawnParticle(Particle.CLOUD, spawnLoc, 5, 0.2, 0, 0.2, 0.01);
                            spawned++;
                        } catch (Throwable ignored) {
                        }
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, intervalTicks);

        scheduleNext();
    }

    private Location randomSpawnLocation(World w, BoundingBox region, double spawnHeight) {
        double rangeX = region.getMaxX() - region.getMinX();
        double rangeZ = region.getMaxZ() - region.getMinZ();
        if (rangeX <= 0 || rangeZ <= 0) return null;

        double x = region.getMinX() + random.nextDouble() * rangeX;
        double z = region.getMinZ() + random.nextDouble() * rangeZ;

        int bx = (int) Math.floor(x);
        int bz = (int) Math.floor(z);
        return new Location(w, bx + 0.5, spawnHeight, bz + 0.5);
    }

    private boolean hasValidLandingBelow(World w, BoundingBox region, Location spawnLoc, Material boxMat) {
        int x = spawnLoc.getBlockX();
        int z = spawnLoc.getBlockZ();
        int minY = (int) Math.floor(region.getMinY());
        int maxY = (int) Math.floor(region.getMaxY());

        for (int y = maxY; y >= minY; y--) {
            Block b = w.getBlockAt(x, y, z);
            if (b.getType().isAir() || b.getType() == boxMat) {
                return true;
            }
        }
        return false;
    }
}
