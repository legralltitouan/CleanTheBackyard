package fr.cleanthebackyard.cleanTheBackyard.event;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.FallingBlock;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.*;

public class BoxRainEvent {

    private static final Set<Material> INVALID_GROUNDS = EnumSet.of(
            Material.OAK_LEAVES, Material.SPRUCE_LEAVES, Material.BIRCH_LEAVES,
            Material.JUNGLE_LEAVES, Material.ACACIA_LEAVES, Material.DARK_OAK_LEAVES,
            Material.MANGROVE_LEAVES, Material.CHERRY_LEAVES, Material.AZALEA_LEAVES,
            Material.FLOWERING_AZALEA_LEAVES, Material.PALE_OAK_LEAVES,
            Material.OAK_FENCE, Material.SPRUCE_FENCE, Material.BIRCH_FENCE,
            Material.JUNGLE_FENCE, Material.ACACIA_FENCE, Material.DARK_OAK_FENCE,
            Material.MANGROVE_FENCE, Material.CHERRY_FENCE, Material.PALE_OAK_FENCE,
            Material.NETHER_BRICK_FENCE, Material.IRON_BARS,
            Material.GLASS, Material.GLASS_PANE,
            Material.WATER, Material.LAVA, Material.BUBBLE_COLUMN,
            Material.NOTE_BLOCK,
            Material.BRICKS, Material.BRICK_STAIRS, Material.BRICK_SLAB, Material.BRICK_WALL,
            Material.STONE_BRICKS, Material.STONE_BRICK_STAIRS, Material.STONE_BRICK_SLAB, Material.STONE_BRICK_WALL,
            Material.MOSSY_STONE_BRICKS, Material.MOSSY_STONE_BRICK_STAIRS, Material.MOSSY_STONE_BRICK_SLAB, Material.MOSSY_STONE_BRICK_WALL,
            Material.CRACKED_STONE_BRICKS, Material.CHISELED_STONE_BRICKS,
            Material.NETHER_BRICKS, Material.NETHER_BRICK_STAIRS, Material.NETHER_BRICK_SLAB, Material.NETHER_BRICK_WALL,
            Material.RED_NETHER_BRICKS, Material.RED_NETHER_BRICK_STAIRS, Material.RED_NETHER_BRICK_SLAB, Material.RED_NETHER_BRICK_WALL,
            Material.POLISHED_BLACKSTONE_BRICKS, Material.POLISHED_BLACKSTONE_BRICK_STAIRS,
            Material.POLISHED_BLACKSTONE_BRICK_SLAB, Material.POLISHED_BLACKSTONE_BRICK_WALL,
            Material.CRACKED_POLISHED_BLACKSTONE_BRICKS, Material.CHISELED_POLISHED_BLACKSTONE,
            Material.MUD_BRICKS, Material.MUD_BRICK_STAIRS, Material.MUD_BRICK_SLAB, Material.MUD_BRICK_WALL,
            Material.STRIPPED_OAK_LOG, Material.STRIPPED_SPRUCE_LOG, Material.STRIPPED_BIRCH_LOG,
            Material.STRIPPED_JUNGLE_LOG, Material.STRIPPED_ACACIA_LOG, Material.STRIPPED_DARK_OAK_LOG,
            Material.STRIPPED_MANGROVE_LOG, Material.STRIPPED_CHERRY_LOG, Material.STRIPPED_PALE_OAK_LOG,
            Material.STRIPPED_OAK_WOOD, Material.STRIPPED_SPRUCE_WOOD, Material.STRIPPED_BIRCH_WOOD,
            Material.STRIPPED_JUNGLE_WOOD, Material.STRIPPED_ACACIA_WOOD, Material.STRIPPED_DARK_OAK_WOOD,
            Material.STRIPPED_MANGROVE_WOOD, Material.STRIPPED_CHERRY_WOOD, Material.STRIPPED_PALE_OAK_WOOD,
            Material.POLISHED_DIORITE, Material.POLISHED_DIORITE_STAIRS, Material.POLISHED_DIORITE_SLAB,
            Material.BEEHIVE, Material.BEE_NEST,
            Material.BARRIER, Material.BEDROCK, Material.SMOOTH_STONE
    );

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    public BoxRainEvent(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void scheduleNext() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getBoxRainMin()
                + random.nextInt(Math.max(1, cfg.getBoxRainMax() - cfg.getBoxRainMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::trigger, delay * 20L);
        plugin.getLogger().info("[CTB] Prochaine pluie de cartons dans " + delay + "s.");
    }

    public void trigger() {
        List<Player> targets = EventUtils.getAllCtbPlayers(plugin);
        if (targets.isEmpty()) {
            scheduleNext();
            return;
        }

        Material boxMat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        if (boxMat == null) boxMat = Material.NOTE_BLOCK;
        final BlockData fallingData = Bukkit.createBlockData(boxMat);

        List<Player> participants = new ArrayList<>();
        for (Player p : targets) {
            if (!EventUtils.isInOwnWorld(plugin, p)) continue;
            participants.add(p);
            p.sendMessage(ChatUtil.color("&3[PLUIE DE CARTONS] &fDes cartons tombent du ciel pendant 30 secondes autour de toi !"));
            p.playSound(p.getLocation(), Sound.WEATHER_RAIN, 1.0f, 1.0f);
        }

        if (participants.isEmpty()) {
            scheduleNext();
            return;
        }

        new BukkitRunnable() {
            int iteration = 0;
            final int MAX_ITERATIONS = 30;
            final int BOXES_PER_ITERATION_PER_PLAYER = 4;
            final int RADIUS = 12;

            @Override
            public void run() {
                if (iteration >= MAX_ITERATIONS) {
                    cancel();
                    return;
                }
                iteration++;

                for (Player p : participants) {
                    if (!p.isOnline() || !EventUtils.isInOwnWorld(plugin, p)) continue;
                    World w = p.getWorld();
                    Location center = p.getLocation();

                    int spawned = 0;
                    int attempts = 0;
                    while (spawned < BOXES_PER_ITERATION_PER_PLAYER && attempts < 30) {
                        attempts++;
                        double angle = random.nextDouble() * Math.PI * 2;
                        double dist = 3 + random.nextDouble() * RADIUS;
                        int x = (int) Math.round(center.getX() + Math.cos(angle) * dist);
                        int z = (int) Math.round(center.getZ() + Math.sin(angle) * dist);

                        Location groundLoc = findGroundLocation(w, x, z, center.getBlockY());
                        if (groundLoc == null) continue;

                        Location visualSpawn = groundLoc.clone().add(0.5, 12, 0.5);
                        if (!visualSpawn.getBlock().getType().isAir()) continue;

                        try {
                            FallingBlock fb = w.spawnFallingBlock(visualSpawn, fallingData);
                            fb.setDropItem(false);
                            fb.setHurtEntities(false);
                            fb.setVelocity(new Vector(0, -0.1, 0));
                            w.playSound(groundLoc, Sound.ENTITY_CHICKEN_EGG, 0.3f, 1.5f);
                            w.spawnParticle(Particle.CLOUD, visualSpawn, 5, 0.2, 0, 0.2, 0.01);
                        } catch (Throwable ignored) {
                            continue;
                        }
                        spawned++;
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);

        scheduleNext();
    }

    private boolean isValidGround(Block block) {
        Material mat = block.getType();
        if (mat.isAir()) return false;
        if (INVALID_GROUNDS.contains(mat)) return false;
        return mat.isSolid();
    }

    private Location findGroundLocation(World w, int x, int z, int referenceY) {
        int maxY = Math.min(w.getMaxHeight() - 1, referenceY + 30);
        int minY = Math.max(w.getMinHeight() + 1, referenceY - 30);

        for (int y = maxY; y >= minY; y--) {
            Block ground = w.getBlockAt(x, y, z);
            if (isValidGround(ground)) {
                Block above = w.getBlockAt(x, y + 1, z);
                if (above.getType().isAir()) {
                    return ground.getLocation();
                }
            }
        }
        return null;
    }
}
