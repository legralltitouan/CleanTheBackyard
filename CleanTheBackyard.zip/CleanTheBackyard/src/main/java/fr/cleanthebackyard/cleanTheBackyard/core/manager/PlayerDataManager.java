package fr.cleanthebackyard.cleanTheBackyard.core.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public class PlayerDataManager {
    private final CleanTheBackyard plugin;
    private final File playersFolder;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();
    private BukkitTask autoSaveTask;
    public PlayerDataManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.playersFolder = new File(plugin.getDataFolder(), "players");
        if (!playersFolder.exists()) playersFolder.mkdirs();
    }
    public void startAutoSave() {
        int interval = plugin.core().config().getAutoSaveIntervalSeconds();
        if (interval <= 0) return;
        long ticks = interval * 20L;
        // Tâche SYNC : on sérialise sur le thread main (structures stables),
        // puis on délègue l'écriture disque — coûteuse en I/O — à un thread async.
        autoSaveTask = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            List<PendingSave> pending = new ArrayList<>(cache.size());
            for (PlayerData d : cache.values()) {
                try {
                    pending.add(new PendingSave(getFile(d.getUuid()), serialize(d), d.getName()));
                } catch (Exception e) {
                    plugin.getLogger().warning("[CTB] Snapshot save fail " + d.getName() + ": " + e.getMessage());
                }
            }
            plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                for (PendingSave p : pending) {
                    try { p.yml.save(p.file); }
                    catch (IOException e) {
                        plugin.getLogger().warning("[CTB] Auto-save I/O fail " + p.name + ": " + e.getMessage());
                    }
                }
            });
        }, ticks, ticks);
    }
    private record PendingSave(File file, YamlConfiguration yml, String name) {}
    public void stopAutoSave() {
        if (autoSaveTask != null && !autoSaveTask.isCancelled()) autoSaveTask.cancel();
    }
    public PlayerData loadPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        if (cache.containsKey(uuid)) return cache.get(uuid);
        File file = getFile(uuid);
        PlayerData data;
        if (file.exists()) {
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
            data = deserialize(uuid, player.getName(), yml);
        } else {
            data = new PlayerData(uuid, player.getName());
        }
        cache.put(uuid, data);
        return data;
    }
    public PlayerData loadOfflineSnapshot(UUID uuid, String name) {
        File file = getFile(uuid);
        if (!file.exists()) return null;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        return deserialize(uuid, name, yml);
    }
    public void unloadPlayer(UUID uuid) {
        PlayerData data = cache.remove(uuid);
        if (data != null) {
            data.setLastSeenMs(System.currentTimeMillis());
            saveData(data);
        }
    }
    public void saveAll() {
        cache.values().forEach(this::saveData);
        plugin.getLogger().info("[CTB] " + cache.size() + " profil(s) sauvegardé(s).");
    }
    public PlayerData get(UUID uuid) { return cache.get(uuid); }
    public PlayerData get(Player p) { return cache.get(p.getUniqueId()); }
    public boolean isLoaded(UUID uuid) { return cache.containsKey(uuid); }
    public Collection<PlayerData> getAll() { return cache.values(); }
    /** Sauvegarde synchrone immédiate (quit, shutdown). */
    private void saveData(PlayerData data) {
        File file = getFile(data.getUuid());
        YamlConfiguration yml = serialize(data);
        try { yml.save(file); }
        catch (IOException e) {
            plugin.getLogger().severe("[CTB] Erreur sauvegarde " + data.getName() + ": " + e.getMessage());
        }
    }
    /** Construit le YamlConfiguration à partir des données. À appeler sur le thread main. */
    private YamlConfiguration serialize(PlayerData data) {
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("name", data.getName());
        yml.set("balance", data.getBalance());
        yml.set("total-earned", data.getTotalEarned());
        yml.set("lifetime-earned", data.getLifetimeEarned());
        yml.set("total-boxes-broken", data.getTotalBoxesBroken());
        yml.set("bag-level", data.getBagLevel());
        yml.set("current-boxes", data.getCurrentBoxes());
        yml.set("tool-level", data.getToolLevel());
        yml.set("energy-level", data.getEnergyLevel());
        yml.set("current-energy", data.getCurrentEnergy());
        yml.set("owned-drones", new ArrayList<>(data.getOwnedDrones()));
        yml.set("prestige-level", data.getPrestigeLevel());
        yml.set("cardboard-zone-level", data.getCardboardZoneLevel());
        yml.set("unlimited-energy-until", data.getUnlimitedEnergyUntil());
        yml.set("double-sell-until", data.getDoubleSellUntil());
        yml.set("black-market-until", data.getBlackMarketUntil());
        yml.set("security-level", data.getSecurityLevel());
        yml.set("trap-level", data.getTrapLevel());
        yml.set("total-stolen-by-rats", data.getTotalStolenByRats());
        yml.set("total-rats-killed", data.getTotalRatsKilled());
        yml.set("total-rats-scared", data.getTotalRatsScared());
        yml.set("collected-items", new ArrayList<>(data.getCollectedItems()));
        yml.set("last-seen-ms", data.getLastSeenMs());
        yml.set("talent-points", data.getTalentPoints());
        yml.set("last-daily-claim-epoch-day", data.getLastDailyClaimEpochDay());
        yml.set("daily-streak", data.getDailyStreak());
        ConfigurationSection furnSec = yml.createSection("owned-furniture");
        for (Map.Entry<String, Integer> e : new HashMap<>(data.getOwnedFurniture()).entrySet())
            furnSec.set(e.getKey(), e.getValue());
        ConfigurationSection talSec = yml.createSection("talent-tiers");
        for (Map.Entry<String, Integer> e : new HashMap<>(data.getAllTalentTiers()).entrySet())
            talSec.set(e.getKey(), e.getValue());
        ConfigurationSection modSec = yml.createSection("drone-modules");
        for (Map.Entry<String, String> e : new HashMap<>(data.getAllDroneModules()).entrySet())
            modSec.set(e.getKey(), e.getValue());
        ConfigurationSection upgSec = yml.createSection("drone-upgrades");
        for (Map.Entry<String, int[]> e : new HashMap<>(data.getAllDroneUpgrades()).entrySet()) {
            int[] t = e.getValue();
            upgSec.set(e.getKey() + ".speed", t[0]);
            upgSec.set(e.getKey() + ".range", t[1]);
            upgSec.set(e.getKey() + ".income", t[2]);
        }
        ConfigurationSection statSec = yml.createSection("drone-stats");
        for (Map.Entry<String, long[]> e : new HashMap<>(data.getAllDroneStats()).entrySet()) {
            long[] s = e.getValue();
            statSec.set(e.getKey() + ".collected", s[0]);
            statSec.set(e.getKey() + ".earned", s[1]);
        }
        yml.set("quest-reset-timestamp", data.getQuestResetTimestamp());
        List<Map<String, Object>> questList = new ArrayList<>();
        for (DailyQuest q : new ArrayList<>(data.getDailyQuests())) {
            Map<String, Object> m = new HashMap<>();
            m.put("type", q.getType().name());
            m.put("target", q.getTarget());
            m.put("progress", q.getProgress());
            m.put("reward", q.getReward());
            m.put("claimed", q.isClaimed());
            questList.add(m);
        }
        yml.set("daily-quests", questList);
        return yml;
    }
    private PlayerData deserialize(UUID uuid, String name, YamlConfiguration yml) {
        PlayerData d = new PlayerData(uuid, name);
        d.setBalance(yml.getDouble("balance", 0));
        long legacyStash = yml.getLong("stash-balance", 0L);
        if (legacyStash > 0) d.setBalance(d.getBalance() + legacyStash);
        d.setLifetimeEarned(yml.getLong("lifetime-earned", 0L));
        d.setTotalBoxesBroken(yml.getLong("total-boxes-broken", 0L));
        d.setBagLevel(yml.getInt("bag-level", 1));
        d.setCurrentBoxes(yml.getInt("current-boxes", 0));
        d.setToolLevel(yml.getInt("tool-level", 1));
        d.setTotalEarned(yml.getLong("total-earned", 0L));
        d.setEnergyLevel(yml.getInt("energy-level", 1));
        d.setCurrentEnergy(yml.getDouble("current-energy", 100));
        d.setPrestigeLevel(yml.getInt("prestige-level", 0));
        d.setCardboardZoneLevel(yml.getInt("cardboard-zone-level", 0));
        List<?> drones = yml.getList("owned-drones", new ArrayList<>());
        for (Object o : drones) if (o instanceof String s) d.addDrone(s);
        d.setRawUnlimitedEnergyUntil(yml.getLong("unlimited-energy-until", 0L));
        d.setRawDoubleSellUntil(yml.getLong("double-sell-until", 0L));
        d.setRawBlackMarketUntil(yml.getLong("black-market-until", 0L));
        d.setSecurityLevel(yml.getInt("security-level", 0));
        d.setTrapLevel(yml.getInt("trap-level", 0));
        d.setTotalStolenByRats(yml.getLong("total-stolen-by-rats", 0L));
        d.setTotalRatsKilled(yml.getLong("total-rats-killed", 0L));
        d.setTotalRatsScared(yml.getLong("total-rats-scared", 0L));
        d.setLastSeenMs(yml.getLong("last-seen-ms", 0L));
        d.setTalentPoints(yml.getInt("talent-points", 0));
        d.setLastDailyClaimEpochDay(yml.getLong("last-daily-claim-epoch-day", 0L));
        d.setDailyStreak(yml.getInt("daily-streak", 0));
        List<?> collected = yml.getList("collected-items", new ArrayList<>());
        List<String> collectedStr = new ArrayList<>();
        for (Object o : collected) if (o instanceof String s) collectedStr.add(s);
        d.setCollectedItems(collectedStr);
        ConfigurationSection furnSec = yml.getConfigurationSection("owned-furniture");
        if (furnSec != null) {
            Map<String, Integer> furnMap = new HashMap<>();
            for (String key : furnSec.getKeys(false)) furnMap.put(key, furnSec.getInt(key, 0));
            d.setOwnedFurniture(furnMap);
        }
        ConfigurationSection talSec = yml.getConfigurationSection("talent-tiers");
        if (talSec != null) {
            Map<String, Integer> talMap = new HashMap<>();
            for (String key : talSec.getKeys(false)) talMap.put(key, talSec.getInt(key, 0));
            d.setAllTalentTiers(talMap);
        }
        ConfigurationSection modSec = yml.getConfigurationSection("drone-modules");
        if (modSec != null) {
            Map<String, String> modMap = new HashMap<>();
            for (String key : modSec.getKeys(false)) {
                String v = modSec.getString(key);
                if (v != null && !v.isEmpty()) modMap.put(key, v);
            }
            d.setAllDroneModules(modMap);
        }
        ConfigurationSection upgSec = yml.getConfigurationSection("drone-upgrades");
        if (upgSec != null) {
            for (String key : upgSec.getKeys(false)) {
                int[] tiers = new int[]{
                        upgSec.getInt(key + ".speed", 0),
                        upgSec.getInt(key + ".range", 0),
                        upgSec.getInt(key + ".income", 0)
                };
                d.setDroneUpgrades(key, tiers);
            }
        }
        ConfigurationSection statSec = yml.getConfigurationSection("drone-stats");
        if (statSec != null) {
            for (String key : statSec.getKeys(false)) {
                long collectedStat = statSec.getLong(key + ".collected", 0L);
                long earned = statSec.getLong(key + ".earned", 0L);
                long[] arr = d.getDroneStats(key);
                arr[0] = collectedStat;
                arr[1] = earned;
            }
        }
        d.setQuestResetTimestamp(yml.getLong("quest-reset-timestamp", 0L));
        List<?> rawQuests = yml.getList("daily-quests", new ArrayList<>());
        List<DailyQuest> quests = new ArrayList<>();
        for (Object o : rawQuests) {
            if (o instanceof Map<?, ?> m) {
                try {
                    DailyQuest.Type type = DailyQuest.Type.valueOf((String) m.get("type"));
                    long target = ((Number) m.get("target")).longValue();
                    long progress = ((Number) m.get("progress")).longValue();
                    long reward = ((Number) m.get("reward")).longValue();
                    boolean claimed = (Boolean) m.get("claimed");
                    quests.add(new DailyQuest(type, target, reward, progress, claimed));
                } catch (Exception ignored) {}
            }
        }
        d.setDailyQuests(quests);
        return d;
    }
    private File getFile(UUID uuid) { return new File(playersFolder, uuid.toString() + ".yml"); }
}