package fr.cleanthebackyard.cleanTheBackyard.entity;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.provider.CustomEntityHandle;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;

import java.util.HashSet;
import java.util.Set;

public class DroneEntity {
    private static final Set<String> lockedBoxes = new HashSet<>();
    private static final long CHASE_TIMEOUT_TICKS = 200;
    private static final long SELL_TIMEOUT_TICKS = 200;
    private static final long TASK_PERIOD = 1L; // tick à chaque tick pour fluidité
    private static final long NAME_UPDATE_INTERVAL = 10L;
    private static final long STUCK_THRESHOLD_TICKS = 40;
    private static final long STUCK_BOOST_LIMIT = 60;

    private final CleanTheBackyard plugin;
    private final Player owner;
    private final PluginConfig.DroneConfig config;
    private final CustomEntityHandle entity;
    private final double speed;
    private final int pickupRange;
    private final double incomeMultiplier;
    private final BlockRef boxRef;
    private final World world;
    private final int[] tiers;

    public enum State { IDLE, MOVING_TO_BOX, MOVING_TO_SELL, NO_TARGET }
    private State state = State.IDLE;
    private Location targetLocation;
    private Location lastBoxTarget;
    private BukkitRunnable task;
    private long collectedSinceSpawn = 0;
    private long tickCounter = 0;
    private long stateTickCounter = 0;
    private double lastDistance = Double.MAX_VALUE;
    private int stuckTicks = 0;

    private TextDisplay hologram;

    // Interpolation de mouvement (position cible vs position lissée)
    private Vector currentVelocity = new Vector(0, 0, 0);

    public DroneEntity(Player owner, PluginConfig.DroneConfig config) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.config = config;
        this.world = owner.getWorld();
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        this.tiers = (data != null) ? data.getDroneUpgrades(config.key()) : new int[]{0, 0, 0};
        double speedBonus = 1.0 + tiers[0] * plugin.getPluginConfig().getDroneSpeedTierBonus();
        double rangeBonus = 1.0 + tiers[1] * plugin.getPluginConfig().getDroneRangeTierBonus();
        double incomeBonus = 1.0 + tiers[2] * plugin.getPluginConfig().getDroneIncomeTierBonus();
        this.speed = config.speed() * speedBonus;
        this.pickupRange = (int) Math.round(config.pickupRange() * rangeBonus);
        this.incomeMultiplier = incomeBonus;
        this.boxRef = plugin.getPluginConfig().getBoxBlockRef();

        Location spawnLoc = plugin.getPluginConfig().getSellZoneCenter(world).clone().add(0, 2, 0);
        this.entity = plugin.getEntityProvider().spawn(config.entityRef(), spawnLoc, EntityType.BEE, "drone");
        Entity bukkit = entity.getBukkitEntity();

        hologram = bukkit.getWorld().spawn(
                bukkit.getLocation().clone().add(0, 2.2, 0),
                TextDisplay.class
        );

        hologram.setBillboard(Display.Billboard.CENTER);
        hologram.setSeeThrough(true);
        hologram.setShadowed(false);
        hologram.setDefaultBackground(false);
        hologram.setPersistent(false);


        bukkit.setSilent(true);
        bukkit.setInvulnerable(true);
        if (bukkit instanceof LivingEntity le) {
            le.setAI(false);
            le.setCanPickupItems(false);
            le.setRemoveWhenFarAway(false);
        }
        updateName();
        startTask();
    }

    public String getKey() { return config.key(); }
    public State getState() { return state; }
    public long getCollectedSinceSpawn() { return collectedSinceSpawn; }

    private void updateName() {
        if (!entity.isValid() || hologram == null || !hologram.isValid()) return;

        String statusColor;
        String statusText;

        switch (state) {
            case IDLE -> {
                statusColor = "&7";
                statusText = "RECHERCHE";
            }
            case MOVING_TO_BOX -> {
                statusColor = "&e";
                statusText = "CHASSE";
            }
            case MOVING_TO_SELL -> {
                statusColor = "&a";
                statusText = "TRANSPORT";
            }
            case NO_TARGET -> {
                statusColor = "&c";
                statusText = "INACTIF";
            }
            default -> {
                statusColor = "&7";
                statusText = "?";
            }
        }

        String tierLabel = "&8[V" + tiers[0] + " R" + tiers[1] + " I" + tiers[2] + "]";

        String text =
                "&6✦ " + config.name() + "\n" +
                        statusColor + statusText + "\n" +
                        tierLabel + " &7| &b" + NumberFormatUtil.format(collectedSinceSpawn) +
                        " &7| &f" + owner.getName();

        hologram.setText(ChatUtil.color(text));
    }

    private void setState(State newState) {
        if (state != newState) {
            state = newState;
            stateTickCounter = 0;
            lastDistance = Double.MAX_VALUE;
            stuckTicks = 0;
            currentVelocity = new Vector(0, 0, 0);
            updateName();
        }
    }

    private void releaseLock() {
        if (lastBoxTarget != null) {
            lockedBoxes.remove(LocationUtil.locKey(lastBoxTarget));
            lastBoxTarget = null;
        }
    }

    private void abortAndReset() {
        releaseLock();
        targetLocation = null;
        setState(State.IDLE);
    }

    private void startTask() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!entity.isValid() || !owner.isOnline() || !owner.isValid()) {
                    stop();
                    return;
                }
                if (!owner.getWorld().equals(world)) {
                    stop();
                    return;
                }

                if (hologram != null && hologram.isValid()) {
                    hologram.teleport(
                            entity.getBukkitEntity()
                                    .getLocation()
                                    .clone()
                                    .add(0, 2.2, 0)
                    );
                }

                tickCounter++;
                stateTickCounter++;
                switch (state) {
                    case IDLE, NO_TARGET -> {
                        // Pas besoin de chercher à chaque tick — toutes les 5 ticks suffit
                        if (tickCounter % 5 == 0) findNewTarget();
                    }
                    case MOVING_TO_BOX -> {
                        if (stateTickCounter > CHASE_TIMEOUT_TICKS) {
                            abortAndReset();
                            return;
                        }
                        if (targetLocation != null && tickCounter % 5 == 0) {
                            Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
                            if (!plugin.getBlockProvider().isCarton(blockLoc.getBlock(), boxRef)) {
                                abortAndReset();
                                return;
                            }
                        }
                        moveTowardsTarget();
                    }
                    case MOVING_TO_SELL -> {
                        if (stateTickCounter > SELL_TIMEOUT_TICKS) {
                            sellBox();
                            releaseLock();
                            targetLocation = null;
                            setState(State.IDLE);
                            return;
                        }
                        moveTowardsTarget();
                    }
                }
                if (tickCounter % NAME_UPDATE_INTERVAL == 0) updateName();
            }
        };
        task.runTaskTimer(plugin, 0L, TASK_PERIOD);
    }

    private void findNewTarget() {
        Location nearestBox = findNearestBox();
        if (nearestBox != null) {
            targetLocation = nearestBox.clone().add(0.5, 0.5, 0.5);
            setState(State.MOVING_TO_BOX);
        } else {
            if (state != State.NO_TARGET) setState(State.NO_TARGET);
        }
    }

    private Location findNearestBox() {
        Location droneLoc = entity.getBukkitEntity().getLocation();
        double bestDistSq = pickupRange * pickupRange;
        Location best = null;
        int minX = droneLoc.getBlockX() - pickupRange;
        int maxX = droneLoc.getBlockX() + pickupRange;
        int minZ = droneLoc.getBlockZ() - pickupRange;
        int maxZ = droneLoc.getBlockZ() + pickupRange;
        int minY = Math.max(world.getMinHeight(), droneLoc.getBlockY() - 5);
        int maxY = Math.min(world.getMaxHeight(), droneLoc.getBlockY() + 5);
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    Location loc = new Location(world, x, y, z);
                    if (plugin.getBlockProvider().isCarton(loc.getBlock(), boxRef)) {
                        String key = LocationUtil.locKey(loc);
                        if (lockedBoxes.contains(key)) continue;
                        double distSq = droneLoc.distanceSquared(loc);
                        if (distSq < bestDistSq) {
                            bestDistSq = distSq;
                            best = loc;
                        }
                    }
                }
            }
        }
        if (best != null) {
            lockedBoxes.add(LocationUtil.locKey(best));
            lastBoxTarget = best.clone();
        }
        return best;
    }

    private void moveTowardsTarget() {
        if (targetLocation == null) {
            setState(State.IDLE);
            return;
        }
        Entity bukkit = entity.getBukkitEntity();
        Location current = bukkit.getLocation();
        double distance = current.distance(targetLocation);

        // Détection blocage
        if (Math.abs(distance - lastDistance) < 0.02) {
            stuckTicks++;
            if (stuckTicks > STUCK_THRESHOLD_TICKS) {
                if (stuckTicks < STUCK_BOOST_LIMIT) {
                    // Petit coup de pouce vertical, sans casser la fluidité
                    bukkit.teleport(current.clone().add(0, 0.4, 0));
                    currentVelocity = new Vector(0, 0, 0);
                } else {
                    abortAndReset();
                    return;
                }
            }
        } else {
            stuckTicks = 0;
        }
        lastDistance = distance;

        // Arrivée
        if (distance < 0.7) {
            if (state == State.MOVING_TO_BOX) {
                collectBox();
                targetLocation = plugin.getPluginConfig().getSellZoneCenter(world);
                setState(State.MOVING_TO_SELL);
            } else if (state == State.MOVING_TO_SELL) {
                sellBox();
                releaseLock();
                targetLocation = null;
                setState(State.IDLE);
            }
            return;
        }

        // Direction désirée
        Vector desiredDirection = targetLocation.toVector().subtract(current.toVector()).normalize();

        // Vitesse linéaire par tick (speed est en blocs/seconde, donc /20)
        double stepPerTick = speed / 20.0;
        // Ralentit doucement à l'approche pour éviter l'overshoot (smooth landing)
        if (distance < 2.0) {
            stepPerTick *= Math.max(0.35, distance / 2.0);
        }

        Vector desiredVelocity = desiredDirection.multiply(stepPerTick);

        // Interpolation : lisse la vélocité actuelle vers la cible (steering smooth)
        double smoothing = 0.35; // 0 = aucun changement, 1 = changement instant
        currentVelocity.setX(currentVelocity.getX() + (desiredVelocity.getX() - currentVelocity.getX()) * smoothing);
        currentVelocity.setY(currentVelocity.getY() + (desiredVelocity.getY() - currentVelocity.getY()) * smoothing);
        currentVelocity.setZ(currentVelocity.getZ() + (desiredVelocity.getZ() - currentVelocity.getZ()) * smoothing);

        // Clamp pour ne jamais dépasser le pas autorisé
        if (currentVelocity.length() > stepPerTick) {
            currentVelocity = currentVelocity.normalize().multiply(stepPerTick);
        }

        // Évite l'overshoot si on est très proche
        double moveLen = currentVelocity.length();
        if (moveLen > distance) {
            currentVelocity = currentVelocity.normalize().multiply(distance);
        }

        Location newLoc = current.clone().add(currentVelocity);

        // Rotation lisse — on suit la direction de mouvement réelle
        if (currentVelocity.lengthSquared() > 0.0001) {
            float targetYaw = (float) Math.toDegrees(Math.atan2(-currentVelocity.getX(), currentVelocity.getZ()));
            float targetPitch = (float) Math.toDegrees(-Math.asin(Math.max(-1.0, Math.min(1.0, currentVelocity.getY() / Math.max(0.001, currentVelocity.length())))));
            newLoc.setYaw(lerpAngle(current.getYaw(), targetYaw, 0.4f));
            newLoc.setPitch(lerpAngle(current.getPitch(), targetPitch, 0.4f));
        } else {
            newLoc.setYaw(current.getYaw());
            newLoc.setPitch(current.getPitch());
        }

        bukkit.teleport(newLoc);
    }

    private float lerpAngle(float from, float to, float t) {
        float diff = ((to - from) % 360 + 540) % 360 - 180;
        return from + diff * t;
    }

    private void collectBox() {
        if (targetLocation == null) return;
        Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
        if (plugin.getBlockProvider().isCarton(blockLoc.getBlock(), boxRef)) {
            plugin.getBlockProvider().breakCarton(blockLoc.getBlock(), boxRef);
            plugin.getEventManager().onBoxBroken(blockLoc);
            blockLoc.getWorld().playSound(blockLoc, org.bukkit.Sound.BLOCK_STONE_BREAK, 0.5f, 1.0f);
        } else {
            releaseLock();
            targetLocation = null;
            setState(State.IDLE);
        }
    }

    private void sellBox() {
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        if (data == null) return;
        double price = plugin.getPluginConfig().getBoxSellPrice() * incomeMultiplier;
        plugin.getEconomyManager().credit(owner, price);
        collectedSinceSpawn++;
        data.incrementDroneCollected(config.key());
        data.addDroneEarnings(config.key(), (long) price);
        owner.getWorld().playSound(owner.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
    }

    public void stop() {
        if (task != null && !task.isCancelled()) {
            task.cancel();
        }

        if (hologram != null && hologram.isValid()) {
            hologram.remove();
        }

        entity.remove();
        releaseLock();
    }
}
