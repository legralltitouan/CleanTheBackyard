package fr.cleanthebackyard.cleanTheBackyard.entity;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Bee;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import java.util.HashSet;
import java.util.Set;
public class DroneEntity {
    private static final Set<String> lockedBoxes = new HashSet<>();
    // Timeouts (en ticks, 1 tick = ~100ms vu que le task tourne toutes les 2 ticks)
    private static final long CHASE_TIMEOUT_TICKS = 200; // 20s max pour atteindre une box
    private static final long SELL_TIMEOUT_TICKS  = 200; // 20s max pour rentrer vendre
    private final CleanTheBackyard plugin;
    private final Player owner;
    private final PluginConfig.DroneConfig config;
    private final Bee entity;
    private final double speed;
    private final int pickupRange;
    private final double incomeMultiplier;
    private final Material boxMaterial;
    private final World world;
    public enum State { IDLE, MOVING_TO_BOX, MOVING_TO_SELL, NO_TARGET }
    private State state = State.IDLE;
    private Location targetLocation;
    private Location lastBoxTarget;
    private BukkitRunnable task;
    private long collectedSinceSpawn = 0;
    private long idleTicksCounter = 0;
    private long stateTickCounter = 0; // compteur depuis le dernier changement d'état
    private double lastDistance = Double.MAX_VALUE;
    private int stuckTicks = 0;
    public DroneEntity(Player owner, PluginConfig.DroneConfig config) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.config = config;
        this.world = owner.getWorld();
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        int[] tiers = (data != null) ? data.getDroneUpgrades(config.key()) : new int[]{0, 0, 0};
        double speedBonus  = 1.0 + tiers[0] * plugin.getPluginConfig().getDroneSpeedTierBonus();
        double rangeBonus  = 1.0 + tiers[1] * plugin.getPluginConfig().getDroneRangeTierBonus();
        double incomeBonus = 1.0 + tiers[2] * plugin.getPluginConfig().getDroneIncomeTierBonus();
        this.speed = config.speed() * speedBonus;
        this.pickupRange = (int) Math.round(config.pickupRange() * rangeBonus);
        this.incomeMultiplier = incomeBonus;
        String boxMatName = plugin.getPluginConfig().getBoxBlock();
        Material mat = Material.matchMaterial(boxMatName);
        this.boxMaterial = (mat != null) ? mat : Material.NOTE_BLOCK;
        Location spawnLoc = plugin.getPluginConfig().getSellZoneCenter(world).clone().add(0, 2, 0);
        this.entity = (Bee) world.spawnEntity(spawnLoc, EntityType.BEE);
        this.entity.setCustomNameVisible(true);
        this.entity.setSilent(true);
        this.entity.setInvulnerable(true);
        this.entity.setAI(false);
        this.entity.setCanPickupItems(false);
        this.entity.setRemoveWhenFarAway(false);
        updateName();
        startTask();
    }
    public String getKey() { return config.key(); }
    private void updateName() {
        if (entity == null || !entity.isValid()) return;
        String statusColor;
        String statusText;
        switch (state) {
            case IDLE -> { statusColor = "&7"; statusText = "RECHERCHE"; }
            case MOVING_TO_BOX -> { statusColor = "&e"; statusText = "CHASSE"; }
            case MOVING_TO_SELL -> { statusColor = "&a"; statusText = "TRANSPORT"; }
            case NO_TARGET -> { statusColor = "&c"; statusText = "INACTIF (0 carton)"; }
            default -> { statusColor = "&7"; statusText = "?"; }
        }
        entity.setCustomName(ChatUtil.color(
                "&6" + config.name() + " " + statusColor + "[" + statusText + "] &7| &b" + collectedSinceSpawn
        ));
    }
    private String lockKey(Location loc) {
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }
    private void setState(State newState) {
        if (state != newState) {
            state = newState;
            stateTickCounter = 0;
            lastDistance = Double.MAX_VALUE;
            stuckTicks = 0;
            updateName();
        }
    }
    private void releaseLock() {
        if (lastBoxTarget != null) {
            lockedBoxes.remove(lockKey(lastBoxTarget));
            lastBoxTarget = null;
        }
    }
    private void abortAndReset() {
        releaseLock();
        targetLocation = null;
        setState(State.IDLE);
    }
    private void startTask() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                if (entity.isDead() || !owner.isOnline() || !owner.isValid()) {
                    stop();
                    return;
                }
                if (!owner.getWorld().equals(world)) {
                    stop();
                    return;
                }
                stateTickCounter++;
                switch (state) {
                    case IDLE, NO_TARGET -> findNewTarget();
                    case MOVING_TO_BOX -> {
                        // Timeout chasse
                        if (stateTickCounter > CHASE_TIMEOUT_TICKS) {
                            abortAndReset();
                            return;
                        }
                        // Vérif que la box existe toujours
                        if (targetLocation != null) {
                            Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
                            if (blockLoc.getBlock().getType() != boxMaterial) {
                                abortAndReset();
                                return;
                            }
                        }
                        moveTowardsTarget();
                    }
                    case MOVING_TO_SELL -> {
                        if (stateTickCounter > SELL_TIMEOUT_TICKS) {
                            // On force la vente même si on n'y arrive pas
                            sellBox();
                            releaseLock();
                            targetLocation = null;
                            setState(State.IDLE);
                            return;
                        }
                        moveTowardsTarget();
                    }
                }
                if (idleTicksCounter++ % 10 == 0) updateName();
            }
        };
        task.runTaskTimer(plugin, 0L, 2L);
    }
    private void findNewTarget() {
        Location nearestBox = findNearestBox();
        if (nearestBox != null) {
            targetLocation = nearestBox.clone().add(0.5, 0.5, 0.5);
            setState(State.MOVING_TO_BOX);
        } else {
            if (state != State.NO_TARGET) setState(State.NO_TARGET);
        }
    }
    private Location findNearestBox() {
        Location droneLoc = entity.getLocation();
        double bestDistSq = pickupRange * pickupRange;
        Location best = null;
        int minX = droneLoc.getBlockX() - pickupRange;
        int maxX = droneLoc.getBlockX() + pickupRange;
        int minZ = droneLoc.getBlockZ() - pickupRange;
        int maxZ = droneLoc.getBlockZ() + pickupRange;
        int minY = Math.max(world.getMinHeight(), droneLoc.getBlockY() - 5);
        int maxY = Math.min(world.getMaxHeight(), droneLoc.getBlockY() + 5);
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    Location loc = new Location(world, x, y, z);
                    if (loc.getBlock().getType() == boxMaterial) {
                        String key = lockKey(loc);
                        if (lockedBoxes.contains(key)) continue;
                        double distSq = droneLoc.distanceSquared(loc);
                        if (distSq < bestDistSq) {
                            bestDistSq = distSq;
                            best = loc;
                        }
                    }
                }
            }
        }
        if (best != null) {
            lockedBoxes.add(lockKey(best));
            lastBoxTarget = best.clone();
        }
        return best;
    }
    private void moveTowardsTarget() {
        if (targetLocation == null) {
            setState(State.IDLE);
            return;
        }
        Location current = entity.getLocation();
        double distance = current.distance(targetLocation);
        // Détection de blocage : si on n'avance pas pendant 20 ticks (~2s)
        if (Math.abs(distance - lastDistance) < 0.05) {
            stuckTicks++;
            if (stuckTicks > 20) {
                // On essaie un petit boost vertical pour se débloquer
                if (stuckTicks < 30) {
                    Location boosted = current.clone().add(0, 0.5, 0);
                    entity.teleport(boosted);
                } else {
                    // Vraiment bloqué : on abandonne cette cible
                    abortAndReset();
                    return;
                }
            }
        } else {
            stuckTicks = 0;
        }
        lastDistance = distance;
        if (distance < 0.7) {
            if (state == State.MOVING_TO_BOX) {
                collectBox();
                targetLocation = plugin.getPluginConfig().getSellZoneCenter(world);
                setState(State.MOVING_TO_SELL);
            } else if (state == State.MOVING_TO_SELL) {
                sellBox();
                releaseLock();
                targetLocation = null;
                setState(State.IDLE);
            }
            return;
        }
        Vector direction = targetLocation.toVector().subtract(current.toVector()).normalize();
        double step = speed / 20.0;
        // Cap le déplacement par tick à la distance restante pour éviter de dépasser
        step = Math.min(step, distance);
        Location newLoc = current.clone().add(direction.multiply(step));
        entity.teleport(newLoc);
        entity.setRotation(
                (float) Math.toDegrees(Math.atan2(-direction.getX(), direction.getZ())),
                (float) Math.toDegrees(Math.asin(direction.getY()))
        );
    }
    private void collectBox() {
        if (targetLocation == null) return;
        Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
        if (blockLoc.getBlock().getType() == boxMaterial) {
            blockLoc.getBlock().setType(Material.AIR);
            plugin.getSectorManager().markBroken(blockLoc);
            blockLoc.getWorld().playSound(blockLoc, org.bukkit.Sound.BLOCK_STONE_BREAK, 0.5f, 1.0f);
        } else {
            // Box volée par un joueur ou autre drone : on abandonne proprement
            releaseLock();
            targetLocation = null;
            setState(State.IDLE);
        }
    }
    private void sellBox() {
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        if (data == null) return;
        double price = plugin.getPluginConfig().getBoxSellPrice() * incomeMultiplier;
        plugin.getEconomyManager().credit(owner, price);
        collectedSinceSpawn++;
        data.incrementDroneCollected(config.key());
        data.addDroneEarnings(config.key(), (long) price);
        owner.getWorld().playSound(owner.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
    }
    public State getState() { return state; }
    public long getCollectedSinceSpawn() { return collectedSinceSpawn; }
    public void stop() {
        if (task != null && !task.isCancelled()) task.cancel();
        if (entity != null && entity.isValid()) entity.remove();
        releaseLock();
    }
}