package fr.cleanthebackyard.cleanTheBackyard.entity;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.provider.CustomEntityHandle;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ThreadLocalRandom;
public class DroneEntity {
    private static final Set<String> lockedBoxes = new HashSet<>();
    private static final long CHASE_TIMEOUT_TICKS = 200;
    private static final long SELL_TIMEOUT_TICKS = 200;
    private static final long TASK_PERIOD = 1L;
    private static final long NAME_UPDATE_INTERVAL = 10L;
    private static final long STUCK_THRESHOLD_TICKS = 40;
    private static final long STUCK_BOOST_LIMIT = 60;
    // Borne dure relevée pour couvrir les zones étendues au max.
    private static final int HARD_RANGE_CAP = 160;
    // Profondeur verticale du scan (au-dessus/dessous du drone).
    private static final int VERTICAL_SCAN = 8;
    // Intervalle (en ticks) entre deux recherches de cible lorsqu'on est en IDLE/NO_TARGET.
    private static final long FIND_TARGET_INTERVAL = 5L;
    // Intervalle de re-vérification que le carton ciblé existe encore.
    private static final long TARGET_RECHECK_INTERVAL = 5L;
    private final CleanTheBackyard plugin;
    private final Player owner;
    private final PluginConfig.DroneConfig config;
    private final CustomEntityHandle entity;
    private final double speed;
    private final int pickupRange;
    private final double incomeMultiplier;
    private final BlockRef boxRef;
    private final World world;
    private final int[] tiers;
    // ── Effets de module ──
    private final double moduleCollectibleBonus;
    private final double moduleSaveChance;
    // Location mutable réutilisée pour le scan de blocs (évite des milliers d'allocations/s).
    private final Location scanCursor;
    public enum State { IDLE, MOVING_TO_BOX, MOVING_TO_SELL, NO_TARGET }
    private State state = State.IDLE;
    private Location targetLocation;
    private Location lastBoxTarget;
    private BukkitRunnable task;
    private long collectedSinceSpawn = 0;
    private long tickCounter = 0;
    private long stateTickCounter = 0;
    private double lastDistance = Double.MAX_VALUE;
    private int stuckTicks = 0;
    private TextDisplay hologram;
    private Vector currentVelocity = new Vector(0, 0, 0);
    public DroneEntity(Player owner, PluginConfig.DroneConfig config) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.config = config;
        this.world = owner.getWorld();
        this.scanCursor = new Location(world, 0, 0, 0);
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        this.tiers = (data != null) ? data.getDroneUpgrades(config.key()) : new int[]{0, 0, 0};
        double speedBonus = 1.0 + tiers[0] * plugin.getPluginConfig().getDroneSpeedTierBonus();
        double rangeBonus = 1.0 + tiers[1] * plugin.getPluginConfig().getDroneRangeTierBonus();
        double incomeBonus = 1.0 + tiers[2] * plugin.getPluginConfig().getDroneIncomeTierBonus();
        if (data != null) incomeBonus *= plugin.getTalentManager().getDroneIncomeMultiplier(data);
        double collectibleBonus = 0.0;
        double saveChance = 0.0;
        String moduleKey = data != null ? data.getDroneModule(config.key()) : null;
        if (moduleKey != null) {
            var mod = plugin.getPluginConfig().getDroneModule(moduleKey);
            if (mod != null) {
                speedBonus += mod.speedBonus();
                rangeBonus += mod.rangeBonus();
                collectibleBonus = mod.collectibleBonus();
                saveChance = mod.saveChance();
            }
        }
        this.moduleCollectibleBonus = collectibleBonus;
        this.moduleSaveChance = saveChance;
        this.speed = config.speed() * speedBonus;
        int rawRange = (int) Math.round(config.pickupRange() * rangeBonus);
        this.pickupRange = Math.min(HARD_RANGE_CAP, Math.max(1, rawRange));
        this.incomeMultiplier = incomeBonus;
        this.boxRef = plugin.getPluginConfig().getBoxBlockRef();
        Location spawnLoc = plugin.getPluginConfig().getSellZoneCenter(world).clone().add(0, 2, 0);
        this.entity = plugin.getEntityProvider().spawn(config.entityRef(), spawnLoc, EntityType.BEE, "drone");
        Entity bukkit = entity.getBukkitEntity();
        hologram = bukkit.getWorld().spawn(
                bukkit.getLocation().clone().add(0, 2.2, 0),
                TextDisplay.class
        );
        hologram.setBillboard(Display.Billboard.CENTER);
        hologram.setSeeThrough(true);
        hologram.setShadowed(false);
        hologram.setDefaultBackground(false);
        hologram.setPersistent(false);
        bukkit.setSilent(true);
        bukkit.setInvulnerable(true);
        if (bukkit instanceof LivingEntity le) {
            le.setAI(false);
            le.setCanPickupItems(false);
            le.setRemoveWhenFarAway(false);
        }
        updateName();
        startTask();
    }
    public String getKey() { return config.key(); }
    public State getState() { return state; }
    public long getCollectedSinceSpawn() { return collectedSinceSpawn; }
    private void updateName() {
        if (!entity.isValid() || hologram == null || !hologram.isValid()) return;
        String statusColor;
        String statusText;
        switch (state) {
            case IDLE -> { statusColor = "&7"; statusText = "RECHERCHE"; }
            case MOVING_TO_BOX -> { statusColor = "&e"; statusText = "CHASSE"; }
            case MOVING_TO_SELL -> { statusColor = "&a"; statusText = "TRANSPORT"; }
            case NO_TARGET -> { statusColor = "&c"; statusText = "INACTIF"; }
            default -> { statusColor = "&7"; statusText = "?"; }
        }
        String tierLabel = "&8[V" + tiers[0] + " R" + tiers[1] + " I" + tiers[2] + "]";
        String text =
                "&6✦ " + config.name() + "\n" +
                        statusColor + statusText + "\n" +
                        tierLabel + " &7| &b" + NumberFormatUtil.format(collectedSinceSpawn) +
                        " &7| &f" + owner.getName();
        hologram.setText(ChatUtil.color(text));
    }
    private void setState(State newState) {
        if (state != newState) {
            state = newState;
            stateTickCounter = 0;
            lastDistance = Double.MAX_VALUE;
            stuckTicks = 0;
            currentVelocity = new Vector(0, 0, 0);
            updateName();
        }
    }
    private void releaseLock() {
        if (lastBoxTarget != null) {
            lockedBoxes.remove(LocationUtil.locKey(lastBoxTarget));
            lastBoxTarget = null;
        }
    }
    private void abortAndReset() {
        releaseLock();
        targetLocation = null;
        setState(State.IDLE);
    }
    private void startTask() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!entity.isValid() || !owner.isOnline() || !owner.isValid()) { stop(); return; }
                if (!owner.getWorld().equals(world)) { stop(); return; }
                if (hologram != null && hologram.isValid()) {
                    hologram.teleport(entity.getBukkitEntity().getLocation().clone().add(0, 2.2, 0));
                }
                tickCounter++;
                stateTickCounter++;
                switch (state) {
                    case IDLE, NO_TARGET -> { if (tickCounter % FIND_TARGET_INTERVAL == 0) findNewTarget(); }
                    case MOVING_TO_BOX -> {
                        if (stateTickCounter > CHASE_TIMEOUT_TICKS) { abortAndReset(); return; }
                        if (targetLocation != null && tickCounter % TARGET_RECHECK_INTERVAL == 0) {
                            Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
                            if (!plugin.getBlockProvider().isCarton(blockLoc.getBlock(), boxRef)) {
                                abortAndReset();
                                return;
                            }
                        }
                        moveTowardsTarget();
                    }
                    case MOVING_TO_SELL -> {
                        if (stateTickCounter > SELL_TIMEOUT_TICKS) {
                            sellBox();
                            releaseLock();
                            targetLocation = null;
                            setState(State.IDLE);
                            return;
                        }
                        moveTowardsTarget();
                    }
                }
                if (tickCounter % NAME_UPDATE_INTERVAL == 0) updateName();
            }
        };
        task.runTaskTimer(plugin, 0L, TASK_PERIOD);
    }
    private void findNewTarget() {
        Location nearestBox = findNearestBox();
        if (nearestBox != null) {
            targetLocation = nearestBox.clone().add(0.5, 0.5, 0.5);
            setState(State.MOVING_TO_BOX);
        } else {
            if (state != State.NO_TARGET) setState(State.NO_TARGET);
        }
    }
    /**
     * Scan optimisé : Location mutable réutilisée, ordre Y→Z→X (favorable au cache
     * de section de chunk), comparaison de distance entière rapide pour le pré-filtrage.
     */
    private Location findNearestBox() {
        Location droneLoc = entity.getBukkitEntity().getLocation();
        final int dcx = droneLoc.getBlockX();
        final int dcy = droneLoc.getBlockY();
        final int dcz = droneLoc.getBlockZ();
        double bestDistSq = (double) pickupRange * pickupRange;
        int bestX = 0, bestY = 0, bestZ = 0;
        boolean found = false;
        final int minX = dcx - pickupRange;
        final int maxX = dcx + pickupRange;
        final int minZ = dcz - pickupRange;
        final int maxZ = dcz + pickupRange;
        final int minY = Math.max(world.getMinHeight(), dcy - VERTICAL_SCAN);
        final int maxY = Math.min(world.getMaxHeight(), dcy + VERTICAL_SCAN);
        for (int y = minY; y <= maxY; y++) {
            double dyc = (y + 0.5) - droneLoc.getY();
            double dySq = dyc * dyc;
            for (int z = minZ; z <= maxZ; z++) {
                double dzc = (z + 0.5) - droneLoc.getZ();
                double dzSq = dzc * dzc;
                // Si même au plus proche en X on dépasse déjà, inutile de scanner la ligne.
                if (dySq + dzSq >= bestDistSq) continue;
                for (int x = minX; x <= maxX; x++) {
                    double dxc = (x + 0.5) - droneLoc.getX();
                    double distSq = dxc * dxc + dySq + dzSq;
                    if (distSq >= bestDistSq) continue;
                    scanCursor.setX(x);
                    scanCursor.setY(y);
                    scanCursor.setZ(z);
                    if (!plugin.getBlockProvider().isCarton(scanCursor.getBlock(), boxRef)) continue;
                    // locKey sans allocation de Location supplémentaire
                    if (lockedBoxes.contains(blockKey(x, y, z))) continue;
                    bestDistSq = distSq;
                    bestX = x; bestY = y; bestZ = z;
                    found = true;
                }
            }
        }
        if (found) {
            Location best = new Location(world, bestX, bestY, bestZ);
            lockedBoxes.add(LocationUtil.locKey(best));
            lastBoxTarget = best.clone();
            return best;
        }
        return null;
    }
    private String blockKey(int x, int y, int z) {
        return world.getName() + ":" + x + ":" + y + ":" + z;
    }
    private void moveTowardsTarget() {
        if (targetLocation == null) { setState(State.IDLE); return; }
        Entity bukkit = entity.getBukkitEntity();
        Location current = bukkit.getLocation();
        double distance = current.distance(targetLocation);
        if (Math.abs(distance - lastDistance) < 0.02) {
            stuckTicks++;
            if (stuckTicks > STUCK_THRESHOLD_TICKS) {
                if (stuckTicks < STUCK_BOOST_LIMIT) {
                    bukkit.teleport(current.clone().add(0, 0.4, 0));
                    currentVelocity = new Vector(0, 0, 0);
                } else {
                    abortAndReset();
                    return;
                }
            }
        } else {
            stuckTicks = 0;
        }
        lastDistance = distance;
        if (distance < 0.7) {
            if (state == State.MOVING_TO_BOX) {
                collectBox();
                targetLocation = plugin.getPluginConfig().getSellZoneCenter(world);
                setState(State.MOVING_TO_SELL);
            } else if (state == State.MOVING_TO_SELL) {
                sellBox();
                releaseLock();
                targetLocation = null;
                setState(State.IDLE);
            }
            return;
        }
        Vector desiredDirection = targetLocation.toVector().subtract(current.toVector()).normalize();
        double stepPerTick = speed / 20.0;
        if (distance < 2.0) stepPerTick *= Math.max(0.35, distance / 2.0);
        Vector desiredVelocity = desiredDirection.multiply(stepPerTick);
        double smoothing = 0.35;
        currentVelocity.setX(currentVelocity.getX() + (desiredVelocity.getX() - currentVelocity.getX()) * smoothing);
        currentVelocity.setY(currentVelocity.getY() + (desiredVelocity.getY() - currentVelocity.getY()) * smoothing);
        currentVelocity.setZ(currentVelocity.getZ() + (desiredVelocity.getZ() - currentVelocity.getZ()) * smoothing);
        if (currentVelocity.length() > stepPerTick) {
            currentVelocity = currentVelocity.normalize().multiply(stepPerTick);
        }
        double moveLen = currentVelocity.length();
        if (moveLen > distance) currentVelocity = currentVelocity.normalize().multiply(distance);
        Location newLoc = current.clone().add(currentVelocity);
        if (currentVelocity.lengthSquared() > 0.0001) {
            float targetYaw = (float) Math.toDegrees(Math.atan2(-currentVelocity.getX(), currentVelocity.getZ()));
            float targetPitch = (float) Math.toDegrees(-Math.asin(Math.max(-1.0, Math.min(1.0, currentVelocity.getY() / Math.max(0.001, currentVelocity.length())))));
            newLoc.setYaw(lerpAngle(current.getYaw(), targetYaw, 0.4f));
            newLoc.setPitch(lerpAngle(current.getPitch(), targetPitch, 0.4f));
        } else {
            newLoc.setYaw(current.getYaw());
            newLoc.setPitch(current.getPitch());
        }
        bukkit.teleport(newLoc);
    }
    private float lerpAngle(float from, float to, float t) {
        float diff = ((to - from) % 360 + 540) % 360 - 180;
        return from + diff * t;
    }
    private void collectBox() {
        if (targetLocation == null) return;
        Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
        if (plugin.getBlockProvider().isCarton(blockLoc.getBlock(), boxRef)) {
            plugin.getBlockProvider().breakCarton(blockLoc.getBlock(), boxRef);
            plugin.getEventManager().onBoxBroken(blockLoc);
            blockLoc.getWorld().playSound(blockLoc, org.bukkit.Sound.BLOCK_STONE_BREAK, 0.5f, 1.0f);
            // ── Module Scanner : chance de drop collectible déclenchée par le drone ──
            if (moduleCollectibleBonus > 0
                    && ThreadLocalRandom.current().nextDouble() < moduleCollectibleBonus) {
                plugin.getCollectibleManager().rollDrop(owner, blockLoc);
            }
        } else {
            releaseLock();
            targetLocation = null;
            setState(State.IDLE);
        }
    }
    private void sellBox() {
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        if (data == null) return;
        // ── Module Accumulateur : économise le carton (revend ET re-pose un carton) ──
        boolean saved = moduleSaveChance > 0
                && ThreadLocalRandom.current().nextDouble() < moduleSaveChance;
        double price = plugin.getPluginConfig().getBoxSellPrice() * incomeMultiplier;
        plugin.getEconomyManager().credit(owner, price);
        collectedSinceSpawn++;
        data.incrementDroneCollected(config.key());
        data.addDroneEarnings(config.key(), (long) price);
        owner.getWorld().playSound(owner.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
        if (saved && lastBoxTarget != null
                && lastBoxTarget.getBlock().getType().isAir()) {
            // Re-pose un carton à l'emplacement d'origine = "économie" de ressource
            plugin.getBlockProvider().placeCarton(lastBoxTarget, boxRef);
        }
    }
    public void stop() {
        if (task != null && !task.isCancelled()) task.cancel();
        if (hologram != null && hologram.isValid()) hologram.remove();
        entity.remove();
        releaseLock();
    }
}
