package fr.cleanthebackyard.cleanTheBackyard.entity;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Bee;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import java.util.HashSet;
import java.util.Set;
public class DroneEntity {
    private static final Set<String> lockedBoxes = new HashSet<>();
    private final CleanTheBackyard plugin;
    private final Player owner;
    private final PluginConfig.DroneConfig config;
    private final Bee entity;
    private final double speed;
    private final int pickupRange;
    private final double incomeMultiplier;
    private final Material boxMaterial;
    private final World world;
    public enum State { IDLE, MOVING_TO_BOX, MOVING_TO_SELL, NO_TARGET }
    private State state = State.IDLE;
    private Location targetLocation;
    private Location lastBoxTarget;
    private BukkitRunnable task;
    // Stats live
    private long collectedSinceSpawn = 0;
    private long idleTicksCounter = 0;
    public DroneEntity(Player owner, PluginConfig.DroneConfig config) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.config = config;
        this.world = owner.getWorld();
        // Récupère les upgrades du joueur pour ce drone
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        int[] tiers = (data != null) ? data.getDroneUpgrades(config.key()) : new int[]{0, 0, 0};
        double speedBonus  = 1.0 + tiers[0] * plugin.getPluginConfig().getDroneSpeedTierBonus();
        double rangeBonus  = 1.0 + tiers[1] * plugin.getPluginConfig().getDroneRangeTierBonus();
        double incomeBonus = 1.0 + tiers[2] * plugin.getPluginConfig().getDroneIncomeTierBonus();
        this.speed = config.speed() * speedBonus;
        this.pickupRange = (int) Math.round(config.pickupRange() * rangeBonus);
        this.incomeMultiplier = incomeBonus;
        String boxMatName = plugin.getPluginConfig().getBoxBlock();
        Material mat = Material.matchMaterial(boxMatName);
        this.boxMaterial = (mat != null) ? mat : Material.NOTE_BLOCK;
        Location spawnLoc = plugin.getPluginConfig().getSellZoneCenter(world).clone().add(0, 2, 0);
        this.entity = (Bee) world.spawnEntity(spawnLoc, EntityType.BEE);
        this.entity.setCustomNameVisible(true);
        this.entity.setSilent(true);
        this.entity.setInvulnerable(true);
        this.entity.setAI(false);
        this.entity.setCanPickupItems(false);
        this.entity.setRemoveWhenFarAway(false);
        updateName();
        startTask();
    }
    public String getKey() { return config.key(); }
    private void updateName() {
        if (entity == null || !entity.isValid()) return;
        String statusColor;
        String statusText;
        switch (state) {
            case IDLE -> { statusColor = "&7"; statusText = "RECHERCHE"; }
            case MOVING_TO_BOX -> { statusColor = "&e"; statusText = "CHASSE"; }
            case MOVING_TO_SELL -> { statusColor = "&a"; statusText = "TRANSPORT"; }
            case NO_TARGET -> { statusColor = "&c"; statusText = "INACTIF (0 carton)"; }
            default -> { statusColor = "&7"; statusText = "?"; }
        }
        entity.setCustomName(ChatUtil.color(
                "&6" + config.name() + " " + statusColor + "[" + statusText + "] &7| &b" + collectedSinceSpawn
        ));
    }
    private String lockKey(Location loc) {
        return loc.getWorld().getName() + ":" + loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
    }
    private void startTask() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                if (entity.isDead() || !owner.isOnline() || !owner.isValid()) {
                    stop();
                    return;
                }
                if (!owner.getWorld().equals(world)) {
                    stop();
                    return;
                }
                switch (state) {
                    case IDLE, NO_TARGET -> findNewTarget();
                    case MOVING_TO_BOX, MOVING_TO_SELL -> moveTowardsTarget();
                }
                // Rafraîchit le nom toutes les ~1s
                if (idleTicksCounter++ % 10 == 0) updateName();
            }
        };
        task.runTaskTimer(plugin, 0L, 2L);
    }
    private void findNewTarget() {
        Location nearestBox = findNearestBox();
        if (nearestBox != null) {
            targetLocation = nearestBox.clone().add(0.5, 0.5, 0.5);
            State old = state;
            state = State.MOVING_TO_BOX;
            if (old == State.NO_TARGET) updateName();
        } else {
            if (state != State.NO_TARGET) {
                state = State.NO_TARGET;
                updateName();
            }
        }
    }
    private Location findNearestBox() {
        Location droneLoc = entity.getLocation();
        double bestDistSq = pickupRange * pickupRange;
        Location best = null;
        int minX = droneLoc.getBlockX() - pickupRange;
        int maxX = droneLoc.getBlockX() + pickupRange;
        int minZ = droneLoc.getBlockZ() - pickupRange;
        int maxZ = droneLoc.getBlockZ() + pickupRange;
        int minY = Math.max(world.getMinHeight(), droneLoc.getBlockY() - 5);
        int maxY = Math.min(world.getMaxHeight(), droneLoc.getBlockY() + 5);
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    Location loc = new Location(world, x, y, z);
                    if (loc.getBlock().getType() == boxMaterial) {
                        String key = lockKey(loc);
                        if (lockedBoxes.contains(key)) continue;
                        if (lastBoxTarget != null && lastBoxTarget.equals(loc)) continue;
                        double distSq = droneLoc.distanceSquared(loc);
                        if (distSq < bestDistSq) {
                            bestDistSq = distSq;
                            best = loc;
                        }
                    }
                }
            }
        }
        if (best != null) lockedBoxes.add(lockKey(best));
        return best;
    }
    private void moveTowardsTarget() {
        if (targetLocation == null) {
            state = State.IDLE;
            return;
        }
        Location current = entity.getLocation();
        double distance = current.distance(targetLocation);
        if (distance < 0.5) {
            if (state == State.MOVING_TO_BOX) {
                collectBox();
                targetLocation = plugin.getPluginConfig().getSellZoneCenter(world);
                state = State.MOVING_TO_SELL;
                updateName();
            } else if (state == State.MOVING_TO_SELL) {
                sellBox();
                if (lastBoxTarget != null) lockedBoxes.remove(lockKey(lastBoxTarget));
                state = State.IDLE;
                targetLocation = null;
                lastBoxTarget = null;
                updateName();
            }
            return;
        }
        Vector direction = targetLocation.toVector().subtract(current.toVector()).normalize();
        double step = speed / 20.0;
        Location newLoc = current.clone().add(direction.multiply(step));
        entity.teleport(newLoc);
        entity.setRotation(
                (float) Math.toDegrees(Math.atan2(-direction.getX(), direction.getZ())),
                (float) Math.toDegrees(Math.asin(direction.getY()))
        );
    }
    private void collectBox() {
        if (targetLocation == null) return;
        Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
        if (blockLoc.getBlock().getType() == boxMaterial) {
            blockLoc.getBlock().setType(Material.AIR);
            lastBoxTarget = blockLoc.clone();
            plugin.getSectorManager().markBroken(blockLoc);
            blockLoc.getWorld().playSound(blockLoc, org.bukkit.Sound.BLOCK_STONE_BREAK, 0.5f, 1.0f);
        } else {
            if (lastBoxTarget != null) {
                lockedBoxes.remove(lockKey(lastBoxTarget));
                lastBoxTarget = null;
            }
            state = State.IDLE;
            targetLocation = null;
        }
    }
    private void sellBox() {
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        if (data == null) return;
        double price = plugin.getPluginConfig().getBoxSellPrice() * incomeMultiplier;
        plugin.getEconomyManager().credit(owner, price);
        collectedSinceSpawn++;
        data.incrementDroneCollected(config.key());
        data.addDroneEarnings(config.key(), (long) price);
        owner.getWorld().playSound(owner.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
    }
    public State getState() { return state; }
    public long getCollectedSinceSpawn() { return collectedSinceSpawn; }
    public void stop() {
        if (task != null && !task.isCancelled()) task.cancel();
        if (entity != null && entity.isValid()) entity.remove();
        if (lastBoxTarget != null) lockedBoxes.remove(lockKey(lastBoxTarget));
    }
}