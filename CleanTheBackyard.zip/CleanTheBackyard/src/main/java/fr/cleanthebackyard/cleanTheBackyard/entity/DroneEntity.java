package fr.cleanthebackyard.cleanTheBackyard.entity;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Bee;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.HashSet;
import java.util.Set;

public class DroneEntity {

    private static final Set<String> lockedBoxes = new HashSet<>();
    private final CleanTheBackyard plugin;
    private final Player owner;
    private final PluginConfig.DroneConfig config;
    private final Bee entity;
    private final double speed;
    private final int pickupRange;
    private final Material boxMaterial; // ← matériau lu depuis la config

    private enum State { IDLE, MOVING_TO_BOX, MOVING_TO_SELL }
    private State state = State.IDLE;
    private Location targetLocation;
    private Location lastBoxTarget;
    private BukkitRunnable task;

    public DroneEntity(Player owner, PluginConfig.DroneConfig config) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.config = config;
        this.speed = config.speed();
        this.pickupRange = config.pickupRange();

        // Lecture du matériau depuis la configuration
        String boxMatName = plugin.getPluginConfig().getBoxBlock();
        Material mat = Material.matchMaterial(boxMatName);
        this.boxMaterial = (mat != null) ? mat : Material.NOTE_BLOCK;

        World world = owner.getWorld();
        Location spawnLoc = plugin.getPluginConfig().getSellZoneCenter().clone().add(0, 2, 0);
        this.entity = (Bee) world.spawnEntity(spawnLoc, EntityType.BEE);
        this.entity.setCustomNameVisible(true);
        this.entity.setCustomName("§6Drone " + config.name() + " §7(§f" + owner.getName() + "§7)");
        this.entity.setSilent(true);
        this.entity.setInvulnerable(true);
        this.entity.setAI(false);
        this.entity.setCanPickupItems(false);
        this.entity.setRemoveWhenFarAway(false);

        startTask();
    }

    private void startTask() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                if (entity.isDead() || !owner.isOnline() || !owner.isValid()) {
                    stop();
                    return;
                }
                switch (state) {
                    case IDLE -> findNewTarget();
                    case MOVING_TO_BOX, MOVING_TO_SELL -> moveTowardsTarget();
                }
            }
        };
        task.runTaskTimer(plugin, 0L, 2L);
    }

    private void findNewTarget() {
        Location nearestBox = findNearestBox();
        if (nearestBox != null) {
            targetLocation = nearestBox.clone().add(0.5, 0.5, 0.5);
            state = State.MOVING_TO_BOX;
        }
    }

    private Location findNearestBox() {
        World w = entity.getWorld();
        Location droneLoc = entity.getLocation();
        double bestDistSq = pickupRange * pickupRange;
        Location best = null;
        Material boxMat = boxMaterial;
        int minX = droneLoc.getBlockX() - pickupRange;
        int maxX = droneLoc.getBlockX() + pickupRange;
        int minZ = droneLoc.getBlockZ() - pickupRange;
        int maxZ = droneLoc.getBlockZ() + pickupRange;
        int minY = Math.max(w.getMinHeight(), droneLoc.getBlockY() - 5);
        int maxY = Math.min(w.getMaxHeight(), droneLoc.getBlockY() + 5);

        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                for (int y = minY; y <= maxY; y++) {
                    Location loc = new Location(w, x, y, z);
                    if (loc.getBlock().getType() == boxMat) {
                        String key = loc.getBlockX() + ":" + loc.getBlockY() + ":" + loc.getBlockZ();
                        if (lockedBoxes.contains(key)) continue;
                        if (lastBoxTarget != null && lastBoxTarget.equals(loc)) continue;
                        double distSq = droneLoc.distanceSquared(loc);
                        if (distSq < bestDistSq) {
                            bestDistSq = distSq;
                            best = loc;
                        }
                    }
                }
            }
        }
        if (best != null) {
            String key = best.getBlockX() + ":" + best.getBlockY() + ":" + best.getBlockZ();
            lockedBoxes.add(key);
        }
        return best;
    }

    private void moveTowardsTarget() {
        if (targetLocation == null) {
            state = State.IDLE;
            return;
        }
        Location current = entity.getLocation();
        double distance = current.distance(targetLocation);
        if (distance < 0.5) {
            if (state == State.MOVING_TO_BOX) {
                collectBox();
                targetLocation = plugin.getPluginConfig().getSellZoneCenter();
                state = State.MOVING_TO_SELL;
            } else if (state == State.MOVING_TO_SELL) {
                sellBox();
                if (lastBoxTarget != null) {
                    String key = lastBoxTarget.getBlockX() + ":" + lastBoxTarget.getBlockY() + ":" + lastBoxTarget.getBlockZ();
                    lockedBoxes.remove(key);
                }
                state = State.IDLE;
                targetLocation = null;
                lastBoxTarget = null;
            }
            return;
        }
        Vector direction = targetLocation.toVector().subtract(current.toVector()).normalize();
        double step = speed / 20.0;
        Location newLoc = current.clone().add(direction.multiply(step));
        entity.teleport(newLoc);
        entity.setRotation(
                (float) Math.toDegrees(Math.atan2(-direction.getX(), direction.getZ())),
                (float) Math.toDegrees(Math.asin(direction.getY()))
        );
    }

    private void collectBox() {
        if (targetLocation == null) return;
        Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
        if (blockLoc.getBlock().getType() == boxMaterial) {
            blockLoc.getBlock().setType(Material.AIR);
            lastBoxTarget = blockLoc.clone();
            plugin.getSectorManager().markBroken(blockLoc);
            blockLoc.getWorld().playSound(blockLoc, org.bukkit.Sound.BLOCK_STONE_BREAK, 0.5f, 1.0f);
        } else {
            if (lastBoxTarget != null) {
                String key = lastBoxTarget.getBlockX() + ":" + lastBoxTarget.getBlockY() + ":" + lastBoxTarget.getBlockZ();
                lockedBoxes.remove(key);
                lastBoxTarget = null;
            }
            state = State.IDLE;
            targetLocation = null;
        }
    }

    private void sellBox() {
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        if (data == null) return;
        double price = plugin.getPluginConfig().getBoxSellPrice();
        plugin.getEconomyManager().credit(owner, price);
        owner.getWorld().playSound(owner.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
    }

    public void stop() {
        if (task != null && !task.isCancelled()) task.cancel();
        if (entity != null && entity.isValid()) entity.remove();
        if (lastBoxTarget != null) {
            String key = lastBoxTarget.getBlockX() + ":" + lastBoxTarget.getBlockY() + ":" + lastBoxTarget.getBlockZ();
            lockedBoxes.remove(key);
        }
    }
}