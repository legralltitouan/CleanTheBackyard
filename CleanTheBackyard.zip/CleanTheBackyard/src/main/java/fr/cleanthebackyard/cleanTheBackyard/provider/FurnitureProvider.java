package fr.cleanthebackyard.cleanTheBackyard.provider;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import java.lang.reflect.Method;
import java.util.UUID;
/**
 * Abstraction pour spawner et manipuler les furnitures ItemsAdder 4.0.17+.
 * Si ItemsAdder est absent, retourne null silencieusement.
 */
public class FurnitureProvider {
    private final CleanTheBackyard plugin;
    private final boolean itemsAdderPresent;
    // Réflexion ItemsAdder
    private Method iaCustomFurnitureSpawn;
    private Method iaCustomStackGetByNamespacedID;
    private Method iaCustomStackGetItemStack;
    private Method iaCustomFurnitureRemove;
    private Method iaCustomFurnitureByEntity;
    private Method iaCustomFurnitureGetNamespacedID;
    public FurnitureProvider(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.itemsAdderPresent = Bukkit.getPluginManager().isPluginEnabled("ItemsAdder");
        if (itemsAdderPresent) initReflection();
    }
    private void initReflection() {
        try {
            Class<?> customStack = Class.forName("dev.lone.itemsadder.api.CustomStack");
            iaCustomStackGetByNamespacedID = customStack.getMethod("getInstance", String.class);
            iaCustomStackGetItemStack = customStack.getMethod("getItemStack");
            Class<?> customFurniture = Class.forName("dev.lone.itemsadder.api.CustomFurniture");
            iaCustomFurnitureSpawn = customFurniture.getMethod("spawn", String.class, org.bukkit.block.Block.class);
            iaCustomFurnitureRemove = customFurniture.getMethod("remove", boolean.class);
            iaCustomFurnitureByEntity = customFurniture.getMethod("byAlreadySpawned", Entity.class);
            iaCustomFurnitureGetNamespacedID = customFurniture.getMethod("getNamespacedID");
            plugin.getLogger().info("[CTB] FurnitureProvider : ItemsAdder API détectée.");
        } catch (Throwable t) {
            plugin.getLogger().warning("[CTB] FurnitureProvider : ItemsAdder API inaccessible : " + t.getMessage());
        }
    }
    public boolean isAvailable() {
        return itemsAdderPresent && iaCustomFurnitureSpawn != null;
    }
    /**
     * Récupère un ItemStack ItemsAdder à partir d'un namespaced ID (ex: "ctb:dirty_cassette").
     */
    public ItemStack getItemStack(String namespacedId) {
        if (!isAvailable() || namespacedId == null) return null;
        try {
            Object customStack = iaCustomStackGetByNamespacedID.invoke(null, namespacedId);
            if (customStack == null) return null;
            return (ItemStack) iaCustomStackGetItemStack.invoke(customStack);
        } catch (Throwable t) {
            plugin.getLogger().warning("[CTB] FurnitureProvider.getItemStack(" + namespacedId + ") : " + t.getMessage());
            return null;
        }
    }
    /**
     * Place une furniture ItemsAdder à une location donnée.
     * Retourne l'UUID de l'entité créée, ou null si échec.
     */
    public UUID placeFurniture(String namespacedId, Location loc) {
        if (!isAvailable() || namespacedId == null || loc == null) return null;
        try {
            Object placed = iaCustomFurnitureSpawn.invoke(null, namespacedId, loc.getBlock());
            if (placed == null) return null;
            // Récupère l'entité Bukkit via réflexion
            Method getArmorstand = placed.getClass().getMethod("getArmorstand");
            Entity ent = (Entity) getArmorstand.invoke(placed);
            return ent != null ? ent.getUniqueId() : null;
        } catch (Throwable t) {
            plugin.getLogger().warning("[CTB] FurnitureProvider.placeFurniture(" + namespacedId + ") : " + t.getMessage());
            return null;
        }
    }
    /**
     * Supprime une furniture par son entité (armorstand ou itemframe).
     */
    public boolean removeFurniture(Entity entity) {
        if (!isAvailable() || entity == null) return false;
        try {
            Object custom = iaCustomFurnitureByEntity.invoke(null, entity);
            if (custom == null) {
                entity.remove();
                return true;
            }
            iaCustomFurnitureRemove.invoke(custom, false);
            return true;
        } catch (Throwable t) {
            entity.remove();
            return true;
        }
    }
    /**
     * Récupère le namespacedID d'une furniture posée, ou null si l'entité n'en est pas une.
     */
    public String getFurnitureId(Entity entity) {
        if (!isAvailable() || entity == null) return null;
        try {
            Object custom = iaCustomFurnitureByEntity.invoke(null, entity);
            if (custom == null) return null;
            return (String) iaCustomFurnitureGetNamespacedID.invoke(custom);
        } catch (Throwable t) {
            return null;
        }
    }
    /**
     * Donne un item ItemsAdder à un joueur (utilisé pour l'item "objet sale" récolté).
     */
    public boolean giveItem(Player player, String namespacedId, int amount) {
        ItemStack stack = getItemStack(namespacedId);
        if (stack == null) return false;
        stack.setAmount(amount);
        var leftover = player.getInventory().addItem(stack);
        if (!leftover.isEmpty()) {
            leftover.values().forEach(i -> player.getWorld().dropItemNaturally(player.getLocation(), i));
        }
        return true;
    }
}