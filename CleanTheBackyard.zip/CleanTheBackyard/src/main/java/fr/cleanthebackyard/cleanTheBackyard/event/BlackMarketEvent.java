package fr.cleanthebackyard.cleanTheBackyard.event;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Random;

public class BlackMarketEvent {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    public BlackMarketEvent(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void scheduleNext() {
        PluginConfig cfg = plugin.core().config();
        int delay = cfg.getBlackMarketMin()
                + random.nextInt(Math.max(1, cfg.getBlackMarketMax() - cfg.getBlackMarketMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::trigger, delay * 20L);
    }

    public void trigger() {
        List<Player> targets = EventUtils.getAllCtbPlayers(plugin);
        if (targets.isEmpty()) {
            scheduleNext();
            return;
        }
        for (Player p : targets) {
            PlayerData d = plugin.core().playerData().get(p);
            if (d == null) continue;
            d.setBlackMarket(60);
            p.sendMessage(ChatUtil.color("&8[MARCHÉ NOIR] &5Vente x3 pendant 60 secondes !"));
            p.playSound(p.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 0.7f, 1.5f);
            if (EventUtils.isInOwnWorld(plugin, p)) {
                p.getWorld().spawnParticle(Particle.WITCH, p.getLocation().add(0, 2, 0), 30, 1, 1, 1, 0.1);
            }
        }
        scheduleNext();
    }
}
