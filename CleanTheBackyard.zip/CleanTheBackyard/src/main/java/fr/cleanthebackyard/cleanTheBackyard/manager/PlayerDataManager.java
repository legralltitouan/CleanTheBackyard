package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

/**
 * Charge, met en cache et sauvegarde les profils joueurs en YAML.
 * Chaque joueur = un fichier /plugins/CleanTheBackyard/players/<uuid>.yml
 */
public class PlayerDataManager {

    private final CleanTheBackyard plugin;
    private final File playersFolder;
    private final Map<UUID, PlayerData> cache = new HashMap<>();

    public PlayerDataManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.playersFolder = new File(plugin.getDataFolder(), "players");
        if (!playersFolder.exists()) playersFolder.mkdirs();
    }

    // ── Load / Save ───────────────────────────────────────────────────

    /** Charge ou cree le profil d'un joueur et le met en cache. */
    public PlayerData loadPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        if (cache.containsKey(uuid)) return cache.get(uuid);

        File file = getFile(uuid);
        PlayerData data;

        if (file.exists()) {
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
            data = deserialize(uuid, player.getName(), yml);
        } else {
            data = new PlayerData(uuid, player.getName());
        }

        cache.put(uuid, data);
        return data;
    }

    /** Sauvegarde le profil d'un joueur et le retire du cache. */
    public void unloadPlayer(UUID uuid) {
        PlayerData data = cache.remove(uuid);
        if (data != null) saveData(data);
    }

    /** Sauvegarde tous les profils en cache (appele a l'onDisable). */
    public void saveAll() {
        cache.values().forEach(this::saveData);
        plugin.getLogger().info("[CTB] " + cache.size() + " profil(s) sauvegarde(s).");
    }

    // ── Cache Access ──────────────────────────────────────────────────

    public PlayerData get(UUID uuid) { return cache.get(uuid); }
    public PlayerData get(Player p)  { return cache.get(p.getUniqueId()); }
    public boolean isLoaded(UUID uuid){ return cache.containsKey(uuid); }
    public Collection<PlayerData> getAll(){ return cache.values(); }

    // ── YAML Serialization ────────────────────────────────────────────

    private void saveData(PlayerData data) {
        File file = getFile(data.getUuid());
        YamlConfiguration yml = new YamlConfiguration();

        yml.set("name",                data.getName());
        yml.set("balance",             data.getBalance());
        yml.set("total-earned",        data.getTotalEarned());
        yml.set("total-boxes-broken",  data.getTotalBoxesBroken());
        yml.set("bag-level",           data.getBagLevel());
        yml.set("current-boxes",       data.getCurrentBoxes());
        yml.set("tool-level",          data.getToolLevel());
        yml.set("energy-level",        data.getEnergyLevel());
        yml.set("current-energy",      data.getCurrentEnergy());
        yml.set("owned-drones",        new ArrayList<>(data.getOwnedDrones()));

        try {
            yml.save(file);
        } catch (IOException e) {
            plugin.getLogger().severe("[CTB] Erreur de sauvegarde pour " + data.getName() + ": " + e.getMessage());
        }
    }

    private PlayerData deserialize(UUID uuid, String name, YamlConfiguration yml) {
        PlayerData d = new PlayerData(uuid, name);
        d.setBalance(yml.getDouble("balance", 0));
        d.setBagLevel(yml.getInt("bag-level", 1));
        d.setCurrentBoxes(yml.getInt("current-boxes", 0));
        d.setToolLevel(yml.getInt("tool-level", 1));
        d.setEnergyLevel(yml.getInt("energy-level", 1));
        d.setCurrentEnergy(yml.getDouble("current-energy", 100));

        List<?> drones = yml.getList("owned-drones", new ArrayList<>());
        for (Object o : drones) {
            if (o instanceof String s) d.addDrone(s);
        }
        return d;
    }

    private File getFile(UUID uuid) {
        return new File(playersFolder, uuid.toString() + ".yml");
    }
}
