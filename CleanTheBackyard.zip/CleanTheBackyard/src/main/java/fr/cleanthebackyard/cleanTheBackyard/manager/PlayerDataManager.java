package fr.cleanthebackyard.cleanTheBackyard.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public class PlayerDataManager {
    private final CleanTheBackyard plugin;
    private final File playersFolder;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();
    private BukkitTask autoSaveTask;
    public PlayerDataManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.playersFolder = new File(plugin.getDataFolder(), "players");
        if (!playersFolder.exists()) playersFolder.mkdirs();
    }
    public void startAutoSave() {
        int interval = plugin.getPluginConfig().getAutoSaveIntervalSeconds();
        if (interval <= 0) return;
        long ticks = interval * 20L;
        autoSaveTask = plugin.getServer().getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            // Copie pour éviter ConcurrentModification pendant qu'on itère
            List<PlayerData> snapshot = new ArrayList<>(cache.values());
            for (PlayerData d : snapshot) {
                try { saveData(d); }
                catch (Exception e) {
                    plugin.getLogger().warning("[CTB] Auto-save fail " + d.getName() + ": " + e.getMessage());
                }
            }
        }, ticks, ticks);
    }
    public void stopAutoSave() {
        if (autoSaveTask != null && !autoSaveTask.isCancelled()) autoSaveTask.cancel();
    }
    public PlayerData loadPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        if (cache.containsKey(uuid)) return cache.get(uuid);
        File file = getFile(uuid);
        PlayerData data;
        if (file.exists()) {
            YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
            data = deserialize(uuid, player.getName(), yml);
        } else {
            data = new PlayerData(uuid, player.getName());
        }
        cache.put(uuid, data);
        return data;
    }
    public void unloadPlayer(UUID uuid) {
        PlayerData data = cache.remove(uuid);
        if (data != null) saveData(data);
    }
    public void saveAll() {
        cache.values().forEach(this::saveData);
        plugin.getLogger().info("[CTB] " + cache.size() + " profil(s) sauvegardé(s).");
    }
    public PlayerData get(UUID uuid) { return cache.get(uuid); }
    public PlayerData get(Player p) { return cache.get(p.getUniqueId()); }
    public boolean isLoaded(UUID uuid) { return cache.containsKey(uuid); }
    public Collection<PlayerData> getAll() { return cache.values(); }
    private void saveData(PlayerData data) {
        File file = getFile(data.getUuid());
        YamlConfiguration yml = new YamlConfiguration();
        yml.set("name", data.getName());
        yml.set("balance", data.getBalance());
        yml.set("total-earned", data.getTotalEarned());
        yml.set("lifetime-earned", data.getLifetimeEarned());
        yml.set("total-boxes-broken", data.getTotalBoxesBroken());
        yml.set("bag-level", data.getBagLevel());
        yml.set("current-boxes", data.getCurrentBoxes());
        yml.set("tool-level", data.getToolLevel());
        yml.set("energy-level", data.getEnergyLevel());
        yml.set("current-energy", data.getCurrentEnergy());
        yml.set("owned-drones", new ArrayList<>(data.getOwnedDrones()));
        yml.set("prestige-level", data.getPrestigeLevel());
        yml.set("unlimited-energy-until", data.getUnlimitedEnergyUntil());
        yml.set("double-sell-until", data.getDoubleSellUntil());
        yml.set("black-market-until", data.getBlackMarketUntil());
        ConfigurationSection upgSec = yml.createSection("drone-upgrades");
        for (Map.Entry<String, int[]> e : data.getAllDroneUpgrades().entrySet()) {
            int[] t = e.getValue();
            upgSec.set(e.getKey() + ".speed", t[0]);
            upgSec.set(e.getKey() + ".range", t[1]);
            upgSec.set(e.getKey() + ".income", t[2]);
        }
        ConfigurationSection statSec = yml.createSection("drone-stats");
        for (Map.Entry<String, long[]> e : data.getAllDroneStats().entrySet()) {
            long[] s = e.getValue();
            statSec.set(e.getKey() + ".collected", s[0]);
            statSec.set(e.getKey() + ".earned", s[1]);
        }
        yml.set("quest-reset-timestamp", data.getQuestResetTimestamp());
        List<Map<String, Object>> questList = new ArrayList<>();
        for (DailyQuest q : data.getDailyQuests()) {
            Map<String, Object> m = new HashMap<>();
            m.put("type", q.getType().name());
            m.put("target", q.getTarget());
            m.put("progress", q.getProgress());
            m.put("reward", q.getReward());
            m.put("claimed", q.isClaimed());
            questList.add(m);
        }
        yml.set("daily-quests", questList);
        try { yml.save(file); }
        catch (IOException e) {
            plugin.getLogger().severe("[CTB] Erreur sauvegarde " + data.getName() + ": " + e.getMessage());
        }
    }
    private PlayerData deserialize(UUID uuid, String name, YamlConfiguration yml) {
        PlayerData d = new PlayerData(uuid, name);
        d.setBalance(yml.getDouble("balance", 0));
        d.setLifetimeEarned(yml.getLong("lifetime-earned", 0L));
        d.setTotalBoxesBroken(yml.getLong("total-boxes-broken", 0L));
        d.setBagLevel(yml.getInt("bag-level", 1));
        d.setCurrentBoxes(yml.getInt("current-boxes", 0));
        d.setToolLevel(yml.getInt("tool-level", 1));
        d.setTotalEarned(yml.getLong("total-earned", 0L));
        d.setEnergyLevel(yml.getInt("energy-level", 1));
        d.setCurrentEnergy(yml.getDouble("current-energy", 100));
        d.setPrestigeLevel(yml.getInt("prestige-level", 0));
        List<?> drones = yml.getList("owned-drones", new ArrayList<>());
        for (Object o : drones) if (o instanceof String s) d.addDrone(s);
        d.setRawUnlimitedEnergyUntil(yml.getLong("unlimited-energy-until", 0L));
        d.setRawDoubleSellUntil(yml.getLong("double-sell-until", 0L));
        d.setRawBlackMarketUntil(yml.getLong("black-market-until", 0L));
        ConfigurationSection upgSec = yml.getConfigurationSection("drone-upgrades");
        if (upgSec != null) {
            for (String key : upgSec.getKeys(false)) {
                int[] tiers = new int[]{
                        upgSec.getInt(key + ".speed", 0),
                        upgSec.getInt(key + ".range", 0),
                        upgSec.getInt(key + ".income", 0)
                };
                d.setDroneUpgrades(key, tiers);
            }
        }
        ConfigurationSection statSec = yml.getConfigurationSection("drone-stats");
        if (statSec != null) {
            for (String key : statSec.getKeys(false)) {
                long collected = statSec.getLong(key + ".collected", 0L);
                long earned = statSec.getLong(key + ".earned", 0L);
                long[] arr = d.getDroneStats(key);
                arr[0] = collected;
                arr[1] = earned;
            }
        }
        d.setQuestResetTimestamp(yml.getLong("quest-reset-timestamp", 0L));
        List<?> rawQuests = yml.getList("daily-quests", new ArrayList<>());
        List<DailyQuest> quests = new ArrayList<>();
        for (Object o : rawQuests) {
            if (o instanceof Map<?, ?> m) {
                try {
                    DailyQuest.Type type = DailyQuest.Type.valueOf((String) m.get("type"));
                    long target = ((Number) m.get("target")).longValue();
                    long progress = ((Number) m.get("progress")).longValue();
                    long reward = ((Number) m.get("reward")).longValue();
                    boolean claimed = (Boolean) m.get("claimed");
                    quests.add(new DailyQuest(type, target, reward, progress, claimed));
                } catch (Exception ignored) {}
            }
        }
        d.setDailyQuests(quests);
        return d;
    }
    private File getFile(UUID uuid) { return new File(playersFolder, uuid.toString() + ".yml"); }
}