package fr.cleanthebackyard.cleanTheBackyard.ui.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class HousePortalGui {

    private static final String TITLE = ChatUtil.color("&8[&6Maison Personnelle&8]");
    private final CleanTheBackyard plugin;

    public HousePortalGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.HOUSE_PORTAL);
        Inventory inv = Bukkit.createInventory(holder, 27, TITLE);
        holder.setInventory(inv);
        build(inv);
        player.openInventory(inv);
    }

    private void build(Inventory inv) {
        ItemStack glass = new ItemBuilder(Material.ORANGE_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        inv.setItem(13, new ItemBuilder(Material.OAK_DOOR)
                .name("&6🏠 Entrer dans ma maison")
                .lore(List.of(
                        ChatUtil.color("&7Téléporte-toi dans ta maison personnelle."),
                        ChatUtil.color("&7Tu pourras y poser des meubles décoratifs."),
                        " ",
                        ChatUtil.color("&aClic pour entrer")
                ))
                .build());
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        if (event.getRawSlot() == 13) {
            player.closeInventory();
            plugin.getHouseManager().enterHouse(player);
        }
        return true;
    }
}
