package fr.cleanthebackyard.cleanTheBackyard.provider;
import org.bukkit.Location;
import org.bukkit.World;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
/**
 * Index spatial des cartons posés, par monde.
 *
 * Clé packée (long) dans un Set concurrent : 0 allocation par insertion (hors
 * boxing du long), itération directe sans snapshot. ConcurrentHashMap.newKeySet()
 * tolère l'itération pendant les modifications (faiblement cohérent), ce qui
 * supprime la copie défensive coûteuse de l'ancienne version.
 */
public final class CartonIndex {
    /** worldName -> set de positions packées. */
    private final Map<String, Set<Long>> byWorld = new ConcurrentHashMap<>();
    /** Packe x/y/z en un long. Supporte y négatif (monde 1.18+). */
    public static long packKey(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38)
                | ((long) (z & 0x3FFFFFF) << 12)
                | (y & 0xFFF);
    }
    public static int unpackX(long key) {
        int x = (int) (key >> 38) & 0x3FFFFFF;
        return (x << 6) >> 6;
    }
    public static int unpackZ(long key) {
        int z = (int) (key >> 12) & 0x3FFFFFF;
        return (z << 6) >> 6;
    }
    public static int unpackY(long key) {
        int y = (int) (key & 0xFFF);
        return (y << 20) >> 20;
    }
    private Set<Long> set(String worldName) {
        return byWorld.computeIfAbsent(worldName, k -> ConcurrentHashMap.newKeySet());
    }
    public void add(World world, int x, int y, int z) {
        if (world == null) return;
        set(world.getName()).add(packKey(x, y, z));
    }
    public void add(Location loc) {
        if (loc == null || loc.getWorld() == null) return;
        add(loc.getWorld(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }
    public void remove(World world, int x, int y, int z) {
        if (world == null) return;
        Set<Long> s = byWorld.get(world.getName());
        if (s != null) s.remove(packKey(x, y, z));
    }
    public void remove(Location loc) {
        if (loc == null || loc.getWorld() == null) return;
        remove(loc.getWorld(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }
    public boolean contains(World world, int x, int y, int z) {
        if (world == null) return false;
        Set<Long> s = byWorld.get(world.getName());
        return s != null && s.contains(packKey(x, y, z));
    }
    /**
     * Itère directement sur les positions du monde, sans snapshot.
     * Le Set concurrent supporte l'itération pendant une casse de carton.
     */
    public Iterable<Long> keys(World world) {
        if (world == null) return Collections.emptyList();
        Set<Long> s = byWorld.get(world.getName());
        return s == null ? Collections.emptyList() : s;
    }
    public int size(World world) {
        if (world == null) return 0;
        Set<Long> s = byWorld.get(world.getName());
        return s == null ? 0 : s.size();
    }
    public void clearWorld(World world) {
        if (world != null) byWorld.remove(world.getName());
    }
    public void clearAll() {
        byWorld.clear();
    }
    /** Réindexe tous les cartons d'une région (après une copie brute de blocs). */
    public void indexRegion(World world, org.bukkit.util.BoundingBox region, org.bukkit.Material boxMat) {
        if (world == null || region == null || boxMat == null) return;
        int minX = (int) Math.floor(region.getMinX());
        int minY = (int) Math.floor(region.getMinY());
        int minZ = (int) Math.floor(region.getMinZ());
        int maxX = (int) Math.floor(region.getMaxX());
        int maxY = (int) Math.floor(region.getMaxY());
        int maxZ = (int) Math.floor(region.getMaxZ());
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (world.getBlockAt(x, y, z).getType() == boxMat) {
                        add(world, x, y, z);
                    }
                }
            }
        }
    }
}