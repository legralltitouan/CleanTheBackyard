package fr.cleanthebackyard.cleanTheBackyard.provider;
import org.bukkit.Location;
import org.bukkit.World;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
/**
 * Index spatial des cartons posés, partitionné par chunk (région 16×16).
 *
 * Au lieu d'un Set plat par monde (toute recherche de proximité = O(n total)),
 * on stocke un Set de positions packées PAR chunk. Un drone qui cherche un
 * carton dans un rayon R n'itère que sur les chunks couvrant [cx-R..cx+R],
 * soit typiquement 1 à quelques dizaines de chunks au lieu de tout le monde.
 *
 * Clé de chunk packée (long) = (chunkX << 32) | (chunkZ & 0xFFFFFFFFL).
 * Clé de bloc packée (long) inchangée : compatible avec l'ancien format.
 *
 * Les Set internes sont des ConcurrentHashMap.newKeySet() : itération faiblement
 * cohérente, tolère la modification concurrente sans snapshot défensif.
 */
public final class CartonIndex {
    /** worldName -> (chunkKey -> set de positions de blocs packées). */
    private final Map<String, Map<Long, Set<Long>>> byWorld = new ConcurrentHashMap<>();
    // ── Packing position de bloc (format inchangé, compat ascendante) ──
    public static long packKey(int x, int y, int z) {
        return ((long) (x & 0x3FFFFFF) << 38)
                | ((long) (z & 0x3FFFFFF) << 12)
                | (y & 0xFFF);
    }
    public static int unpackX(long key) {
        int x = (int) (key >> 38) & 0x3FFFFFF;
        return (x << 6) >> 6;
    }
    public static int unpackZ(long key) {
        int z = (int) (key >> 12) & 0x3FFFFFF;
        return (z << 6) >> 6;
    }
    public static int unpackY(long key) {
        int y = (int) (key & 0xFFF);
        return (y << 20) >> 20;
    }
    // ── Packing clé de chunk ──
    public static long chunkKey(int chunkX, int chunkZ) {
        return ((long) chunkX << 32) | (chunkZ & 0xFFFFFFFFL);
    }
    private Map<Long, Set<Long>> world(String worldName) {
        return byWorld.computeIfAbsent(worldName, k -> new ConcurrentHashMap<>());
    }
    public void add(World world, int x, int y, int z) {
        if (world == null) return;
        Map<Long, Set<Long>> chunks = world(world.getName());
        long ck = chunkKey(x >> 4, z >> 4);
        chunks.computeIfAbsent(ck, k -> ConcurrentHashMap.newKeySet())
                .add(packKey(x, y, z));
    }
    public void add(Location loc) {
        if (loc == null || loc.getWorld() == null) return;
        add(loc.getWorld(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }
    public void remove(World world, int x, int y, int z) {
        if (world == null) return;
        Map<Long, Set<Long>> chunks = byWorld.get(world.getName());
        if (chunks == null) return;
        long ck = chunkKey(x >> 4, z >> 4);
        Set<Long> s = chunks.get(ck);
        if (s != null) {
            s.remove(packKey(x, y, z));
            // Purge du chunk vide pour ne pas laisser des entrées mortes
            // que l'itération de recherche devrait traverser inutilement.
            if (s.isEmpty()) chunks.remove(ck, s);
        }
    }
    public void remove(Location loc) {
        if (loc == null || loc.getWorld() == null) return;
        remove(loc.getWorld(), loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
    }
    public boolean contains(World world, int x, int y, int z) {
        if (world == null) return false;
        Map<Long, Set<Long>> chunks = byWorld.get(world.getName());
        if (chunks == null) return false;
        Set<Long> s = chunks.get(chunkKey(x >> 4, z >> 4));
        return s != null && s.contains(packKey(x, y, z));
    }
    /**
     * Itère les positions de bloc des chunks couvrant le rayon donné autour
     * d'un bloc central. Le consommateur reçoit chaque clé packée via le
     * visiteur ; aucune allocation de liste intermédiaire.
     *
     * @param world     monde concerné
     * @param centerX   coord. bloc X du centre (drone)
     * @param centerZ   coord. bloc Z du centre (drone)
     * @param range     rayon en blocs
     * @param visitor   appelé pour chaque carton dans les chunks pertinents
     */
    public void forEachInRange(World world, int centerX, int centerZ, int range, LongVisitor visitor) {
        if (world == null) return;
        Map<Long, Set<Long>> chunks = byWorld.get(world.getName());
        if (chunks == null || chunks.isEmpty()) return;
        int minCX = (centerX - range) >> 4;
        int maxCX = (centerX + range) >> 4;
        int minCZ = (centerZ - range) >> 4;
        int maxCZ = (centerZ + range) >> 4;
        for (int cx = minCX; cx <= maxCX; cx++) {
            for (int cz = minCZ; cz <= maxCZ; cz++) {
                Set<Long> s = chunks.get(chunkKey(cx, cz));
                if (s == null) continue;
                for (long key : s) visitor.accept(key);
            }
        }
    }
    /** Visiteur primitif pour éviter le boxing systématique d'un Consumer<Long>. */
    @FunctionalInterface
    public interface LongVisitor {
        void accept(long key);
    }
    public int size(World world) {
        if (world == null) return 0;
        Map<Long, Set<Long>> chunks = byWorld.get(world.getName());
        if (chunks == null) return 0;
        int total = 0;
        for (Set<Long> s : chunks.values()) total += s.size();
        return total;
    }
    public void clearWorld(World world) {
        if (world != null) byWorld.remove(world.getName());
    }
    public void clearAll() {
        byWorld.clear();
    }
    /** Réindexe tous les cartons d'une région (après une copie brute de blocs). */
    public void indexRegion(World world, org.bukkit.util.BoundingBox region, org.bukkit.Material boxMat) {
        if (world == null || region == null || boxMat == null) return;
        int minX = (int) Math.floor(region.getMinX());
        int minY = (int) Math.floor(region.getMinY());
        int minZ = (int) Math.floor(region.getMinZ());
        int maxX = (int) Math.floor(region.getMaxX());
        int maxY = (int) Math.floor(region.getMaxY());
        int maxZ = (int) Math.floor(region.getMaxZ());
        for (int x = minX; x <= maxX; x++) {
            for (int z = minZ; z <= maxZ; z++) {
                // On regroupe la résolution de chunk par colonne (x,z) :
                // tous les y partagent le même chunk.
                for (int y = minY; y <= maxY; y++) {
                    if (world.getBlockAt(x, y, z).getType() == boxMat) {
                        add(world, x, y, z);
                    }
                }
            }
        }
    }
}