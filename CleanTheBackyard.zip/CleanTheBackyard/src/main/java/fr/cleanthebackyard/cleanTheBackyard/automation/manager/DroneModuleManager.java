package fr.cleanthebackyard.cleanTheBackyard.automation.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;

public class DroneModuleManager {

    private final CleanTheBackyard plugin;

    public DroneModuleManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean installModule(Player player, String droneKey, String moduleKey) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (!data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&cTu ne possèdes pas ce drone."));
            return false;
        }
        PluginConfig.DroneModuleDef module = plugin.getPluginConfig().getDroneModule(moduleKey);
        if (module == null) {
            player.sendMessage(ChatUtil.color("&cModule inconnu : " + moduleKey));
            return false;
        }
        String existing = data.getDroneModule(droneKey);
        if (moduleKey.equals(existing)) {
            player.sendMessage(ChatUtil.color("&eCe module est déjà installé."));
            return false;
        }
        if (!plugin.getEconomyManager().debit(player, module.cost(),
                "Module " + module.name() + " pour " + droneKey)) return false;

        data.setDroneModule(droneKey, moduleKey);
        player.sendMessage(ChatUtil.color("&a✦ Module &f" + module.name() + " &ainstallé sur &f" + droneKey + "&a !"));
        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_ANVIL_USE, 0.6f, 1.2f);
        // Respawn pour appliquer les bonus
        plugin.getDroneManager().respawnSingleDrone(player, droneKey);
        return true;
    }

    public boolean removeModule(Player player, String droneKey) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (data.getDroneModule(droneKey) == null) {
            player.sendMessage(ChatUtil.color("&eAucun module installé."));
            return false;
        }
        data.setDroneModule(droneKey, null);
        player.sendMessage(ChatUtil.color("&aModule retiré."));
        plugin.getDroneManager().respawnSingleDrone(player, droneKey);
        return true;
    }
}
