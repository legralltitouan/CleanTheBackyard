package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.*;

/**
 * Découpage du jardin en secteurs de 16x16 blocs.
 * Un secteur se régénère uniquement lorsqu'il est vide
 * et qu'aucun joueur n'est à proximité.
 *
 * Géré PAR MONDE : chaque monde CTB a ses secteurs.
 */
public class SectorManager {

    private static final int SECTOR_SIZE = 16;

    private final CleanTheBackyard plugin;

    // Map<worldName, Map<sectorKey, Sector>>
    private final Map<String, Map<String, Sector>> sectorsByWorld = new HashMap<>();

    public SectorManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    // ── API Publique ──────────────────────────────────────────────────

    /**
     * Enregistre un secteur avec la liste de ses emplacements de cartons.
     */
    public void registerSector(World world, int sectorX, int sectorZ, List<Location> boxLocations) {
        String worldName = world.getName();
        sectorsByWorld
                .computeIfAbsent(worldName, k -> new HashMap<>())
                .put(sectorKey(sectorX, sectorZ), new Sector(sectorX, sectorZ, new ArrayList<>(boxLocations)));
    }

    /**
     * Marque un emplacement comme vide (carton brisé).
     */
    public void markBroken(Location loc) {
        World world = loc.getWorld();
        if (world == null) return;
        Map<String, Sector> sectors = sectorsByWorld.get(world.getName());
        if (sectors == null) return;
        String key = getSectorKeyFor(loc);
        Sector sector = sectors.get(key);
        if (sector != null) sector.markBroken(loc);
    }

    /**
     * Tente de régénérer les secteurs éligibles.
     * Appelé par SectorRegenTask toutes les 4 secondes.
     */
    public void tickRegen() {
        String hubName = plugin.getPluginConfig().getHubWorldName();

        for (World world : plugin.getServer().getWorlds()) {
            if (world.getName().equals(hubName)) continue; // pas de secteurs dans le hub
            Map<String, Sector> sectors = sectorsByWorld.get(world.getName());
            if (sectors == null) continue;

            for (Sector sector : sectors.values()) {
                if (!sector.isEmpty()) continue;

                Location center = sector.getCenterLocation(world);
                boolean playerNearby = world.getPlayers().stream()
                        .anyMatch(p -> p.getLocation().distanceSquared(center) < (SECTOR_SIZE * SECTOR_SIZE));

                if (!playerNearby) {
                    regenerateSector(sector, world);
                }
            }
        }

        plugin.getBoxManager().flushDestructionQueue();
    }

    // ── Regen Interne ─────────────────────────────────────────────────

    private void regenerateSector(Sector sector, World world) {
        Material boxMaterial = Material.matchMaterial(
                plugin.getPluginConfig().getBoxBlock()
        );
        if (boxMaterial == null) boxMaterial = Material.NOTE_BLOCK;

        for (Location loc : sector.getBoxLocations()) {
            Location realLoc = loc.clone();
            realLoc.setWorld(world);
            if (realLoc.getBlock().getType() == Material.AIR) {
                realLoc.getBlock().setType(boxMaterial, false);
            }
        }
        sector.resetBroken();
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private String getSectorKeyFor(Location loc) {
        int sx = Math.floorDiv(loc.getBlockX(), SECTOR_SIZE) * SECTOR_SIZE;
        int sz = Math.floorDiv(loc.getBlockZ(), SECTOR_SIZE) * SECTOR_SIZE;
        return sectorKey(sx, sz);
    }

    private String sectorKey(int x, int z) { return x + "_" + z; }

    public int getSectorCount()  {
        return sectorsByWorld.values().stream().mapToInt(Map::size).sum();
    }

    public Map<String, Map<String, Sector>> getSectorsByWorld() {
        return sectorsByWorld;
    }

    // ── Classe interne Secteur ────────────────────────────────────────

    public static class Sector {
        private final int x, z;
        private final List<Location> boxLocations;
        private final Set<String>    brokenLocations = new HashSet<>();

        public Sector(int x, int z, List<Location> boxLocations) {
            this.x = x;
            this.z = z;
            this.boxLocations = boxLocations;
        }

        public void markBroken(Location loc) {
            brokenLocations.add(locKey(loc));
        }

        public boolean isEmpty() {
            return brokenLocations.size() >= boxLocations.size();
        }

        public void resetBroken() { brokenLocations.clear(); }

        public List<Location> getBoxLocations() { return boxLocations; }

        public Location getCenterLocation(World world) {
            return new Location(world,
                    x + (SECTOR_SIZE / 2.0),
                    64,
                    z + (SECTOR_SIZE / 2.0));
        }

        private String locKey(Location l) {
            return l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
        }
    }
}
