package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;

import java.util.*;

/**
 * Decoupage du jardin en secteurs de 16x16 blocs.
 * Un secteur se regenere uniquement lorsqu'il est vide
 * et qu'aucun joueur n'est a proximite.
 */
public class SectorManager {

    private static final int SECTOR_SIZE = 16;

    private final CleanTheBackyard plugin;

    // Cle = "x_z" du coin NW du secteur
    private final Map<String, Sector> sectors = new HashMap<>();

    public SectorManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    // ── API Publique ──────────────────────────────────────────────────

    /**
     * Enregistre un secteur avec la liste de ses emplacements de cartons.
     */
    public void registerSector(int sectorX, int sectorZ, List<Location> boxLocations) {
        String key = sectorKey(sectorX, sectorZ);
        sectors.put(key, new Sector(sectorX, sectorZ, new ArrayList<>(boxLocations)));
    }

    /**
     * Marque un emplacement comme vide (carton brise).
     */
    public void markBroken(Location loc) {
        String key = getSectorKeyFor(loc);
        Sector sector = sectors.get(key);
        if (sector != null) sector.markBroken(loc);
    }

    /**
     * Tente de regenerer les secteurs eligibles.
     * Appele par SectorRegenTask toutes les 4 secondes.
     */
    public void tickRegen() {
        World world = plugin.getPluginConfig().getGameWorld();
        if (world == null) return;

        for (Sector sector : sectors.values()) {
            if (!sector.isEmpty()) continue;

            // Verifie qu'aucun joueur n'est proche
            Location center = sector.getCenterLocation(world);
            boolean playerNearby = world.getPlayers().stream()
                    .anyMatch(p -> p.getLocation().distanceSquared(center) < (SECTOR_SIZE * SECTOR_SIZE));

            if (!playerNearby) {
                regenerateSector(sector, world);
            }
        }

        // Vide la queue de destruction
        plugin.getBoxManager().flushDestructionQueue();
    }

    // ── Regen Interne ─────────────────────────────────────────────────

    private void regenerateSector(Sector sector, World world) {
        Material boxMaterial = Material.matchMaterial(
                plugin.getPluginConfig().getBoxBlock()
        );
        if (boxMaterial == null) boxMaterial = Material.NOTE_BLOCK;

        for (Location loc : sector.getBoxLocations()) {
            Location realLoc = loc.clone();
            realLoc.setWorld(world);
            if (realLoc.getBlock().getType() == Material.AIR) {
                realLoc.getBlock().setType(boxMaterial, false);
            }
        }
        sector.resetBroken();
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private String getSectorKeyFor(Location loc) {
        int sx = Math.floorDiv(loc.getBlockX(), SECTOR_SIZE) * SECTOR_SIZE;
        int sz = Math.floorDiv(loc.getBlockZ(), SECTOR_SIZE) * SECTOR_SIZE;
        return sectorKey(sx, sz);
    }

    private String sectorKey(int x, int z) { return x + "_" + z; }

    public int getSectorCount()  { return sectors.size(); }
    public Map<String, Sector> getSectors(){ return sectors; }

    // ── Classe interne Secteur ────────────────────────────────────────

    public static class Sector {
        private final int x, z;
        private final List<Location> boxLocations;
        private final Set<String>    brokenLocations = new HashSet<>();

        public Sector(int x, int z, List<Location> boxLocations) {
            this.x = x;
            this.z = z;
            this.boxLocations = boxLocations;
        }

        public void markBroken(Location loc) {
            brokenLocations.add(locKey(loc));
        }

        public boolean isEmpty() {
            return brokenLocations.size() >= boxLocations.size();
        }

        public void resetBroken() { brokenLocations.clear(); }

        public List<Location> getBoxLocations() { return boxLocations; }

        public Location getCenterLocation(World world) {
            return new Location(world,
                    x + (SECTOR_SIZE / 2.0),
                    64,
                    z + (SECTOR_SIZE / 2.0));
        }

        private String locKey(Location l) {
            return l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
        }
    }
}
