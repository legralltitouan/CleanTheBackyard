package fr.cleanthebackyard.cleanTheBackyard.entity;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Rabbit;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public class RatEntity {

    private final CleanTheBackyard plugin;
    private final Player owner;
    private final World world;
    private final Rabbit entity;
    private final Location stashLoc;
    private final long stealAmount;
    private final UUID id;

    private enum State { APPROACHING, STEALING, ESCAPING }
    private State state = State.APPROACHING;

    private org.bukkit.scheduler.BukkitRunnable task;
    private long startTime;
    private boolean detected = false;

    public RatEntity(Player owner, Location stashLoc, long stealAmount) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.world = owner.getWorld();
        this.stashLoc = stashLoc;
        this.stealAmount = stealAmount;
        this.id = UUID.randomUUID();

        PluginConfig cfg = plugin.getPluginConfig();
        double radius = cfg.getRatsSpawnRadius();

        Location spawnLoc = findSafeSpawnLocation(stashLoc, radius);

        this.entity = (Rabbit) world.spawnEntity(spawnLoc, EntityType.RABBIT);
        this.entity.setRabbitType(Rabbit.Type.BLACK);
        this.entity.setAdult();
        this.entity.setCustomNameVisible(true);
        this.entity.setCustomName(ChatUtil.color("&8🐀 Rat voleur"));
        this.entity.setRemoveWhenFarAway(false);
        this.entity.setAware(false);
        this.entity.setInvulnerable(false);

        this.startTime = System.currentTimeMillis();
        startTask();
        rollDetection();
    }

    private Location findSafeSpawnLocation(Location center, double radius) {
        for (int attempts = 0; attempts < 10; attempts++) {
            double angle = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);
            double dist = radius * 0.5 + ThreadLocalRandom.current().nextDouble() * (radius * 0.5);
            double x = center.getX() + Math.cos(angle) * dist;
            double z = center.getZ() + Math.sin(angle) * dist;

            int bx = (int) Math.floor(x);
            int bz = (int) Math.floor(z);

            int topY = world.getHighestBlockYAt(bx, bz);
            int spawnY = topY + 1;

            Block feet = world.getBlockAt(bx, spawnY, bz);
            Block head = world.getBlockAt(bx, spawnY + 1, bz);

            if (feet.getType().isAir() && head.getType().isAir()) {
                return new Location(world, bx + 0.5, spawnY, bz + 0.5);
            }
        }
        int bx = stashLoc.getBlockX();
        int bz = stashLoc.getBlockZ();
        int spawnY = world.getHighestBlockYAt(bx, bz) + 1;
        return new Location(world, bx + 0.5, spawnY, bz + 0.5);
    }

    public UUID getId() { return id; }
    public Player getOwner() { return owner; }
    public long getStealAmount() { return stealAmount; }
    public boolean isDetected() { return detected; }

    private void rollDetection() {
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        if (data == null) return;
        int level = data.getSecurityLevel();
        if (level <= 0) return;
        PluginConfig.SecurityUpgrade up = plugin.getPluginConfig().getSecurityUpgrade(level);
        if (up == null) return;
        if (ThreadLocalRandom.current().nextDouble() < up.detectionChance()) {
            detected = true;
            if (owner.isOnline()) {
                owner.sendMessage(ChatUtil.color("&c[Caméra] &fUn rat tente de te voler de l'argent !"));
                owner.playSound(owner.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 0.5f);
            }
        }
    }

    private void rollTrap() {
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        if (data == null) return;
        int level = data.getTrapLevel();
        if (level <= 0) return;
        PluginConfig.TrapUpgrade up = plugin.getPluginConfig().getTrapUpgrade(level);
        if (up == null) return;
        if (ThreadLocalRandom.current().nextDouble() < up.killChance()) {
            if (owner.isOnline()) {
                owner.sendMessage(ChatUtil.color("&a[Piège] &fUn rat a été éliminé !"));
                owner.playSound(owner.getLocation(), Sound.BLOCK_TRIPWIRE_CLICK_ON, 1.0f, 1.5f);
            }
            data.incrementRatsKilled();
            killByTrap();
        }
    }

    private void startTask() {
        task = new org.bukkit.scheduler.BukkitRunnable() {
            @Override
            public void run() {
                if (entity.isDead() || !entity.isValid()) {
                    stop(false);
                    return;
                }
                if (!owner.isOnline() || !owner.getWorld().equals(world)) {
                    stop(false);
                    return;
                }
                switch (state) {
                    case APPROACHING -> approachStash();
                    case STEALING -> doSteal();
                    case ESCAPING -> escape();
                }
            }
        };
        task.runTaskTimer(plugin, 2L, 4L);
        plugin.getServer().getScheduler().runTaskLater(plugin, this::rollTrap, 20L);
    }

    private void approachStash() {
        Location current = entity.getLocation();
        double dist = current.distance(stashLoc);
        if (dist < 1.8) {
            state = State.STEALING;
            startTime = System.currentTimeMillis();
            world.spawnParticle(Particle.SMOKE, stashLoc, 10, 0.3, 0.3, 0.3, 0.02);
            return;
        }
        moveTowards(stashLoc);
    }

    private void doSteal() {
        long elapsed = System.currentTimeMillis() - startTime;
        long required = plugin.getPluginConfig().getRatsTimeToStealSec() * 1000L;
        world.spawnParticle(Particle.ANGRY_VILLAGER, entity.getLocation().add(0, 0.5, 0), 1);
        if (elapsed >= required) {
            PlayerData data = plugin.getPlayerDataManager().get(owner);
            if (data != null) {
                long actual = Math.min(stealAmount, (long) data.getBalance());
                if (actual > 0) {
                    data.removeBalance(actual);
                    data.addStolenByRats(actual);
                    if (owner.isOnline()) {
                        owner.sendMessage(ChatUtil.color(
                                "&c[VOL] &fUn rat t'a volé &c" + NumberFormatUtil.money(actual) + " &f!"));
                        owner.playSound(owner.getLocation(), Sound.ENTITY_ITEM_BREAK, 0.8f, 0.7f);
                    }
                }
            }
            state = State.ESCAPING;
            startTime = System.currentTimeMillis();
        }
    }

    private void escape() {
        Location current = entity.getLocation();
        Vector away = current.toVector().subtract(stashLoc.toVector()).normalize();
        if (away.lengthSquared() < 0.01) {
            away = new Vector(1, 0, 0);
        }
        Location target = current.clone().add(away.multiply(15));
        moveTowards(target);
        if (current.distance(stashLoc) > 20 || System.currentTimeMillis() - startTime > 15_000) {
            stop(false);
        }
    }

    private void moveTowards(Location target) {
        Location current = entity.getLocation();
        Vector direction = target.toVector().subtract(current.toVector());
        direction.setY(0);
        if (direction.lengthSquared() < 0.001) return;
        direction.normalize().multiply(plugin.getPluginConfig().getRatsSpeed());

        Location newLoc = current.clone().add(direction);
        int bx = newLoc.getBlockX();
        int bz = newLoc.getBlockZ();
        int topY = world.getHighestBlockYAt(bx, bz);
        int safeY = topY + 1;

        Block feet = world.getBlockAt(bx, safeY, bz);
        Block head = world.getBlockAt(bx, safeY + 1, bz);
        if (!feet.getType().isAir() || !head.getType().isAir()) {
            return;
        }

        newLoc.setY(safeY);
        float yaw = (float) Math.toDegrees(Math.atan2(-direction.getX(), direction.getZ()));
        newLoc.setYaw(yaw);
        entity.teleport(newLoc);
    }

    public void killByTrap() {
        if (entity.isValid()) {
            world.spawnParticle(Particle.CRIT, entity.getLocation(), 15, 0.3, 0.3, 0.3, 0.1);
            world.playSound(entity.getLocation(), Sound.ENTITY_RABBIT_DEATH, 1.0f, 0.5f);
        }
        stop(true);
    }

    public void killByPlayer() {
        PlayerData data = plugin.getPlayerDataManager().get(owner);
        if (data != null) {
            if (state == State.STEALING || state == State.APPROACHING) {
                data.incrementRatsScared();
            } else {
                data.incrementRatsKilled();
            }
        }
        if (entity.isValid()) {
            world.spawnParticle(Particle.CRIT, entity.getLocation(), 15, 0.3, 0.3, 0.3, 0.1);
            world.playSound(entity.getLocation(), Sound.ENTITY_RABBIT_DEATH, 1.0f, 0.5f);
        }
        if (owner.isOnline()) {
            owner.sendMessage(ChatUtil.color("&aTu as éliminé un rat voleur !"));
        }
        stop(true);
    }

    public void stop(boolean killed) {
        if (task != null && !task.isCancelled()) task.cancel();
        if (entity != null && entity.isValid()) entity.remove();
        plugin.getRatManager().unregister(this);
    }
}
