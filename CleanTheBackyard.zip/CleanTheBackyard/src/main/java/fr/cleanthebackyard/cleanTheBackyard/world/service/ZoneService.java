package fr.cleanthebackyard.cleanTheBackyard.world.service;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import static fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil.inRadius;

public class ZoneService {
    public enum Zone {
        NONE, GARAGE, VENDING_MACHINE, DRONE_SHOP, SELL_ZONE,
        QUEST_BOARD, PRESTIGE_ALTAR, STASH, COLLECTION_BOARD,
        HOUSE_PORTAL, HOUSE_EXIT
    }

    private final CleanTheBackyard plugin;
    private final Map<UUID, Zone> currentZone = new HashMap<>();
    private BukkitRunnable task;

    public ZoneService(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void start() {
        task = new BukkitRunnable() {
            @Override
            public void run() { tick(); }
        };
        task.runTaskTimer(plugin, 10L, 5L);
    }

    public void stop() {
        if (task != null && !task.isCancelled()) task.cancel();
        currentZone.clear();
    }

    public void forget(UUID uuid) {
        currentZone.remove(uuid);
    }

    private void tick() {
        final PluginConfig cfg = plugin.getPluginConfig();
        final String hubName = cfg.getHubWorldName();
        final String prefix = cfg.getPlayerWorldPrefix();
        final String housePrefix = cfg.getHouseWorldPrefix();

        for (Player p : plugin.getServer().getOnlinePlayers()) {
            World w = p.getWorld();
            if (w == null) { currentZone.remove(p.getUniqueId()); continue; }
            String wName = w.getName();
            if (wName.equals(hubName)) {
                currentZone.remove(p.getUniqueId());
                continue;
            }
            boolean isHouseWorld = wName.startsWith(housePrefix);
            boolean isGameWorld = !isHouseWorld && wName.startsWith(prefix);
            if (!isGameWorld && !isHouseWorld) {
                currentZone.remove(p.getUniqueId());
                continue;
            }

            Zone newZone = isHouseWorld ? detectHouseZone(p.getLocation()) : detectGameZone(p.getLocation());
            Zone oldZone = currentZone.get(p.getUniqueId());
            if (newZone == oldZone) continue;
            if (newZone != Zone.SELL_ZONE && plugin.getGuiManager().hasOpenGui(p)) continue;
            if (newZone == Zone.NONE) {
                currentZone.remove(p.getUniqueId());
                continue;
            }
            currentZone.put(p.getUniqueId(), newZone);
            triggerZoneAction(p, newZone);
        }
    }

    private void triggerZoneAction(Player p, Zone zone) {
        switch (zone) {
            case GARAGE -> plugin.getGuiManager().openUpgradeGui(p);
            case VENDING_MACHINE -> plugin.getGuiManager().openVendingMachine(p);
            case DRONE_SHOP -> plugin.getGuiManager().openDroneShop(p);
            case SELL_ZONE -> plugin.getEconomyManager().sellBag(p);
            case QUEST_BOARD -> plugin.getGuiManager().openQuestGui(p);
            case PRESTIGE_ALTAR -> plugin.getGuiManager().openPrestigeGui(p);
            case STASH -> plugin.getGuiManager().openSecurityGui(p);
            case COLLECTION_BOARD -> plugin.getGuiManager().openCollectionGui(p);
            case HOUSE_PORTAL -> plugin.getGuiManager().openHousePortal(p);
            case HOUSE_EXIT -> plugin.getGuiManager().openHouseExit(p);
            default -> {}
        }
    }

    private Zone detectGameZone(Location loc) {
        PluginConfig cfg = plugin.getPluginConfig();
        World world = loc.getWorld();
        if (world == null) return Zone.NONE;
        if (inRadius(loc, cfg.getGarageLocation(world), cfg.getGarageRadius())) return Zone.GARAGE;
        if (inRadius(loc, cfg.getVendingMachineLocation(world), cfg.getVendingMachineRadius())) return Zone.VENDING_MACHINE;
        if (inRadius(loc, cfg.getDroneShopLocation(world), cfg.getDroneShopRadius())) return Zone.DRONE_SHOP;
        if (inRadius(loc, cfg.getSellZoneCenter(world), cfg.getSellZoneRadius())) return Zone.SELL_ZONE;
        if (inRadius(loc, cfg.getQuestBoardLocation(world), cfg.getQuestBoardRadius())) return Zone.QUEST_BOARD;
        if (inRadius(loc, cfg.getPrestigeAltarLocation(world), cfg.getPrestigeAltarRadius())) return Zone.PRESTIGE_ALTAR;
        if (inRadius(loc, cfg.getStashLocation(world), cfg.getStashRadius())) return Zone.STASH;
        if (inRadius(loc, cfg.getCollectionBoardLocation(world), cfg.getCollectionBoardRadius())) return Zone.COLLECTION_BOARD;
        if (inRadius(loc, cfg.getHousePortalLocation(world), cfg.getHousePortalRadius())) return Zone.HOUSE_PORTAL;
        return Zone.NONE;
    }

    private Zone detectHouseZone(Location loc) {
        PluginConfig cfg = plugin.getPluginConfig();
        World world = loc.getWorld();
        if (world == null) return Zone.NONE;
        if (inRadius(loc, cfg.getHouseExitLocation(world), cfg.getHouseExitRadius())) return Zone.HOUSE_EXIT;
        return Zone.NONE;
    }
}
