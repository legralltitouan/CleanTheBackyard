package fr.cleanthebackyard.cleanTheBackyard.event;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.CustomEntityHandle;
import fr.cleanthebackyard.cleanTheBackyard.provider.EntityRef;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * Event "Drone Doré" : un drone apparaît près d'un joueur et s'enfuit en
 * ligne droite à vitesse constante mais avec mouvement interpolé.
 */
public class GoldenDroneEvent {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    private CustomEntityHandle handle = null;
    private UUID entityUUID = null;
    private int reward = 0;
    private BukkitTask task = null;
    private Player target = null;

    private Vector flightDirection = null;
    private double flightSpeed = 0.35; // blocs / tick
    private Vector currentVelocity = new Vector(0, 0, 0);

    public GoldenDroneEvent(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void scheduleNext() {
        PluginConfig cfg = plugin.core().config();
        int delay = cfg.getGoldenDroneMin()
                + random.nextInt(Math.max(1, cfg.getGoldenDroneMax() - cfg.getGoldenDroneMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::trigger, delay * 20L);
    }

    public void trigger() {
        if (entityUUID != null) return;
        List<Player> ctbPlayers = EventUtils.getAllCtbPlayers(plugin);
        if (ctbPlayers.isEmpty()) {
            scheduleNext();
            return;
        }

        target = ctbPlayers.get(random.nextInt(ctbPlayers.size()));
        if (!EventUtils.isInOwnWorld(plugin, target)) {
            scheduleNext();
            return;
        }

        PlayerData targetData = plugin.core().playerData().get(target);
        reward = calculateReward(targetData);

        PluginConfig cfg = plugin.core().config();
        double spawnDist = cfg.getGoldenDroneSpawnDistance();
        flightSpeed = cfg.getGoldenDroneSpeed();
        int lifetimeSec = cfg.getGoldenDroneLifetimeSec();

        double angle = random.nextDouble() * Math.PI * 2;
        Vector offset = new Vector(Math.cos(angle) * spawnDist, 2.5, Math.sin(angle) * spawnDist);
        Location spawnLoc = target.getLocation().clone().add(offset);

        flightDirection = target.getLocation().toVector()
                .subtract(spawnLoc.toVector())
                .setY(0)
                .normalize()
                .add(new Vector(0, 0.1, 0))
                .normalize();

        currentVelocity = new Vector(0, 0, 0);

        EntityRef ref = cfg.getGoldenDroneEntityRef();
        handle = plugin.providers().entity().spawn(ref, spawnLoc, EntityType.BAT, "golden-drone");
        Entity drone = handle.getBukkitEntity();
        drone.setCustomName(ChatUtil.color("&6✦ Drone Doré &7[&e$" + reward + "&7] ✦"));
        drone.setCustomNameVisible(true);
        drone.setInvulnerable(false);

        if (drone instanceof LivingEntity le) le.setRemoveWhenFarAway(false);
        if (drone instanceof Mob mob) mob.setAware(false);

        entityUUID = drone.getUniqueId();

        target.sendMessage(ChatUtil.color(
                "&6[DRONE DORÉ] &eUn drone s'enfuit ! Cours après et frappe-le pour gagner &f$" + reward
                        + " &e(disparaît dans " + lifetimeSec + "s)"
        ));
        target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.5f);

        startFlightTask(lifetimeSec);
    }

    private void startFlightTask(int lifetimeSec) {
        final UUID droneUUID = entityUUID;
        final long maxTicks = lifetimeSec * 20L;

        task = new BukkitRunnable() {
            long ticks = 0;

            @Override
            public void run() {
                ticks++;

                Entity entity = Bukkit.getEntity(droneUUID);

                if (entity == null || !entity.isValid()) {
                    expire(false);
                    cancel();
                    return;
                }

                if (ticks >= maxTicks) {
                    expire(true);
                    entity.remove();
                    cancel();
                    return;
                }

                Location current = entity.getLocation();

                // Vélocité désirée = direction de fuite × vitesse
                Vector desiredVelocity = flightDirection.clone().multiply(flightSpeed);

                // Interpolation pour un démarrage doux et un mouvement stable
                double smoothing = 0.25;
                currentVelocity.setX(currentVelocity.getX() + (desiredVelocity.getX() - currentVelocity.getX()) * smoothing);
                currentVelocity.setY(currentVelocity.getY() + (desiredVelocity.getY() - currentVelocity.getY()) * smoothing);
                currentVelocity.setZ(currentVelocity.getZ() + (desiredVelocity.getZ() - currentVelocity.getZ()) * smoothing);

                // Clamp à la vitesse cible
                if (currentVelocity.length() > flightSpeed) {
                    currentVelocity = currentVelocity.normalize().multiply(flightSpeed);
                }

                Location next = current.clone().add(currentVelocity);

                if (currentVelocity.lengthSquared() > 0.0001) {
                    float targetYaw = (float) Math.toDegrees(
                            Math.atan2(-currentVelocity.getX(), currentVelocity.getZ())
                    );
                    next.setYaw(lerpAngle(current.getYaw(), targetYaw, 0.3f));
                }
                next.setPitch(0);

                entity.teleport(next);
            }
        }.runTaskTimer(plugin, 1L, 1L);
    }

    private float lerpAngle(float from, float to, float t) {
        float diff = ((to - from) % 360 + 540) % 360 - 180;
        return from + diff * t;
    }

    private int calculateReward(PlayerData data) {
        if (data == null) return 500 + random.nextInt(500);
        int baseReward = 500 + random.nextInt(500);
        baseReward += data.getBagLevel() * 100;
        baseReward += data.getToolLevel() * 75;
        baseReward += data.getEnergyLevel() * 50;
        baseReward *= (1 + data.getPrestigeLevel() / 2);
        return baseReward;
    }

    private void expire(boolean timeout) {
        Player t = target;
        cleanup();
        if (timeout && t != null && t.isOnline()) {
            t.sendMessage(ChatUtil.colored("&7[Drone Doré] Trop tard, il s'est échappé..."));
        }
        scheduleNext();
    }

    public boolean claim(Player player, UUID uuid) {
        if (entityUUID == null || !entityUUID.equals(uuid)) return false;
        int r = reward;
        Entity drone = Bukkit.getEntity(uuid);
        cleanup();
        if (drone != null) drone.remove();
        plugin.core().economy().credit(player, r);
        player.sendMessage(ChatUtil.colored("&6✦ Drone Doré abattu ! +$" + r + " ✦"));
        player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.2f);
        scheduleNext();
        return true;
    }

    private void cleanup() {
        entityUUID = null;
        handle = null;
        reward = 0;
        target = null;
        flightDirection = null;
        currentVelocity = new Vector(0, 0, 0);
        if (task != null) { task.cancel(); task = null; }
    }

    public boolean isSpawned()             { return entityUUID != null; }
    public UUID getCurrentEntityUUID()     { return entityUUID; }
}
