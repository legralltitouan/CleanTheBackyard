package fr.cleanthebackyard.cleanTheBackyard.event;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.entity.Bat;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.List;
import java.util.Random;
import java.util.UUID;

public class GoldenDroneEvent {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    private UUID entityUUID = null;
    private int reward = 0;
    private BukkitTask task = null;
    private Player target = null;

    public GoldenDroneEvent(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void scheduleNext() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getGoldenDroneMin()
                + random.nextInt(Math.max(1, cfg.getGoldenDroneMax() - cfg.getGoldenDroneMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::trigger, delay * 20L);
    }

    public void trigger() {
        if (entityUUID != null) return;
        List<Player> ctbPlayers = EventUtils.getAllCtbPlayers(plugin);
        if (ctbPlayers.isEmpty()) { scheduleNext(); return; }

        target = ctbPlayers.get(random.nextInt(ctbPlayers.size()));
        if (!EventUtils.isInOwnWorld(plugin, target)) {
            scheduleNext();
            return;
        }

        PlayerData targetData = plugin.getPlayerDataManager().get(target);
        reward = calculateReward(targetData);

        Location spawnLoc = target.getLocation().clone().add(
                (random.nextDouble() - 0.5) * 6,
                4 + random.nextDouble() * 2,
                (random.nextDouble() - 0.5) * 6
        );

        Bat drone = (Bat) spawnLoc.getWorld().spawnEntity(spawnLoc, EntityType.BAT);
        drone.setCustomName(ChatUtil.color("&6✦ Drone Doré [$" + reward + "] ✦"));
        drone.setCustomNameVisible(true);
        drone.setRemoveWhenFarAway(false);
        drone.setAware(false);
        entityUUID = drone.getUniqueId();

        double angle = random.nextDouble() * Math.PI * 2;
        drone.setVelocity(new Vector(Math.cos(angle) * 0.15, 0.05, Math.sin(angle) * 0.15));

        target.sendMessage(ChatUtil.color(
                "&6[DRONE DORÉ] &eDrone Doré apparu ! Frappe-le en moins de &f30s &epour &f$" + reward
        ));
        target.playSound(target.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.5f);

        final UUID droneUUID = entityUUID;
        task = new BukkitRunnable() {
            int ticks = 0;
            final double baseSpeed = 0.15;
            @Override public void run() {
                ticks += 2;
                Entity entity = Bukkit.getEntity(droneUUID);
                if (entity == null || !entity.isValid()) { expire(false); cancel(); return; }
                if (ticks >= 600) { expire(true); entity.remove(); cancel(); return; }
                Vector vel = entity.getVelocity();
                double hSpeed = Math.sqrt(vel.getX() * vel.getX() + vel.getZ() * vel.getZ());
                if (hSpeed < baseSpeed * 0.8) {
                    double a = Math.atan2(vel.getZ(), vel.getX());
                    entity.setVelocity(new Vector(Math.cos(a) * baseSpeed, vel.getY(), Math.sin(a) * baseSpeed));
                }
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }

    private int calculateReward(PlayerData data) {
        if (data == null) return 500 + random.nextInt(500);
        int baseReward = 500 + random.nextInt(500);
        baseReward += data.getBagLevel() * 100;
        baseReward += data.getToolLevel() * 75;
        baseReward += data.getEnergyLevel() * 50;
        baseReward *= (1 + data.getPrestigeLevel() / 2);
        return baseReward;
    }

    private void expire(boolean timeout) {
        Player t = target;
        cleanup();
        if (timeout && t != null && t.isOnline()) {
            t.sendMessage(ChatUtil.colored("&7[Drone Doré] Trop tard..."));
        }
        scheduleNext();
    }

    public boolean claim(Player player, UUID uuid) {
        if (entityUUID == null || !entityUUID.equals(uuid)) return false;
        int r = reward;
        Entity drone = Bukkit.getEntity(uuid);
        cleanup();
        if (drone != null) drone.remove();
        plugin.getEconomyManager().credit(player, r);
        player.sendMessage(ChatUtil.colored("&6✦ Drone Doré abattu ! +$" + r + " ✦"));
        scheduleNext();
        return true;
    }

    private void cleanup() {
        entityUUID = null;
        reward = 0;
        target = null;
        if (task != null) { task.cancel(); task = null; }
    }

    public boolean isSpawned() { return entityUUID != null; }
}
