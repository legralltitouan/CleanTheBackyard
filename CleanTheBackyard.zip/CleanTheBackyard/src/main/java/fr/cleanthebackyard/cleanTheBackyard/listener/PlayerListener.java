package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import java.util.UUID;
public class PlayerListener implements Listener {
    private final CleanTheBackyard plugin;
    public PlayerListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private boolean isPlayerGameWorld(World world) {
        if (world == null) return false;
        String hubName = plugin.getPluginConfig().getHubWorldName();
        if (world.getName().equals(hubName)) return false;
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        String housePrefix = plugin.getPluginConfig().getHouseWorldPrefix();
        // Exclut explicitement les mondes-maison (ctb_house_*) qui matchent aussi "ctb_"
        if (world.getName().startsWith(housePrefix)) return false;
        return world.getName().startsWith(prefix);
    }
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            PlayerData data = plugin.getPlayerDataManager().loadPlayer(player);
            int maxEnergy = plugin.getBoxManager().getMaxEnergyForPlayer(data);
            if (data.getCurrentEnergy() > maxEnergy) data.setCurrentEnergy(maxEnergy);
            plugin.getQuestManager().checkAndResetQuests(data);

            // ── Sleep mode (avant tout autre message d'argent) ──
            plugin.getOfflineEarningsManager().applyOnJoin(player, data);

            // ── Daily streak : check si on a cassé la streak ──
            plugin.getDailyRewardManager().maybeNotifyStreakBroken(player, data);

            player.sendMessage(ChatUtil.color(
                    "&a&lClean The Backyard &8| &fBienvenue " + player.getName() + " !"
                            + (data.getPrestigeLevel() > 0 ? " &6[Prestige " + data.getPrestigeLevel() + "]" : "")
                            + "\n&7Solde : &f" + NumberFormatUtil.money(data.getBalance())
                            + " &7| Sac : &f" + data.getCurrentBoxes() + "/" +
                            plugin.getBoxManager().getBagCapacity(data.getBagLevel())
            ));
            if (data.getTalentPoints() > 0) {
                player.sendMessage(ChatUtil.color("&d✦ Tu as &f" + data.getTalentPoints()
                        + " &dpoint(s) de talent à dépenser ! &7(/ctb talent)"));
            }

            if (isPlayerGameWorld(player.getWorld())) {
                plugin.getDroneManager().respawnPlayerDrones(player);
                plugin.getRatManager().onPlayerEnterWorld(player);
                // Affiche la frontière de zone
                plugin.getServer().getScheduler().runTaskLater(plugin,
                        () -> { if (player.isOnline()) plugin.getZoneBorderManager().refresh(player); }, 20L);
            }

            // ── Ouvre la GUI de récompense quotidienne si pas réclamée ──
            if (!plugin.getDailyRewardManager().alreadyClaimedToday(data)) {
                plugin.getServer().getScheduler().runTaskLater(plugin,
                        () -> { if (player.isOnline()) plugin.getGuiManager().openDailyReward(player); },
                        40L);
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        plugin.getDroneManager().despawnPlayerDrones(player);
        plugin.getRatManager().onPlayerLeaveWorld(player);
        plugin.getZoneBorderManager().clearForPlayerWorld(player);

        PlayerData pd = plugin.getPlayerDataManager().get(player);
        if (pd != null) pd.setLastSeenMs(System.currentTimeMillis());


        plugin.getPlayerDataManager().unloadPlayer(uuid);
        plugin.getZoneService().forget(uuid);
        plugin.getHudTask().forgetPlayer(uuid);
    }
    /**
     * Hook ESSENTIEL : gère rats ET drones quand le joueur change de monde
     * via /go, /spawn, l'entrée/sortie de maison ou tout autre téléport inter-mondes.
     */
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        World from = event.getFrom();
        World to = player.getWorld();
        // Quittait un monde de jeu : on stoppe rats + drones
        if (isPlayerGameWorld(from)) {
            plugin.getRatManager().onPlayerLeaveWorld(player);
            plugin.getDroneManager().despawnPlayerDrones(player);
        }
        // Entre dans un monde de jeu : on démarre rats + drones
        if (isPlayerGameWorld(to)) {
            plugin.getRatManager().onPlayerEnterWorld(player);
            // Petit délai pour laisser le monde se charger complètement après le téléport
            plugin.getServer().getScheduler().runTaskLater(plugin,
                    () -> {
                        if (player.isOnline() && isPlayerGameWorld(player.getWorld())) {
                            plugin.getDroneManager().respawnPlayerDrones(player);
                            plugin.getZoneBorderManager().refresh(player);
                        }
                    }, 10L);
        }
    }
    @EventHandler
    public void onSprint(PlayerToggleSprintEvent event) {
        if (!event.isSprinting()) return;
        Player player = event.getPlayer();
        if (!isPlayerGameWorld(player.getWorld())) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        if (data.getCurrentEnergy() < 10) {
            player.sendActionBar(Component.text(
                    ChatUtil.color("&cÉnergie faible ! (" + String.format("%.0f", data.getCurrentEnergy()) + ")")
            ));
        }
    }
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!isPlayerGameWorld(player.getWorld())) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        if (event.getTo() == null) return;
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;
        updateEnergyEffects(player, data);
        if (player.isSprinting() && data.getCurrentEnergy() <= 0) {
            plugin.getBoxManager().applyFatigue(player, data);
        }
    }
    private void updateEnergyEffects(Player player, PlayerData data) {
        double currentEnergy = data.getCurrentEnergy();
        if (currentEnergy < 5) {
            if (!player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
                player.addPotionEffect(new PotionEffect(
                        PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 2, false, false, false));
            }
            if (!player.hasPotionEffect(PotionEffectType.BLINDNESS)) {
                player.addPotionEffect(new PotionEffect(
                        PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false));
            }
        } else if (currentEnergy > 25) {
            if (player.hasPotionEffect(PotionEffectType.SLOWNESS)) player.removePotionEffect(PotionEffectType.SLOWNESS);
            if (player.hasPotionEffect(PotionEffectType.BLINDNESS)) player.removePotionEffect(PotionEffectType.BLINDNESS);
        }
    }
}