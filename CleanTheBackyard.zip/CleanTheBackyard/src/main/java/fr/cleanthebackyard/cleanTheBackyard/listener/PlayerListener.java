package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.potion.PotionEffectType;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class PlayerListener implements Listener {

    /** Zones interactives détectées par déplacement. */

    private enum Zone { GARAGE, VENDING_MACHINE, DRONE_SHOP, SELL_ZONE }

    private final CleanTheBackyard plugin;

    /** Zone actuellement occupée par chaque joueur (anti-spam à l'entrée). */

    private final Map<UUID, Zone> currentZone = new HashMap<>();

    public PlayerListener(CleanTheBackyard plugin) {

        this.plugin = plugin;

    }

    @EventHandler

    public void onJoin(PlayerJoinEvent event) {

        var player = event.getPlayer();

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () ->

                plugin.getServer().getScheduler().runTask(plugin, () -> {

                    PlayerData data = plugin.getPlayerDataManager().loadPlayer(player);

                    int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());

                    if (data.getCurrentEnergy() > maxEnergy) data.setCurrentEnergy(maxEnergy);

                    player.sendMessage(ChatUtil.colored(

                            "&a&lClean The Backyard &8| &fBienvenue " + player.getName() + " !"

                                    + "\n&7Solde : &f$" + String.format("%.0f", data.getBalance())

                                    + " &7| Sac : &f" + data.getCurrentBoxes() + "/" +

                                    plugin.getBoxManager().getBagCapacity(data.getBagLevel())

                    ));

                })

        );

    }

    @EventHandler

    public void onQuit(PlayerQuitEvent event) {

        plugin.getPlayerDataManager().unloadPlayer(event.getPlayer().getUniqueId());

        currentZone.remove(event.getPlayer().getUniqueId());

    }

    @EventHandler

    public void onSprint(PlayerToggleSprintEvent event) {

        if (!event.isSprinting()) return;

        var player = event.getPlayer();

        PlayerData data = plugin.getPlayerDataManager().get(player);

        if (data == null) return;

        if (data.getCurrentEnergy() < 10) {

            player.sendActionBar(Component.text(

                    ChatUtil.color("&cEnergie faible ! (" + String.format("%.0f", data.getCurrentEnergy()) + ")")

            ));

        }

    }

    @EventHandler

    public void onMove(PlayerMoveEvent event) {

        var player = event.getPlayer();

        PlayerData data = plugin.getPlayerDataManager().get(player);

        if (data == null) return;

        // Gestion des effets de fatigue selon l'énergie
        updateEnergyEffects(player, data);

        // Fatigue en sprint si énergie = 0

        if (player.isSprinting() && data.getCurrentEnergy() <= 0) {

            plugin.getBoxManager().applyFatigue(player, data);

        }

        // Détection uniquement quand on change de bloc (perf)

        if (event.getTo() == null) return;

        if (event.getFrom().getBlockX() == event.getTo().getBlockX()

                && event.getFrom().getBlockY() == event.getTo().getBlockY()

                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;

        Zone newZone = detectZone(event.getTo());

        Zone oldZone = currentZone.get(player.getUniqueId());

        if (newZone == oldZone) return;

        if (newZone == null) {

            currentZone.remove(player.getUniqueId());

            return;

        }

        // La zone de vente n'ouvre pas de GUI, donc elle ignore hasOpenGui.

        if (newZone != Zone.SELL_ZONE && plugin.getGuiManager().hasOpenGui(player)) return;

        currentZone.put(player.getUniqueId(), newZone);

        switch (newZone) {

            case GARAGE          -> plugin.getGuiManager().openUpgradeGui(player);

            case VENDING_MACHINE -> plugin.getGuiManager().openVendingMachine(player);

            case DRONE_SHOP      -> plugin.getGuiManager().openDroneShop(player);

            case SELL_ZONE       -> plugin.getEconomyManager().sellBag(player);

        }

    }

    /**

     * Gère les effets de potion selon le niveau d'énergie.

     * - En dessous de 5 : Slowness + Blindness

     * - Au-dessus de 25 : Retire tous les effets négatifs

     */

    private void updateEnergyEffects(Player player, PlayerData data) {

        double currentEnergy = data.getCurrentEnergy();

        if (currentEnergy < 5) {

            // Applique slowness et blindness

            if (!player.hasPotionEffect(PotionEffectType.SLOWNESS)) {

                player.addPotionEffect(new org.bukkit.potion.PotionEffect(

                        PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 2, false, false, false

                ));

            }

            if (!player.hasPotionEffect(PotionEffectType.BLINDNESS)) {

                player.addPotionEffect(new org.bukkit.potion.PotionEffect(

                        PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false

                ));

            }

        } else if (currentEnergy > 25) {

            // Retire slowness et blindness

            if (player.hasPotionEffect(PotionEffectType.SLOWNESS)) {

                player.removePotionEffect(PotionEffectType.SLOWNESS);

            }

            if (player.hasPotionEffect(PotionEffectType.BLINDNESS)) {

                player.removePotionEffect(PotionEffectType.BLINDNESS);

            }

        }

    }

    /** Renvoie la zone d'interaction dans laquelle se trouve la position, ou null. */

    private Zone detectZone(Location loc) {

        PluginConfig cfg = plugin.getPluginConfig();

        World world = loc.getWorld();

        if (world == null || !world.getName().equals(cfg.getGameWorldName())) return null;

        if (inRadius(loc, cfg.getGarageLocation(), cfg.getGarageRadius()))

            return Zone.GARAGE;

        if (inRadius(loc, cfg.getVendingMachineLocation(), cfg.getVendingMachineRadius()))

            return Zone.VENDING_MACHINE;

        if (inRadius(loc, cfg.getDroneShopLocation(), cfg.getDroneShopRadius()))

            return Zone.DRONE_SHOP;

        if (inRadius(loc, cfg.getSellZoneCenter(), cfg.getSellZoneRadius()))

            return Zone.SELL_ZONE;

        return null;

    }

    private boolean inRadius(Location player, Location target, double radius) {

        if (target.getWorld() == null || !target.getWorld().equals(player.getWorld())) return false;

        return player.distanceSquared(target) <= radius * radius;

    }

}