package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.potion.PotionEffectType;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
public class PlayerListener implements Listener {
    private enum Zone { GARAGE, VENDING_MACHINE, DRONE_SHOP, SELL_ZONE, QUEST_BOARD, PRESTIGE_ALTAR }
    private final CleanTheBackyard plugin;
    private final Map<UUID, Zone> currentZone = new HashMap<>();
    public PlayerListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private boolean isPlayerGameWorld(World world, UUID uuid) {
        if (world == null) return false;
        String hubName = plugin.getPluginConfig().getHubWorldName();
        if (world.getName().equals(hubName)) return false;
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        return world.getName().startsWith(prefix);
    }
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            PlayerData data = plugin.getPlayerDataManager().loadPlayer(player);
            int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());
            if (data.getCurrentEnergy() > maxEnergy) data.setCurrentEnergy(maxEnergy);
            plugin.getQuestManager().checkAndResetQuests(data);
            player.sendMessage(ChatUtil.color(
                    "&a&lClean The Backyard &8| &fBienvenue " + player.getName() + " !"
                            + (data.getPrestigeLevel() > 0 ? " &6[Prestige " + data.getPrestigeLevel() + "]" : "")
                            + "\n&7Solde : &f$" + String.format("%.0f", data.getBalance())
                            + " &7| Sac : &f" + data.getCurrentBoxes() + "/" +
                            plugin.getBoxManager().getBagCapacity(data.getBagLevel())
            ));
            if (isPlayerGameWorld(player.getWorld(), player.getUniqueId())) {
                plugin.getDroneManager().respawnPlayerDrones(player);
            }
        });
    }
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        plugin.getDroneManager().despawnPlayerDrones(player);
        plugin.getPlayerDataManager().unloadPlayer(uuid);
        currentZone.remove(uuid);
        plugin.getHudTask().forgetPlayer(uuid);
    }
    @EventHandler
    public void onSprint(PlayerToggleSprintEvent event) {
        if (!event.isSprinting()) return;
        Player player = event.getPlayer();
        if (!isPlayerGameWorld(player.getWorld(), player.getUniqueId())) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        if (data.getCurrentEnergy() < 10) {
            player.sendActionBar(Component.text(
                    ChatUtil.color("&cÉnergie faible ! (" + String.format("%.0f", data.getCurrentEnergy()) + ")")
            ));
        }
    }
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        World world = player.getWorld();
        if (!isPlayerGameWorld(world, uuid)) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        updateEnergyEffects(player, data);
        if (player.isSprinting() && data.getCurrentEnergy() <= 0) {
            plugin.getBoxManager().applyFatigue(player, data);
        }
        if (event.getTo() == null) return;
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;
        Zone newZone = detectZone(event.getTo());
        Zone oldZone = currentZone.get(uuid);
        if (newZone == oldZone) return;
        if (newZone == null) {
            currentZone.remove(uuid);
            return;
        }
        if (newZone != Zone.SELL_ZONE && plugin.getGuiManager().hasOpenGui(player)) return;
        currentZone.put(uuid, newZone);
        switch (newZone) {
            case GARAGE          -> plugin.getGuiManager().openUpgradeGui(player);
            case VENDING_MACHINE -> plugin.getGuiManager().openVendingMachine(player);
            case DRONE_SHOP      -> plugin.getGuiManager().openDroneShop(player);
            case SELL_ZONE       -> plugin.getEconomyManager().sellBag(player);
            case QUEST_BOARD     -> plugin.getGuiManager().openQuestGui(player);
            case PRESTIGE_ALTAR  -> plugin.getGuiManager().openPrestigeGui(player);
        }
    }
    private void updateEnergyEffects(Player player, PlayerData data) {
        double currentEnergy = data.getCurrentEnergy();
        if (currentEnergy < 5) {
            if (!player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                        PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 2, false, false, false));
            }
            if (!player.hasPotionEffect(PotionEffectType.BLINDNESS)) {
                player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                        PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false));
            }
        } else if (currentEnergy > 25) {
            if (player.hasPotionEffect(PotionEffectType.SLOWNESS)) player.removePotionEffect(PotionEffectType.SLOWNESS);
            if (player.hasPotionEffect(PotionEffectType.BLINDNESS)) player.removePotionEffect(PotionEffectType.BLINDNESS);
        }
    }
    private Zone detectZone(Location loc) {
        PluginConfig cfg = plugin.getPluginConfig();
        World world = loc.getWorld();
        if (world == null) return null;
        if (world.getName().equals(cfg.getHubWorldName())) return null;
        if (inRadius(loc, cfg.getGarageLocation(world), cfg.getGarageRadius())) return Zone.GARAGE;
        if (inRadius(loc, cfg.getVendingMachineLocation(world), cfg.getVendingMachineRadius())) return Zone.VENDING_MACHINE;
        if (inRadius(loc, cfg.getDroneShopLocation(world), cfg.getDroneShopRadius())) return Zone.DRONE_SHOP;
        if (inRadius(loc, cfg.getSellZoneCenter(world), cfg.getSellZoneRadius())) return Zone.SELL_ZONE;
        if (inRadius(loc, cfg.getQuestBoardLocation(world), cfg.getQuestBoardRadius())) return Zone.QUEST_BOARD;
        if (inRadius(loc, cfg.getPrestigeAltarLocation(world), cfg.getPrestigeAltarRadius())) return Zone.PRESTIGE_ALTAR;
        return null;
    }
    private boolean inRadius(Location player, Location target, double radius) {
        if (target == null || target.getWorld() == null) return false;
        if (!target.getWorld().equals(player.getWorld())) return false;
        return player.distanceSquared(target) <= radius * radius;
    }
}