package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.UUID;

public class PlayerListener implements Listener {

    private final CleanTheBackyard plugin;

    public PlayerListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private boolean isPlayerGameWorld(World world) {
        if (world == null) return false;
        String hubName = plugin.getPluginConfig().getHubWorldName();
        if (world.getName().equals(hubName)) return false;
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        return world.getName().startsWith(prefix);
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            PlayerData data = plugin.getPlayerDataManager().loadPlayer(player);
            int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());
            if (data.getCurrentEnergy() > maxEnergy) data.setCurrentEnergy(maxEnergy);
            plugin.getQuestManager().checkAndResetQuests(data);

            player.sendMessage(ChatUtil.color(
                    "&a&lClean The Backyard &8| &fBienvenue " + player.getName() + " !"
                            + (data.getPrestigeLevel() > 0 ? " &6[Prestige " + data.getPrestigeLevel() + "]" : "")
                            + "\n&7Solde : &f$" + String.format("%.0f", data.getBalance())
                            + " &7| Sac : &f" + data.getCurrentBoxes() + "/" +
                            plugin.getBoxManager().getBagCapacity(data.getBagLevel())
            ));

            if (isPlayerGameWorld(player.getWorld())) {
                plugin.getDroneManager().respawnPlayerDrones(player);
            }
        });
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        plugin.getDroneManager().despawnPlayerDrones(player);
        plugin.getPlayerDataManager().unloadPlayer(uuid);
        plugin.getZoneService().forget(uuid);
        plugin.getHudTask().forgetPlayer(uuid);
    }

    @EventHandler
    public void onSprint(PlayerToggleSprintEvent event) {
        if (!event.isSprinting()) return;
        Player player = event.getPlayer();
        if (!isPlayerGameWorld(player.getWorld())) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        if (data.getCurrentEnergy() < 10) {
            player.sendActionBar(Component.text(
                    ChatUtil.color("&cÉnergie faible ! (" + String.format("%.0f", data.getCurrentEnergy()) + ")")
            ));
        }
    }

    /**
     * On garde ce listener léger : seulement gestion des effets visuels d'énergie
     * + déclenchement de la fatigue. La détection de zone est dans ZoneService.
     */
    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!isPlayerGameWorld(player.getWorld())) return;
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        // Skip si même bloc (optimisation classique)
        if (event.getTo() == null) return;
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) return;

        updateEnergyEffects(player, data);

        if (player.isSprinting() && data.getCurrentEnergy() <= 0) {
            plugin.getBoxManager().applyFatigue(player, data);
        }
    }

    private void updateEnergyEffects(Player player, PlayerData data) {
        double currentEnergy = data.getCurrentEnergy();
        if (currentEnergy < 5) {
            if (!player.hasPotionEffect(PotionEffectType.SLOWNESS)) {
                player.addPotionEffect(new PotionEffect(
                        PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 2, false, false, false));
            }
            if (!player.hasPotionEffect(PotionEffectType.BLINDNESS)) {
                player.addPotionEffect(new PotionEffect(
                        PotionEffectType.BLINDNESS, Integer.MAX_VALUE, 0, false, false, false));
            }
        } else if (currentEnergy > 25) {
            if (player.hasPotionEffect(PotionEffectType.SLOWNESS)) player.removePotionEffect(PotionEffectType.SLOWNESS);
            if (player.hasPotionEffect(PotionEffectType.BLINDNESS)) player.removePotionEffect(PotionEffectType.BLINDNESS);
        }
    }
}
