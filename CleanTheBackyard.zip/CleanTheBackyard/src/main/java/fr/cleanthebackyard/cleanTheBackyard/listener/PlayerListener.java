package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import java.util.UUID;
public class PlayerListener implements Listener {
    private final CleanTheBackyard plugin;
    public PlayerListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private boolean isPlayerGameWorld(World world) {
        if (world == null) return false;
        String hubName = plugin.core().config().getHubWorldName();
        if (world.getName().equals(hubName)) return false;
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        if (world.getName().startsWith(housePrefix)) return false;
        return world.getName().startsWith(prefix);
    }
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            PlayerData data = plugin.core().playerData().loadPlayer(player);
            data.setRawDoubleSellUntil(0L);
            data.setRawBlackMarketUntil(0L);
            data.setRawUnlimitedEnergyUntil(0L);
            int maxEnergy = plugin.gameplay().box().getMaxEnergyForPlayer(data);
            if (data.getCurrentEnergy() > maxEnergy) data.setCurrentEnergy(maxEnergy);
            plugin.progression().quest().checkAndResetQuests(data);
            plugin.progression().offlineEarnings().applyOnJoin(player, data);
            plugin.progression().dailyReward().maybeNotifyStreakBroken(player, data);
            player.sendMessage(ChatUtil.color(
                    "&a&lClean The Backyard &8| &fBienvenue " + player.getName() + " !"
                            + (data.getPrestigeLevel() > 0 ? " &6[Prestige " + data.getPrestigeLevel() + "]" : "")
                            + "\n&7Solde : &f" + NumberFormatUtil.money(data.getBalance())
                            + " &7| Sac : &f" + data.getCurrentBoxes() + "/" +
                            plugin.gameplay().box().getBagCapacity(data.getBagLevel())
            ));
            if (data.getTalentPoints() > 0) {
                player.sendMessage(ChatUtil.color("&d✦ Tu as &f" + data.getTalentPoints()
                        + " &dpoint(s) de talent à dépenser ! &7(/ctb talent)"));
            }
            if (isPlayerGameWorld(player.getWorld())) {
                // Indexe les cartons déjà présents (monde cloné du template)
                // AVANT de respawn les drones, pour qu'ils aient une cible dès le départ.
                indexWorldBoxesOnce(player);
                plugin.automation().drone().respawnPlayerDrones(player);
                plugin.security().rat().onPlayerEnterWorld(player);
                plugin.getServer().getScheduler().runTaskLater(plugin,
                        () -> { if (player.isOnline()) plugin.world().zoneBorder().refresh(player);
                        }, 20L);
            }
            if (!plugin.progression().dailyReward().alreadyClaimedToday(data)) {
                plugin.getServer().getScheduler().runTaskLater(plugin,
                        () -> { if (player.isOnline()) plugin.ui().gui().openDailyReward(player);
                        },
                        40L);
            }
        });
    }
    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();
        PlayerData pd = plugin.core().playerData().get(player);
        if (pd != null) {
            pd.setRawDoubleSellUntil(0L);
            pd.setRawBlackMarketUntil(0L);
            pd.setRawUnlimitedEnergyUntil(0L);
            pd.setLastSeenMs(System.currentTimeMillis());
        }
        plugin.automation().drone().despawnPlayerDrones(player);
        plugin.security().rat().onPlayerLeaveWorld(player);
        plugin.world().zoneBorder().clearForPlayerWorld(player);
        plugin.core().playerData().unloadPlayer(uuid);
        plugin.world().zone().forget(uuid);
        plugin.ui().hud().forgetPlayer(uuid);
    }
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        Player player = event.getPlayer();
        World from = event.getFrom();
        World to = player.getWorld();
        if (isPlayerGameWorld(from)) {
            plugin.security().rat().onPlayerLeaveWorld(player);
            plugin.automation().drone().despawnPlayerDrones(player);
        }
        if (isPlayerGameWorld(to)) {
            // Indexe les cartons du monde rejoint avant le respawn des drones.
            indexWorldBoxesOnce(player);
            plugin.security().rat().onPlayerEnterWorld(player);
            plugin.getServer().getScheduler().runTaskLater(plugin,
                    () -> {
                        if (player.isOnline() && isPlayerGameWorld(player.getWorld())) {
                            plugin.automation().drone().respawnPlayerDrones(player);
                            plugin.world().zoneBorder().refresh(player);
                        }
                    }, 10L);
        }
    }
    @EventHandler
    public void onSprint(PlayerToggleSprintEvent event) {
        if (!event.isSprinting()) return;
        Player player = event.getPlayer();
        if (!isPlayerGameWorld(player.getWorld())) return;
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return;
        if (data.getCurrentEnergy() < 10) {
            player.sendActionBar(Component.text(
                    ChatUtil.color("&cÉnergie faible ! (" + String.format("%.0f", data.getCurrentEnergy()) + ")")
            ));
        }
    }
    /**
     * Indexe une seule fois les cartons déjà présents dans le monde du joueur
     * (cas d'un monde cloné du template, jamais passé par placeCarton).
     * Le garde size > 0 évite tout re-scan si l'index est déjà peuplé.
     */
    private void indexWorldBoxesOnce(Player player) {
        World w = player.getWorld();
        if (w == null) return;
        if (plugin.providers().cartonIndex().size(w) > 0) return;
        var boxRef = plugin.core().config().getBoxBlockRef();
        var boxMat = plugin.providers().block().getFallbackMaterial(boxRef);
        var region = plugin.core().config().getBoxRainRegionMax();
        plugin.providers().cartonIndex().indexRegion(w, region, boxMat);
        plugin.getLogger().info("[CTB] Index cartons initialisé pour " + w.getName()
                + " (" + plugin.providers().cartonIndex().size(w) + " carton(s)).");
    }
}