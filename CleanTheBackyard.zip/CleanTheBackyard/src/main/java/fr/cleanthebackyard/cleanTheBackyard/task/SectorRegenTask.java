package fr.cleanthebackyard.cleanTheBackyard.task;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Tâche responsable de la régénération des secteurs du jardin.
 */
public class SectorRegenTask extends BukkitRunnable {

    private final CleanTheBackyard plugin;

    public SectorRegenTask(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        plugin.getSectorManager().tickRegen(); // Vérifie et régénère les secteurs
    }
}
