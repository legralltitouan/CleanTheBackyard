package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;

/**
 * Gere toutes les transactions economiques.
 * Point d'entrée unique pour crediter / debiter un joueur.
 */
public class EconomyManager {

    private final CleanTheBackyard plugin;

    public EconomyManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    /**
     * Credite un joueur du montant spécifié (avec multiplicateurs appliqués).
     * Le montant final (après multiplicateurs) est affiché dans le HUD via HudTask.registerGain().
     */
    public void credit(Player player, double amount) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        double multiplier = plugin.getPluginConfig().getGlobalSellMultiplier();
        if (data.hasDoubleSell()) multiplier *= 2.0;

        double finalAmount = amount * multiplier;
        data.addBalance(finalAmount);

        // Notification dans l'action bar (gain visible 1 seconde)
        plugin.getHudTask().registerGain(player, finalAmount, multiplier);

        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
    }

    /**
     * Debite un joueur. Retourne false si fonds insuffisants.
     */
    public boolean debit(Player player, double amount, String reason) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;

        if (!data.removeBalance(amount)) {
            player.sendMessage(ChatUtil.color("&cFonds insuffisants ! Il vous manque $"
                    + String.format("%.0f", amount - data.getBalance()) + " pour : " + reason));
            return false;
        }
        return true;
    }

    /**
     * Vend tous les cartons du sac d'un joueur.
     * Le montant affiché correspond exactement au montant crédité (multiplicateurs déjà appliqués via credit()).
     */
    public void sellBag(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        int boxes = data.getCurrentBoxes();
        if (boxes == 0) {
            player.sendMessage(ChatUtil.color("&eVotre sac est deja vide !"));
            return;
        }

        double pricePerBox = plugin.getPluginConfig().getBoxSellPrice();
        double baseTotal   = boxes * pricePerBox;

        data.clearBag();
        credit(player, baseTotal); // credit() applique les multiplicateurs

        // Calcul du montant effectivement crédité (après multiplicateurs) pour l'affichage
        double mult = plugin.getPluginConfig().getGlobalSellMultiplier();
        if (data.hasDoubleSell()) mult *= 2.0;
        double finalAmount = baseTotal * mult;

        player.sendMessage(ChatUtil.color(
                "&aVente reussie ! &f" + boxes + " cartons &a-> &f$"
                        + String.format("%.0f", finalAmount)
        ));
        player.playSound(player.getLocation(),
                org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
    }

    public double getBalance(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        return data != null ? data.getBalance() : 0;
    }
}