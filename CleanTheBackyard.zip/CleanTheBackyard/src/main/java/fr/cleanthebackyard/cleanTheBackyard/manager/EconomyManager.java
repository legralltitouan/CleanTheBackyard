package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.entity.Player;

public class EconomyManager {
    private final CleanTheBackyard plugin;

    public EconomyManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private double computeMultiplier(PlayerData data) {
        double multiplier = plugin.getPluginConfig().getGlobalSellMultiplier();
        if (data.hasDoubleSell()) multiplier *= 2.0;
        if (data.hasBlackMarket()) multiplier *= 3.0;
        // Talent Économie remplace le bonus prestige
        multiplier *= plugin.getTalentManager().getSellMultiplier(data);
        return multiplier;
    }

    public void credit(Player player, double amount) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        double multiplier = computeMultiplier(data);
        double finalAmount = amount * multiplier;
        data.addBalance(finalAmount);
        plugin.getQuestManager().onProgress(player, DailyQuest.Type.EARN_MONEY, (long) finalAmount);
        plugin.getHudTask().registerGain(player, finalAmount, multiplier);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
    }

    public boolean debit(Player player, double amount, String reason) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (!data.removeBalance(amount)) {
            double missing = amount - data.getBalance();
            player.sendMessage(ChatUtil.color("&cFonds insuffisants ! Il vous manque "
                    + NumberFormatUtil.money(missing) + " pour : " + reason));
            return false;
        }
        return true;
    }

    public void sellBag(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        int boxes = data.getCurrentBoxes();
        if (boxes == 0) {
            player.sendMessage(ChatUtil.color("&eVotre sac est déjà vide !"));
            return;
        }
        double pricePerBox = plugin.getPluginConfig().getBoxSellPrice();
        double baseTotal = boxes * pricePerBox;
        data.clearBag();
        double mult = computeMultiplier(data);
        double finalAmount = baseTotal * mult;
        credit(player, baseTotal);
        player.sendMessage(ChatUtil.color(
                "&aVente réussie ! &f" + boxes + " cartons &a-> &f" + NumberFormatUtil.money(finalAmount)
        ));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
        plugin.getQuestManager().onProgress(player, DailyQuest.Type.SELL_TIMES, 1);
    }

    public double getBalance(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        return data != null ? data.getBalance() : 0;
    }
}
