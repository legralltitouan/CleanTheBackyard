package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;

/**
 * Gere toutes les transactions economiques.
 * Point d'entree unique pour crediter / debiter un joueur.
 */
public class EconomyManager {

    private final CleanTheBackyard plugin;

    public EconomyManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    /**
     * Credite un joueur du montant specifie (avec eventuel multiplicateur global).
     */
    public void credit(Player player, double amount) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        double multiplier = plugin.getPluginConfig().getGlobalSellMultiplier();
        // Buff personnel OVNI (s'ajoute au global)
        if (data.hasDoubleSell()) multiplier *= 2.0;

        double finalAmount = amount * multiplier;
        data.addBalance(finalAmount);

        String msg = ChatUtil.color("&a+$" + String.format("%.0f", finalAmount));
        if (multiplier > 1.0) {
            msg += ChatUtil.color(" &e[x" + String.format("%.1f", multiplier) + " BONUS!]");
        }
        player.sendActionBar(net.kyori.adventure.text.Component.text(msg));
    }

    /**
     * Debite un joueur. Retourne false si fonds insuffisants.
     */
    public boolean debit(Player player, double amount, String reason) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;

        if (!data.removeBalance(amount)) {
            player.sendMessage(ChatUtil.colored("&cFonds insuffisants ! Il vous manque $"
                    + String.format("%.0f", amount - data.getBalance()) + " pour : " + reason));
            return false;
        }
        return true;
    }

    /**
     * Vend tous les cartons du sac d'un joueur.
     */
    public void sellBag(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        int boxes = data.getCurrentBoxes();
        if (boxes == 0) {
            player.sendMessage(ChatUtil.colored("&eVotre sac est deja vide !"));
            return;
        }

        double pricePerBox = plugin.getPluginConfig().getBoxSellPrice();
        double total       = boxes * pricePerBox;

        data.clearBag();
        credit(player, total);

        player.sendMessage(ChatUtil.colored(
                "&aVente reussie ! &f" + boxes + " cartons &a-> &f$"
                        + String.format("%.0f", total * plugin.getPluginConfig().getGlobalSellMultiplier())
        ));
        player.playSound(player.getLocation(),
                org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);
    }

    public double getBalance(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        return data != null ? data.getBalance() : 0;
    }
}
