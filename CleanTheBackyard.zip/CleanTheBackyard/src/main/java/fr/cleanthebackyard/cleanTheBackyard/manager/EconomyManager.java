package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;

public class EconomyManager {

    private final CleanTheBackyard plugin;

    public EconomyManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    /** Crédite le joueur en appliquant TOUS les multiplicateurs (global, perso, prestige). */
    public void credit(Player player, double amount) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        double multiplier = plugin.getPluginConfig().getGlobalSellMultiplier();
        if (data.hasDoubleSell())  multiplier *= 2.0;
        if (data.hasBlackMarket()) multiplier *= 3.0;
        multiplier *= data.getPrestigeMultiplier(plugin.getPluginConfig().getPrestigeBonusPerLevel());

        double finalAmount = amount * multiplier;
        data.addBalance(finalAmount);

        plugin.getQuestManager().onProgress(player, DailyQuest.Type.EARN_MONEY, (long) finalAmount);
        plugin.getHudTask().registerGain(player, finalAmount, multiplier);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
    }

    public boolean debit(Player player, double amount, String reason) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;

        if (!data.removeBalance(amount)) {
            player.sendMessage(ChatUtil.color("&cFonds insuffisants ! Il vous manque $"
                    + String.format("%.0f", amount - data.getBalance()) + " pour : " + reason));
            return false;
        }
        return true;
    }

    public void sellBag(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        int boxes = data.getCurrentBoxes();
        if (boxes == 0) {
            player.sendMessage(ChatUtil.color("&eVotre sac est déjà vide !"));
            return;
        }

        double pricePerBox = plugin.getPluginConfig().getBoxSellPrice();
        double baseTotal   = boxes * pricePerBox;

        data.clearBag();

        // credit() applique déjà tous les multiplicateurs → on calcule juste pour l'affichage
        double mult = plugin.getPluginConfig().getGlobalSellMultiplier();
        if (data.hasDoubleSell())  mult *= 2.0;
        if (data.hasBlackMarket()) mult *= 3.0;
        mult *= data.getPrestigeMultiplier(plugin.getPluginConfig().getPrestigeBonusPerLevel());
        double finalAmount = baseTotal * mult;

        credit(player, baseTotal);

        player.sendMessage(ChatUtil.color(
                "&aVente réussie ! &f" + boxes + " cartons &a-> &f$" + String.format("%.0f", finalAmount)
        ));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.2f);

        plugin.getQuestManager().onProgress(player, DailyQuest.Type.SELL_TIMES, 1);
    }

    public double getBalance(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        return data != null ? data.getBalance() : 0;
    }
}
