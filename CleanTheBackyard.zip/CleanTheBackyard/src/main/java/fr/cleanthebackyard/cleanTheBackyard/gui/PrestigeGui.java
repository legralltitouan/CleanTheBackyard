package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

public class PrestigeGui {

    private static final String TITLE = ChatUtil.color("&8[&6✦ AUTEL DE PRESTIGE ✦&8]");
    private final CleanTheBackyard plugin;

    public PrestigeGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.PRESTIGE);
        Inventory inv = Bukkit.createInventory(holder, 27, TITLE);
        holder.setInventory(inv);
        build(inv, player);
        player.openInventory(inv);
    }

    private void build(Inventory inv, Player player) {
        ItemStack glass = new ItemBuilder(Material.MAGENTA_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, glass);

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        boolean canPrestige = plugin.getPrestigeManager().canPrestige(data);
        long required = plugin.getPrestigeManager().getRequiredForNextPrestige(data);
        double bonusPercent = plugin.getPluginConfig().getPrestigeBonusPerLevel() * 100;

        inv.setItem(4, new ItemBuilder(Material.NETHER_STAR)
                .name("&6Prestige actuel : &f" + data.getPrestigeLevel())
                .lore(List.of(
                        ChatUtil.color("&7Bonus permanent : &a+" + String.format("%.0f", bonusPercent * data.getPrestigeLevel()) + "% &7gains"),
                        ChatUtil.color("&7Total gagné (lifetime) : &f" + NumberFormatUtil.money(data.getLifetimeEarned())),
                        ChatUtil.color("&7Pour le prochain : &f" + NumberFormatUtil.money(required))
                )).build());

        inv.setItem(13, new ItemBuilder(canPrestige ? Material.BEACON : Material.BARRIER)
                .name(canPrestige ? "&a✦ CLIC POUR PRESTIGE ✦" : "&cConditions non remplies")
                .lore(List.of(
                        ChatUtil.color("&c⚠ Reset : solde, niveaux, sac"),
                        ChatUtil.color("&c⚠ Reset : drones possédés + leurs upgrades"),
                        ChatUtil.color("&7Conservé : stats lifetime, prestige"),
                        " ",
                        ChatUtil.color("&aGain : +" + String.format("%.0f", bonusPercent) + "% gains permanents")
                )).build());
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        if (event.getRawSlot() == 13) {
            if (plugin.getPrestigeManager().prestige(player)) {
                player.closeInventory();
            } else {
                build(event.getInventory(), player);
            }
        }
        return true;
    }
}
