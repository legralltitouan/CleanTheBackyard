package fr.cleanthebackyard.cleanTheBackyard.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.CollectibleItem;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import java.util.*;
/**
 * Gère le tableau de collection : un emplacement fixe par joueur où il peut
 * "déposer" ses items propres pour les exposer.
 * Le tableau est représenté par un set d'items collectés par joueur.
 */
public class CollectionBoardManager {
    private final CleanTheBackyard plugin;
    public CollectionBoardManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    /**
     * Le joueur dépose un item propre sur son tableau.
     */
    public boolean depositItem(Player player, String collectibleKey) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        CollectibleItem item = plugin.getCollectibleManager().get(collectibleKey);
        if (item == null) return false;
        if (data.hasCollectedItem(collectibleKey)) {
            player.sendMessage(ChatUtil.color("&eTu possèdes déjà cet objet dans ta collection."));
            return false;
        }
        data.addCollectedItem(collectibleKey);
        player.sendMessage(ChatUtil.color("&a✦ Ajouté à ta collection : "
                + item.getRarity().getDisplayName() + " &f" + item.getDisplayName()));
        player.playSound(player.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1.2f);
        // Bonus de complétion
        checkCompletionBonus(player, data);
        return true;
    }
    private void checkCompletionBonus(Player player, PlayerData data) {
        int total = plugin.getCollectibleManager().getAll().size();
        int owned = data.getCollectedItems().size();
        if (total > 0 && owned == total) {
            player.sendMessage(ChatUtil.color("&6&l✦ COLLECTION COMPLÈTE ! &fBonus permanent x1.5 sur les ventes !"));
            // Tu peux ajouter un bonus permanent ici (ex: data.setCollectionBonus(true))
        }
    }
    /**
     * Liste les items collectés par le joueur.
     */
    public Set<String> getCollectedItems(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        return data != null ? data.getCollectedItems() : Collections.emptySet();
    }
}