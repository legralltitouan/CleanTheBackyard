package fr.cleanthebackyard.cleanTheBackyard.config;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
public class PluginConfig {
    private final CleanTheBackyard plugin;
    private final FileConfiguration cfg;
    public PluginConfig(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.cfg    = plugin.getConfig();
    }
    // ── Worlds ────────────────────────────────────────────────────────
    public String getHubWorldName()        { return cfg.getString("hub-world", "world"); }
    public World  getHubWorld()            { return plugin.getServer().getWorld(getHubWorldName()); }
    public String getTemplateWorldName()   { return cfg.getString("template-world", "ctb_template"); }
    public String getPlayerWorldPrefix()   { return cfg.getString("player-world-prefix", "ctb_"); }
    public String getPlayerWorldName(UUID uuid) { return getPlayerWorldPrefix() + uuid.toString(); }
    public World  getPlayerWorld(UUID uuid){ return plugin.getServer().getWorld(getPlayerWorldName(uuid)); }
    public String getGameWorldName()       { return cfg.getString("game-world", getTemplateWorldName()); }
    public World  getGameWorld()           { return plugin.getServer().getWorld(getGameWorldName()); }
    // ── Zones ─────────────────────────────────────────────────────────
    public Location getSellZoneCenter(World w) {
        return new Location(w, cfg.getDouble("sell-zone.x"), cfg.getDouble("sell-zone.y"), cfg.getDouble("sell-zone.z"));
    }
    public double getSellZoneRadius() { return cfg.getDouble("sell-zone.radius", 3.0); }
    public Location getGarageLocation(World w) {
        return new Location(w, cfg.getDouble("garage.x"), cfg.getDouble("garage.y"), cfg.getDouble("garage.z"));
    }
    public double getGarageRadius() { return cfg.getDouble("garage.radius", 2.5); }
    public Location getVendingMachineLocation(World w) {
        return new Location(w, cfg.getDouble("vending-machine.x"), cfg.getDouble("vending-machine.y"), cfg.getDouble("vending-machine.z"));
    }
    public double getVendingMachineRadius() { return cfg.getDouble("vending-machine.radius", 2.5); }
    public Location getDroneShopLocation(World w) {
        return new Location(w, cfg.getDouble("drone-shop.x"), cfg.getDouble("drone-shop.y"), cfg.getDouble("drone-shop.z"));
    }
    public double getDroneShopRadius() { return cfg.getDouble("drone-shop.radius", 2.5); }
    // NOUVELLES ZONES
    public Location getDroneGarageLocation(World w) {
        return new Location(w, cfg.getDouble("drone-garage.x", -3), cfg.getDouble("drone-garage.y", -60), cfg.getDouble("drone-garage.z", -11));
    }
    public double getDroneGarageRadius() { return cfg.getDouble("drone-garage.radius", 2.5); }
    public Location getQuestBoardLocation(World w) {
        return new Location(w, cfg.getDouble("quest-board.x", 4), cfg.getDouble("quest-board.y", -60), cfg.getDouble("quest-board.z", -11));
    }
    public double getQuestBoardRadius() { return cfg.getDouble("quest-board.radius", 2.5); }
    public Location getPrestigeAltarLocation(World w) {
        return new Location(w, cfg.getDouble("prestige-altar.x", 0), cfg.getDouble("prestige-altar.y", -60), cfg.getDouble("prestige-altar.z", -15));
    }
    public double getPrestigeAltarRadius() { return cfg.getDouble("prestige-altar.radius", 2.5); }
    // ── Gameplay ──────────────────────────────────────────────────────
    public double getBoxSellPrice()        { return cfg.getDouble("box-sell-price", 5.0); }
    public double getGlobalSellMultiplier(){ return cfg.getDouble("global-sell-multiplier", 1.0); }
    public void   setGlobalSellMultiplier(double v){ cfg.set("global-sell-multiplier", v); plugin.saveConfig(); }
    public int    getUfoMultiplierDuration(){ return cfg.getInt("ufo-multiplier-duration", 120); }
    public int    getUfoEventQuota()       { return cfg.getInt("ufo-event-quota", 500); }
    public int    getGoldenDroneMin()      { return cfg.getInt("golden-drone-min", 180); }
    public int    getGoldenDroneMax()      { return cfg.getInt("golden-drone-max", 480); }
    public int    getUfoMin()              { return cfg.getInt("ufo-min", 900); }
    public int    getUfoMax()              { return cfg.getInt("ufo-max", 1800); }
    public int    getBoxRainMin()          { return cfg.getInt("box-rain-min", 600); }
    public int    getBoxRainMax()          { return cfg.getInt("box-rain-max", 1500); }
    public int    getBlackMarketMin()      { return cfg.getInt("black-market-min", 1200); }
    public int    getBlackMarketMax()      { return cfg.getInt("black-market-max", 2400); }
    public int    getGoldenDroneRewardMin(){ return cfg.getInt("golden-drone-reward-min", 500); }
    public int    getGoldenDroneRewardMax(){ return cfg.getInt("golden-drone-reward-max", 2000); }
    public String getBoxBlock()            { return cfg.getString("box-block", "NOTE_BLOCK"); }
    public double getMaxBreakDistance()    { return cfg.getDouble("max-break-distance", 5.0); }
    public double getEnergyCostPerBox()    { return cfg.getDouble("energy-cost-per-box", 3.0); }
    // ── Prestige ──────────────────────────────────────────────────────
    public long   getPrestigeRequiredEarned() { return cfg.getLong("prestige.required-total-earned", 1_000_000L); }
    public double getPrestigeBonusPerLevel()  { return cfg.getDouble("prestige.bonus-per-level", 0.10); } // +10% par prestige
    public int    getPrestigeMaxLevel()       { return cfg.getInt("prestige.max-level", 50); }
    // ── Upgrade Tables ────────────────────────────────────────────────
    public record BagUpgrade(int level, int capacity, long cost) {}
    public record ToolUpgrade(int level, long cooldownMs, int boxesPerCollection, double extraBoxChance, long cost) {}
    public record EnergyUpgrade(int level, int maxEnergy, double regenPerSec, long cost) {}
    public List<BagUpgrade> getBagUpgrades() {
        List<BagUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("bag-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof java.util.Map<?,?> map) {
                list.add(new BagUpgrade(
                        toInt(map.get("level"), 1),
                        toInt(map.get("capacity"), 10),
                        toLong(map.get("cost"), 0)
                ));
            }
        }
        return list;
    }
    public List<ToolUpgrade> getToolUpgrades() {
        List<ToolUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("tool-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof java.util.Map<?,?> map) {
                list.add(new ToolUpgrade(
                        toInt(map.get("level"), 1),
                        toLong(map.get("cooldown-ms"), 1000),
                        toInt(map.get("boxes-per-collection"), 1),
                        toDouble(map.get("extra-box-chance"), 0.0),
                        toLong(map.get("cost"), 0)
                ));
            }
        }
        return list;
    }
    public List<EnergyUpgrade> getEnergyUpgrades() {
        List<EnergyUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("energy-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof java.util.Map<?,?> map) {
                list.add(new EnergyUpgrade(
                        toInt(map.get("level"), 1),
                        toInt(map.get("max-energy"), 100),
                        toDouble(map.get("regen-per-sec"), 1.0),
                        toLong(map.get("cost"), 0)
                ));
            }
        }
        return list;
    }
    // ── Drones ────────────────────────────────────────────────────────
    public record DroneConfig(
            String key, String name, double income,
            int intervalSec, long cost,
            int bagLevelRequired, int toolLevelRequired, int energyLevelRequired,
            double speed, int pickupRange,
            // Plafonds des upgrades
            int maxSpeedTier, int maxRangeTier, int maxIncomeTier
    ) {}
    public List<DroneConfig> getDroneConfigs() {
        List<DroneConfig> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("drone-types");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection d = section.getConfigurationSection(key);
            if (d == null) continue;
            list.add(new DroneConfig(
                    key,
                    d.getString("name", key),
                    d.getDouble("income", 2),
                    d.getInt("interval-sec", 10),
                    d.getLong("cost", 500),
                    d.getInt("bag-level-required", 1),
                    d.getInt("tool-level-required", 1),
                    d.getInt("energy-level-required", 1),
                    d.getDouble("speed", 3.0),
                    d.getInt("pickup-range", 20),
                    d.getInt("max-speed-tier", 5),
                    d.getInt("max-range-tier", 5),
                    d.getInt("max-income-tier", 5)
            ));
        }
        return list;
    }
    /** Coût d'upgrade d'un drone : cost_drone * base_multiplier * (growth ^ currentTier). */
    public long getDroneUpgradeCost(long droneCost, String upgradeType, int currentTier) {
        double base = cfg.getDouble("drone-upgrade.base-multiplier." + upgradeType, 0.4);
        double growth = cfg.getDouble("drone-upgrade.growth-per-tier", 1.8);
        return Math.round(droneCost * base * Math.pow(growth, currentTier));
    }
    /** Gain par tier (% additif). */
    public double getDroneSpeedTierBonus()  { return cfg.getDouble("drone-upgrade.speed-bonus-per-tier", 0.20); }
    public double getDroneRangeTierBonus()  { return cfg.getDouble("drone-upgrade.range-bonus-per-tier", 0.25); }
    public double getDroneIncomeTierBonus() { return cfg.getDouble("drone-upgrade.income-bonus-per-tier", 0.30); }
    // ── Vending Machine Items ─────────────────────────────────────────
    public record VendingItem(String key, String name, int energyRestore, long cost) {}
    public List<VendingItem> getVendingItems() {
        List<VendingItem> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("vending-machine-items");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection v = section.getConfigurationSection(key);
            if (v == null) continue;
            list.add(new VendingItem(
                    key,
                    v.getString("name", key),
                    v.getInt("energy-restore", 25),
                    v.getLong("cost", 10)
            ));
        }
        return list;
    }
    // ── Helpers ───────────────────────────────────────────────────────
    private int    toInt(Object o, int def)    { return o instanceof Number n ? n.intValue()    : def; }
    private long   toLong(Object o, long def)  { return o instanceof Number n ? n.longValue()   : def; }
    private double toDouble(Object o, double d){ return o instanceof Number n ? n.doubleValue() : d; }
}