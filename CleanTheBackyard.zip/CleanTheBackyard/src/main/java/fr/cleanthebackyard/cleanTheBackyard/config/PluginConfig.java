package fr.cleanthebackyard.cleanTheBackyard.config;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.provider.EntityRef;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.util.BoundingBox;
import java.util.*;
/**
 * Accès typé à config.yml. Toute lecture passe par ici.
 * Reload supporté via {@link #reload()}.
 */
public class PluginConfig {
    private final CleanTheBackyard plugin;
    private FileConfiguration cfg;
    // ── Tables d'upgrade ──
    private List<BagUpgrade> bagUpgrades = List.of();
    private List<ToolUpgrade> toolUpgrades = List.of();
    private List<EnergyUpgrade> energyUpgrades = List.of();
    private List<DroneConfig> droneConfigs = List.of();
    private List<VendingItem> vendingItems = List.of();
    private List<SecurityUpgrade> securityUpgrades = List.of();
    private List<TrapUpgrade> trapUpgrades = List.of();
    // ── Index par clé ──
    private Map<Integer, BagUpgrade> bagByLevel = Map.of();
    private Map<Integer, ToolUpgrade> toolByLevel = Map.of();
    private Map<Integer, EnergyUpgrade> energyByLevel = Map.of();
    private Map<String, DroneConfig> droneByKey = Map.of();
    private Map<Integer, SecurityUpgrade> securityByLevel = Map.of();
    private Map<Integer, TrapUpgrade> trapByLevel = Map.of();
    // ── Références blocs/entités ──
    private BlockRef boxBlockRef;
    private BlockRef ufoBlockRef;
    private EntityRef goldenDroneEntityRef;
    private EntityRef ratEntityRef;
    public PluginConfig(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.cfg = plugin.getConfig();
        loadAll();
    }
    public void reload() {
        plugin.reloadConfig();
        this.cfg = plugin.getConfig();
        loadAll();
    }
    private void loadAll() {
        bagUpgrades      = Collections.unmodifiableList(loadBagUpgrades());
        toolUpgrades     = Collections.unmodifiableList(loadToolUpgrades());
        energyUpgrades   = Collections.unmodifiableList(loadEnergyUpgrades());
        droneConfigs     = Collections.unmodifiableList(loadDroneConfigs());
        vendingItems     = Collections.unmodifiableList(loadVendingItems());
        securityUpgrades = Collections.unmodifiableList(loadSecurityUpgrades());
        trapUpgrades     = Collections.unmodifiableList(loadTrapUpgrades());
        bagByLevel      = indexByLevel(bagUpgrades, BagUpgrade::level);
        toolByLevel     = indexByLevel(toolUpgrades, ToolUpgrade::level);
        energyByLevel   = indexByLevel(energyUpgrades, EnergyUpgrade::level);
        securityByLevel = indexByLevel(securityUpgrades, SecurityUpgrade::level);
        trapByLevel     = indexByLevel(trapUpgrades, TrapUpgrade::level);
        Map<String, DroneConfig> dm = new LinkedHashMap<>();
        droneConfigs.forEach(d -> dm.put(d.key(), d));
        droneByKey = Collections.unmodifiableMap(dm);
        boxBlockRef          = BlockRef.parse(cfg.getString("box-block", "vanilla:NOTE_BLOCK"));
        ufoBlockRef          = BlockRef.parse(cfg.getString("ufo-box-block", "vanilla:GLOWSTONE"));
        goldenDroneEntityRef = EntityRef.parse(cfg.getString("golden-drone-entity", "vanilla:BAT"), EntityType.BAT);
        ratEntityRef         = EntityRef.parse(cfg.getString("rats.entity", "vanilla:RABBIT"), EntityType.RABBIT);
    }
    private <T> Map<Integer, T> indexByLevel(List<T> list, java.util.function.ToIntFunction<T> levelFn) {
        Map<Integer, T> m = new HashMap<>();
        list.forEach(t -> m.put(levelFn.applyAsInt(t), t));
        return Collections.unmodifiableMap(m);
    }
    // ── Refs blocs/entités ──
    public BlockRef getBoxBlockRef()             { return boxBlockRef; }
    public BlockRef getUfoBlockRef()             { return ufoBlockRef; }
    public EntityRef getGoldenDroneEntityRef()   { return goldenDroneEntityRef; }
    public EntityRef getRatEntityRef()           { return ratEntityRef; }
    // ── Worlds ──
    public String getHubWorldName()             { return cfg.getString("hub-world", "world"); }
    public World  getHubWorld()                 { return plugin.getServer().getWorld(getHubWorldName()); }
    public String getTemplateWorldName()        { return cfg.getString("template-world", "ctb_template"); }
    public String getPlayerWorldPrefix()        { return cfg.getString("player-world-prefix", "ctb_"); }
    public String getPlayerWorldName(UUID uuid) { return getPlayerWorldPrefix() + uuid; }
    public World  getPlayerWorld(UUID uuid)     { return plugin.getServer().getWorld(getPlayerWorldName(uuid)); }
    // ── Spawn hub ──
    public Location getHubSpawnLocation() {
        World hub = getHubWorld();
        if (hub == null) return null;
        return readLocation("hub-spawn", hub);
    }
    public void setHubSpawn(Location loc) { writeLocation("hub-spawn", loc); }
    public Location getPlayerWorldSpawn(World w) {
        if (w == null) return null;
        return readLocation("player-world-spawn", w);
    }
    public void setPlayerWorldSpawn(Location loc) { writeLocation("player-world-spawn", loc); }
    private Location readLocation(String path, World fallbackWorld) {
        ConfigurationSection sec = cfg.getConfigurationSection(path);
        if (sec == null) return fallbackWorld.getSpawnLocation();
        return new Location(
                fallbackWorld,
                sec.getDouble("x", fallbackWorld.getSpawnLocation().getX()),
                sec.getDouble("y", fallbackWorld.getSpawnLocation().getY()),
                sec.getDouble("z", fallbackWorld.getSpawnLocation().getZ()),
                (float) sec.getDouble("yaw", 0),
                (float) sec.getDouble("pitch", 0)
        );
    }
    private void writeLocation(String path, Location loc) {
        cfg.set(path + ".x", loc.getX());
        cfg.set(path + ".y", loc.getY());
        cfg.set(path + ".z", loc.getZ());
        cfg.set(path + ".yaw", loc.getYaw());
        cfg.set(path + ".pitch", loc.getPitch());
        plugin.saveConfig();
    }
    // ── Zones ──
    public Location getSellZoneCenter(World w)        { return zoneLoc(w, "sell-zone"); }
    public double   getSellZoneRadius()                { return cfg.getDouble("sell-zone.radius", 3.0); }
    public Location getGarageLocation(World w)         { return zoneLoc(w, "garage"); }
    public double   getGarageRadius()                  { return cfg.getDouble("garage.radius", 2.5); }
    public Location getVendingMachineLocation(World w) { return zoneLoc(w, "vending-machine"); }
    public double   getVendingMachineRadius()          { return cfg.getDouble("vending-machine.radius", 2.5); }
    public Location getDroneShopLocation(World w)      { return zoneLoc(w, "drone-shop"); }
    public double   getDroneShopRadius()               { return cfg.getDouble("drone-shop.radius", 2.5); }
    public Location getQuestBoardLocation(World w)     { return zoneLoc(w, "quest-board"); }
    public double   getQuestBoardRadius()              { return cfg.getDouble("quest-board.radius", 2.5); }
    public Location getPrestigeAltarLocation(World w)  { return zoneLoc(w, "prestige-altar"); }
    public double   getPrestigeAltarRadius()           { return cfg.getDouble("prestige-altar.radius", 2.5); }
    public Location getStashLocation(World w)          { return zoneLoc(w, "stash"); }
    public double   getStashRadius()                   { return cfg.getDouble("stash.radius", 2.5); }
    private Location zoneLoc(World w, String path) {
        return new Location(w, cfg.getDouble(path + ".x"), cfg.getDouble(path + ".y"), cfg.getDouble(path + ".z"));
    }
    // ── Régions ──
    public BoundingBox getBoxRainRegion()        { return readRegion("box-rain-region"); }
    public BoundingBox getPrestigeResetRegion()  { return readRegion("prestige-reset-region"); }
    public BoundingBox getStashRegion()          { return readRegion("stash-region"); }
    private BoundingBox readRegion(String path) {
        return new BoundingBox(
                cfg.getDouble(path + ".min.x"), cfg.getDouble(path + ".min.y"), cfg.getDouble(path + ".min.z"),
                cfg.getDouble(path + ".max.x"), cfg.getDouble(path + ".max.y"), cfg.getDouble(path + ".max.z")
        );
    }
    public int  getBoxRainBoxesPerIteration() { return cfg.getInt("box-rain-region.boxes-per-iteration-per-player", 4); }
    public int  getBoxRainIterations()        { return cfg.getInt("box-rain-region.iterations", 30); }
    public long getBoxRainIntervalTicks()     { return cfg.getLong("box-rain-region.interval-ticks", 20L); }
    // ── Gameplay ──
    public double getBoxSellPrice()              { return cfg.getDouble("box-sell-price", 5.0); }
    public double getGlobalSellMultiplier()      { return cfg.getDouble("global-sell-multiplier", 1.0); }
    public void   setGlobalSellMultiplier(double v) { cfg.set("global-sell-multiplier", v); plugin.saveConfig(); }
    public double getMaxBreakDistance()          { return cfg.getDouble("max-break-distance", 5.0); }
    public double getEnergyCostPerBox()          { return cfg.getDouble("energy-cost-per-box", 10.0); }
    // ── Événements ──
    public int getUfoMultiplierDuration()        { return cfg.getInt("ufo-multiplier-duration", 3600); }
    public int getUfoEventQuota()                { return cfg.getInt("ufo-event-quota", 500); }
    public int getUfoMin()                       { return cfg.getInt("ufo-min", 900); }
    public int getUfoMax()                       { return cfg.getInt("ufo-max", 1800); }
    public int getGoldenDroneMin()               { return cfg.getInt("golden-drone-min", 240); }
    public int getGoldenDroneMax()               { return cfg.getInt("golden-drone-max", 600); }
    public int getGoldenDroneRewardMin()         { return cfg.getInt("golden-drone-reward-min", 500); }
    public int getGoldenDroneRewardMax()         { return cfg.getInt("golden-drone-reward-max", 2000); }
    public double getGoldenDroneSpeed()          { return cfg.getDouble("golden-drone-speed", 0.35); }
    public double getGoldenDroneSpawnDistance()  { return cfg.getDouble("golden-drone-spawn-distance", 8.0); }
    public int getGoldenDroneLifetimeSec()       { return cfg.getInt("golden-drone-lifetime-sec", 30); }
    public int getBoxRainMin()                   { return cfg.getInt("box-rain-min", 1200); }
    public int getBoxRainMax()                   { return cfg.getInt("box-rain-max", 2400); }
    public int getBlackMarketMin()               { return cfg.getInt("black-market-min", 1500); }
    public int getBlackMarketMax()               { return cfg.getInt("black-market-max", 3000); }
    // ── Rats ──
    public boolean isRatsEnabled()               { return cfg.getBoolean("rats.enabled", true); }
    public int     getRatsMinSpawnSec()          { return cfg.getInt("rats.spawn-min-sec", 180); }
    public int     getRatsMaxSpawnSec()          { return cfg.getInt("rats.spawn-max-sec", 480); }
    public double  getRatsStealPercentMin()      { return cfg.getDouble("rats.steal-percent-min", 0.01); }
    public double  getRatsStealPercentMax()      { return cfg.getDouble("rats.steal-percent-max", 0.05); }
    public long    getRatsStealCap()             { return cfg.getLong("rats.steal-cap", 5000L); }
    public int     getRatsTimeToStealSec()       { return cfg.getInt("rats.time-to-steal-sec", 20); }
    public double  getRatsSpeed()                { return cfg.getDouble("rats.speed", 0.3); }
    public long    getRatsMinBalanceToTrigger()  { return cfg.getLong("rats.min-balance-to-trigger", 200L); }
    public double  getRatsSpawnRadius()          { return cfg.getDouble("rats.spawn-radius", 6.0); }
    // ── Prestige ──
    public long   getPrestigeRequiredEarned()    { return cfg.getLong("prestige.required-total-earned", 500_000L); }
    public double getPrestigeBonusPerLevel()     { return cfg.getDouble("prestige.bonus-per-level", 0.10); }
    public int    getPrestigeMaxLevel()          { return cfg.getInt("prestige.max-level", 50); }
    // ── Auto-save ──
    public int getAutoSaveIntervalSeconds()      { return cfg.getInt("auto-save-interval-seconds", 300); }
    // ── Drone upgrade cost ──
    public long getDroneUpgradeCost(long droneCost, String upgradeType, int currentTier) {
        double base = cfg.getDouble("drone-upgrade.base-multiplier." + upgradeType, 0.4);
        double growth = cfg.getDouble("drone-upgrade.growth-per-tier", 1.75);
        return Math.round(droneCost * base * Math.pow(growth, currentTier));
    }
    public double getDroneSpeedTierBonus()  { return cfg.getDouble("drone-upgrade.speed-bonus-per-tier", 0.20); }
    public double getDroneRangeTierBonus()  { return cfg.getDouble("drone-upgrade.range-bonus-per-tier", 0.25); }
    public double getDroneIncomeTierBonus() { return cfg.getDouble("drone-upgrade.income-bonus-per-tier", 0.30); }
    // ── Records ──
    public record BagUpgrade(int level, int capacity, long cost) {}
    public record ToolUpgrade(int level, long cooldownMs, int boxesPerCollection, double extraBoxChance, long cost) {}
    public record EnergyUpgrade(int level, int maxEnergy, double regenPerSec, long cost) {}
    public record DroneConfig(
            String key, String name, double income,
            int intervalSec, long cost,
            int bagLevelRequired, int toolLevelRequired, int energyLevelRequired,
            double speed, int pickupRange,
            int maxSpeedTier, int maxRangeTier, int maxIncomeTier,
            EntityRef entityRef
    ) {}
    public record VendingItem(String key, String name, int energyRestore, long cost) {}
    public record SecurityUpgrade(int level, String name, double detectionChance, long cost) {}
    public record TrapUpgrade(int level, String name, double killChance, long cost) {}
    public List<BagUpgrade>      getBagUpgrades()      { return bagUpgrades; }
    public List<ToolUpgrade>     getToolUpgrades()     { return toolUpgrades; }
    public List<EnergyUpgrade>   getEnergyUpgrades()   { return energyUpgrades; }
    public List<DroneConfig>     getDroneConfigs()     { return droneConfigs; }
    public List<VendingItem>     getVendingItems()     { return vendingItems; }
    public List<SecurityUpgrade> getSecurityUpgrades() { return securityUpgrades; }
    public List<TrapUpgrade>     getTrapUpgrades()     { return trapUpgrades; }
    public BagUpgrade      getBagUpgrade(int level)    { return bagByLevel.get(level); }
    public ToolUpgrade     getToolUpgrade(int level)   { return toolByLevel.get(level); }
    public EnergyUpgrade   getEnergyUpgrade(int level) { return energyByLevel.get(level); }
    public DroneConfig     getDroneConfig(String key)  { return droneByKey.get(key); }
    public SecurityUpgrade getSecurityUpgrade(int l)   { return securityByLevel.get(l); }
    public TrapUpgrade     getTrapUpgrade(int l)       { return trapByLevel.get(l); }
    // ── Loaders ──
    private List<BagUpgrade> loadBagUpgrades() {
        List<BagUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("bag-upgrades");
        if (raw == null) return list;
        for (Object o : raw) {
            if (o instanceof Map<?, ?> m) {
                list.add(new BagUpgrade(toInt(m.get("level"), 1), toInt(m.get("capacity"), 10), toLong(m.get("cost"), 0)));
            }
        }
        return list;
    }
    private List<ToolUpgrade> loadToolUpgrades() {
        List<ToolUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("tool-upgrades");
        if (raw == null) return list;
        for (Object o : raw) {
            if (o instanceof Map<?, ?> m) {
                list.add(new ToolUpgrade(
                        toInt(m.get("level"), 1),
                        toLong(m.get("cooldown-ms"), 1000),
                        toInt(m.get("boxes-per-collection"), 1),
                        toDouble(m.get("extra-box-chance"), 0.0),
                        toLong(m.get("cost"), 0)
                ));
            }
        }
        return list;
    }
    private List<EnergyUpgrade> loadEnergyUpgrades() {
        List<EnergyUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("energy-upgrades");
        if (raw == null) return list;
        for (Object o : raw) {
            if (o instanceof Map<?, ?> m) {
                list.add(new EnergyUpgrade(
                        toInt(m.get("level"), 1),
                        toInt(m.get("max-energy"), 100),
                        toDouble(m.get("regen-per-sec"), 1.0),
                        toLong(m.get("cost"), 0)
                ));
            }
        }
        return list;
    }
    private List<DroneConfig> loadDroneConfigs() {
        List<DroneConfig> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("drone-types");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection d = section.getConfigurationSection(key);
            if (d == null) continue;
            EntityRef ref = EntityRef.parse(d.getString("entity", "vanilla:BEE"), EntityType.BEE);
            list.add(new DroneConfig(
                    key,
                    d.getString("name", key),
                    d.getDouble("income", 2),
                    d.getInt("interval-sec", 10),
                    d.getLong("cost", 500),
                    d.getInt("bag-level-required", 1),
                    d.getInt("tool-level-required", 1),
                    d.getInt("energy-level-required", 1),
                    d.getDouble("speed", 3.0),
                    d.getInt("pickup-range", 20),
                    d.getInt("max-speed-tier", 5),
                    d.getInt("max-range-tier", 5),
                    d.getInt("max-income-tier", 5),
                    ref
            ));
        }
        return list;
    }
    private List<VendingItem> loadVendingItems() {
        List<VendingItem> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("vending-machine-items");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection v = section.getConfigurationSection(key);
            if (v == null) continue;
            list.add(new VendingItem(
                    key,
                    v.getString("name", key),
                    v.getInt("energy-restore", 25),
                    v.getLong("cost", 10)
            ));
        }
        return list;
    }
    private List<SecurityUpgrade> loadSecurityUpgrades() {
        List<SecurityUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("security-upgrades");
        if (raw == null) return list;
        for (Object o : raw) {
            if (o instanceof Map<?, ?> m) {
                list.add(new SecurityUpgrade(
                        toInt(m.get("level"), 1),
                        toStr(m.get("name"), "Caméra"),
                        toDouble(m.get("detection-chance"), 0.0),
                        toLong(m.get("cost"), 0)
                ));
            }
        }
        return list;
    }
    private List<TrapUpgrade> loadTrapUpgrades() {
        List<TrapUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("trap-upgrades");
        if (raw == null) return list;
        for (Object o : raw) {
            if (o instanceof Map<?, ?> m) {
                list.add(new TrapUpgrade(
                        toInt(m.get("level"), 1),
                        toStr(m.get("name"), "Piège"),
                        toDouble(m.get("kill-chance"), 0.0),
                        toLong(m.get("cost"), 0)
                ));
            }
        }
        return list;
    }
    private int    toInt(Object o, int d)        { return o instanceof Number n ? n.intValue() : d; }
    private long   toLong(Object o, long d)      { return o instanceof Number n ? n.longValue() : d; }
    private double toDouble(Object o, double d)  { return o instanceof Number n ? n.doubleValue() : d; }
    private String toStr(Object o, String d)     { return o == null ? d : o.toString(); }
}