package fr.cleanthebackyard.cleanTheBackyard.config;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;

/**
 * Centralise l'acces a toutes les valeurs de config.yml.
 * Permet un refactoring facile et evite les magic strings partout dans le code.
 */
public class PluginConfig {

    private final CleanTheBackyard plugin;
    private final FileConfiguration cfg;

    public PluginConfig(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.cfg    = plugin.getConfig();
    }

    // ── World & Zones (REMPLACE la section existante) ────────────────

    public String getGameWorldName() {
        return cfg.getString("game-world", "world");
    }

    public World getGameWorld() {
        return plugin.getServer().getWorld(getGameWorldName());
    }

    public Location getSellZoneCenter() {
        return new Location(getGameWorld(),
                cfg.getDouble("sell-zone.x"),
                cfg.getDouble("sell-zone.y"),
                cfg.getDouble("sell-zone.z"));
    }
    public double getSellZoneRadius() { return cfg.getDouble("sell-zone.radius", 3.0); }

    public Location getGarageLocation() {
        return new Location(getGameWorld(),
                cfg.getDouble("garage.x"),
                cfg.getDouble("garage.y"),
                cfg.getDouble("garage.z"));
    }
    public double getGarageRadius() { return cfg.getDouble("garage.radius", 2.5); }

    public Location getVendingMachineLocation() {
        return new Location(getGameWorld(),
                cfg.getDouble("vending-machine.x"),
                cfg.getDouble("vending-machine.y"),
                cfg.getDouble("vending-machine.z"));
    }
    public double getVendingMachineRadius() { return cfg.getDouble("vending-machine.radius", 2.5); }

    public Location getDroneShopLocation() {
        return new Location(getGameWorld(),
                cfg.getDouble("drone-shop.x"),
                cfg.getDouble("drone-shop.y"),
                cfg.getDouble("drone-shop.z"));
    }
    public double getDroneShopRadius() { return cfg.getDouble("drone-shop.radius", 2.5); }

    // ── Gameplay ──────────────────────────────────────────────────────

    public double getBoxSellPrice()        { return cfg.getDouble("box-sell-price", 5.0); }
    public double getGlobalSellMultiplier(){ return cfg.getDouble("global-sell-multiplier", 1.0); }
    public void   setGlobalSellMultiplier(double v){ cfg.set("global-sell-multiplier", v); }
    public int    getUfoMultiplierDuration(){ return cfg.getInt("ufo-multiplier-duration", 120); }
    public int    getUfoEventQuota()       { return cfg.getInt("ufo-event-quota", 500); }
    public int    getGoldenDroneMin()      { return cfg.getInt("golden-drone-min", 180); }
    public int    getGoldenDroneMax()      { return cfg.getInt("golden-drone-max", 480); }
    public int    getUfoMin()              { return cfg.getInt("ufo-min", 900); }
    public int    getUfoMax()              { return cfg.getInt("ufo-max", 1800); }
    public int    getGoldenDroneRewardMin(){ return cfg.getInt("golden-drone-reward-min", 500); }
    public int    getGoldenDroneRewardMax(){ return cfg.getInt("golden-drone-reward-max", 2000); }
    public String getBoxBlock()            { return cfg.getString("box-block", "NOTE_BLOCK"); }
    public double getMaxBreakDistance()    { return cfg.getDouble("max-break-distance", 5.0); }
    public double getEnergyCostPerBox() { return cfg.getDouble("energy-cost-per-box", 3.0); }

    // ── Upgrade Tables ────────────────────────────────────────────────

    public record BagUpgrade(int level, int capacity, long cost) {}
    public record ToolUpgrade(int level, long cooldownMs, int boxesPerCollection, long cost) {}
    public record EnergyUpgrade(int level, int maxEnergy, double regenPerSec, long cost) {}

    public List<BagUpgrade> getBagUpgrades() {
        List<BagUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("bag-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof java.util.Map<?,?> map) {
                int level    = toInt(map.get("level"), 1);
                int capacity = toInt(map.get("capacity"), 10);
                long cost    = toLong(map.get("cost"), 0);
                list.add(new BagUpgrade(level, capacity, cost));
            }
        }
        return list;
    }

    public List<ToolUpgrade> getToolUpgrades() {
        List<ToolUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("tool-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof java.util.Map<?,?> map) {
                int level              = toInt(map.get("level"), 1);
                long cooldownMs        = toLong(map.get("cooldown-ms"), 1000);
                int boxesPerCollection = toInt(map.get("boxes-per-collection"), 1);
                long cost              = toLong(map.get("cost"), 0);
                list.add(new ToolUpgrade(level, cooldownMs, boxesPerCollection, cost));
            }
        }
        return list;
    }

    public List<EnergyUpgrade> getEnergyUpgrades() {
        List<EnergyUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("energy-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof java.util.Map<?,?> map) {
                int level       = toInt(map.get("level"), 1);
                int maxEnergy   = toInt(map.get("max-energy"), 100);
                double regen    = toDouble(map.get("regen-per-sec"), 1.0);
                long cost       = toLong(map.get("cost"), 0);
                list.add(new EnergyUpgrade(level, maxEnergy, regen, cost));
            }
        }
        return list;
    }

    // ── Drone Config ──────────────────────────────────────────────────

    public record DroneConfig(
            String key, String name, double income,
            int intervalSec, long cost,
            int bagLevelRequired, int toolLevelRequired, int energyLevelRequired
    ) {}

    public List<DroneConfig> getDroneConfigs() {
        List<DroneConfig> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("drone-types");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection d = section.getConfigurationSection(key);
            if (d == null) continue;
            list.add(new DroneConfig(
                    key,
                    d.getString("name", key),
                    d.getDouble("income", 2),
                    d.getInt("interval-sec", 10),
                    d.getLong("cost", 500),
                    d.getInt("bag-level-required", 1),
                    d.getInt("tool-level-required", 1),
                    d.getInt("energy-level-required", 1)
            ));
        }
        return list;
    }

    // ── Vending Machine Items ─────────────────────────────────────────

    public record VendingItem(String key, String name, int energyRestore, long cost) {}

    public List<VendingItem> getVendingItems() {
        List<VendingItem> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("vending-machine-items");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection v = section.getConfigurationSection(key);
            if (v == null) continue;
            list.add(new VendingItem(
                    key,
                    v.getString("name", key),
                    v.getInt("energy-restore", 25),
                    v.getLong("cost", 10)
            ));
        }
        return list;
    }

    // ── Helpers ───────────────────────────────────────────────────────

    private int    toInt(Object o, int def)    { return o instanceof Number n ? n.intValue()    : def; }
    private long   toLong(Object o, long def)  { return o instanceof Number n ? n.longValue()   : def; }
    private double toDouble(Object o, double d){ return o instanceof Number n ? n.doubleValue() : d; }
}
