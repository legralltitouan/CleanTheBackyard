package fr.cleanthebackyard.cleanTheBackyard.config;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.util.BoundingBox;

import java.util.*;

public class PluginConfig {

    private final CleanTheBackyard plugin;
    private FileConfiguration cfg;

    private List<BagUpgrade> bagUpgrades = List.of();
    private List<ToolUpgrade> toolUpgrades = List.of();
    private List<EnergyUpgrade> energyUpgrades = List.of();
    private List<DroneConfig> droneConfigs = List.of();
    private List<VendingItem> vendingItems = List.of();
    private List<SecurityUpgrade> securityUpgrades = List.of();
    private List<TrapUpgrade> trapUpgrades = List.of();

    private Map<Integer, BagUpgrade> bagByLevel = Map.of();
    private Map<Integer, ToolUpgrade> toolByLevel = Map.of();
    private Map<Integer, EnergyUpgrade> energyByLevel = Map.of();
    private Map<String, DroneConfig> droneByKey = Map.of();
    private Map<Integer, SecurityUpgrade> securityByLevel = Map.of();
    private Map<Integer, TrapUpgrade> trapByLevel = Map.of();

    public PluginConfig(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.cfg = plugin.getConfig();
        loadAll();
    }

    public void reload() {
        plugin.reloadConfig();
        this.cfg = plugin.getConfig();
        loadAll();
    }

    private void loadAll() {
        bagUpgrades = Collections.unmodifiableList(loadBagUpgrades());
        toolUpgrades = Collections.unmodifiableList(loadToolUpgrades());
        energyUpgrades = Collections.unmodifiableList(loadEnergyUpgrades());
        droneConfigs = Collections.unmodifiableList(loadDroneConfigs());
        vendingItems = Collections.unmodifiableList(loadVendingItems());
        securityUpgrades = Collections.unmodifiableList(loadSecurityUpgrades());
        trapUpgrades = Collections.unmodifiableList(loadTrapUpgrades());

        Map<Integer, BagUpgrade> bm = new HashMap<>();
        bagUpgrades.forEach(u -> bm.put(u.level(), u));
        bagByLevel = Collections.unmodifiableMap(bm);

        Map<Integer, ToolUpgrade> tm = new HashMap<>();
        toolUpgrades.forEach(u -> tm.put(u.level(), u));
        toolByLevel = Collections.unmodifiableMap(tm);

        Map<Integer, EnergyUpgrade> em = new HashMap<>();
        energyUpgrades.forEach(u -> em.put(u.level(), u));
        energyByLevel = Collections.unmodifiableMap(em);

        Map<String, DroneConfig> dm = new LinkedHashMap<>();
        droneConfigs.forEach(d -> dm.put(d.key(), d));
        droneByKey = Collections.unmodifiableMap(dm);

        Map<Integer, SecurityUpgrade> sm = new HashMap<>();
        securityUpgrades.forEach(u -> sm.put(u.level(), u));
        securityByLevel = Collections.unmodifiableMap(sm);

        Map<Integer, TrapUpgrade> trm = new HashMap<>();
        trapUpgrades.forEach(u -> trm.put(u.level(), u));
        trapByLevel = Collections.unmodifiableMap(trm);
    }

    // ── Worlds ──
    public String getHubWorldName() { return cfg.getString("hub-world", "world"); }
    public World getHubWorld() { return plugin.getServer().getWorld(getHubWorldName()); }
    public String getTemplateWorldName() { return cfg.getString("template-world", "ctb_template"); }
    public String getPlayerWorldPrefix() { return cfg.getString("player-world-prefix", "ctb_"); }
    public String getPlayerWorldName(UUID uuid) { return getPlayerWorldPrefix() + uuid.toString(); }
    public World getPlayerWorld(UUID uuid) { return plugin.getServer().getWorld(getPlayerWorldName(uuid)); }

    // ── Spawn (hub) ──
    public Location getHubSpawnLocation() {
        World hub = getHubWorld();
        if (hub == null) return null;
        ConfigurationSection sec = cfg.getConfigurationSection("hub-spawn");
        if (sec == null) return hub.getSpawnLocation();
        double x = sec.getDouble("x", hub.getSpawnLocation().getX());
        double y = sec.getDouble("y", hub.getSpawnLocation().getY());
        double z = sec.getDouble("z", hub.getSpawnLocation().getZ());
        float yaw = (float) sec.getDouble("yaw", 0);
        float pitch = (float) sec.getDouble("pitch", 0);
        return new Location(hub, x, y, z, yaw, pitch);
    }

    public void setHubSpawn(Location loc) {
        cfg.set("hub-spawn.x", loc.getX());
        cfg.set("hub-spawn.y", loc.getY());
        cfg.set("hub-spawn.z", loc.getZ());
        cfg.set("hub-spawn.yaw", loc.getYaw());
        cfg.set("hub-spawn.pitch", loc.getPitch());
        plugin.saveConfig();
    }

    public Location getPlayerWorldSpawn(World playerWorld) {
        if (playerWorld == null) return null;
        ConfigurationSection sec = cfg.getConfigurationSection("player-world-spawn");
        if (sec == null) return playerWorld.getSpawnLocation();
        double x = sec.getDouble("x", playerWorld.getSpawnLocation().getX());
        double y = sec.getDouble("y", playerWorld.getSpawnLocation().getY());
        double z = sec.getDouble("z", playerWorld.getSpawnLocation().getZ());
        float yaw = (float) sec.getDouble("yaw", 0);
        float pitch = (float) sec.getDouble("pitch", 0);
        return new Location(playerWorld, x, y, z, yaw, pitch);
    }

    public void setPlayerWorldSpawn(Location loc) {
        cfg.set("player-world-spawn.x", loc.getX());
        cfg.set("player-world-spawn.y", loc.getY());
        cfg.set("player-world-spawn.z", loc.getZ());
        cfg.set("player-world-spawn.yaw", loc.getYaw());
        cfg.set("player-world-spawn.pitch", loc.getPitch());
        plugin.saveConfig();
    }

    // ── Zones ──
    public Location getSellZoneCenter(World w) {
        return new Location(w, cfg.getDouble("sell-zone.x"), cfg.getDouble("sell-zone.y"), cfg.getDouble("sell-zone.z"));
    }
    public double getSellZoneRadius() { return cfg.getDouble("sell-zone.radius", 3.0); }

    public Location getGarageLocation(World w) {
        return new Location(w, cfg.getDouble("garage.x"), cfg.getDouble("garage.y"), cfg.getDouble("garage.z"));
    }
    public double getGarageRadius() { return cfg.getDouble("garage.radius", 2.5); }

    public Location getVendingMachineLocation(World w) {
        return new Location(w, cfg.getDouble("vending-machine.x"), cfg.getDouble("vending-machine.y"), cfg.getDouble("vending-machine.z"));
    }
    public double getVendingMachineRadius() { return cfg.getDouble("vending-machine.radius", 2.5); }

    public Location getDroneShopLocation(World w) {
        return new Location(w, cfg.getDouble("drone-shop.x"), cfg.getDouble("drone-shop.y"), cfg.getDouble("drone-shop.z"));
    }
    public double getDroneShopRadius() { return cfg.getDouble("drone-shop.radius", 2.5); }

    public Location getQuestBoardLocation(World w) {
        return new Location(w, cfg.getDouble("quest-board.x", 4), cfg.getDouble("quest-board.y", -60), cfg.getDouble("quest-board.z", -11));
    }
    public double getQuestBoardRadius() { return cfg.getDouble("quest-board.radius", 2.5); }

    public Location getPrestigeAltarLocation(World w) {
        return new Location(w, cfg.getDouble("prestige-altar.x", 0), cfg.getDouble("prestige-altar.y", -60), cfg.getDouble("prestige-altar.z", -15));
    }
    public double getPrestigeAltarRadius() { return cfg.getDouble("prestige-altar.radius", 2.5); }

    public Location getStashLocation(World w) {
        return new Location(w,
                cfg.getDouble("stash.x", 8),
                cfg.getDouble("stash.y", -60),
                cfg.getDouble("stash.z", -6));
    }
    public double getStashRadius() { return cfg.getDouble("stash.radius", 2.5); }

    // ── Gameplay ──
    public double getBoxSellPrice() { return cfg.getDouble("box-sell-price", 5.0); }
    public double getGlobalSellMultiplier() { return cfg.getDouble("global-sell-multiplier", 1.0); }
    public void setGlobalSellMultiplier(double v) { cfg.set("global-sell-multiplier", v); plugin.saveConfig(); }
    public int getUfoMultiplierDuration() { return cfg.getInt("ufo-multiplier-duration", 3600); }
    public int getUfoEventQuota() { return cfg.getInt("ufo-event-quota", 500); }
    public int getGoldenDroneMin() { return cfg.getInt("golden-drone-min", 240); }
    public int getGoldenDroneMax() { return cfg.getInt("golden-drone-max", 600); }
    public int getUfoMin() { return cfg.getInt("ufo-min", 900); }
    public int getUfoMax() { return cfg.getInt("ufo-max", 1800); }
    public int getBoxRainMin() { return cfg.getInt("box-rain-min", 1200); }
    public int getBoxRainMax() { return cfg.getInt("box-rain-max", 2400); }
    public int getBlackMarketMin() { return cfg.getInt("black-market-min", 1500); }
    public int getBlackMarketMax() { return cfg.getInt("black-market-max", 3000); }
    public int getGoldenDroneRewardMin() { return cfg.getInt("golden-drone-reward-min", 500); }
    public int getGoldenDroneRewardMax() { return cfg.getInt("golden-drone-reward-max", 2000); }
    public String getBoxBlock() { return cfg.getString("box-block", "NOTE_BLOCK"); }
    public double getMaxBreakDistance() { return cfg.getDouble("max-break-distance", 5.0); }
    public double getEnergyCostPerBox() { return cfg.getDouble("energy-cost-per-box", 10.0); }

    // ── Prestige ──
    public long getPrestigeRequiredEarned() { return cfg.getLong("prestige.required-total-earned", 500_000L); }
    public double getPrestigeBonusPerLevel() { return cfg.getDouble("prestige.bonus-per-level", 0.10); }
    public int getPrestigeMaxLevel() { return cfg.getInt("prestige.max-level", 50); }

    // ── Auto-save ──
    public int getAutoSaveIntervalSeconds() { return cfg.getInt("auto-save-interval-seconds", 300); }

    // ── Records (PUBLIC pour accès cross-package) ──
    public record BagUpgrade(int level, int capacity, long cost) {}
    public record ToolUpgrade(int level, long cooldownMs, int boxesPerCollection, double extraBoxChance, long cost) {}
    public record EnergyUpgrade(int level, int maxEnergy, double regenPerSec, long cost) {}
    public record DroneConfig(
            String key, String name, double income,
            int intervalSec, long cost,
            int bagLevelRequired, int toolLevelRequired, int energyLevelRequired,
            double speed, int pickupRange,
            int maxSpeedTier, int maxRangeTier, int maxIncomeTier
    ) {}
    public record VendingItem(String key, String name, int energyRestore, long cost) {}
    public record SecurityUpgrade(int level, String name, double detectionChance, long cost) {}
    public record TrapUpgrade(int level, String name, double killChance, long cost) {}

    public List<BagUpgrade> getBagUpgrades() { return bagUpgrades; }
    public List<ToolUpgrade> getToolUpgrades() { return toolUpgrades; }
    public List<EnergyUpgrade> getEnergyUpgrades() { return energyUpgrades; }
    public List<DroneConfig> getDroneConfigs() { return droneConfigs; }
    public List<VendingItem> getVendingItems() { return vendingItems; }
    public List<SecurityUpgrade> getSecurityUpgrades() { return securityUpgrades; }
    public List<TrapUpgrade> getTrapUpgrades() { return trapUpgrades; }

    public BagUpgrade getBagUpgrade(int level) { return bagByLevel.get(level); }
    public ToolUpgrade getToolUpgrade(int level) { return toolByLevel.get(level); }
    public EnergyUpgrade getEnergyUpgrade(int level) { return energyByLevel.get(level); }
    public DroneConfig getDroneConfig(String key) { return droneByKey.get(key); }
    public SecurityUpgrade getSecurityUpgrade(int level) { return securityByLevel.get(level); }
    public TrapUpgrade getTrapUpgrade(int level) { return trapByLevel.get(level); }

    private List<BagUpgrade> loadBagUpgrades() {
        List<BagUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("bag-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof Map<?, ?> map) {
                list.add(new BagUpgrade(
                        toInt(map.get("level"), 1),
                        toInt(map.get("capacity"), 10),
                        toLong(map.get("cost"), 0)
                ));
            }
        }
        return list;
    }

    private List<ToolUpgrade> loadToolUpgrades() {
        List<ToolUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("tool-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof Map<?, ?> map) {
                list.add(new ToolUpgrade(
                        toInt(map.get("level"), 1),
                        toLong(map.get("cooldown-ms"), 1000),
                        toInt(map.get("boxes-per-collection"), 1),
                        toDouble(map.get("extra-box-chance"), 0.0),
                        toLong(map.get("cost"), 0)
                ));
            }
        }
        return list;
    }

    // ── Box Rain Region ──
    public BoundingBox getBoxRainRegion() {
        double minX = cfg.getDouble("box-rain-region.min.x", -18);
        double minY = cfg.getDouble("box-rain-region.min.y", -61);
        double minZ = cfg.getDouble("box-rain-region.min.z", 3);
        double maxX = cfg.getDouble("box-rain-region.max.x", 18);
        double maxY = cfg.getDouble("box-rain-region.max.y", -40);
        double maxZ = cfg.getDouble("box-rain-region.max.z", 24);
        return new BoundingBox(minX, minY, minZ, maxX, maxY, maxZ);
    }

    public int getBoxRainBoxesPerIteration() {
        return cfg.getInt("box-rain-region.boxes-per-iteration-per-player", 4);
    }

    public int getBoxRainIterations() {
        return cfg.getInt("box-rain-region.iterations", 30);
    }

    public long getBoxRainIntervalTicks() {
        return cfg.getLong("box-rain-region.interval-ticks", 20L);
    }

    public BoundingBox getPrestigeResetRegion() {
        double minX = cfg.getDouble("prestige-reset-region.min.x", -18);
        double minY = cfg.getDouble("prestige-reset-region.min.y", -61);
        double minZ = cfg.getDouble("prestige-reset-region.min.z", 3);
        double maxX = cfg.getDouble("prestige-reset-region.max.x", 18);
        double maxY = cfg.getDouble("prestige-reset-region.max.y", -40);
        double maxZ = cfg.getDouble("prestige-reset-region.max.z", 24);
        return new BoundingBox(minX, minY, minZ, maxX, maxY, maxZ);
    }

    // ── Rats / Stash ──
    public boolean isRatsEnabled() { return cfg.getBoolean("rats.enabled", true); }
    public int getRatsMinSpawnSec() { return cfg.getInt("rats.spawn-min-sec", 180); }
    public int getRatsMaxSpawnSec() { return cfg.getInt("rats.spawn-max-sec", 480); }
    public double getRatsStealPercentMin() { return cfg.getDouble("rats.steal-percent-min", 0.01); }
    public double getRatsStealPercentMax() { return cfg.getDouble("rats.steal-percent-max", 0.05); }
    public long getRatsStealCap() { return cfg.getLong("rats.steal-cap", 5000L); }
    public int getRatsTimeToStealSec() { return cfg.getInt("rats.time-to-steal-sec", 20); }
    public double getRatsSpeed() { return cfg.getDouble("rats.speed", 0.3); }
    public long getRatsMinBalanceToTrigger() { return cfg.getLong("rats.min-balance-to-trigger", 200L); }
    public double getRatsSpawnRadius() { return cfg.getDouble("rats.spawn-radius", 6.0); }

    public BoundingBox getStashRegion() {
        double minX = cfg.getDouble("stash-region.min.x", 6);
        double minY = cfg.getDouble("stash-region.min.y", -61);
        double minZ = cfg.getDouble("stash-region.min.z", -8);
        double maxX = cfg.getDouble("stash-region.max.x", 10);
        double maxY = cfg.getDouble("stash-region.max.y", -55);
        double maxZ = cfg.getDouble("stash-region.max.z", -4);
        return new BoundingBox(minX, minY, minZ, maxX, maxY, maxZ);
    }

    private List<EnergyUpgrade> loadEnergyUpgrades() {
        List<EnergyUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("energy-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof Map<?, ?> map) {
                list.add(new EnergyUpgrade(
                        toInt(map.get("level"), 1),
                        toInt(map.get("max-energy"), 100),
                        toDouble(map.get("regen-per-sec"), 1.0),
                        toLong(map.get("cost"), 0)
                ));
            }
        }
        return list;
    }

    private List<DroneConfig> loadDroneConfigs() {
        List<DroneConfig> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("drone-types");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection d = section.getConfigurationSection(key);
            if (d == null) continue;
            list.add(new DroneConfig(
                    key,
                    d.getString("name", key),
                    d.getDouble("income", 2),
                    d.getInt("interval-sec", 10),
                    d.getLong("cost", 500),
                    d.getInt("bag-level-required", 1),
                    d.getInt("tool-level-required", 1),
                    d.getInt("energy-level-required", 1),
                    d.getDouble("speed", 3.0),
                    d.getInt("pickup-range", 20),
                    d.getInt("max-speed-tier", 5),
                    d.getInt("max-range-tier", 5),
                    d.getInt("max-income-tier", 5)
            ));
        }
        return list;
    }

    private List<VendingItem> loadVendingItems() {
        List<VendingItem> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("vending-machine-items");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection v = section.getConfigurationSection(key);
            if (v == null) continue;
            list.add(new VendingItem(
                    key,
                    v.getString("name", key),
                    v.getInt("energy-restore", 25),
                    v.getLong("cost", 10)
            ));
        }
        return list;
    }

    private List<SecurityUpgrade> loadSecurityUpgrades() {
        List<SecurityUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("security-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof Map<?, ?> map) {
                list.add(new SecurityUpgrade(
                        toInt(map.get("level"), 1),
                        toStr(map.get("name"), "Caméra"),
                        toDouble(map.get("detection-chance"), 0.0),
                        toLong(map.get("cost"), 0)
                ));
            }
        }
        return list;
    }

    private List<TrapUpgrade> loadTrapUpgrades() {
        List<TrapUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("trap-upgrades");
        if (raw == null) return list;
        for (Object obj : raw) {
            if (obj instanceof Map<?, ?> map) {
                list.add(new TrapUpgrade(
                        toInt(map.get("level"), 1),
                        toStr(map.get("name"), "Piège"),
                        toDouble(map.get("kill-chance"), 0.0),
                        toLong(map.get("cost"), 0)
                ));
            }
        }
        return list;
    }

    public long getDroneUpgradeCost(long droneCost, String upgradeType, int currentTier) {
        double base = cfg.getDouble("drone-upgrade.base-multiplier." + upgradeType, 0.4);
        double growth = cfg.getDouble("drone-upgrade.growth-per-tier", 1.75);
        return Math.round(droneCost * base * Math.pow(growth, currentTier));
    }

    public double getDroneSpeedTierBonus() { return cfg.getDouble("drone-upgrade.speed-bonus-per-tier", 0.20); }
    public double getDroneRangeTierBonus() { return cfg.getDouble("drone-upgrade.range-bonus-per-tier", 0.25); }
    public double getDroneIncomeTierBonus() { return cfg.getDouble("drone-upgrade.income-bonus-per-tier", 0.30); }

    private int toInt(Object o, int def) { return o instanceof Number n ? n.intValue() : def; }
    private long toLong(Object o, long def) { return o instanceof Number n ? n.longValue() : def; }
    private double toDouble(Object o, double d) { return o instanceof Number n ? n.doubleValue() : d; }
    private String toStr(Object o, String def) { return o == null ? def : o.toString(); }
}
