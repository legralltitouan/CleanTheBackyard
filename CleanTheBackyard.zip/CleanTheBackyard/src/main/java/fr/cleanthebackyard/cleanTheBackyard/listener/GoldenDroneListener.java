package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class GoldenDroneListener implements Listener {

    private final CleanTheBackyard plugin;

    public GoldenDroneListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        Entity ent = event.getEntity();
        if (!plugin.providers().entity().isCtbEntity(ent, "golden-drone")) return;
        if (!plugin.events().isGoldenDroneSpawned()) return;

        boolean claimed = plugin.events().claimGoldenDrone(player, ent.getUniqueId());
        if (claimed) {
            event.setCancelled(true);
        }
    }
}
