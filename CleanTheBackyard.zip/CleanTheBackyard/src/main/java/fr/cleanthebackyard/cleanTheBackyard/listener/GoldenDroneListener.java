package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.entity.Bat;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class GoldenDroneListener implements Listener {

    private final CleanTheBackyard plugin;

    public GoldenDroneListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Bat)) return;
        if (!(event.getDamager() instanceof Player player)) return;
        if (!plugin.getEventManager().isGoldenDroneSpawned()) return;

        boolean claimed = plugin.getEventManager().claimGoldenDrone(player, event.getEntity().getUniqueId());
        if (claimed) {
            event.setCancelled(true); // On évite les dégâts normaux, le drone est supprimé dans claimGoldenDrone
        }
    }
}