package fr.cleanthebackyard.cleanTheBackyard.provider;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.event.block.BlockBreakEvent;
import java.lang.reflect.Method;
/**
 * Abstraction unifiée pour manipuler un "carton", qu'il soit vanilla
 * (NOTE_BLOCK, etc.) ou un CustomBlock ItemsAdder.
 *
 * Si ItemsAdder est absent, tout est traité en vanilla — aucune erreur.
 * On utilise la réflexion pour ne pas avoir ItemsAdder en dépendance dure.
 */
public class BlockProvider {
    private final CleanTheBackyard plugin;
    private final boolean itemsAdderPresent;
    // Cache des méthodes IA (réflexion)
    private Method iaGetByNamespacedID;
    private Method iaPlace;
    private Method iaGetCustomBlockAtLocation;
    private Method iaGetNamespacedID;
    private Method iaRemove;
    public BlockProvider(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.itemsAdderPresent = Bukkit.getPluginManager().isPluginEnabled("ItemsAdder");
        if (itemsAdderPresent) initItemsAdderReflection();
    }
    private void initItemsAdderReflection() {
        try {
            Class<?> customBlock = Class.forName("dev.lone.itemsadder.api.CustomBlock");
            iaGetByNamespacedID        = customBlock.getMethod("getInstance", String.class);
            iaPlace                    = customBlock.getMethod("place", Location.class);
            iaGetCustomBlockAtLocation = customBlock.getMethod("byAlreadyPlaced", Block.class);
            iaGetNamespacedID          = customBlock.getMethod("getNamespacedID");
            iaRemove                   = customBlock.getMethod("remove");
            plugin.getLogger().info("[CTB] ItemsAdder détecté : support des cartons custom activé.");
        } catch (Throwable t) {
            plugin.getLogger().warning("[CTB] ItemsAdder présent mais API inaccessible (" + t.getMessage()
                    + "). Bascule en vanilla.");
        }
    }
    public boolean isItemsAdderAvailable() {
        return itemsAdderPresent && iaGetByNamespacedID != null;
    }
    /** Le bloc à cette location est-il un carton du type {@code ref} ? */
    public boolean isCarton(Block block, BlockRef ref) {
        if (block == null || ref == null) return false;
        if (ref.getType() == BlockRef.Type.VANILLA) {
            Material m = Material.matchMaterial(ref.getId());
            return m != null && block.getType() == m;
        }
        // ItemsAdder
        if (!isItemsAdderAvailable()) {
            return block.getType() == Material.NOTE_BLOCK; // fallback raisonnable
        }
        try {
            Object custom = iaGetCustomBlockAtLocation.invoke(null, block);
            if (custom == null) return false;
            String id = (String) iaGetNamespacedID.invoke(custom);
            return ref.getId().equalsIgnoreCase(id);
        } catch (Throwable t) {
            return false;
        }
    }
    /** Pose un carton à la location indiquée. */
    public boolean placeCarton(Location loc, BlockRef ref) {
        if (loc == null || ref == null) return false;
        if (ref.getType() == BlockRef.Type.VANILLA) {
            Material m = Material.matchMaterial(ref.getId());
            if (m == null) return false;
            loc.getBlock().setType(m, false);
            return true;
        }
        if (!isItemsAdderAvailable()) {
            loc.getBlock().setType(Material.NOTE_BLOCK, false);
            return true;
        }
        try {
            Object customBlock = iaGetByNamespacedID.invoke(null, ref.getId());
            if (customBlock == null) {
                plugin.getLogger().warning("[CTB] Carton ItemsAdder introuvable : " + ref.getId());
                return false;
            }
            iaPlace.invoke(customBlock, loc);
            return true;
        } catch (Throwable t) {
            plugin.getLogger().warning("[CTB] Erreur placement carton IA : " + t.getMessage());
            return false;
        }
    }
    /** Casse / vide un carton. */
    public void breakCarton(Block block, BlockRef ref) {
        if (block == null) return;
        if (ref != null && ref.getType() == BlockRef.Type.ITEMSADDER && isItemsAdderAvailable()) {
            try {
                Object custom = iaGetCustomBlockAtLocation.invoke(null, block);
                if (custom != null) {
                    iaRemove.invoke(custom);
                    return;
                }
            } catch (Throwable ignored) {}
        }
        block.setType(Material.AIR, false);
    }
    public boolean matchesBreakEvent(BlockBreakEvent event, BlockRef ref) {
        return isCarton(event.getBlock(), ref);
    }
    /**
     * Matériau utilisé pour le rendu des FallingBlock pendant la pluie.
     * Pour les cartons IA, on utilise NOTE_BLOCK pendant la chute, puis on
     * convertit à l'atterrissage via {@link #placeCarton}.
     */
    public Material getFallbackMaterial(BlockRef ref) {
        if (ref.getType() == BlockRef.Type.VANILLA) {
            Material m = Material.matchMaterial(ref.getId());
            return m != null ? m : Material.NOTE_BLOCK;
        }
        return Material.NOTE_BLOCK;
    }
}