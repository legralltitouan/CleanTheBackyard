package fr.cleanthebackyard.cleanTheBackyard.task;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Tâche responsable de la régénération d'énergie des joueurs.
 */
public class EnergyRegenTask extends BukkitRunnable {

    private final CleanTheBackyard plugin;

    public EnergyRegenTask(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (data == null) continue;

            // Régénération d'énergie
            double regen = plugin.getBoxManager().getEnergyRegenForLevel(data.getEnergyLevel());
            data.addEnergy(regen);

            // Si l'énergie dépasse le maximum, la remettre au maximum
            int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());
            if (data.getCurrentEnergy() > maxEnergy) {
                data.setCurrentEnergy(maxEnergy);
            }
        }
    }
}
