package fr.cleanthebackyard.cleanTheBackyard.task;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

public class EnergyRegenTask extends BukkitRunnable {

    private final CleanTheBackyard plugin;

    public EnergyRegenTask(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        String hub = plugin.getPluginConfig().getHubWorldName();

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (data == null) continue;

            int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());

            // En hub : énergie au max (le joueur se repose)
            if (player.getWorld().getName().equals(hub)) {
                if (data.getCurrentEnergy() < maxEnergy) {
                    data.setCurrentEnergy(maxEnergy);
                    plugin.getBoxManager().removeFatigue(player, data);
                }
                continue;
            }

            double regen = plugin.getBoxManager().getEnergyRegenForLevel(data.getEnergyLevel());
            data.addEnergy(regen);

            if (data.getCurrentEnergy() > maxEnergy) {
                data.setCurrentEnergy(maxEnergy);
            }

            // Retire la fatigue si l'énergie est suffisante
            if (data.getCurrentEnergy() > 10 && plugin.getBoxManager().isFatigued(player.getUniqueId())) {
                plugin.getBoxManager().removeFatigue(player, data);
            }
        }
    }
}
