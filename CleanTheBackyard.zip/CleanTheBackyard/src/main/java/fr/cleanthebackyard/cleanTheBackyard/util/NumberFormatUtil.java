package fr.cleanthebackyard.cleanTheBackyard.util;
public final class NumberFormatUtil {
    private NumberFormatUtil() {}
    private static final String[] SUFFIXES = {"", "K", "M", "B", "T", "Q"};
    /**
     * Formate un nombre en notation compacte :
     *   999       -> "999"
     *   1200      -> "1.2K"
     *   12000     -> "12K"
     *   120000    -> "120K"
     *   1200000   -> "1.2M"
     *   1500000000 -> "1.5B"
     */
    public static String format(double value) {
        boolean negative = value < 0;
        double abs = Math.abs(value);
        if (abs < 1000) {
            // Pas de décimales pour les petits nombres
            long rounded = Math.round(abs);
            return (negative ? "-" : "") + rounded;
        }
        int suffixIdx = 0;
        double scaled = abs;
        while (scaled >= 1000 && suffixIdx < SUFFIXES.length - 1) {
            scaled /= 1000.0;
            suffixIdx++;
        }
        String numberPart;
        if (scaled >= 100) {
            // ex: 120K (pas de décimale)
            numberPart = String.valueOf((long) scaled);
        } else if (scaled >= 10) {
            // ex: 12K (pas de décimale)
            numberPart = String.valueOf((long) scaled);
        } else {
            // ex: 1.2K (une décimale, sans zéro final inutile)
            double rounded = Math.round(scaled * 10.0) / 10.0;
            if (rounded == (long) rounded) {
                numberPart = String.valueOf((long) rounded);
            } else {
                numberPart = String.format(java.util.Locale.US, "%.1f", rounded);
            }
        }
        return (negative ? "-" : "") + numberPart + SUFFIXES[suffixIdx];
    }
    public static String format(long value) {
        return format((double) value);
    }
    /**
     * Préfixe avec "$" pour les soldes.
     */
    public static String money(double value) {
        return "$" + format(value);
    }
    public static String money(long value) {
        return "$" + format(value);
    }
}