package fr.cleanthebackyard.cleanTheBackyard.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.RegionUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;
import java.time.Duration;
public class PrestigeManager {
    private final CleanTheBackyard plugin;
    public PrestigeManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public boolean canPrestige(PlayerData data) {
        long required = getRequiredForNextPrestige(data);
        return data.getLifetimeEarned() >= required
                && data.getPrestigeLevel() < plugin.getPluginConfig().getPrestigeMaxLevel();
    }
    public long getRequiredForNextPrestige(PlayerData data) {
        return plugin.getPluginConfig().getPrestigeRequiredEarned()
                * (long) Math.pow(2, data.getPrestigeLevel());
    }
    public boolean prestige(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (!canPrestige(data)) {
            long need = getRequiredForNextPrestige(data) - data.getLifetimeEarned();
            player.sendMessage(ChatUtil.color("&cIl te manque &f$" + need + "&c (gains totaux) pour prestige !"));
            return false;
        }
        data.setBalance(0);
        data.setBagLevel(1);
        data.setToolLevel(1);
        data.setEnergyLevel(1);
        data.setCurrentEnergy(100);
        data.clearBag();
        data.getOwnedDrones().clear();
        data.getAllDroneUpgrades().clear();
        data.getAllDroneModules().clear();
        plugin.getDroneManager().despawnPlayerDrones(player);
        data.setSecurityLevel(0);
        data.setTrapLevel(0);
        // ── Reset de la zone de carton débloquée ──
        data.setCardboardZoneLevel(0);
        // ── Préservé : collection, lifetime, talents (mais on donne un point en plus) ──
        data.setPrestigeLevel(data.getPrestigeLevel() + 1);
        data.addTalentPoints(1);
        // ── Restaure TOUS les cartons jusqu'à l'extension MAX depuis le template ──
        restoreBoxesFromTemplate(player, data);
        // ── Replace le display de frontière selon la nouvelle zone (niveau 0) ──
        plugin.getServer().getScheduler().runTaskLater(plugin,
                () -> plugin.getZoneBorderManager().refresh(player), 5L);
        Title title = Title.title(
                Component.text(ChatUtil.color("&6✦ PRESTIGE " + data.getPrestigeLevel() + " ✦")),
                Component.text(ChatUtil.color("&e+1 point de talent à dépenser !")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofSeconds(1))
        );
        player.showTitle(title);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.8f);
        player.sendMessage(ChatUtil.color("&6Prestige " + data.getPrestigeLevel()
                + " ! &e+1 point de talent &7(total : &f" + data.getTalentPoints() + "&7)"));
        player.sendMessage(ChatUtil.color("&7Reset : solde, niveaux, sac, drones (+upgrades +modules), caméras, pièges, zone de cartons."));
        player.sendMessage(ChatUtil.color("&aConservé : collection, lifetime, talents."));
        if (data.getPrestigeLevel() == plugin.getPluginConfig().getSleepUnlockPrestige()) {
            player.sendMessage(ChatUtil.color("&b💤 Sleep Mode débloqué ! Tes drones produisent maintenant offline."));
        }
        // ── Ouvre directement l'arbre de talents après le prestige ──
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (player.isOnline()) plugin.getGuiManager().openTalent(player);
        }, 30L);
        return true;
    }
    private void restoreBoxesFromTemplate(Player player, PlayerData data) {
        String templateName = plugin.getPluginConfig().getTemplateWorldName();
        World template = Bukkit.getWorld(templateName);
        if (template == null) {
            plugin.getLogger().warning("[CTB] Template '" + templateName + "' non chargé.");
            return;
        }
        World playerWorld = plugin.getPluginConfig().getPlayerWorld(player.getUniqueId());
        if (playerWorld == null) return;
        BlockRef boxRef = plugin.getPluginConfig().getBoxBlockRef();
        Material boxMat = plugin.getBlockProvider().getFallbackMaterial(boxRef);
        // Région complète jusqu'à l'extension MAX (peu importe le niveau actuel du joueur).
        BoundingBox maxRegion = plugin.getPluginConfig().getPrestigeResetRegionMax();
        // 1) On casse tous les cartons existants dans la région max du monde joueur.
        int removed = clearBoxesInRegion(playerWorld, maxRegion, boxMat);
        // 2) On re-clone l'intégralité des cartons du template (jusqu'à l'extension max).
        int copied = RegionUtil.copyRegionFiltered(template, playerWorld, maxRegion, boxMat);
        plugin.getLogger().info("[CTB] Prestige " + player.getName()
                + " : " + removed + " carton(s) retiré(s), " + copied + " carton(s) restauré(s) (zone max).");
    }
    /** Supprime tous les blocs de type {@code boxMat} dans la région donnée du monde. */
    private int clearBoxesInRegion(World world, BoundingBox region, Material boxMat) {
        int minX = (int) Math.floor(region.getMinX());
        int minY = (int) Math.floor(region.getMinY());
        int minZ = (int) Math.floor(region.getMinZ());
        int maxX = (int) Math.floor(region.getMaxX());
        int maxY = (int) Math.floor(region.getMaxY());
        int maxZ = (int) Math.floor(region.getMaxZ());
        int count = 0;
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    Block b = world.getBlockAt(x, y, z);
                    if (b.getType() == boxMat) {
                        b.setType(Material.AIR, false);
                        count++;
                    }
                }
            }
        }
        return count;
    }
}