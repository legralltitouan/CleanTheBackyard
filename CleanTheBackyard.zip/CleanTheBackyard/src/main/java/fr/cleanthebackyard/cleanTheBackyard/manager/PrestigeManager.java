package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.time.Duration;
import java.util.Map;

public class PrestigeManager {

    private final CleanTheBackyard plugin;

    public PrestigeManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean canPrestige(PlayerData data) {
        long required = plugin.getPluginConfig().getPrestigeRequiredEarned()
                * (long) Math.pow(2, data.getPrestigeLevel());
        return data.getLifetimeEarned() >= required
                && data.getPrestigeLevel() < plugin.getPluginConfig().getPrestigeMaxLevel();
    }

    public long getRequiredForNextPrestige(PlayerData data) {
        return plugin.getPluginConfig().getPrestigeRequiredEarned()
                * (long) Math.pow(2, data.getPrestigeLevel());
    }

    public boolean prestige(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (!canPrestige(data)) {
            long need = getRequiredForNextPrestige(data) - data.getLifetimeEarned();
            player.sendMessage(ChatUtil.color("&cIl te manque &f$" + need + "&c (gains totaux) pour prestige !"));
            return false;
        }

        // Reset complet : solde, niveaux, sac, drones possédés ET upgrades drones
        data.setBalance(0);
        data.setBagLevel(1);
        data.setToolLevel(1);
        data.setEnergyLevel(1);
        data.setCurrentEnergy(100);
        data.clearBag();

        // Reset des drones et de leurs upgrades
        data.getOwnedDrones().clear();
        data.getAllDroneUpgrades().clear();
        // On garde les stats drone (lifetime, pour le tableau d'honneur)

        // Despawn tous les drones physiques du joueur
        plugin.getDroneManager().despawnPlayerDrones(player);

        data.setPrestigeLevel(data.getPrestigeLevel() + 1);

        double bonus = plugin.getPluginConfig().getPrestigeBonusPerLevel() * 100;
        Title title = Title.title(
                Component.text(ChatUtil.color("&6✦ PRESTIGE " + data.getPrestigeLevel() + " ✦")),
                Component.text(ChatUtil.color("&e+" + String.format("%.0f", bonus * data.getPrestigeLevel()) + "% gains permanents")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofSeconds(1))
        );
        player.showTitle(title);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.8f);
        player.sendMessage(ChatUtil.color("&6Tu as prestige ! Bonus permanent : &f+"
                + String.format("%.0f", bonus * data.getPrestigeLevel()) + "% &6sur tous tes gains."));
        player.sendMessage(ChatUtil.color("&7Reset effectué : solde, niveaux, sac, drones et leurs upgrades."));
        return true;
    }
}
