package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.RegionUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

import java.time.Duration;

public class PrestigeManager {

    private final CleanTheBackyard plugin;

    public PrestigeManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean canPrestige(PlayerData data) {
        long required = plugin.getPluginConfig().getPrestigeRequiredEarned()
                * (long) Math.pow(2, data.getPrestigeLevel());
        return data.getLifetimeEarned() >= required
                && data.getPrestigeLevel() < plugin.getPluginConfig().getPrestigeMaxLevel();
    }

    public long getRequiredForNextPrestige(PlayerData data) {
        return plugin.getPluginConfig().getPrestigeRequiredEarned()
                * (long) Math.pow(2, data.getPrestigeLevel());
    }

    public boolean prestige(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (!canPrestige(data)) {
            long need = getRequiredForNextPrestige(data) - data.getLifetimeEarned();
            player.sendMessage(ChatUtil.color("&cIl te manque &f$" + need + "&c (gains totaux) pour prestige !"));
            return false;
        }

        // Reset stats joueur
        data.setBalance(0);
        data.setBagLevel(1);
        data.setToolLevel(1);
        data.setEnergyLevel(1);
        data.setCurrentEnergy(100);
        data.clearBag();
        data.getOwnedDrones().clear();
        data.getAllDroneUpgrades().clear();
        plugin.getDroneManager().despawnPlayerDrones(player);

        data.setPrestigeLevel(data.getPrestigeLevel() + 1);

        // Restaure les cartons depuis le template
        restoreBoxesFromTemplate(player);

        double bonus = plugin.getPluginConfig().getPrestigeBonusPerLevel() * 100;
        Title title = Title.title(
                Component.text(ChatUtil.color("&6✦ PRESTIGE " + data.getPrestigeLevel() + " ✦")),
                Component.text(ChatUtil.color("&e+" + String.format("%.0f", bonus * data.getPrestigeLevel()) + "% gains permanents")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofSeconds(1))
        );
        player.showTitle(title);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.8f);
        player.sendMessage(ChatUtil.color("&6Tu as prestige ! Bonus permanent : &f+"
                + String.format("%.0f", bonus * data.getPrestigeLevel()) + "% &6sur tous tes gains."));
        player.sendMessage(ChatUtil.color("&7Reset : solde, niveaux, sac, drones et leurs upgrades."));
        player.sendMessage(ChatUtil.color("&aLes cartons ont été réinitialisés depuis le template !"));
        return true;
    }

    /**
     * Copie les cartons (NOTE_BLOCK) depuis le monde template vers le monde du joueur
     * dans la région définie par `prestige-reset-region`.
     */
    private void restoreBoxesFromTemplate(Player player) {
        String templateName = plugin.getPluginConfig().getTemplateWorldName();
        World template = Bukkit.getWorld(templateName);
        if (template == null) {
            plugin.getLogger().warning("[CTB] Template '" + templateName + "' non chargé, impossible de restaurer les cartons.");
            return;
        }

        World playerWorld = plugin.getPluginConfig().getPlayerWorld(player.getUniqueId());
        if (playerWorld == null) {
            plugin.getLogger().warning("[CTB] Monde du joueur " + player.getName() + " introuvable.");
            return;
        }

        BoundingBox region = plugin.getPluginConfig().getPrestigeResetRegion();
        Material boxMat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        if (boxMat == null) boxMat = Material.NOTE_BLOCK;

        // On execute sur le thread principal (déjà le cas si appelé depuis la GUI)
        int copied = RegionUtil.copyRegionFiltered(template, playerWorld, region, boxMat);
        plugin.getLogger().info("[CTB] Prestige " + player.getName() + " : " + copied + " carton(s) restauré(s).");
    }
}
