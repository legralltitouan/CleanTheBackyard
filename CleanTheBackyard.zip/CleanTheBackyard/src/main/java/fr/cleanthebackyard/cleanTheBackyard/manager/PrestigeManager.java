package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.RegionUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;

import java.time.Duration;

public class PrestigeManager {

    private final CleanTheBackyard plugin;

    public PrestigeManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean canPrestige(PlayerData data) {
        long required = getRequiredForNextPrestige(data);
        return data.getLifetimeEarned() >= required
                && data.getPrestigeLevel() < plugin.getPluginConfig().getPrestigeMaxLevel();
    }

    public long getRequiredForNextPrestige(PlayerData data) {
        return plugin.getPluginConfig().getPrestigeRequiredEarned()
                * (long) Math.pow(2, data.getPrestigeLevel());
    }

    public boolean prestige(Player player) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (!canPrestige(data)) {
            long need = getRequiredForNextPrestige(data) - data.getLifetimeEarned();
            player.sendMessage(ChatUtil.color("&cIl te manque &f$" + need + "&c (gains totaux) pour prestige !"));
            return false;
        }

        // Reset stats joueur
        data.setBalance(0);
        data.setBagLevel(1);
        data.setToolLevel(1);
        data.setEnergyLevel(1);
        data.setCurrentEnergy(100);
        data.clearBag();

        // Reset drones (possession + upgrades)
        data.getOwnedDrones().clear();
        data.getAllDroneUpgrades().clear();
        plugin.getDroneManager().despawnPlayerDrones(player);

        // Reset sécurité
        data.setSecurityLevel(0);
        data.setTrapLevel(0);

        // ── PRÉSERVÉ AU PRESTIGE :
        // - data.getCollectedItems() : la collection est permanente
        // - data.getLifetimeEarned() : gains lifetime
        // - data.getTotalBoxesBroken() : stats lifetime
        // - data.getTotalStolenByRats(), totalRatsKilled, totalRatsScared
        // - drone stats lifetime
        // Aucun reset à effectuer sur ces champs.

        data.setPrestigeLevel(data.getPrestigeLevel() + 1);
        restoreBoxesFromTemplate(player);

        double bonus = plugin.getPluginConfig().getPrestigeBonusPerLevel() * 100;
        Title title = Title.title(
                Component.text(ChatUtil.color("&6✦ PRESTIGE " + data.getPrestigeLevel() + " ✦")),
                Component.text(ChatUtil.color("&e+" + String.format("%.0f", bonus * data.getPrestigeLevel()) + "% gains permanents")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofSeconds(1))
        );
        player.showTitle(title);
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.8f);
        player.sendMessage(ChatUtil.color("&6Tu as prestige ! Bonus permanent : &f+"
                + String.format("%.0f", bonus * data.getPrestigeLevel()) + "% &6sur tous tes gains."));
        player.sendMessage(ChatUtil.color("&7Reset : solde, niveaux, sac, drones (+upgrades), caméras, pièges."));
        player.sendMessage(ChatUtil.color("&aConservé : ta collection, tes stats lifetime, ton prestige."));
        player.sendMessage(ChatUtil.color("&aLes cartons ont été réinitialisés depuis le template !"));
        return true;
    }

    private void restoreBoxesFromTemplate(Player player) {
        String templateName = plugin.getPluginConfig().getTemplateWorldName();
        World template = Bukkit.getWorld(templateName);
        if (template == null) {
            plugin.getLogger().warning("[CTB] Template '" + templateName + "' non chargé, restauration impossible.");
            return;
        }

        World playerWorld = plugin.getPluginConfig().getPlayerWorld(player.getUniqueId());
        if (playerWorld == null) {
            plugin.getLogger().warning("[CTB] Monde du joueur " + player.getName() + " introuvable.");
            return;
        }

        BoundingBox region = plugin.getPluginConfig().getPrestigeResetRegion()
                ;
        BlockRef boxRef = plugin.getPluginConfig().getBoxBlockRef();
        Material boxMat = plugin.getBlockProvider().getFallbackMaterial(boxRef);

        int copied = RegionUtil.copyRegionFiltered(template, playerWorld, region, boxMat);
        plugin.getLogger().info("[CTB] Prestige " + player.getName() + " : " + copied + " carton(s) restauré(s).");
    }
}
