package fr.cleanthebackyard.cleanTheBackyard.data;
import java.util.*;
public class PlayerData {
    private final UUID uuid;
    private final String name;
    // ── Économie ──
    private double balance;
    private long   totalEarned;
    private long   totalBoxesBroken;
    // ── Sac ──
    private int bagLevel;
    private int currentBoxes;
    // ── Outil ──
    private int  toolLevel;
    private long lastBreakTime;
    // ── Énergie ──
    private int    energyLevel;
    private double currentEnergy;
    // ── Drones ──
    private final Set<String> ownedDrones;
    // Upgrades par drone : key = droneKey, value = [speedTier, rangeTier, incomeTier]
    private final Map<String, int[]> droneUpgrades;
    // Stats par drone : key = droneKey, value = [boxesCollected, totalEarnedFromDrone]
    private final Map<String, long[]> droneStats;
    // ── Stats session ──
    private long sessionBoxesBroken;
    private long sessionEarned;
    // ── Buffs ──
    private long unlimitedEnergyUntil = 0L;
    private long doubleSellUntil      = 0L;
    private long blackMarketUntil     = 0L; // x3 vente perso
    // ── Prestige ──
    private int  prestigeLevel = 0;
    private long lifetimeEarned = 0L; // jamais reset, sert au prestige
    // ── Quêtes journalières ──
    private long questResetTimestamp = 0L; // timestamp du dernier reset (jour)
    private final List<DailyQuest> dailyQuests = new ArrayList<>();
    public PlayerData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
        this.balance = 0.0;
        this.bagLevel = 1;
        this.toolLevel = 1;
        this.energyLevel = 1;
        this.currentEnergy = 100.0;
        this.ownedDrones = new HashSet<>();
        this.droneUpgrades = new HashMap<>();
        this.droneStats = new HashMap<>();
    }
    // ── Getters / Setters ──
    public UUID   getUuid()           { return uuid; }
    public String getName()           { return name; }
    public double getBalance()        { return balance; }
    public void   setBalance(double v){ this.balance = Math.max(0, v); }
    public void   addBalance(double v){
        this.balance += v;
        totalEarned += (long) v;
        sessionEarned += (long) v;
        lifetimeEarned += (long) v;
    }
    public boolean removeBalance(double v) {
        if (balance < v) return false;
        balance -= v;
        return true;
    }
    public long getTotalEarned()      { return totalEarned; }
    public long getLifetimeEarned()   { return lifetimeEarned; }
    public void setLifetimeEarned(long v) { this.lifetimeEarned = v; }
    public long getTotalBoxesBroken() { return totalBoxesBroken; }
    public void setTotalBoxesBroken(long v) { this.totalBoxesBroken = v; }
    public void incrementBoxesBroken(){ totalBoxesBroken++; sessionBoxesBroken++; }
    public int  getBagLevel()         { return bagLevel; }
    public void setBagLevel(int lvl)  { this.bagLevel = lvl; }
    public int  getCurrentBoxes()     { return currentBoxes; }
    public void setCurrentBoxes(int v){ this.currentBoxes = v; }
    public void addBox()              { this.currentBoxes++; }
    public void clearBag()            { this.currentBoxes = 0; }
    public int  getToolLevel()        { return toolLevel; }
    public void setToolLevel(int lvl) { this.toolLevel = lvl; }
    public long getLastBreakTime()    { return lastBreakTime; }
    public void setLastBreakTime(long t){ this.lastBreakTime = t; }
    public int    getEnergyLevel()      { return energyLevel; }
    public void   setEnergyLevel(int v) { this.energyLevel = v; }
    public double getCurrentEnergy()    { return currentEnergy; }
    public void   setCurrentEnergy(double v){ this.currentEnergy = v; }
    public void   addEnergy(double v)   { this.currentEnergy += v; }
    public void   removeEnergy(double v){ this.currentEnergy = Math.max(0, currentEnergy - v); }
    public Set<String> getOwnedDrones() { return ownedDrones; }
    public boolean hasDrone(String key) { return ownedDrones.contains(key); }
    public void addDrone(String key)    {
        ownedDrones.add(key);
        droneUpgrades.putIfAbsent(key, new int[]{0, 0, 0});
        droneStats.putIfAbsent(key, new long[]{0L, 0L});
    }
    // Drone upgrades [0]=speed [1]=range [2]=income
    public int[] getDroneUpgrades(String key) {
        return droneUpgrades.computeIfAbsent(key, k -> new int[]{0, 0, 0});
    }
    public void setDroneUpgrades(String key, int[] tiers) {
        droneUpgrades.put(key, tiers);
    }
    public Map<String, int[]> getAllDroneUpgrades() { return droneUpgrades; }
    public long[] getDroneStats(String key) {
        return droneStats.computeIfAbsent(key, k -> new long[]{0L, 0L});
    }
    public void incrementDroneCollected(String key) { getDroneStats(key)[0]++; }
    public void addDroneEarnings(String key, long amount) { getDroneStats(key)[1] += amount; }
    public Map<String, long[]> getAllDroneStats() { return droneStats; }
    public long getSessionBoxesBroken() { return sessionBoxesBroken; }
    public long getSessionEarned()      { return sessionEarned; }
    public void resetSession()          { sessionBoxesBroken = 0; sessionEarned = 0; }
    // ── Buffs ──
    public boolean hasUnlimitedEnergy() { return System.currentTimeMillis() < unlimitedEnergyUntil; }
    public void setUnlimitedEnergy(int durationSeconds) {
        long now = System.currentTimeMillis();
        this.unlimitedEnergyUntil = Math.max(now, unlimitedEnergyUntil) + durationSeconds * 1000L;
    }
    public long getUnlimitedEnergyRemainingSeconds() {
        return Math.max(0, (unlimitedEnergyUntil - System.currentTimeMillis()) / 1000L);
    }
    public long getUnlimitedEnergyUntil() { return unlimitedEnergyUntil; }
    public void setRawUnlimitedEnergyUntil(long t) { this.unlimitedEnergyUntil = t; }
    public boolean hasDoubleSell() { return System.currentTimeMillis() < doubleSellUntil; }
    public void setDoubleSell(int durationSeconds) {
        long now = System.currentTimeMillis();
        this.doubleSellUntil = Math.max(now, doubleSellUntil) + durationSeconds * 1000L;
    }
    public long getDoubleSellRemainingSeconds() {
        return Math.max(0, (doubleSellUntil - System.currentTimeMillis()) / 1000L);
    }
    public long getDoubleSellUntil() { return doubleSellUntil; }
    public void setRawDoubleSellUntil(long t) { this.doubleSellUntil = t; }
    public boolean hasBlackMarket() { return System.currentTimeMillis() < blackMarketUntil; }
    public void setBlackMarket(int durationSeconds) {
        long now = System.currentTimeMillis();
        this.blackMarketUntil = Math.max(now, blackMarketUntil) + durationSeconds * 1000L;
    }
    public long getBlackMarketRemainingSeconds() {
        return Math.max(0, (blackMarketUntil - System.currentTimeMillis()) / 1000L);
    }
    public long getBlackMarketUntil() { return blackMarketUntil; }
    public void setRawBlackMarketUntil(long t) { this.blackMarketUntil = t; }
    // ── Prestige ──
    public int  getPrestigeLevel()       { return prestigeLevel; }
    public void setPrestigeLevel(int v)  { this.prestigeLevel = v; }
    public double getPrestigeMultiplier(double bonusPerLevel) {
        return 1.0 + prestigeLevel * bonusPerLevel;
    }
    // ── Quêtes journalières ──
    public long getQuestResetTimestamp() { return questResetTimestamp; }
    public void setQuestResetTimestamp(long t) { this.questResetTimestamp = t; }
    public List<DailyQuest> getDailyQuests() { return dailyQuests; }
    public void setDailyQuests(List<DailyQuest> quests) {
        this.dailyQuests.clear();
        this.dailyQuests.addAll(quests);
    }
}