package fr.cleanthebackyard.cleanTheBackyard.data;
import java.util.*;
public class PlayerData {
    private final UUID uuid;
    private final String name;
    private double balance;
    private long totalEarned;
    private long totalBoxesBroken;
    private int bagLevel;
    private int currentBoxes;
    private int toolLevel;
    private long lastBreakTime;
    private int energyLevel;
    private double currentEnergy;
    private final Set<String> ownedDrones = new HashSet<>();
    private final Map<String, int[]> droneUpgrades = new HashMap<>();
    private final Map<String, long[]> droneStats = new HashMap<>();
    /** drone-key -> module-key (1 module max par drone). */
    private final Map<String, String> droneModules = new HashMap<>();
    // ── Batterie des drones ──
    /** drone-key -> charge courante (Wh, double). */
    private final Map<String, Double> droneBattery = new HashMap<>();
    /** drone-key -> tier de capacité de batterie. */
    private final Map<String, Integer> droneBatteryTier = new HashMap<>();
    private long sessionBoxesBroken;
    private long sessionEarned;
    private long unlimitedEnergyUntil = 0L;
    private long doubleSellUntil = 0L;
    private long blackMarketUntil = 0L;
    private int prestigeLevel = 0;
    // ── Zone de carton débloquée (reset au prestige) ──
    private int cardboardZoneLevel = 0;
    private long lifetimeEarned = 0L;
    private int securityLevel = 0;
    private int trapLevel = 0;
    private long totalStolenByRats = 0L;
    private long totalRatsKilled = 0L;
    private long totalRatsScared = 0L;
    private long questResetTimestamp = 0L;
    private final List<DailyQuest> dailyQuests = new ArrayList<>();
    private final Set<String> collectedItems = new HashSet<>();
    private final Map<String, Integer> ownedFurniture = new HashMap<>();
    // ── Talents ──
    private int talentPoints = 0;
    private final Map<String, Integer> talentTiers = new HashMap<>();
    // ── Daily streak ──
    /** Date (epoch day) de la dernière récompense réclamée. */
    private long lastDailyClaimEpochDay = 0L;
    /** Streak courante (jour 1..7 puis cycle). */
    private int dailyStreak = 0;
    // ── Sleep mode / offline ──
    /** Timestamp ms du dernier logout (0 = jamais). */
    private long lastSeenMs = 0L;
    public PlayerData(UUID uuid, String name) {
        this.uuid = uuid;
        this.name = name;
        this.balance = 0;
        this.bagLevel = 1;
        this.toolLevel = 1;
        this.energyLevel = 1;
        this.currentEnergy = 100;
    }
    public UUID getUuid() { return uuid; }
    public String getName() { return name; }
    public double getBalance() { return balance; }
    public void setBalance(double v) { this.balance = Math.max(0, v); }
    public void addBalance(double v) {
        this.balance += v;
        this.totalEarned += Math.round(v);
        this.sessionEarned += Math.round(v);
        this.lifetimeEarned += Math.round(v);
    }
    public boolean removeBalance(double v) {
        if (balance < v) return false;
        balance -= v;
        return true;
    }
    public long getTotalEarned() { return totalEarned; }
    public void setTotalEarned(long v) { this.totalEarned = v; }
    public long getLifetimeEarned() { return lifetimeEarned; }
    public void setLifetimeEarned(long v) { this.lifetimeEarned = v; }
    public long getTotalBoxesBroken() { return totalBoxesBroken; }
    public void setTotalBoxesBroken(long v) { this.totalBoxesBroken = v; }
    public void incrementBoxesBroken() { totalBoxesBroken++; sessionBoxesBroken++; }
    public int getBagLevel() { return bagLevel; }
    public void setBagLevel(int v) { this.bagLevel = v; }
    public int getCurrentBoxes() { return currentBoxes; }
    public void setCurrentBoxes(int v) { this.currentBoxes = v; }
    public void addBox() { this.currentBoxes++; }
    public void clearBag() { this.currentBoxes = 0; }
    public int getToolLevel() { return toolLevel; }
    public void setToolLevel(int v) { this.toolLevel = v; }
    public long getLastBreakTime() { return lastBreakTime; }
    public void setLastBreakTime(long t) { this.lastBreakTime = t; }
    public int getEnergyLevel() { return energyLevel; }
    public void setEnergyLevel(int v) { this.energyLevel = v; }
    public double getCurrentEnergy() { return currentEnergy; }
    public void setCurrentEnergy(double v) { this.currentEnergy = v; }
    public void addEnergy(double v) { this.currentEnergy += v; }
    public void removeEnergy(double v) { this.currentEnergy = Math.max(0, currentEnergy - v); }
    public Set<String> getOwnedDrones() { return ownedDrones; }
    public boolean hasDrone(String key) { return ownedDrones.contains(key); }
    public void addDrone(String key) {
        ownedDrones.add(key);
        droneUpgrades.putIfAbsent(key, new int[]{0, 0, 0});
        droneStats.putIfAbsent(key, new long[]{0L, 0L});
        droneBatteryTier.putIfAbsent(key, 0);
        droneBattery.putIfAbsent(key, 0.0);
    }
    public int[] getDroneUpgrades(String key) {
        return droneUpgrades.computeIfAbsent(key, k -> new int[]{0, 0, 0});
    }
    public void setDroneUpgrades(String key, int[] tiers) { droneUpgrades.put(key, tiers); }
    public Map<String, int[]> getAllDroneUpgrades() { return droneUpgrades; }
    public long[] getDroneStats(String key) {
        return droneStats.computeIfAbsent(key, k -> new long[]{0L, 0L});
    }
    public void incrementDroneCollected(String key) { getDroneStats(key)[0]++; }
    public void addDroneEarnings(String key, long amount) { getDroneStats(key)[1] += amount; }
    public Map<String, long[]> getAllDroneStats() { return droneStats; }
    // ── Modules drones ──
    public String getDroneModule(String droneKey) { return droneModules.get(droneKey); }
    public void setDroneModule(String droneKey, String moduleKey) {
        if (moduleKey == null) droneModules.remove(droneKey);
        else droneModules.put(droneKey, moduleKey);
    }
    public Map<String, String> getAllDroneModules() { return droneModules; }
    public void setAllDroneModules(Map<String, String> map) {
        droneModules.clear();
        if (map != null) droneModules.putAll(map);
    }
    // ── Batterie drones ──
    public double getDroneBattery(String droneKey) { return droneBattery.getOrDefault(droneKey, 0.0); }
    public void setDroneBattery(String droneKey, double value) {
        droneBattery.put(droneKey, Math.max(0.0, value));
    }
    public Map<String, Double> getAllDroneBattery() { return droneBattery; }
    public void setAllDroneBattery(Map<String, Double> map) {
        droneBattery.clear();
        if (map != null) droneBattery.putAll(map);
    }
    public int getDroneBatteryTier(String droneKey) { return droneBatteryTier.getOrDefault(droneKey, 0); }
    public void setDroneBatteryTier(String droneKey, int tier) {
        droneBatteryTier.put(droneKey, Math.max(0, tier));
    }
    public Map<String, Integer> getAllDroneBatteryTiers() { return droneBatteryTier; }
    public void setAllDroneBatteryTiers(Map<String, Integer> map) {
        droneBatteryTier.clear();
        if (map != null) droneBatteryTier.putAll(map);
    }
    public long getSessionBoxesBroken() { return sessionBoxesBroken; }
    public long getSessionEarned() { return sessionEarned; }
    public void resetSession() { sessionBoxesBroken = 0; sessionEarned = 0; }
    public boolean hasUnlimitedEnergy() { return System.currentTimeMillis() < unlimitedEnergyUntil; }
    public void setUnlimitedEnergy(int durationSeconds) {
        long now = System.currentTimeMillis();
        this.unlimitedEnergyUntil = Math.max(now, unlimitedEnergyUntil) + durationSeconds * 1000L;
    }
    public long getUnlimitedEnergyRemainingSeconds() {
        return Math.max(0, (unlimitedEnergyUntil - System.currentTimeMillis()) / 1000L);
    }
    public long getUnlimitedEnergyUntil() { return unlimitedEnergyUntil; }
    public void setRawUnlimitedEnergyUntil(long t) { this.unlimitedEnergyUntil = t; }
    public boolean hasDoubleSell() { return System.currentTimeMillis() < doubleSellUntil; }
    public void setDoubleSell(int durationSeconds) {
        long now = System.currentTimeMillis();
        this.doubleSellUntil = Math.max(now, doubleSellUntil) + durationSeconds * 1000L;
    }
    public long getDoubleSellRemainingSeconds() {
        return Math.max(0, (doubleSellUntil - System.currentTimeMillis()) / 1000L);
    }
    public long getDoubleSellUntil() { return doubleSellUntil; }
    public void setRawDoubleSellUntil(long t) { this.doubleSellUntil = t; }
    public boolean hasBlackMarket() { return System.currentTimeMillis() < blackMarketUntil; }
    public void setBlackMarket(int durationSeconds) {
        long now = System.currentTimeMillis();
        this.blackMarketUntil = Math.max(now, blackMarketUntil) + durationSeconds * 1000L;
    }
    public long getBlackMarketRemainingSeconds() {
        return Math.max(0, (blackMarketUntil - System.currentTimeMillis()) / 1000L);
    }
    public long getBlackMarketUntil() { return blackMarketUntil; }
    public void setRawBlackMarketUntil(long t) { this.blackMarketUntil = t; }
    public int getPrestigeLevel() { return prestigeLevel; }
    public void setPrestigeLevel(int v) { this.prestigeLevel = v; }
    public int getCardboardZoneLevel() { return cardboardZoneLevel; }
    public void setCardboardZoneLevel(int v) { this.cardboardZoneLevel = Math.max(0, v); }
    public long getQuestResetTimestamp() { return questResetTimestamp; }
    public void setQuestResetTimestamp(long t) { this.questResetTimestamp = t; }
    public List<DailyQuest> getDailyQuests() { return dailyQuests; }
    public void setDailyQuests(List<DailyQuest> quests) {
        this.dailyQuests.clear();
        this.dailyQuests.addAll(quests);
    }
    public int getSecurityLevel() { return securityLevel; }
    public void setSecurityLevel(int v) { this.securityLevel = Math.max(0, v); }
    public int getTrapLevel() { return trapLevel; }
    public void setTrapLevel(int v) { this.trapLevel = Math.max(0, v); }
    public long getTotalStolenByRats() { return totalStolenByRats; }
    public void addStolenByRats(long v) { this.totalStolenByRats += v; }
    public void setTotalStolenByRats(long v) { this.totalStolenByRats = v; }
    public long getTotalRatsKilled() { return totalRatsKilled; }
    public void incrementRatsKilled() { this.totalRatsKilled++; }
    public void setTotalRatsKilled(long v) { this.totalRatsKilled = v; }
    public long getTotalRatsScared() { return totalRatsScared; }
    public void incrementRatsScared() { this.totalRatsScared++; }
    public void setTotalRatsScared(long v) { this.totalRatsScared = v; }
    public Set<String> getCollectedItems() { return collectedItems; }
    public boolean hasCollectedItem(String key) { return collectedItems.contains(key); }
    public void addCollectedItem(String key) { collectedItems.add(key); }
    public void setCollectedItems(Collection<String> items) {
        this.collectedItems.clear();
        if (items != null) this.collectedItems.addAll(items);
    }
    public Map<String, Integer> getOwnedFurniture() { return ownedFurniture; }
    public int getFurnitureCount(String key) { return ownedFurniture.getOrDefault(key, 0); }
    public void addFurniture(String key, int amount) {
        ownedFurniture.merge(key, amount, Integer::sum);
    }
    public boolean removeFurniture(String key, int amount) {
        int current = ownedFurniture.getOrDefault(key, 0);
        if (current < amount) return false;
        int newAmount = current - amount;
        if (newAmount <= 0) ownedFurniture.remove(key);
        else ownedFurniture.put(key, newAmount);
        return true;
    }
    public void setOwnedFurniture(Map<String, Integer> map) {
        ownedFurniture.clear();
        if (map != null) ownedFurniture.putAll(map);
    }
    // ── Talents ──
    public int getTalentPoints() { return talentPoints; }
    public void setTalentPoints(int v) { this.talentPoints = Math.max(0, v); }
    public void addTalentPoints(int v) { this.talentPoints = Math.max(0, this.talentPoints + v); }
    public int getTalentTier(String key) { return talentTiers.getOrDefault(key, 0); }
    public void setTalentTier(String key, int tier) {
        if (tier <= 0) talentTiers.remove(key);
        else talentTiers.put(key, tier);
    }
    public Map<String, Integer> getAllTalentTiers() { return talentTiers; }
    public void setAllTalentTiers(Map<String, Integer> map) {
        talentTiers.clear();
        if (map != null) talentTiers.putAll(map);
    }
    public void resetTalents() { talentTiers.clear(); }
    // ── Daily streak ──
    public long getLastDailyClaimEpochDay() { return lastDailyClaimEpochDay; }
    public void setLastDailyClaimEpochDay(long v) { this.lastDailyClaimEpochDay = v; }
    public int getDailyStreak() { return dailyStreak; }
    public void setDailyStreak(int v) { this.dailyStreak = Math.max(0, v); }
    // ── Offline ──
    public long getLastSeenMs() { return lastSeenMs; }
    public void setLastSeenMs(long v) { this.lastSeenMs = v; }
}