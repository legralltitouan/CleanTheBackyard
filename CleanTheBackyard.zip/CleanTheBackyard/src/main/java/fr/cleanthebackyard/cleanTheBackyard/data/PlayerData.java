package fr.cleanthebackyard.cleanTheBackyard.data;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * Contient toutes les donnees persistantes d'un joueur.
 */
public class PlayerData {

    private final UUID uuid;
    private final String name;

    // ── Economie ──────────────────────────────────────────────────────
    private double balance;
    private long   totalEarned;
    private long   totalBoxesBroken;

    // ── Sac ───────────────────────────────────────────────────────────
    private int bagLevel;
    private int currentBoxes;

    // ── Outil ─────────────────────────────────────────────────────────
    private int  toolLevel;
    private long lastBreakTime;

    // ── Energie ───────────────────────────────────────────────────────
    private int  energyLevel;
    private double currentEnergy;

    // ── Drones ────────────────────────────────────────────────────────
    private final Set<String> ownedDrones;

    // ── Stats Session ─────────────────────────────────────────────────
    private long sessionBoxesBroken;
    private long sessionEarned;

    // ── Event Buffs ───────────────────────────────────────────────────
    private long unlimitedEnergyUntil = 0L;
    private long doubleSellUntil      = 0L;

    // ── Constructeur (nouveau joueur) ─────────────────────────────────
    public PlayerData(UUID uuid, String name) {
        this.uuid            = uuid;
        this.name            = name;
        this.balance         = 0.0;
        this.totalEarned     = 0L;
        this.totalBoxesBroken= 0L;
        this.bagLevel        = 1;
        this.currentBoxes    = 0;
        this.toolLevel       = 1;
        this.lastBreakTime   = 0L;
        this.energyLevel     = 1;
        this.currentEnergy   = 100.0;
        this.ownedDrones     = new HashSet<>();
        this.sessionBoxesBroken = 0L;
        this.sessionEarned      = 0L;
    }

    // ── Getters / Setters ──────────────────────────────────────────────
    public UUID   getUuid()           { return uuid; }
    public String getName()           { return name; }

    public double getBalance()        { return balance; }
    public void   setBalance(double v){ this.balance = Math.max(0, v); }
    public void   addBalance(double v){ this.balance += v; totalEarned += (long) v; sessionEarned += (long) v; }
    public boolean removeBalance(double v) {
        if (balance < v) return false;
        balance -= v;
        return true;
    }

    public long getTotalEarned()      { return totalEarned; }
    public long getTotalBoxesBroken() { return totalBoxesBroken; }
    public void incrementBoxesBroken(){ totalBoxesBroken++; sessionBoxesBroken++; }

    public int  getBagLevel()         { return bagLevel; }
    public void setBagLevel(int lvl)  { this.bagLevel = lvl; }
    public int  getCurrentBoxes()     { return currentBoxes; }
    public void setCurrentBoxes(int v){ this.currentBoxes = v; }
    public void addBox()              { this.currentBoxes++; }
    public void clearBag()            { this.currentBoxes = 0; }

    public int  getToolLevel()        { return toolLevel; }
    public void setToolLevel(int lvl) { this.toolLevel = lvl; }
    public long getLastBreakTime()    { return lastBreakTime; }
    public void setLastBreakTime(long t){ this.lastBreakTime = t; }

    public int    getEnergyLevel()      { return energyLevel; }
    public void   setEnergyLevel(int v) { this.energyLevel = v; }
    public double getCurrentEnergy()    { return currentEnergy; }
    public void   setCurrentEnergy(double v){ this.currentEnergy = v; }
    public void   addEnergy(double v)   { this.currentEnergy += v; }
    public void   removeEnergy(double v){ this.currentEnergy = Math.max(0, currentEnergy - v); }

    public Set<String> getOwnedDrones() { return ownedDrones; }
    public boolean hasDrone(String key) { return ownedDrones.contains(key); }
    public void addDrone(String key)    { ownedDrones.add(key); }

    public long getSessionBoxesBroken() { return sessionBoxesBroken; }
    public long getSessionEarned()      { return sessionEarned; }
    public void resetSession()          { sessionBoxesBroken = 0; sessionEarned = 0; }

    // ── Buffs OVNI ───────────────────────────────────────────────────
    public boolean hasUnlimitedEnergy() { return System.currentTimeMillis() < unlimitedEnergyUntil; }
    public void setUnlimitedEnergy(int durationSeconds) {
        long now = System.currentTimeMillis();
        this.unlimitedEnergyUntil = Math.max(now, unlimitedEnergyUntil) + durationSeconds * 1000L;
    }
    public long getUnlimitedEnergyRemainingSeconds() {
        return Math.max(0, (unlimitedEnergyUntil - System.currentTimeMillis()) / 1000L);
    }
    // Getter brut pour la persistance
    public long getUnlimitedEnergyUntil() { return unlimitedEnergyUntil; }
    public void setRawUnlimitedEnergyUntil(long t) { this.unlimitedEnergyUntil = t; }

    public boolean hasDoubleSell() { return System.currentTimeMillis() < doubleSellUntil; }
    public void setDoubleSell(int durationSeconds) {
        long now = System.currentTimeMillis();
        this.doubleSellUntil = Math.max(now, doubleSellUntil) + durationSeconds * 1000L;
    }
    public long getDoubleSellRemainingSeconds() {
        return Math.max(0, (doubleSellUntil - System.currentTimeMillis()) / 1000L);
    }
    // Getter brut pour la persistance
    public long getDoubleSellUntil() { return doubleSellUntil; }
    public void setRawDoubleSellUntil(long t) { this.doubleSellUntil = t; }
}