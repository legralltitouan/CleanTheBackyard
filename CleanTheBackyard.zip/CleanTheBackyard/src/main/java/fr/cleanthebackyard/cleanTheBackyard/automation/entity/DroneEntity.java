package fr.cleanthebackyard.cleanTheBackyard.automation.entity;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.provider.CartonIndex;
import fr.cleanthebackyard.cleanTheBackyard.provider.CustomEntityHandle;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
public class DroneEntity {
    private static final Map<String, Set<Long>> lockedBoxesByWorld = new ConcurrentHashMap<>();
    private static Set<Long> locksFor(World world) {
        return lockedBoxesByWorld.computeIfAbsent(world.getName(),
                k -> ConcurrentHashMap.newKeySet());
    }
    private static final long CHASE_TIMEOUT_TICKS = 200;
    private static final long SELL_TIMEOUT_TICKS = 200;
    private static final long TASK_PERIOD = 1L;
    private static final long NAME_UPDATE_INTERVAL = 10L;
    private static final long STUCK_THRESHOLD_TICKS = 40;
    private static final long STUCK_BOOST_LIMIT = 60;
    private static final int HARD_RANGE_CAP = 160;
    private static final int VERTICAL_SCAN = 8;
    private static final long FIND_TARGET_INTERVAL = 5L;
    private static final long TARGET_RECHECK_INTERVAL = 5L;
    /** Périodicité (ticks) de recharge solaire + persistance batterie. */
    private static final long SOLAR_TICK_INTERVAL = 20L; // 1s
    private final CleanTheBackyard plugin;
    private final Player owner;
    private final PluginConfig.DroneConfig config;
    private final CustomEntityHandle entity;
    private final double speed;
    private final double stepPerTick;
    private final int pickupRange;
    private final double incomeMultiplier;
    private final BlockRef boxRef;
    private final World world;
    private final int worldMinHeight;
    private final int worldMaxHeight;
    private final int[] tiers;
    private final double moduleSaveChance;
    private final double moduleSolarChargePerSec;
    // ── Batterie ──
    private final boolean batteryEnabled;
    private final double batteryCapacity;
    private final double batteryDrainPerBox;
    private double batteryCharge;
    public enum State { IDLE, MOVING_TO_BOX, MOVING_TO_SELL, NO_TARGET, OUT_OF_BATTERY }
    private State state = State.IDLE;
    private Location targetLocation;
    private Location lastBoxTarget;
    private long lastBoxKey = 0;
    private boolean hasLock = false;
    private BukkitRunnable task;
    private long collectedSinceSpawn = 0;
    private long tickCounter = 0;
    private long stateTickCounter = 0;
    private double lastDistanceSq = Double.MAX_VALUE;
    private int stuckTicks = 0;
    private TextDisplay hologram;
    private Vector currentVelocity = new Vector(0, 0, 0);
    private long bestKey;
    private double bestDistSq;
    private boolean foundAny;
    private double scanX, scanY, scanZ;
    private int scanMinY, scanMaxY;
    public DroneEntity(Player owner, PluginConfig.DroneConfig config) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.config = config;
        this.world = owner.getWorld();
        this.worldMinHeight = world.getMinHeight();
        this.worldMaxHeight = world.getMaxHeight();
        PlayerData data = plugin.core().playerData().get(owner);
        this.tiers = (data != null) ? data.getDroneUpgrades(config.key()) : new int[]{0, 0, 0};
        double speedBonus = 1.0 + tiers[0] * plugin.core().config().getDroneSpeedTierBonus();
        double rangeBonus = 1.0 + tiers[1] * plugin.core().config().getDroneRangeTierBonus();
        double incomeBonus = 1.0 + tiers[2] * plugin.core().config().getDroneIncomeTierBonus();
        if (data != null) incomeBonus *= plugin.progression().talent().getDroneIncomeMultiplier(data);
        double saveChance = 0.0;
        double solarCharge = 0.0;
        String moduleKey = data != null ? data.getDroneModule(config.key()) : null;
        if (moduleKey != null) {
            var mod = plugin.core().config().getDroneModule(moduleKey);
            if (mod != null) {
                speedBonus += mod.speedBonus();
                rangeBonus += mod.rangeBonus();
                saveChance = mod.saveChance();
                solarCharge = mod.solarChargePerSec();
            }
        }
        this.moduleSaveChance = saveChance;
        this.moduleSolarChargePerSec = solarCharge;
        this.speed = config.speed() * speedBonus;
        this.stepPerTick = this.speed / 20.0;
        int rawRange = (int) Math.round(config.pickupRange() * rangeBonus);
        this.pickupRange = Math.min(HARD_RANGE_CAP, Math.max(1, rawRange));
        this.incomeMultiplier = incomeBonus;
        this.boxRef = plugin.core().config().getBoxBlockRef();
        // ── Batterie ──
        var cfg = plugin.core().config();
        this.batteryEnabled = cfg.isDroneBatteryEnabled();
        int batteryTier = (data != null) ? data.getDroneBatteryTier(config.key()) : 0;
        double cap = cfg.getDroneBatteryBaseCapacity()
                * (1.0 + batteryTier * cfg.getDroneBatteryCapacityPerTier());
        this.batteryCapacity = cap;
        this.batteryDrainPerBox = cfg.getDroneBatteryDrainPerBox();
        // Charge persistée (clampée à la capacité courante).
        double persisted = (data != null) ? data.getDroneBattery(config.key()) : cap;
        this.batteryCharge = Math.min(cap, Math.max(0.0, persisted));
        Location spawnLoc = cfg.getSellZoneCenter(world).clone().add(0, 2, 0);
        this.entity = plugin.providers().entity().spawn(config.entityRef(), spawnLoc, EntityType.BEE, "drone");
        Entity bukkit = entity.getBukkitEntity();
        hologram = bukkit.getWorld().spawn(
                bukkit.getLocation().clone().add(0, 2.2, 0),
                TextDisplay.class
        );
        hologram.setBillboard(Display.Billboard.CENTER);
        hologram.setSeeThrough(true);
        hologram.setShadowed(false);
        hologram.setDefaultBackground(false);
        hologram.setPersistent(false);
        bukkit.setSilent(true);
        bukkit.setInvulnerable(true);
        if (bukkit instanceof LivingEntity le) {
            le.setAI(false);
            le.setCanPickupItems(false);
            le.setRemoveWhenFarAway(false);
        }
        if (batteryEnabled && batteryCharge <= 0) state = State.OUT_OF_BATTERY;
        updateName();
        startTask();
    }
    public String getKey() { return config.key(); }
    public State getState() { return state; }
    public long getCollectedSinceSpawn() { return collectedSinceSpawn; }
    public double getBatteryCharge() { return batteryCharge; }
    public double getBatteryCapacity() { return batteryCapacity; }
    public int getBatteryPercent() {
        if (batteryCapacity <= 0) return 0;
        return (int) Math.round(100.0 * batteryCharge / batteryCapacity);
    }
    /** Persiste la charge courante dans PlayerData (appelée régulièrement + à l'arrêt). */
    private void persistBattery() {
        if (!batteryEnabled) return;
        PlayerData data = plugin.core().playerData().get(owner);
        if (data != null) data.setDroneBattery(config.key(), batteryCharge);
    }
    private boolean hasBattery() {
        return !batteryEnabled || batteryCharge > 0;
    }
    private void updateName() {
        if (!entity.isValid() || hologram == null || !hologram.isValid()) return;
        String statusColor;
        String statusText;
        switch (state) {
            case IDLE -> { statusColor = "&7"; statusText = "RECHERCHE"; }
            case MOVING_TO_BOX -> { statusColor = "&e"; statusText = "CHASSE"; }
            case MOVING_TO_SELL -> { statusColor = "&a"; statusText = "TRANSPORT"; }
            case NO_TARGET -> { statusColor = "&c"; statusText = "INACTIF"; }
            case OUT_OF_BATTERY -> { statusColor = "&4"; statusText = "BATTERIE VIDE"; }
            default -> { statusColor = "&7"; statusText = "?"; }
        }
        String tierLabel = "&8[V" + tiers[0] + " R" + tiers[1] + " I" + tiers[2] + "]";
        String batteryLine = "";
        if (batteryEnabled) {
            batteryLine = "\n" + batteryColor() + "⚡ " + getBatteryPercent() + "%"
                    + (moduleSolarChargePerSec > 0 ? " &e☀" : "");
        }
        String text =
                "&6✦ " + config.name() + "\n" +
                        statusColor + statusText +
                        batteryLine + "\n" +
                        tierLabel + " &7| &b" + NumberFormatUtil.format(collectedSinceSpawn) +
                        " &7| &f" + owner.getName();
        hologram.setText(ChatUtil.color(text));
    }
    private String batteryColor() {
        int pct = getBatteryPercent();
        if (pct <= 15) return "&4";
        if (pct <= 40) return "&c";
        if (pct <= 70) return "&e";
        return "&a";
    }
    private void setState(State newState) {
        if (state != newState) {
            state = newState;
            stateTickCounter = 0;
            lastDistanceSq = Double.MAX_VALUE;
            stuckTicks = 0;
            currentVelocity = new Vector(0, 0, 0);
            updateName();
        }
    }
    private void releaseLock() {
        if (hasLock) {
            locksFor(world).remove(lastBoxKey);
            hasLock = false;
        }
        lastBoxTarget = null;
    }
    private void abortAndReset() {
        releaseLock();
        targetLocation = null;
        setState(State.IDLE);
    }
    private void startTask() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!entity.isValid() || !owner.isOnline() || !owner.isValid()) { stop(); return; }
                if (!owner.getWorld().equals(world)) { stop(); return; }
                if (hologram != null && hologram.isValid()) {
                    hologram.teleport(entity.getBukkitEntity().getLocation().clone().add(0, 2.2, 0));
                }
                tickCounter++;
                stateTickCounter++;
                // ── Recharge solaire + persistance ──
                if (batteryEnabled && tickCounter % SOLAR_TICK_INTERVAL == 0) {
                    if (moduleSolarChargePerSec > 0 && batteryCharge < batteryCapacity) {
                        batteryCharge = Math.min(batteryCapacity, batteryCharge + moduleSolarChargePerSec);
                        // Réveil si on était à plat.
                        if (state == State.OUT_OF_BATTERY && batteryCharge > 0) {
                            setState(State.IDLE);
                        }
                    }
                    persistBattery();
                }
                // ── Si plus de batterie : on fige sur OUT_OF_BATTERY ──
                if (batteryEnabled && batteryCharge <= 0) {
                    if (state != State.OUT_OF_BATTERY) {
                        releaseLock();
                        targetLocation = null;
                        setState(State.OUT_OF_BATTERY);
                    }
                    if (tickCounter % NAME_UPDATE_INTERVAL == 0) updateName();
                    return;
                }
                switch (state) {
                    case IDLE, NO_TARGET, OUT_OF_BATTERY -> {
                        if (tickCounter % FIND_TARGET_INTERVAL == 0) findNewTarget();
                    }
                    case MOVING_TO_BOX -> {
                        if (stateTickCounter > CHASE_TIMEOUT_TICKS) { abortAndReset(); return; }
                        if (targetLocation != null && tickCounter % TARGET_RECHECK_INTERVAL == 0) {
                            Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
                            if (!plugin.providers().block().isCarton(blockLoc.getBlock(), boxRef)) {
                                abortAndReset();
                                return;
                            }
                        }
                        moveTowardsTarget();
                    }
                    case MOVING_TO_SELL -> {
                        if (stateTickCounter > SELL_TIMEOUT_TICKS) {
                            sellBox();
                            releaseLock();
                            targetLocation = null;
                            setState(State.IDLE);
                            return;
                        }
                        moveTowardsTarget();
                    }
                }
                if (tickCounter % NAME_UPDATE_INTERVAL == 0) updateName();
            }
        };
        task.runTaskTimer(plugin, 0L, TASK_PERIOD);
    }
    private void findNewTarget() {
        if (!hasBattery()) { setState(State.OUT_OF_BATTERY); return; }
        Location nearestBox = findNearestBox();
        if (nearestBox != null) {
            targetLocation = nearestBox.clone().add(0.5, 0.5, 0.5);
            setState(State.MOVING_TO_BOX);
        } else {
            if (state != State.NO_TARGET) setState(State.NO_TARGET);
        }
    }
    private Location findNearestBox() {
        CartonIndex index = plugin.providers().cartonIndex();
        Location droneLoc = entity.getBukkitEntity().getLocation();
        scanX = droneLoc.getX();
        scanY = droneLoc.getY();
        scanZ = droneLoc.getZ();
        int dcy = droneLoc.getBlockY();
        scanMinY = Math.max(worldMinHeight, dcy - VERTICAL_SCAN);
        scanMaxY = Math.min(worldMaxHeight, dcy + VERTICAL_SCAN);
        bestDistSq = (double) pickupRange * pickupRange;
        bestKey = 0;
        foundAny = false;
        index.forEachInRange(world, droneLoc.getBlockX(), droneLoc.getBlockZ(),
                pickupRange, this::considerCarton);
        if (!foundAny) return null;
        int bx = CartonIndex.unpackX(bestKey);
        int by = CartonIndex.unpackY(bestKey);
        int bz = CartonIndex.unpackZ(bestKey);
        Location best = new Location(world, bx, by, bz);
        if (!plugin.providers().block().isCarton(best.getBlock(), boxRef)) {
            index.remove(world, bx, by, bz);
            return null;
        }
        locksFor(world).add(bestKey);
        lastBoxKey = bestKey;
        hasLock = true;
        lastBoxTarget = best.clone();
        return best;
    }
    private void considerCarton(long key) {
        int y = CartonIndex.unpackY(key);
        if (y < scanMinY || y > scanMaxY) return;
        if (locksFor(world).contains(key)) return;
        int x = CartonIndex.unpackX(key);
        int z = CartonIndex.unpackZ(key);
        double dxc = (x + 0.5) - scanX;
        double dyc = (y + 0.5) - scanY;
        double dzc = (z + 0.5) - scanZ;
        double distSq = dxc * dxc + dyc * dyc + dzc * dzc;
        if (distSq >= bestDistSq) return;
        bestDistSq = distSq;
        bestKey = key;
        foundAny = true;
    }
    public static void clearAllLocks() {
        lockedBoxesByWorld.clear();
    }
    public static void clearLocksForWorld(World world) {
        if (world != null) lockedBoxesByWorld.remove(world.getName());
    }
    private void moveTowardsTarget() {
        if (targetLocation == null) { setState(State.IDLE); return; }
        Entity bukkit = entity.getBukkitEntity();
        Location current = bukkit.getLocation();
        double dx = targetLocation.getX() - current.getX();
        double dy = targetLocation.getY() - current.getY();
        double dz = targetLocation.getZ() - current.getZ();
        double distSq = dx * dx + dy * dy + dz * dz;
        if (Math.abs(distSq - lastDistanceSq) < 0.0004) {
            stuckTicks++;
            if (stuckTicks > STUCK_THRESHOLD_TICKS) {
                if (stuckTicks < STUCK_BOOST_LIMIT) {
                    bukkit.teleport(current.clone().add(0, 0.4, 0));
                    currentVelocity = new Vector(0, 0, 0);
                } else {
                    abortAndReset();
                    return;
                }
            }
        } else {
            stuckTicks = 0;
        }
        lastDistanceSq = distSq;
        if (distSq < 0.49) {
            if (state == State.MOVING_TO_BOX) {
                collectBox();
                targetLocation = plugin.core().config().getSellZoneCenter(world);
                setState(State.MOVING_TO_SELL);
            } else if (state == State.MOVING_TO_SELL) {
                sellBox();
                releaseLock();
                targetLocation = null;
                setState(State.IDLE);
            }
            return;
        }
        double distance = Math.sqrt(distSq);
        double invDist = 1.0 / distance;
        double dirX = dx * invDist;
        double dirY = dy * invDist;
        double dirZ = dz * invDist;
        double step = stepPerTick;
        if (distance < 2.0) step *= Math.max(0.35, distance / 2.0);
        double desiredX = dirX * step;
        double desiredY = dirY * step;
        double desiredZ = dirZ * step;
        double smoothing = 0.35;
        double vx = currentVelocity.getX() + (desiredX - currentVelocity.getX()) * smoothing;
        double vy = currentVelocity.getY() + (desiredY - currentVelocity.getY()) * smoothing;
        double vz = currentVelocity.getZ() + (desiredZ - currentVelocity.getZ()) * smoothing;
        double velLenSq = vx * vx + vy * vy + vz * vz;
        if (velLenSq > step * step) {
            double scale = step / Math.sqrt(velLenSq);
            vx *= scale; vy *= scale; vz *= scale;
            velLenSq = step * step;
        }
        double moveLen = Math.sqrt(velLenSq);
        if (moveLen > distance && moveLen > 0) {
            double scale = distance / moveLen;
            vx *= scale; vy *= scale; vz *= scale;
        }
        currentVelocity.setX(vx);
        currentVelocity.setY(vy);
        currentVelocity.setZ(vz);
        Location newLoc = current.clone().add(vx, vy, vz);
        if (velLenSq > 0.0001) {
            float targetYaw = (float) Math.toDegrees(Math.atan2(-vx, vz));
            double vLen = Math.sqrt(velLenSq);
            float targetPitch = (float) Math.toDegrees(-Math.asin(Math.max(-1.0, Math.min(1.0, vy / vLen))));
            newLoc.setYaw(lerpAngle(current.getYaw(), targetYaw, 0.4f));
            newLoc.setPitch(lerpAngle(current.getPitch(), targetPitch, 0.4f));
        } else {
            newLoc.setYaw(current.getYaw());
            newLoc.setPitch(current.getPitch());
        }
        bukkit.teleport(newLoc);
    }
    private float lerpAngle(float from, float to, float t) {
        float diff = ((to - from) % 360 + 540) % 360 - 180;
        return from + diff * t;
    }
    private void collectBox() {
        if (targetLocation == null) return;
        Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
        if (plugin.providers().block().isCarton(blockLoc.getBlock(), boxRef)) {
            plugin.providers().block().breakCarton(blockLoc.getBlock(), boxRef);
            plugin.events().onBoxBroken(blockLoc);
            blockLoc.getWorld().playSound(blockLoc, org.bukkit.Sound.BLOCK_STONE_BREAK, 0.5f, 1.0f);
        } else {
            releaseLock();
            targetLocation = null;
            setState(State.IDLE);
        }
    }
    private void sellBox() {
        PlayerData data = plugin.core().playerData().get(owner);
        if (data == null) return;
        boolean saved = moduleSaveChance > 0
                && ThreadLocalRandom.current().nextDouble() < moduleSaveChance;
        double price = plugin.core().config().getBoxSellPrice() * incomeMultiplier;
        plugin.core().economy().credit(owner, price);
        collectedSinceSpawn++;
        data.incrementDroneCollected(config.key());
        data.addDroneEarnings(config.key(), (long) price);
        owner.getWorld().playSound(owner.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
        // ── Consommation de batterie sur la vente effective ──
        if (batteryEnabled) {
            batteryCharge = Math.max(0.0, batteryCharge - batteryDrainPerBox);
            persistBattery();
            if (batteryCharge <= 0) {
                releaseLock();
                targetLocation = null;
                setState(State.OUT_OF_BATTERY);
                if (owner.isOnline()) {
                    owner.sendActionBar(net.kyori.adventure.text.Component.text(
                            ChatUtil.color("&4⚡ &fLe drone &6" + config.name()
                                    + " &fest à court de batterie ! Recharge-le dans sa GUI.")));
                }
            }
        }
        if (saved && lastBoxTarget != null
                && lastBoxTarget.getBlock().getType().isAir()) {
            plugin.providers().block().placeCarton(lastBoxTarget, boxRef);
        }
    }
    /** Arrêt par défaut : persiste la charge courante. */
    public void stop() {
        stop(true);
    }
    /**
     * Arrête le drone.
     *
     * @param persist {@code false} pour NE PAS réécrire la batterie dans PlayerData.
     *                Indispensable lors d'un respawn faisant suite à une modification
     *                externe de la charge (ex : recharge en GUI), afin que la valeur
     *                fraîche ne soit pas écrasée par la charge basse de cette instance.
     */
    public void stop(boolean persist) {
        if (persist) persistBattery();
        if (task != null && !task.isCancelled()) task.cancel();
        if (hologram != null && hologram.isValid()) hologram.remove();
        entity.remove();
        releaseLock();
    }
}