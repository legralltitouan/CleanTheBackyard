package fr.cleanthebackyard.cleanTheBackyard.automation.entity;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.provider.CartonIndex;
import fr.cleanthebackyard.cleanTheBackyard.provider.CustomEntityHandle;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;
public class DroneEntity {
    // Verrou inter-drones par clé packée (monde implicite : chaque drone vit dans
    // un seul monde, et un carton de coordonnées identiques dans deux mondes
    // joueurs distincts ne peut être ciblé simultanément que par des drones de
    // mondes différents — collision sans conséquence car la vérif isCarton tranche).
    private static final Set<Long> lockedBoxes = ConcurrentHashMap.newKeySet();
    private static final long CHASE_TIMEOUT_TICKS = 200;
    private static final long SELL_TIMEOUT_TICKS = 200;
    private static final long TASK_PERIOD = 1L;
    private static final long NAME_UPDATE_INTERVAL = 10L;
    private static final long STUCK_THRESHOLD_TICKS = 40;
    private static final long STUCK_BOOST_LIMIT = 60;
    private static final int HARD_RANGE_CAP = 160;
    private static final int VERTICAL_SCAN = 8;
    private static final long FIND_TARGET_INTERVAL = 5L;
    private static final long TARGET_RECHECK_INTERVAL = 5L;
    private final CleanTheBackyard plugin;
    private final Player owner;
    private final PluginConfig.DroneConfig config;
    private final CustomEntityHandle entity;
    private final double speed;
    private final int pickupRange;
    private final double incomeMultiplier;
    private final BlockRef boxRef;
    private final World world;
    private final int[] tiers;
    private final double moduleCollectibleBonus;
    private final double moduleSaveChance;
    public enum State { IDLE, MOVING_TO_BOX, MOVING_TO_SELL, NO_TARGET }
    private State state = State.IDLE;
    private Location targetLocation;
    private Location lastBoxTarget;
    private long lastBoxKey = 0;
    private boolean hasLock = false;
    private BukkitRunnable task;
    private long collectedSinceSpawn = 0;
    private long tickCounter = 0;
    private long stateTickCounter = 0;
    private double lastDistance = Double.MAX_VALUE;
    private int stuckTicks = 0;
    private TextDisplay hologram;
    private Vector currentVelocity = new Vector(0, 0, 0);
    public DroneEntity(Player owner, PluginConfig.DroneConfig config) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.config = config;
        this.world = owner.getWorld();
        PlayerData data = plugin.core().playerData().get(owner);
        this.tiers = (data != null) ? data.getDroneUpgrades(config.key()) : new int[]{0, 0, 0};
        double speedBonus = 1.0 + tiers[0] * plugin.core().config().getDroneSpeedTierBonus();
        double rangeBonus = 1.0 + tiers[1] * plugin.core().config().getDroneRangeTierBonus();
        double incomeBonus = 1.0 + tiers[2] * plugin.core().config().getDroneIncomeTierBonus();
        if (data != null) incomeBonus *= plugin.progression().talent().getDroneIncomeMultiplier(data);
        double collectibleBonus = 0.0;
        double saveChance = 0.0;
        String moduleKey = data != null ? data.getDroneModule(config.key()) : null;
        if (moduleKey != null) {
            var mod = plugin.core().config().getDroneModule(moduleKey);
            if (mod != null) {
                speedBonus += mod.speedBonus();
                rangeBonus += mod.rangeBonus();
                collectibleBonus = mod.collectibleBonus();
                saveChance = mod.saveChance();
            }
        }
        this.moduleCollectibleBonus = collectibleBonus;
        this.moduleSaveChance = saveChance;
        this.speed = config.speed() * speedBonus;
        int rawRange = (int) Math.round(config.pickupRange() * rangeBonus);
        this.pickupRange = Math.min(HARD_RANGE_CAP, Math.max(1, rawRange));
        this.incomeMultiplier = incomeBonus;
        this.boxRef = plugin.core().config().getBoxBlockRef();
        Location spawnLoc = plugin.core().config().getSellZoneCenter(world).clone().add(0, 2, 0);
        this.entity = plugin.providers().entity().spawn(config.entityRef(), spawnLoc, EntityType.BEE, "drone");
        Entity bukkit = entity.getBukkitEntity();
        hologram = bukkit.getWorld().spawn(
                bukkit.getLocation().clone().add(0, 2.2, 0),
                TextDisplay.class
        );
        hologram.setBillboard(Display.Billboard.CENTER);
        hologram.setSeeThrough(true);
        hologram.setShadowed(false);
        hologram.setDefaultBackground(false);
        hologram.setPersistent(false);
        bukkit.setSilent(true);
        bukkit.setInvulnerable(true);
        if (bukkit instanceof LivingEntity le) {
            le.setAI(false);
            le.setCanPickupItems(false);
            le.setRemoveWhenFarAway(false);
        }
        updateName();
        startTask();
    }
    public String getKey() { return config.key(); }
    public State getState() { return state; }
    public long getCollectedSinceSpawn() { return collectedSinceSpawn; }
    private void updateName() {
        if (!entity.isValid() || hologram == null || !hologram.isValid()) return;
        String statusColor;
        String statusText;
        switch (state) {
            case IDLE -> { statusColor = "&7"; statusText = "RECHERCHE"; }
            case MOVING_TO_BOX -> { statusColor = "&e"; statusText = "CHASSE"; }
            case MOVING_TO_SELL -> { statusColor = "&a"; statusText = "TRANSPORT"; }
            case NO_TARGET -> { statusColor = "&c"; statusText = "INACTIF"; }
            default -> { statusColor = "&7"; statusText = "?"; }
        }
        String tierLabel = "&8[V" + tiers[0] + " R" + tiers[1] + " I" + tiers[2] + "]";
        String text =
                "&6✦ " + config.name() + "\n" +
                        statusColor + statusText + "\n" +
                        tierLabel + " &7| &b" + NumberFormatUtil.format(collectedSinceSpawn) +
                        " &7| &f" + owner.getName();
        hologram.setText(ChatUtil.color(text));
    }
    private void setState(State newState) {
        if (state != newState) {
            state = newState;
            stateTickCounter = 0;
            lastDistance = Double.MAX_VALUE;
            stuckTicks = 0;
            currentVelocity = new Vector(0, 0, 0);
            updateName();
        }
    }
    private void releaseLock() {
        if (hasLock) {
            lockedBoxes.remove(lastBoxKey);
            hasLock = false;
        }
        lastBoxTarget = null;
    }
    private void abortAndReset() {
        releaseLock();
        targetLocation = null;
        setState(State.IDLE);
    }
    private void startTask() {
        task = new BukkitRunnable() {
            @Override
            public void run() {
                if (!entity.isValid() || !owner.isOnline() || !owner.isValid()) { stop(); return; }
                if (!owner.getWorld().equals(world)) { stop(); return; }
                if (hologram != null && hologram.isValid()) {
                    hologram.teleport(entity.getBukkitEntity().getLocation().clone().add(0, 2.2, 0));
                }
                tickCounter++;
                stateTickCounter++;
                switch (state) {
                    case IDLE, NO_TARGET -> { if (tickCounter % FIND_TARGET_INTERVAL == 0) findNewTarget(); }
                    case MOVING_TO_BOX -> {
                        if (stateTickCounter > CHASE_TIMEOUT_TICKS) { abortAndReset(); return; }
                        if (targetLocation != null && tickCounter % TARGET_RECHECK_INTERVAL == 0) {
                            Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
                            if (!plugin.providers().block().isCarton(blockLoc.getBlock(), boxRef)) {
                                abortAndReset();
                                return;
                            }
                        }
                        moveTowardsTarget();
                    }
                    case MOVING_TO_SELL -> {
                        if (stateTickCounter > SELL_TIMEOUT_TICKS) {
                            sellBox();
                            releaseLock();
                            targetLocation = null;
                            setState(State.IDLE);
                            return;
                        }
                        moveTowardsTarget();
                    }
                }
                if (tickCounter % NAME_UPDATE_INTERVAL == 0) updateName();
            }
        };
        task.runTaskTimer(plugin, 0L, TASK_PERIOD);
    }
    private void findNewTarget() {
        Location nearestBox = findNearestBox();
        if (nearestBox != null) {
            targetLocation = nearestBox.clone().add(0.5, 0.5, 0.5);
            setState(State.MOVING_TO_BOX);
        } else {
            if (state != State.NO_TARGET) setState(State.NO_TARGET);
        }
    }
    /**
     * Recherche du carton le plus proche via l'index spatial.
     * Itère directement sur le Set concurrent (aucune allocation de snapshot)
     * et compare des longs packés pour le verrou (aucune String construite).
     */
    private Location findNearestBox() {
        CartonIndex index = plugin.providers().cartonIndex();
        Location droneLoc = entity.getBukkitEntity().getLocation();
        final double dx0 = droneLoc.getX();
        final double dy0 = droneLoc.getY();
        final double dz0 = droneLoc.getZ();
        final int dcx = droneLoc.getBlockX();
        final int dcz = droneLoc.getBlockZ();
        final int dcy = droneLoc.getBlockY();
        final int range = pickupRange;
        double bestDistSq = (double) range * range;
        final int minY = Math.max(world.getMinHeight(), dcy - VERTICAL_SCAN);
        final int maxY = Math.min(world.getMaxHeight(), dcy + VERTICAL_SCAN);
        long bestKey = 0;
        boolean found = false;
        for (long key : index.keys(world)) {
            int x = CartonIndex.unpackX(key);
            int dxi = x - dcx;
            if (dxi < -range || dxi > range) continue;
            int z = CartonIndex.unpackZ(key);
            int dzi = z - dcz;
            if (dzi < -range || dzi > range) continue;
            int y = CartonIndex.unpackY(key);
            if (y < minY || y > maxY) continue;
            // Carton déjà verrouillé par un autre drone : comparaison de long.
            if (lockedBoxes.contains(key)) continue;
            double dxc = (x + 0.5) - dx0;
            double dyc = (y + 0.5) - dy0;
            double dzc = (z + 0.5) - dz0;
            double distSq = dxc * dxc + dyc * dyc + dzc * dzc;
            if (distSq >= bestDistSq) continue;
            bestDistSq = distSq;
            bestKey = key;
            found = true;
        }
        if (!found) return null;
        int bx = CartonIndex.unpackX(bestKey);
        int by = CartonIndex.unpackY(bestKey);
        int bz = CartonIndex.unpackZ(bestKey);
        Location best = new Location(world, bx, by, bz);
        if (!plugin.providers().block().isCarton(best.getBlock(), boxRef)) {
            index.remove(world, bx, by, bz);
            return null;
        }
        lockedBoxes.add(bestKey);
        lastBoxKey = bestKey;
        hasLock = true;
        lastBoxTarget = best.clone();
        return best;
    }
    public static void clearAllLocks() {
        lockedBoxes.clear();
    }
    private void moveTowardsTarget() {
        if (targetLocation == null) { setState(State.IDLE); return; }
        Entity bukkit = entity.getBukkitEntity();
        Location current = bukkit.getLocation();
        double distance = current.distance(targetLocation);
        if (Math.abs(distance - lastDistance) < 0.02) {
            stuckTicks++;
            if (stuckTicks > STUCK_THRESHOLD_TICKS) {
                if (stuckTicks < STUCK_BOOST_LIMIT) {
                    bukkit.teleport(current.clone().add(0, 0.4, 0));
                    currentVelocity = new Vector(0, 0, 0);
                } else {
                    abortAndReset();
                    return;
                }
            }
        } else {
            stuckTicks = 0;
        }
        lastDistance = distance;
        if (distance < 0.7) {
            if (state == State.MOVING_TO_BOX) {
                collectBox();
                targetLocation = plugin.core().config().getSellZoneCenter(world);
                setState(State.MOVING_TO_SELL);
            } else if (state == State.MOVING_TO_SELL) {
                sellBox();
                releaseLock();
                targetLocation = null;
                setState(State.IDLE);
            }
            return;
        }
        Vector desiredDirection = targetLocation.toVector().subtract(current.toVector()).normalize();
        double stepPerTick = speed / 20.0;
        if (distance < 2.0) stepPerTick *= Math.max(0.35, distance / 2.0);
        Vector desiredVelocity = desiredDirection.multiply(stepPerTick);
        double smoothing = 0.35;
        currentVelocity.setX(currentVelocity.getX() + (desiredVelocity.getX() - currentVelocity.getX()) * smoothing);
        currentVelocity.setY(currentVelocity.getY() + (desiredVelocity.getY() - currentVelocity.getY()) * smoothing);
        currentVelocity.setZ(currentVelocity.getZ() + (desiredVelocity.getZ() - currentVelocity.getZ()) * smoothing);
        if (currentVelocity.length() > stepPerTick) {
            currentVelocity = currentVelocity.normalize().multiply(stepPerTick);
        }
        double moveLen = currentVelocity.length();
        if (moveLen > distance) currentVelocity = currentVelocity.normalize().multiply(distance);
        Location newLoc = current.clone().add(currentVelocity);
        if (currentVelocity.lengthSquared() > 0.0001) {
            float targetYaw = (float) Math.toDegrees(Math.atan2(-currentVelocity.getX(), currentVelocity.getZ()));
            float targetPitch = (float) Math.toDegrees(-Math.asin(Math.max(-1.0, Math.min(1.0, currentVelocity.getY() / Math.max(0.001, currentVelocity.length())))));
            newLoc.setYaw(lerpAngle(current.getYaw(), targetYaw, 0.4f));
            newLoc.setPitch(lerpAngle(current.getPitch(), targetPitch, 0.4f));
        } else {
            newLoc.setYaw(current.getYaw());
            newLoc.setPitch(current.getPitch());
        }
        bukkit.teleport(newLoc);
    }
    private float lerpAngle(float from, float to, float t) {
        float diff = ((to - from) % 360 + 540) % 360 - 180;
        return from + diff * t;
    }
    private void collectBox() {
        if (targetLocation == null) return;
        Location blockLoc = targetLocation.clone().subtract(0.5, 0.5, 0.5);
        if (plugin.providers().block().isCarton(blockLoc.getBlock(), boxRef)) {
            plugin.providers().block().breakCarton(blockLoc.getBlock(), boxRef);
            plugin.events().onBoxBroken(blockLoc);
            blockLoc.getWorld().playSound(blockLoc, org.bukkit.Sound.BLOCK_STONE_BREAK, 0.5f, 1.0f);
            if (moduleCollectibleBonus > 0
                    && ThreadLocalRandom.current().nextDouble() < moduleCollectibleBonus) {
                plugin.gameplay().collectible().rollDrop(owner, blockLoc);
            }
        } else {
            releaseLock();
            targetLocation = null;
            setState(State.IDLE);
        }
    }
    private void sellBox() {
        PlayerData data = plugin.core().playerData().get(owner);
        if (data == null) return;
        boolean saved = moduleSaveChance > 0
                && ThreadLocalRandom.current().nextDouble() < moduleSaveChance;
        double price = plugin.core().config().getBoxSellPrice() * incomeMultiplier;
        plugin.core().economy().credit(owner, price);
        collectedSinceSpawn++;
        data.incrementDroneCollected(config.key());
        data.addDroneEarnings(config.key(), (long) price);
        owner.getWorld().playSound(owner.getLocation(), org.bukkit.Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.5f);
        if (saved && lastBoxTarget != null
                && lastBoxTarget.getBlock().getType().isAir()) {
            plugin.providers().block().placeCarton(lastBoxTarget, boxRef);
        }
    }
    public void stop() {
        if (task != null && !task.isCancelled()) task.cancel();
        if (hologram != null && hologram.isValid()) hologram.remove();
        entity.remove();
        releaseLock();
    }
}