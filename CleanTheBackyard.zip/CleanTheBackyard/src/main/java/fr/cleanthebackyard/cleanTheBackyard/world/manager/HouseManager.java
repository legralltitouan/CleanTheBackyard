package fr.cleanthebackyard.cleanTheBackyard.world.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.mvplugins.multiverse.core.MultiverseCoreApi;
import org.mvplugins.multiverse.core.world.MultiverseWorld;
import org.mvplugins.multiverse.core.world.WorldManager;
import org.mvplugins.multiverse.core.world.options.CloneWorldOptions;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Gère la création/téléport entre le monde de jeu et la maison personnelle du joueur.
 */
public class HouseManager {

    private final CleanTheBackyard plugin;
    /** Mémorise la dernière position du joueur dans son monde de jeu avant d'entrer dans la maison. */
    private final Map<UUID, Location> lastGameLocation = new HashMap<>();

    public HouseManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private WorldManager getWorldManager() {
        try { return MultiverseCoreApi.get().getWorldManager(); }
        catch (Throwable t) {
            plugin.getLogger().severe("[CTB] MultiverseCoreApi inaccessible : " + t.getMessage());
            return null;
        }
    }

    /** Crée la maison du joueur si elle n'existe pas. Retourne true si OK. */
    public boolean ensureHouseExists(Player player) {
        UUID uuid = player.getUniqueId();
        String worldName = plugin.getPluginConfig().getHouseWorldName(uuid);

        if (Bukkit.getWorld(worldName) != null || worldFolderExists(worldName)) {
            return true;
        }

        WorldManager wm = getWorldManager();
        if (wm == null) return false;

        String templateName = plugin.getPluginConfig().getHouseTemplateName();
        MultiverseWorld template = wm.getWorld(templateName).getOrNull();
        if (template == null) {
            player.sendMessage(ChatUtil.color("&cTemplate maison &f" + templateName + " &cnon chargé."));
            return false;
        }

        player.sendMessage(ChatUtil.color("&aCréation de ta maison personnelle..."));
        var result = wm.cloneWorld(CloneWorldOptions.fromTo(template, worldName));
        if (!result.isSuccess()) {
            player.sendMessage(ChatUtil.color("&cCréation de la maison échouée."));
            plugin.getLogger().warning("[CTB] cloneWorld house failed: " + result);
            return false;
        }
        return true;
    }

    /** Téléporte le joueur dans sa maison. Crée le monde au besoin. */
    public boolean enterHouse(Player player) {
        if (!ensureHouseExists(player)) return false;

        UUID uuid = player.getUniqueId();
        String worldName = plugin.getPluginConfig().getHouseWorldName(uuid);
        World w = Bukkit.getWorld(worldName);
        if (w == null) {
            WorldManager wm = getWorldManager();
            if (wm != null && worldFolderExists(worldName)) {
                wm.loadWorld(worldName);
                w = Bukkit.getWorld(worldName);
            }
        }
        if (w == null) {
            player.sendMessage(ChatUtil.color("&cImpossible de charger ta maison."));
            return false;
        }

        // Mémorise la position actuelle si c'est le monde de jeu
        String playerWorldName = plugin.getPluginConfig().getPlayerWorldName(uuid);
        if (player.getWorld().getName().equals(playerWorldName)) {
            lastGameLocation.put(uuid, player.getLocation().clone());
        }

        Location spawn = plugin.getPluginConfig().getHouseSpawn(w);
        player.teleport(spawn != null ? spawn : w.getSpawnLocation());
        player.sendMessage(ChatUtil.color("&aBienvenue dans ta maison !"));
        return true;
    }

    /** Téléporte le joueur depuis sa maison vers son monde de jeu. */
    public boolean exitHouse(Player player) {
        UUID uuid = player.getUniqueId();
        String houseName = plugin.getPluginConfig().getHouseWorldName(uuid);
        if (!player.getWorld().getName().equals(houseName)) {
            player.sendMessage(ChatUtil.color("&cTu n'es pas dans ta maison."));
            return false;
        }

        String playerWorldName = plugin.getPluginConfig().getPlayerWorldName(uuid);
        World gameWorld = Bukkit.getWorld(playerWorldName);
        if (gameWorld == null) {
            player.sendMessage(ChatUtil.color("&cTon monde de jeu n'est pas chargé."));
            return false;
        }

        Location target = lastGameLocation.remove(uuid);
        if (target == null || !target.getWorld().getName().equals(playerWorldName)) {
            target = plugin.getPluginConfig().getPlayerWorldSpawn(gameWorld);
            if (target == null) target = gameWorld.getSpawnLocation();
        }
        player.teleport(target);
        player.sendMessage(ChatUtil.color("&aDe retour dans ton jardin !"));
        return true;
    }

    public boolean isInHouseWorld(Player player) {
        String houseName = plugin.getPluginConfig().getHouseWorldName(player.getUniqueId());
        return player.getWorld().getName().equals(houseName);
    }

    public boolean isAnyHouseWorld(World w) {
        if (w == null) return false;
        return w.getName().startsWith(plugin.getPluginConfig().getHouseWorldPrefix());
    }

    private boolean worldFolderExists(String worldName) {
        File f = new File(Bukkit.getWorldContainer(), worldName);
        return f.exists() && f.isDirectory();
    }
}
