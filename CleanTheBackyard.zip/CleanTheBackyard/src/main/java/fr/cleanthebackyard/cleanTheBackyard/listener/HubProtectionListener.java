package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;

/**
 * Protections spécifiques au monde hub ('world') :
 *   ─ interdiction de casser / poser des blocs,
 *   ─ interdiction de drop des items,
 *   ─ interdiction de ramasser des items au sol.
 *
 * Le mode Créatif/Spectateur contourne ces règles (admins).
 */
public class HubProtectionListener implements Listener {

    private final CleanTheBackyard plugin;

    public HubProtectionListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private boolean isHubWorld(World world) {
        if (world == null) return false;
        return world.getName().equals(plugin.core().config().getHubWorldName());
    }

    private boolean isBypass(Player player) {
        return player.getGameMode() == GameMode.CREATIVE
                || player.getGameMode() == GameMode.SPECTATOR;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (isBypass(event.getPlayer())) return;
        if (!isHubWorld(event.getBlock().getWorld())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (isBypass(event.getPlayer())) return;
        if (!isHubWorld(event.getBlock().getWorld())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (isBypass(event.getPlayer())) return;
        if (!isHubWorld(event.getPlayer().getWorld())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (isBypass(player)) return;
        if (!isHubWorld(player.getWorld())) return;
        event.setCancelled(true);
    }
}
