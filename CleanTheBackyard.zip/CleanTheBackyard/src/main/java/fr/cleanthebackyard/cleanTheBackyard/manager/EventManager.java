package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.data.BlockData;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class EventManager {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    // OVNI
    private boolean ufoEventActive      = false;
    private boolean ufoMultiplierActive = false;
    private final AtomicInteger ufoBoxCount = new AtomicInteger(0);
    private int ufoQuota = 0;
    private final Map<String, UfoBoxReward> ufoBoxes = new HashMap<>();
    private final List<Location> ufoBoxLocations = new ArrayList<>();
    private BukkitTask ufoTimeoutTask = null;

    // Drone Doré
    private UUID     goldenDroneEntityUUID = null;
    private int      goldenDroneReward     = 0;
    private BukkitTask goldenDroneTask     = null;
    private Player   goldenDroneTarget     = null;

    public enum UfoBoxReward { BONUS_MONEY, DOUBLE_SELL, UNLIMITED_ENERGY, BLACK_MARKET }

    // Blacklist : blocs sur lesquels on NE pose PAS de carton (même s'ils sont "solides")
    private static final Set<Material> RAIN_INVALID_GROUNDS = EnumSet.of(
            // Feuilles et clôtures (existants)
            Material.OAK_LEAVES, Material.SPRUCE_LEAVES, Material.BIRCH_LEAVES,
            Material.JUNGLE_LEAVES, Material.ACACIA_LEAVES, Material.DARK_OAK_LEAVES,
            Material.MANGROVE_LEAVES, Material.CHERRY_LEAVES, Material.AZALEA_LEAVES,
            Material.FLOWERING_AZALEA_LEAVES, Material.PALE_OAK_LEAVES,
            Material.OAK_FENCE, Material.SPRUCE_FENCE, Material.BIRCH_FENCE,
            Material.JUNGLE_FENCE, Material.ACACIA_FENCE, Material.DARK_OAK_FENCE,
            Material.MANGROVE_FENCE, Material.CHERRY_FENCE, Material.PALE_OAK_FENCE,
            Material.NETHER_BRICK_FENCE, Material.IRON_BARS,
            Material.GLASS, Material.GLASS_PANE,
            Material.WATER, Material.LAVA, Material.BUBBLE_COLUMN,
            Material.NOTE_BLOCK, // évite de poser sur un carton existant

            // === BRIQUES (tous types) ===
            // Brique classique
            Material.BRICKS,
            Material.BRICK_STAIRS,
            Material.BRICK_SLAB,
            Material.BRICK_WALL,
            // Briques de pierre
            Material.STONE_BRICKS,
            Material.STONE_BRICK_STAIRS,
            Material.STONE_BRICK_SLAB,
            Material.STONE_BRICK_WALL,
            Material.MOSSY_STONE_BRICKS,
            Material.MOSSY_STONE_BRICK_STAIRS,
            Material.MOSSY_STONE_BRICK_SLAB,
            Material.MOSSY_STONE_BRICK_WALL,
            Material.CRACKED_STONE_BRICKS,
            Material.CHISELED_STONE_BRICKS,
            // Briques du Nether
            Material.NETHER_BRICKS,
            Material.NETHER_BRICK_STAIRS,
            Material.NETHER_BRICK_SLAB,
            Material.NETHER_BRICK_WALL,
            Material.RED_NETHER_BRICKS,
            Material.RED_NETHER_BRICK_STAIRS,
            Material.RED_NETHER_BRICK_SLAB,
            Material.RED_NETHER_BRICK_WALL,
            // Briques de blackstone polies
            Material.POLISHED_BLACKSTONE_BRICKS,
            Material.POLISHED_BLACKSTONE_BRICK_STAIRS,
            Material.POLISHED_BLACKSTONE_BRICK_SLAB,
            Material.POLISHED_BLACKSTONE_BRICK_WALL,
            Material.CRACKED_POLISHED_BLACKSTONE_BRICKS,
            Material.CHISELED_POLISHED_BLACKSTONE,
            // Briques de terre (Mud)
            Material.MUD_BRICKS,
            Material.MUD_BRICK_STAIRS,
            Material.MUD_BRICK_SLAB,
            Material.MUD_BRICK_WALL,

            // === BOIS ÉCORCÉ (stripped logs) ===
            Material.STRIPPED_OAK_LOG,
            Material.STRIPPED_SPRUCE_LOG,
            Material.STRIPPED_BIRCH_LOG,
            Material.STRIPPED_JUNGLE_LOG,
            Material.STRIPPED_ACACIA_LOG,
            Material.STRIPPED_DARK_OAK_LOG,
            Material.STRIPPED_MANGROVE_LOG,
            Material.STRIPPED_CHERRY_LOG,
            Material.STRIPPED_PALE_OAK_LOG,
            // Variantes "wood" (sans les cernes)
            Material.STRIPPED_OAK_WOOD,
            Material.STRIPPED_SPRUCE_WOOD,
            Material.STRIPPED_BIRCH_WOOD,
            Material.STRIPPED_JUNGLE_WOOD,
            Material.STRIPPED_ACACIA_WOOD,
            Material.STRIPPED_DARK_OAK_WOOD,
            Material.STRIPPED_MANGROVE_WOOD,
            Material.STRIPPED_CHERRY_WOOD,
            Material.STRIPPED_PALE_OAK_WOOD,

            // === DIORITE POLIE ===
            Material.POLISHED_DIORITE,
            Material.POLISHED_DIORITE_STAIRS,
            Material.POLISHED_DIORITE_SLAB,

            // === RUCHES ===
            Material.BEEHIVE,
            Material.BEE_NEST,

            // === Barrière Invisible ===
            Material.BARRIER,


            Material.BEDROCK,
            Material.SMOOTH_STONE
    );

    public void triggerBoxRainNow() { triggerBoxRain(); }
    public void triggerBlackMarketNow() { triggerBlackMarket(); }

    public EventManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private List<Player> getAllCtbPlayers() {
        String hub = plugin.getPluginConfig().getHubWorldName();
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            World w = p.getWorld();
            if (w.getName().equals(hub)) continue;
            if (w.getName().startsWith(prefix)) list.add(p);
        }
        return list;
    }

    private boolean isInOwnWorld(Player p) {
        String expected = plugin.getPluginConfig().getPlayerWorldName(p.getUniqueId());
        return p.getWorld().getName().equals(expected);
    }

    // ── PLANIFICATIONS ────────────────────────────────────────────────
    public void scheduleNextUfoEvent() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getUfoMin() + random.nextInt(Math.max(1, cfg.getUfoMax() - cfg.getUfoMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::startUfoEvent, delay * 20L);
    }

    public void scheduleNextGoldenDrone() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getGoldenDroneMin()
                + random.nextInt(Math.max(1, cfg.getGoldenDroneMax() - cfg.getGoldenDroneMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::spawnGoldenDrone, delay * 20L);
    }

    public void scheduleNextBoxRain() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getBoxRainMin()
                + random.nextInt(Math.max(1, cfg.getBoxRainMax() - cfg.getBoxRainMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::triggerBoxRain, delay * 20L);
        plugin.getLogger().info("[CTB] Prochaine pluie de cartons dans " + delay + "s.");
    }

    public void scheduleNextBlackMarket() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getBlackMarketMin()
                + random.nextInt(Math.max(1, cfg.getBlackMarketMax() - cfg.getBlackMarketMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::triggerBlackMarket, delay * 20L);
    }

    // ── PLUIE DE CARTONS (refonte) ────────────────────────────────────

    /**
     * Détermine si un bloc est un sol acceptable pour poser un carton dessus.
     * On accepte tout bloc plein/solide qui n'est pas explicitement blacklisté.
     */
    private boolean isValidGround(Block block) {
        Material mat = block.getType();
        if (mat.isAir()) return false;
        if (RAIN_INVALID_GROUNDS.contains(mat)) return false;
        // Évite les fluides, plantes, items posés au sol, etc.
        if (!mat.isSolid()) return false;
        return true;
    }

    /**
     * Cherche le premier sol valide en partant du haut du monde et en descendant.
     * Retourne la location du bloc SOLIDE (pas celle de l'air au-dessus).
     */
    private Location findGroundLocation(World w, int x, int z, int referenceY) {
        int maxY = Math.min(w.getMaxHeight() - 1, referenceY + 30);
        int minY = Math.max(w.getMinHeight() + 1, referenceY - 30);

        // On descend depuis le haut
        for (int y = maxY; y >= minY; y--) {
            Block ground = w.getBlockAt(x, y, z);
            if (isValidGround(ground)) {
                // Vérifie qu'il y a au moins 1 bloc d'air au-dessus pour poser
                Block above = w.getBlockAt(x, y + 1, z);
                if (above.getType().isAir()) {
                    return ground.getLocation();
                }
            }
        }
        return null;
    }

    private void triggerBoxRain() {
        List<Player> targets = getAllCtbPlayers();
        if (targets.isEmpty()) {
            plugin.getLogger().info("[CTB] BoxRain : aucun joueur CTB en ligne.");
            scheduleNextBoxRain();
            return;
        }

        Material boxMat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        if (boxMat == null) boxMat = Material.NOTE_BLOCK;
        final Material finalMat = boxMat;
        final BlockData fallingData = Bukkit.createBlockData(finalMat);

        List<Player> participants = new ArrayList<>();
        for (Player p : targets) {
            if (!isInOwnWorld(p)) {
                plugin.getLogger().info("[CTB] BoxRain : " + p.getName() + " skipped (pas dans son monde).");
                continue;
            }
            participants.add(p);
            p.sendMessage(ChatUtil.color("&3[PLUIE DE CARTONS] &fDes cartons tombent du ciel pendant 30 secondes autour de toi !"));
            p.playSound(p.getLocation(), Sound.WEATHER_RAIN, 1.0f, 1.0f);
        }

        if (participants.isEmpty()) {
            plugin.getLogger().warning("[CTB] BoxRain : aucun participant éligible (joueurs pas dans leur monde).");
            scheduleNextBoxRain();
            return;
        }

        plugin.getLogger().info("[CTB] BoxRain démarré pour " + participants.size() + " joueur(s).");

        BukkitTask rainTask = new BukkitRunnable() {
            int iteration = 0;
            final int MAX_ITERATIONS = 30;
            final int BOXES_PER_ITERATION_PER_PLAYER = 4;
            final int RADIUS = 12;
            int totalPlaced = 0;
            int totalAttempts = 0;
            // Échantillonnage pour debug : on log le matériau rencontré la 1re fois
            final Map<Material, Integer> rejectedMaterials = new HashMap<>();

            @Override
            public void run() {
                if (iteration >= MAX_ITERATIONS) {
                    plugin.getLogger().info("[CTB] BoxRain terminé. Total placé : "
                            + totalPlaced + " / " + totalAttempts + " tentatives.");
                    if (totalPlaced == 0 && !rejectedMaterials.isEmpty()) {
                        StringBuilder sb = new StringBuilder("[CTB] BoxRain : matériaux rejetés rencontrés : ");
                        rejectedMaterials.forEach((m, n) -> sb.append(m.name()).append("x").append(n).append(" "));
                        plugin.getLogger().warning(sb.toString());
                    }
                    cancel();
                    return;
                }
                iteration++;

                for (Player p : participants) {
                    if (!p.isOnline() || !isInOwnWorld(p)) continue;
                    World w = p.getWorld();
                    Location center = p.getLocation();

                    int placed = 0;
                    int attempts = 0;
                    while (placed < BOXES_PER_ITERATION_PER_PLAYER && attempts < 30) {
                        attempts++;
                        totalAttempts++;

                        double angle = random.nextDouble() * Math.PI * 2;
                        double dist  = 3 + random.nextDouble() * RADIUS;
                        int x = (int) Math.round(center.getX() + Math.cos(angle) * dist);
                        int z = (int) Math.round(center.getZ() + Math.sin(angle) * dist);

                        Location groundLoc = findGroundLocation(w, x, z, center.getBlockY());
                        if (groundLoc == null) {
                            // Pour debug : on note le matériau de la colonne
                            Block probe = w.getBlockAt(x, center.getBlockY(), z);
                            rejectedMaterials.merge(probe.getType(), 1, Integer::sum);
                            continue;
                        }

                        Location placeLoc = groundLoc.clone().add(0, 1, 0);

                        // Pose immédiate du bloc (garantit le succès)
                        placeLoc.getBlock().setType(finalMat, false);

                        // Effet visuel : FallingBlock fantôme qui tombe puis disparaît
                        Location visualSpawn = placeLoc.clone().add(0.5, 10, 0.5);
                        try {
                            FallingBlock fb = w.spawnFallingBlock(visualSpawn, fallingData);
                            fb.setDropItem(false);
                            fb.setHurtEntities(false);
                            fb.setCancelDrop(true);
                            fb.setVelocity(new Vector(0, -0.05, 0));
                            w.playSound(placeLoc, Sound.ENTITY_CHICKEN_EGG, 0.3f, 1.5f);
                            w.spawnParticle(Particle.CLOUD, visualSpawn, 5, 0.2, 0, 0.2, 0.01);
                        } catch (Throwable t) {
                            plugin.getLogger().warning("[CTB] BoxRain : FallingBlock spawn failed : " + t.getMessage());
                        }

                        placed++;
                        totalPlaced++;
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);

        plugin.getLogger().info("[CTB] BoxRain task scheduled (id=" + rainTask.getTaskId() + ")");
        scheduleNextBoxRain();
    }

    // ── MARCHÉ NOIR ───────────────────────────────────────────────────
    private void triggerBlackMarket() {
        List<Player> targets = getAllCtbPlayers();
        if (targets.isEmpty()) {
            scheduleNextBlackMarket();
            return;
        }
        for (Player p : targets) {
            PlayerData d = plugin.getPlayerDataManager().get(p);
            if (d != null) {
                d.setBlackMarket(60);
                p.sendMessage(ChatUtil.color("&8[MARCHÉ NOIR] &5Vente x3 pendant 60 secondes !"));
                p.playSound(p.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 0.7f, 1.5f);
                if (isInOwnWorld(p)) {
                    p.getWorld().spawnParticle(Particle.WITCH, p.getLocation().add(0, 2, 0), 30, 1, 1, 1, 0.1);
                }
            }
        }
        scheduleNextBlackMarket();
    }

    // ── OVNI ──────────────────────────────────────────────────────────
    private void startUfoEvent() {
        List<Player> ctbPlayers = getAllCtbPlayers();
        if (ctbPlayers.isEmpty()) {
            scheduleNextUfoEvent();
            return;
        }
        ufoEventActive = true;
        ufoBoxCount.set(0);
        ufoQuota = Math.max(1, ctbPlayers.size()) * 10;
        spawnUfoBoxes(ctbPlayers);

        Title title = Title.title(
                Component.text(ChatUtil.color("&5ALERTE OVNI !")),
                Component.text(ChatUtil.color("&dDes caisses spéciales sont apparues !")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(5), Duration.ofMillis(1000))
        );
        String msg = ChatUtil.color("&5[ALERTE] &dUn OVNI ! Détruisez &f" + ufoQuota + " &dcartons pour activer le &fx2 vente &dglobal !");
        for (Player p : ctbPlayers) {
            p.sendMessage(msg);
            p.showTitle(title);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.5f);
        }

        new BukkitRunnable() {
            @Override public void run() { if (ufoEventActive) endUfoEvent(false); }
        }.runTaskLater(plugin, 20L * 600);

        scheduleUfoBoxTimeout();
    }

    private void scheduleUfoBoxTimeout() {
        if (ufoTimeoutTask != null) ufoTimeoutTask.cancel();
        ufoTimeoutTask = new BukkitRunnable() {
            @Override public void run() {
                if (!ufoEventActive) return;
                List<Location> toRemove = new ArrayList<>();
                for (Location loc : ufoBoxLocations) {
                    if (loc.getBlock().getType() == Material.GLOWSTONE) {
                        loc.getBlock().setType(Material.AIR, false);
                        toRemove.add(loc);
                    }
                }
                toRemove.forEach(loc -> ufoBoxes.remove(LocationUtil.locKey(loc)));
                ufoBoxLocations.removeAll(toRemove);
                endUfoEvent(false);
            }
        }.runTaskLater(plugin, 20L * 30);
    }

    private void spawnUfoBoxes(List<Player> ctbPlayers) {
        ufoBoxes.clear();
        ufoBoxLocations.clear();
        if (ctbPlayers.isEmpty()) return;

        UfoBoxReward[] rewards = UfoBoxReward.values();
        for (Player target : ctbPlayers) {
            if (!isInOwnWorld(target)) continue;
            for (int i = 0; i < 5; i++) {
                Location base = target.getLocation();
                double angle = random.nextDouble() * Math.PI * 2;
                double dist  = 8 + random.nextInt(8);
                Location spawnLoc = base.clone().add(
                        Math.cos(angle) * dist, 0, Math.sin(angle) * dist
                );
                spawnLoc.setY(spawnLoc.getWorld().getHighestBlockYAt(spawnLoc));
                if (spawnLoc.getBlock().getType() != Material.AIR) spawnLoc.add(0, 1, 0);
                UfoBoxReward reward = rewards[random.nextInt(rewards.length)];
                spawnLoc.getBlock().setType(Material.GLOWSTONE, false);
                ufoBoxes.put(LocationUtil.locKey(spawnLoc), reward);
                ufoBoxLocations.add(spawnLoc.clone());
            }
        }
    }

    // ── Récompenses OVNI rééquilibrées ────────────────────────────────
    public boolean tryClaimUfoBox(Player player, Location loc) {
        String key = LocationUtil.locKey(loc);
        UfoBoxReward reward = ufoBoxes.remove(key);
        if (reward == null) return false;

        ufoBoxLocations.removeIf(l -> LocationUtil.locKey(l).equals(key));
        loc.getBlock().setType(Material.AIR, false);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        int avgLevel = Math.max(1, (data.getBagLevel() + data.getToolLevel() + data.getEnergyLevel()) / 3);

        switch (reward) {
            case BONUS_MONEY -> {
                int bonus = 20 + avgLevel * 15 + random.nextInt(Math.max(1, avgLevel * 10));
                plugin.getEconomyManager().credit(player, bonus);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &fCaisse mystérieuse ! &a+$" + bonus));
            }
            case DOUBLE_SELL -> {
                int duration = Math.min(60, 10 + avgLevel * 2);
                data.setDoubleSell(duration);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &ex2 VENTE perso pendant &f" + duration + "s"));
            }
            case UNLIMITED_ENERGY -> {
                int duration = Math.min(60, 15 + avgLevel * 3);
                data.setUnlimitedEnergy(duration);
                plugin.getBoxManager().removeFatigue(player, data);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &bÉnergie illimitée pendant &f" + duration + "s"));
            }
            case BLACK_MARKET -> {
                int duration = Math.min(30, 10 + avgLevel);
                data.setBlackMarket(duration);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &5Marché noir x3 pendant &f" + duration + "s"));
            }
        }
        return true;
    }

    public boolean isUfoBox(Location loc) { return ufoBoxes.containsKey(LocationUtil.locKey(loc)); }

    public void onBoxBroken(Location loc) {
        if (!ufoEventActive) return;
        int count = ufoBoxCount.incrementAndGet();
        if (count % 50 == 0) {
            getAllCtbPlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&d[OVNI] &f" + count + " / " + ufoQuota))
            );
        }
        if (count >= ufoQuota) endUfoEvent(true);
    }

    private void endUfoEvent(boolean success, boolean skipNextSchedule) {
        ufoEventActive = false;
        if (ufoTimeoutTask != null) { ufoTimeoutTask.cancel(); ufoTimeoutTask = null; }
        ufoBoxLocations.forEach(l -> {
            if (l.getBlock().getType() == Material.GLOWSTONE) l.getBlock().setType(Material.AIR, false);
        });
        ufoBoxes.clear();
        ufoBoxLocations.clear();

        if (success) activateSellMultiplier();
        if (!skipNextSchedule) scheduleNextUfoEvent();
    }

    private void endUfoEvent(boolean success) { endUfoEvent(success, false); }

    private void activateSellMultiplier() {
        ufoMultiplierActive = true;
        plugin.getPluginConfig().setGlobalSellMultiplier(2.0);
        final int DURATION = 3600;
        getAllCtbPlayers().forEach(p -> {
            p.sendMessage(ChatUtil.colored("&6[SUCCÈS] &ex2 GLOBAL pendant &f1 heure &e!"));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        });
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getPluginConfig().setGlobalSellMultiplier(1.0);
            ufoMultiplierActive = false;
        }, DURATION * 20L);
    }

    // ── DRONE DORÉ ────────────────────────────────────────────────────
    public void spawnGoldenDrone() {
        if (goldenDroneEntityUUID != null) return;
        List<Player> ctbPlayers = getAllCtbPlayers();
        if (ctbPlayers.isEmpty()) { scheduleNextGoldenDrone(); return; }

        goldenDroneTarget = ctbPlayers.get(random.nextInt(ctbPlayers.size()));
        if (!isInOwnWorld(goldenDroneTarget)) {
            scheduleNextGoldenDrone();
            return;
        }
        PlayerData targetData = plugin.getPlayerDataManager().get(goldenDroneTarget);
        goldenDroneReward = calculateDroneReward(targetData);

        Location spawnLoc = goldenDroneTarget.getLocation().clone().add(
                (random.nextDouble() - 0.5) * 6,
                4 + random.nextDouble() * 2,
                (random.nextDouble() - 0.5) * 6
        );

        Bat drone = (Bat) spawnLoc.getWorld().spawnEntity(spawnLoc, EntityType.BAT);
        drone.setCustomName(ChatUtil.color("&6✦ Drone Doré [$" + goldenDroneReward + "] ✦"));
        drone.setCustomNameVisible(true);
        drone.setRemoveWhenFarAway(false);
        drone.setAware(false);
        goldenDroneEntityUUID = drone.getUniqueId();

        double angle = random.nextDouble() * Math.PI * 2;
        drone.setVelocity(new Vector(Math.cos(angle) * 0.15, 0.05, Math.sin(angle) * 0.15));

        goldenDroneTarget.sendMessage(ChatUtil.color(
                "&6[DRONE DORÉ] &eDrone Doré apparu ! Frappe-le en moins de &f30s &epour &f$" + goldenDroneReward
        ));
        goldenDroneTarget.playSound(goldenDroneTarget.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.5f);

        final UUID droneUUID = goldenDroneEntityUUID;
        goldenDroneTask = new BukkitRunnable() {
            int ticks = 0;
            final double baseSpeed = 0.15;
            @Override public void run() {
                ticks += 2;
                Entity entity = Bukkit.getEntity(droneUUID);
                if (entity == null || !entity.isValid()) { expireGoldenDrone(false); cancel(); return; }
                if (ticks >= 600) { expireGoldenDrone(true); entity.remove(); cancel(); return; }
                Vector vel = entity.getVelocity();
                double hSpeed = Math.sqrt(vel.getX()*vel.getX() + vel.getZ()*vel.getZ());
                if (hSpeed < baseSpeed * 0.8) {
                    double a = Math.atan2(vel.getZ(), vel.getX());
                    entity.setVelocity(new Vector(Math.cos(a) * baseSpeed, vel.getY(), Math.sin(a) * baseSpeed));
                }
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }

    private int calculateDroneReward(PlayerData data) {
        if (data == null) return 500 + random.nextInt(500);
        int baseReward = 500 + random.nextInt(500);
        baseReward += data.getBagLevel() * 100;
        baseReward += data.getToolLevel() * 75;
        baseReward += data.getEnergyLevel() * 50;
        baseReward *= (1 + data.getPrestigeLevel() / 2);
        return baseReward;
    }

    private void expireGoldenDrone(boolean timeout) {
        Player target = goldenDroneTarget;
        goldenDroneEntityUUID = null;
        goldenDroneReward = 0;
        goldenDroneTarget = null;
        if (goldenDroneTask != null) { goldenDroneTask.cancel(); goldenDroneTask = null; }
        if (timeout && target != null && target.isOnline()) {
            target.sendMessage(ChatUtil.colored("&7[Drone Doré] Trop tard..."));
        }
        scheduleNextGoldenDrone();
    }

    public boolean claimGoldenDrone(Player player, UUID entityUUID) {
        if (goldenDroneEntityUUID == null || !goldenDroneEntityUUID.equals(entityUUID)) return false;
        int reward = goldenDroneReward;
        goldenDroneEntityUUID = null;
        goldenDroneReward = 0;
        goldenDroneTarget = null;
        if (goldenDroneTask != null) { goldenDroneTask.cancel(); goldenDroneTask = null; }
        Entity drone = Bukkit.getEntity(entityUUID);
        if (drone != null) drone.remove();
        plugin.getEconomyManager().credit(player, reward);
        player.sendMessage(ChatUtil.colored("&6✦ Drone Doré abattu ! +$" + reward + " ✦"));
        scheduleNextGoldenDrone();
        return true;
    }

    public boolean isUfoEventActive()      { return ufoEventActive; }
    public boolean isUfoMultiplierActive() { return ufoMultiplierActive; }
    public boolean isGoldenDroneSpawned()  { return goldenDroneEntityUUID != null; }
    public int     getUfoBoxCount()        { return ufoBoxCount.get(); }
    public int     getUfoQuota()           { return ufoQuota; }

    public void forceStartUfoEvent() {
        if (ufoEventActive) endUfoEvent(false, true);
        startUfoEvent();
    }
}
