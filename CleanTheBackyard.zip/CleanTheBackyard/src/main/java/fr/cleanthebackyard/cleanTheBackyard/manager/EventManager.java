package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class EventManager {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    // ── OVNI ──────────────────────────────────────────────────────────
    private boolean ufoEventActive      = false;
    private boolean ufoMultiplierActive = false;
    private final AtomicInteger ufoBoxCount = new AtomicInteger(0);
    private int ufoQuota = 0;

    // Boites spéciales OVNI : location -> type de récompense
    public enum UfoBoxReward { BONUS_MONEY, DOUBLE_SELL, UNLIMITED_ENERGY }
    private final Map<String, UfoBoxReward> ufoBoxes = new HashMap<>();
    private final List<Location> ufoBoxLocations = new ArrayList<>();

    // ── Drone Doré ────────────────────────────────────────────────────
    private UUID     goldenDroneEntityUUID = null;
    private int      goldenDroneReward     = 0;
    private BukkitTask goldenDroneTask     = null;

    public EventManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    // ── PLANIFICATION ─────────────────────────────────────────────────

    public void scheduleNextUfoEvent() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delaySeconds = cfg.getUfoMin() + random.nextInt(cfg.getUfoMax() - cfg.getUfoMin());
        Bukkit.getScheduler().runTaskLater(plugin, this::startUfoEvent, delaySeconds * 20L);
        plugin.getLogger().info("[CTB] Prochain événement OVNI dans " + delaySeconds + "s.");
    }

    public void scheduleNextGoldenDrone() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delaySeconds = cfg.getGoldenDroneMin()
                + random.nextInt(cfg.getGoldenDroneMax() - cfg.getGoldenDroneMin());
        Bukkit.getScheduler().runTaskLater(plugin, this::spawnGoldenDrone, delaySeconds * 20L);
        plugin.getLogger().info("[CTB] Prochain Drone Doré dans " + delaySeconds + "s.");
    }

    // ── OVNI ──────────────────────────────────────────────────────────

    private void startUfoEvent() {
        ufoEventActive = true;
        ufoBoxCount.set(0);
        ufoQuota = plugin.getPluginConfig().getUfoEventQuota();

        spawnUfoBoxes();

        String msg = ChatUtil.color("&5[ALERTE] &dUn OVNI survole le jardin ! "
                + "Des &fcaisses mystérieuses &dont atterri ! "
                + "Détruisez &f" + ufoQuota + " &dcartons en équipe pour activer le &fx2 &dde vente !");

        Title title = Title.title(
                Component.text(ChatUtil.color("&5ALERTE OVNI !")),
                Component.text(ChatUtil.color("&dDes caisses spéciales sont apparues !")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(5), Duration.ofMillis(1000))
        );

        for (var player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(msg);
            player.showTitle(title);
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.5f);
        }

        // Fin automatique après 10 minutes
        new BukkitRunnable() {
            @Override public void run() {
                if (ufoEventActive) endUfoEvent(false);
            }
        }.runTaskLater(plugin, 20L * 600);
    }

    private void spawnUfoBoxes() {
        ufoBoxes.clear();
        ufoBoxLocations.clear();

        World world = plugin.getPluginConfig().getGameWorld();
        if (world == null || world.getPlayers().isEmpty()) return;

        // Spawn 5 caisses spéciales autour de joueurs aléatoires
        List<Player> players = new ArrayList<>(world.getPlayers());
        UfoBoxReward[] rewards = UfoBoxReward.values();

        for (int i = 0; i < 5; i++) {
            Player target = players.get(random.nextInt(players.size()));
            Location base = target.getLocation();

            // Offset aléatoire dans un rayon de 8-15 blocs, même Y
            double angle = random.nextDouble() * Math.PI * 2;
            double dist  = 8 + random.nextInt(8);
            Location spawnLoc = base.clone().add(
                    Math.cos(angle) * dist,
                    0,
                    Math.sin(angle) * dist
            );
            spawnLoc.setY(spawnLoc.getWorld().getHighestBlockYAt(spawnLoc));

            // Évite de placer sur un bloc NOTE_BLOCK existant
            if (spawnLoc.getBlock().getType() != Material.AIR) {
                spawnLoc.add(0, 1, 0);
            }

            UfoBoxReward reward = rewards[random.nextInt(rewards.length)];
            spawnLoc.getBlock().setType(Material.GLOWSTONE, false);

            String key = locKey(spawnLoc);
            ufoBoxes.put(key, reward);
            ufoBoxLocations.add(spawnLoc.clone());
        }

        Bukkit.getOnlinePlayers().forEach(p ->
                p.sendMessage(ChatUtil.colored("&d[OVNI] &fDes caisses &6mystérieuses &fbrillantes ont atterri dans le jardin !"))
        );
    }

    /**
     * Appelé quand un joueur collecte une caisse OVNI spéciale.
     * @return true si c'était bien une caisse OVNI
     */
    public boolean tryClaimUfoBox(Player player, Location loc) {
        String key = locKey(loc);
        UfoBoxReward reward = ufoBoxes.remove(key);
        if (reward == null) return false;

        ufoBoxLocations.removeIf(l -> locKey(l).equals(key));
        loc.getBlock().setType(Material.AIR, false);

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        switch (reward) {
            case BONUS_MONEY -> {
                int bonus = 500 + random.nextInt(1500); // 500-2000$
                plugin.getEconomyManager().credit(player, bonus);
                player.sendMessage(ChatUtil.colored(
                        "&6[OVNI] &fCaisse mystérieuse ! Vous avez trouvé &a+$" + bonus + " &fdedans !"
                ));
                Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals(player)).forEach(p ->
                        p.sendMessage(ChatUtil.colored("&6[OVNI] &f" + player.getName() + " a trouvé de l'argent dans une caisse OVNI !"))
                );
            }
            case DOUBLE_SELL -> {
                data.setDoubleSell(180); // 3 minutes
                player.sendMessage(ChatUtil.colored(
                        "&6[OVNI] &fCaisse mystérieuse ! &ex2 VENTE &fpersonnel pendant &f3 minutes &f!"
                ));
                Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals(player)).forEach(p ->
                        p.sendMessage(ChatUtil.colored("&6[OVNI] &f" + player.getName() + " a obtenu un &ex2 vente personnel &fpendant 3 min !"))
                );
            }
            case UNLIMITED_ENERGY -> {
                data.setUnlimitedEnergy(300); // 5 minutes
                plugin.getBoxManager().removeFatigue(player, data);
                player.sendMessage(ChatUtil.colored(
                        "&6[OVNI] &fCaisse mystérieuse ! &bÉNERGIE ILLIMITÉE &fpendant &f5 minutes &f!"
                ));
                Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals(player)).forEach(p ->
                        p.sendMessage(ChatUtil.colored("&6[OVNI] &f" + player.getName() + " a obtenu de l'&bénergie illimitée &fpendant 5 min !"))
                );
            }
        }
        return true;
    }

    public boolean isUfoBox(Location loc) {
        return ufoBoxes.containsKey(locKey(loc));
    }

    public void onBoxBroken(Location loc) {
        if (!ufoEventActive) return;

        int count = ufoBoxCount.incrementAndGet();
        if (count % 50 == 0) {
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&d[OVNI] &f" + count + " / " + ufoQuota + " cartons détruits !"))
            );
        }
        if (count >= ufoQuota) endUfoEvent(true);
    }

    private void endUfoEvent(boolean success) {
        ufoEventActive = false;
        // Nettoie les boites OVNI restantes
        ufoBoxLocations.forEach(l -> {
            if (l.getBlock().getType() == Material.GLOWSTONE) l.getBlock().setType(Material.AIR, false);
        });
        ufoBoxes.clear();
        ufoBoxLocations.clear();

        if (success) {
            activateSellMultiplier();
        } else {
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&c[OVNI] Objectif non atteint ! "
                            + ufoBoxCount.get() + "/" + ufoQuota + " cartons."))
            );
        }
        scheduleNextUfoEvent();
    }

    private void activateSellMultiplier() {
        ufoMultiplierActive = true;
        plugin.getPluginConfig().setGlobalSellMultiplier(2.0);

        Bukkit.getOnlinePlayers().forEach(p -> {
            p.sendMessage(ChatUtil.colored("&6[SUCCÈS] &ex2 bonus de vente global pendant "
                    + plugin.getPluginConfig().getUfoMultiplierDuration() + "s !"));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        });

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getPluginConfig().setGlobalSellMultiplier(1.0);
            ufoMultiplierActive = false;
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&7[Bonus] Le multiplicateur x2 global est expiré."))
            );
        }, plugin.getPluginConfig().getUfoMultiplierDuration() * 20L);
    }

    // ── DRONE DORÉ ────────────────────────────────────────────────────

    public void spawnGoldenDrone() {
        if (goldenDroneEntityUUID != null) return; // déjà actif

        Collection<? extends Player> online = Bukkit.getOnlinePlayers();
        if (online.isEmpty()) {
            scheduleNextGoldenDrone();
            return;
        }

        // Cible un joueur aléatoire
        Player target = online.stream()
                .skip(random.nextInt(online.size()))
                .findFirst().orElse(null);
        if (target == null) { scheduleNextGoldenDrone(); return; }

        PluginConfig cfg = plugin.getPluginConfig();
        goldenDroneReward = cfg.getGoldenDroneRewardMin()
                + random.nextInt(cfg.getGoldenDroneRewardMax() - cfg.getGoldenDroneRewardMin());

        // Spawn à 4-6 blocs au-dessus du joueur, légèrement décalé
        Location spawnLoc = target.getLocation().clone().add(
                (random.nextDouble() - 0.5) * 6,
                4 + random.nextInt(3), // hauteur 4-6 : frappable depuis le sol
                (random.nextDouble() - 0.5) * 6
        );

        Bat drone = (Bat) spawnLoc.getWorld().spawnEntity(spawnLoc, EntityType.BAT);
        drone.setCustomName(ChatUtil.color("&6✦ Drone Doré [$" + goldenDroneReward + "] ✦"));
        drone.setCustomNameVisible(true);
        drone.setRemoveWhenFarAway(false);
        drone.setAware(false); // NoAI pour contrôle manuel

        // Vitesse linéaire aléatoire
        double angle = random.nextDouble() * Math.PI * 2;
        double speed = 0.12;
        drone.setVelocity(new Vector(Math.cos(angle) * speed, 0, Math.sin(angle) * speed));

        goldenDroneEntityUUID = drone.getUniqueId();

        String msg = ChatUtil.color("&6[DRONE DORÉ] &eUn Drone Doré est apparu près de &f"
                + target.getName() + " &e! Frappez-le en moins de &f30s &epour gagner &f$" + goldenDroneReward + " &e!");
        Bukkit.getOnlinePlayers().forEach(p -> {
            p.sendMessage(msg);
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.5f);
        });

        // Mouvement continu + timer 30s
        final UUID droneUUID = goldenDroneEntityUUID;
        goldenDroneTask = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                ticks += 4; // appelé toutes les 4 ticks
                Entity entity = Bukkit.getEntity(droneUUID);

                if (entity == null || !entity.isValid()) {
                    expireGoldenDrone(false);
                    cancel();
                    return;
                }

                if (ticks >= 600) { // 30 secondes (600 ticks)
                    expireGoldenDrone(true);
                    entity.remove();
                    cancel();
                    return;
                }

                // Maintient la vitesse linéaire (les entités ralentissent avec la friction)
                Vector vel = entity.getVelocity();
                double hSpeed = Math.sqrt(vel.getX() * vel.getX() + vel.getZ() * vel.getZ());
                if (hSpeed < 0.08) {
                    double norm = speed / Math.max(hSpeed, 0.01);
                    entity.setVelocity(new Vector(vel.getX() * norm, 0, vel.getZ() * norm));
                }
            }
        }.runTaskTimer(plugin, 4L, 4L);
    }

    private void expireGoldenDrone(boolean timeout) {
        goldenDroneEntityUUID = null;
        goldenDroneReward     = 0;
        if (goldenDroneTask != null) { goldenDroneTask.cancel(); goldenDroneTask = null; }

        if (timeout) {
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&7[Drone Doré] Personne n'a attrapé le drone à temps..."))
            );
        }
        scheduleNextGoldenDrone();
    }

    /**
     * Appelé par GoldenDroneListener quand le drone est frappé.
     */
    public boolean claimGoldenDrone(Player player, UUID entityUUID) {
        if (goldenDroneEntityUUID == null || !goldenDroneEntityUUID.equals(entityUUID)) return false;

        int reward = goldenDroneReward;
        goldenDroneEntityUUID = null;
        goldenDroneReward     = 0;
        if (goldenDroneTask != null) { goldenDroneTask.cancel(); goldenDroneTask = null; }

        Entity drone = Bukkit.getEntity(entityUUID);
        if (drone != null) drone.remove();

        plugin.getEconomyManager().credit(player, reward);
        player.sendMessage(ChatUtil.colored("&6✦ Vous avez abattu le Drone Doré ! +$" + reward + " ✦"));
        Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals(player)).forEach(p ->
                p.sendMessage(ChatUtil.colored("&6[Drone Doré] &f" + player.getName()
                        + " &6a remporté &f$" + reward + " &6en abattant le Drone Doré !"))
        );

        scheduleNextGoldenDrone();
        return true;
    }

    // ── Getters ───────────────────────────────────────────────────────

    public boolean isUfoEventActive()      { return ufoEventActive; }
    public boolean isUfoMultiplierActive() { return ufoMultiplierActive; }
    public boolean isGoldenDroneSpawned()  { return goldenDroneEntityUUID != null; }
    public int     getUfoBoxCount()        { return ufoBoxCount.get(); }
    public int     getUfoQuota()           { return ufoQuota; }

    private String locKey(Location l) {
        return l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }

    // Dans EventManager.java — rendre startUfoEvent accessible depuis l'admin
    public void forceStartUfoEvent() {
        startUfoEvent();
    }
}