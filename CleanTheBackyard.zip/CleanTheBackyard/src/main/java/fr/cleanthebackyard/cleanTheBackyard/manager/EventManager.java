package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

public class EventManager {

    private final CleanTheBackyard plugin;
    private final Random random = new Random();

    // OVNI
    private boolean ufoEventActive      = false;
    private boolean ufoMultiplierActive = false;
    private final AtomicInteger ufoBoxCount = new AtomicInteger(0);
    private int ufoQuota = 0;
    private final Map<String, UfoBoxReward> ufoBoxes = new HashMap<>();
    private final List<Location> ufoBoxLocations = new ArrayList<>();
    private BukkitTask ufoTimeoutTask = null;

    // Drone Doré
    private UUID     goldenDroneEntityUUID = null;
    private int      goldenDroneReward     = 0;
    private BukkitTask goldenDroneTask     = null;
    private Player   goldenDroneTarget     = null;

    public enum UfoBoxReward { BONUS_MONEY, DOUBLE_SELL, UNLIMITED_ENERGY }

    public EventManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    // ── PLANIFICATION ─────────────────────────────────────────────────
    public void scheduleNextUfoEvent() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delaySeconds = cfg.getUfoMin() + random.nextInt(cfg.getUfoMax() - cfg.getUfoMin());
        Bukkit.getScheduler().runTaskLater(plugin, this::startUfoEvent, delaySeconds * 20L);
        plugin.getLogger().info("[CTB] Prochain événement OVNI dans " + delaySeconds + "s.");
    }

    public void scheduleNextGoldenDrone() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delaySeconds = cfg.getGoldenDroneMin()
                + random.nextInt(cfg.getGoldenDroneMax() - cfg.getGoldenDroneMin());
        Bukkit.getScheduler().runTaskLater(plugin, this::spawnGoldenDrone, delaySeconds * 20L);
        plugin.getLogger().info("[CTB] Prochain Drone Doré dans " + delaySeconds + "s.");
    }

    // ── OVNI ──────────────────────────────────────────────────────────
    private void startUfoEvent() {
        ufoEventActive = true;
        ufoBoxCount.set(0);
        ufoQuota = Math.max(1, Bukkit.getOnlinePlayers().size()) * 10;
        spawnUfoBoxes();

        String msg = ChatUtil.color("&5[ALERTE] &dUn OVNI survole le jardin ! "
                + "Des &fcaisses mystérieuses &dont atterri ! "
                + "Détruisez &f" + ufoQuota + " &dcartons en équipe pour activer le &fx2 &dde vente !");
        Title title = Title.title(
                Component.text(ChatUtil.color("&5ALERTE OVNI !")),
                Component.text(ChatUtil.color("&dDes caisses spéciales sont apparues !")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(5), Duration.ofMillis(1000))
        );
        for (var player : Bukkit.getOnlinePlayers()) {
            player.sendMessage(msg);
            player.showTitle(title);
            player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.5f);
        }

        // Fin automatique après 10 minutes
        new BukkitRunnable() {
            @Override public void run() {
                if (ufoEventActive) endUfoEvent(false);
            }
        }.runTaskLater(plugin, 20L * 600);

        // Timeout des boîtes OVNI après 30 secondes
        scheduleUfoBoxTimeout();
    }

    private void scheduleUfoBoxTimeout() {
        if (ufoTimeoutTask != null) ufoTimeoutTask.cancel();
        ufoTimeoutTask = new BukkitRunnable() {
            @Override
            public void run() {
                if (!ufoEventActive) return;
                World world = plugin.getPluginConfig().getGameWorld();
                if (world == null) return;

                List<Location> toRemove = new ArrayList<>();
                for (Location loc : ufoBoxLocations) {
                    if (loc.getBlock().getType() == Material.GLOWSTONE) {
                        loc.getBlock().setType(Material.AIR, false);
                        toRemove.add(loc);
                    }
                }
                int removed = toRemove.size();
                toRemove.forEach(loc -> ufoBoxes.remove(LocationUtil.locKey(loc)));
                ufoBoxLocations.removeAll(toRemove);

                if (removed > 0) {
                    Bukkit.getOnlinePlayers().forEach(p ->
                            p.sendMessage(ChatUtil.colored(
                                    "&d[OVNI] &fLes caisses mystérieuses ont disparu... "
                                            + removed + " n'ont pas été réclamées."
                            ))
                    );
                }
                endUfoEvent(false);
            }
        }.runTaskLater(plugin, 20L * 30);
    }

    private void spawnUfoBoxes() {
        ufoBoxes.clear();
        ufoBoxLocations.clear();
        World world = plugin.getPluginConfig().getGameWorld();
        if (world == null || world.getPlayers().isEmpty()) return;

        List<Player> players = new ArrayList<>(world.getPlayers());
        UfoBoxReward[] rewards = UfoBoxReward.values();
        for (int i = 0; i < 5; i++) {
            Player target = players.get(random.nextInt(players.size()));
            Location base = target.getLocation();
            double angle = random.nextDouble() * Math.PI * 2;
            double dist  = 8 + random.nextInt(8);
            Location spawnLoc = base.clone().add(
                    Math.cos(angle) * dist,
                    0,
                    Math.sin(angle) * dist
            );
            spawnLoc.setY(spawnLoc.getWorld().getHighestBlockYAt(spawnLoc));
            if (spawnLoc.getBlock().getType() != Material.AIR) {
                spawnLoc.add(0, 1, 0);
            }
            UfoBoxReward reward = rewards[random.nextInt(rewards.length)];
            spawnLoc.getBlock().setType(Material.GLOWSTONE, false);
            ufoBoxes.put(LocationUtil.locKey(spawnLoc), reward);
            ufoBoxLocations.add(spawnLoc.clone());
        }

        Bukkit.getOnlinePlayers().forEach(p ->
                p.sendMessage(ChatUtil.colored("&d[OVNI] &fDes caisses &6mystérieuses &fbrillantes ont atterri dans le jardin !"))
        );
    }

    public boolean tryClaimUfoBox(Player player, Location loc) {
        String key = LocationUtil.locKey(loc);
        UfoBoxReward reward = ufoBoxes.remove(key);
        if (reward == null) return false;

        ufoBoxLocations.removeIf(l -> LocationUtil.locKey(l).equals(key));
        loc.getBlock().setType(Material.AIR, false);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        int avgLevel = (data.getBagLevel() + data.getToolLevel() + data.getEnergyLevel()) / 3;
        avgLevel = Math.max(1, avgLevel); // protection contre division par zéro

        switch (reward) {
            case BONUS_MONEY -> {
                int bonus = 50 + avgLevel * 75 + random.nextInt(Math.max(1, avgLevel * 50));
                plugin.getEconomyManager().credit(player, bonus);
                player.sendMessage(ChatUtil.colored(
                        "&6[OVNI] &fCaisse mystérieuse ! Vous avez trouvé &a+$" + bonus + " &fdedans !"
                ));
                Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals(player)).forEach(p ->
                        p.sendMessage(ChatUtil.colored("&6[OVNI] &f" + player.getName()
                                + " a trouvé &a$" + bonus + " &fdans une caisse OVNI !"))
                );
            }
            case DOUBLE_SELL -> {
                int duration = 20 + avgLevel * 10;
                data.setDoubleSell(duration);
                player.sendMessage(ChatUtil.colored(
                        "&6[OVNI] &fCaisse mystérieuse ! &ex2 VENTE &fpersonnel +&f"
                                + duration + "s &f(Niv. moy. " + avgLevel + ")"
                ));
                Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals(player)).forEach(p ->
                        p.sendMessage(ChatUtil.colored("&6[OVNI] &f" + player.getName()
                                + " a obtenu un &ex2 vente &fpersonnel +&f" + duration + "s !"))
                );
            }
            case UNLIMITED_ENERGY -> {
                int duration = 30 + avgLevel * 15;
                data.setUnlimitedEnergy(duration);
                plugin.getBoxManager().removeFatigue(player, data);
                player.sendMessage(ChatUtil.colored(
                        "&6[OVNI] &fCaisse mystérieuse ! &bÉNERGIE ILLIMITÉE &f+&f"
                                + duration + "s &f(Niv. moy. " + avgLevel + ")"
                ));
                Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals(player)).forEach(p ->
                        p.sendMessage(ChatUtil.colored("&6[OVNI] &f" + player.getName()
                                + " a obtenu de l'&bénergie illimitée &f+" + duration + "s !"))
                );
            }
        }
        return true;
    }

    public boolean isUfoBox(Location loc) {
        return ufoBoxes.containsKey(LocationUtil.locKey(loc));
    }

    public void onBoxBroken(Location loc) {
        if (!ufoEventActive) return;
        int count = ufoBoxCount.incrementAndGet();
        if (count % 50 == 0) {
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&d[OVNI] &f" + count + " / " + ufoQuota + " cartons détruits !"))
            );
        }
        if (count >= ufoQuota) endUfoEvent(true);
    }

    /**
     * Termine l'événement OVNI.
     * @param success true si le quota a été atteint
     * @param skipNextSchedule true pour ne pas planifier le prochain événement (utilisé par forceStart)
     */
    private void endUfoEvent(boolean success, boolean skipNextSchedule) {
        ufoEventActive = false;
        if (ufoTimeoutTask != null) {
            ufoTimeoutTask.cancel();
            ufoTimeoutTask = null;
        }

        ufoBoxLocations.forEach(l -> {
            if (l.getBlock().getType() == Material.GLOWSTONE) l.getBlock().setType(Material.AIR, false);
        });
        ufoBoxes.clear();
        ufoBoxLocations.clear();

        if (success) {
            activateSellMultiplier();
        } else {
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&c[OVNI] Objectif non atteint ! "
                            + ufoBoxCount.get() + "/" + ufoQuota + " cartons."))
            );
        }

        if (!skipNextSchedule) {
            scheduleNextUfoEvent();
        }
    }

    /** Surcharge pour conserver la compatibilité */
    private void endUfoEvent(boolean success) {
        endUfoEvent(success, false);
    }

    private void activateSellMultiplier() {
        ufoMultiplierActive = true;
        plugin.getPluginConfig().setGlobalSellMultiplier(2.0);

        final int DURATION_SEC = 3600;
        Bukkit.getOnlinePlayers().forEach(p -> {
            p.sendMessage(ChatUtil.colored("&6[SUCCÈS] &ex2 bonus de vente global pendant &f1 heure &e!"));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        });

        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getPluginConfig().setGlobalSellMultiplier(1.0);
            ufoMultiplierActive = false;
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&7[Bonus] Le multiplicateur x2 global d'1 heure est expiré."))
            );
        }, DURATION_SEC * 20L);
    }

    // ── DRONE DORÉ ────────────────────────────────────────────────────
    public void spawnGoldenDrone() {
        if (goldenDroneEntityUUID != null) return;

        Collection<? extends Player> online = Bukkit.getOnlinePlayers();
        if (online.isEmpty()) {
            scheduleNextGoldenDrone();
            return;
        }

        goldenDroneTarget = online.stream()
                .skip(random.nextInt(online.size()))
                .findFirst().orElse(null);
        if (goldenDroneTarget == null) { scheduleNextGoldenDrone(); return; }

        PlayerData targetData = plugin.getPlayerDataManager().get(goldenDroneTarget);
        goldenDroneReward = calculateDroneReward(targetData);

        Location spawnLoc = goldenDroneTarget.getLocation().clone().add(
                (random.nextDouble() - 0.5) * 6,
                4 + random.nextDouble() * 2,
                (random.nextDouble() - 0.5) * 6
        );

        Bat drone = (Bat) spawnLoc.getWorld().spawnEntity(spawnLoc, EntityType.BAT);
        drone.setCustomName(ChatUtil.color("&6✦ Drone Doré [$" + goldenDroneReward + "] ✦"));
        drone.setCustomNameVisible(true);
        drone.setRemoveWhenFarAway(false);
        drone.setAware(false);
        goldenDroneEntityUUID = drone.getUniqueId();

        double angle = random.nextDouble() * Math.PI * 2;
        double speed = 0.15;
        drone.setVelocity(new Vector(Math.cos(angle) * speed, 0.05, Math.sin(angle) * speed));

        String msg = ChatUtil.color("&6[DRONE DORÉ] &eUn Drone Doré est apparu près de &f"
                + goldenDroneTarget.getName() + " &e! Frappez-le en moins de &f30s &epour gagner &f$" + goldenDroneReward + " &e!");
        Bukkit.getOnlinePlayers().forEach(p -> {
            p.sendMessage(msg);
            p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.5f);
        });

        final UUID droneUUID = goldenDroneEntityUUID;
        goldenDroneTask = new BukkitRunnable() {
            int ticks = 0;
            final double baseSpeed = 0.15;
            @Override
            public void run() {
                ticks += 2;
                Entity entity = Bukkit.getEntity(droneUUID);
                if (entity == null || !entity.isValid()) {
                    expireGoldenDrone(false);
                    cancel();
                    return;
                }
                if (ticks >= 600) {
                    expireGoldenDrone(true);
                    entity.remove();
                    cancel();
                    return;
                }
                Vector vel = entity.getVelocity();
                double hSpeed = Math.sqrt(vel.getX() * vel.getX() + vel.getZ() * vel.getZ());
                if (hSpeed < baseSpeed * 0.8) {
                    double angle = Math.atan2(vel.getZ(), vel.getX());
                    entity.setVelocity(new Vector(
                            Math.cos(angle) * baseSpeed,
                            vel.getY(),
                            Math.sin(angle) * baseSpeed
                    ));
                } else if (hSpeed > baseSpeed * 1.2) {
                    double norm = baseSpeed / hSpeed;
                    entity.setVelocity(new Vector(
                            vel.getX() * norm,
                            vel.getY(),
                            vel.getZ() * norm
                    ));
                }
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }

    private int calculateDroneReward(PlayerData data) {
        if (data == null) return 500 + random.nextInt(500);
        int baseReward = 500 + random.nextInt(500);
        if (data.getBagLevel() > 3) baseReward += (data.getBagLevel() - 3) * 500;
        if (data.getToolLevel() > 2) baseReward += (data.getToolLevel() - 2) * 300;
        if (data.getEnergyLevel() > 2) baseReward += (data.getEnergyLevel() - 2) * 200;
        return baseReward;
    }

    private void expireGoldenDrone(boolean timeout) {
        goldenDroneEntityUUID = null;
        goldenDroneReward     = 0;
        goldenDroneTarget     = null;
        if (goldenDroneTask != null) { goldenDroneTask.cancel(); goldenDroneTask = null; }
        if (timeout) {
            Bukkit.getOnlinePlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&7[Drone Doré] Personne n'a attrapé le drone à temps..."))
            );
        }
        scheduleNextGoldenDrone();
    }

    public boolean claimGoldenDrone(Player player, UUID entityUUID) {
        if (goldenDroneEntityUUID == null || !goldenDroneEntityUUID.equals(entityUUID)) return false;
        int reward = goldenDroneReward;
        goldenDroneEntityUUID = null;
        goldenDroneReward     = 0;
        goldenDroneTarget     = null;
        if (goldenDroneTask != null) { goldenDroneTask.cancel(); goldenDroneTask = null; }
        Entity drone = Bukkit.getEntity(entityUUID);
        if (drone != null) drone.remove();
        plugin.getEconomyManager().credit(player, reward);
        player.sendMessage(ChatUtil.colored("&6✦ Vous avez abattu le Drone Doré ! +$" + reward + " ✦"));
        Bukkit.getOnlinePlayers().stream().filter(p -> !p.equals(player)).forEach(p ->
                p.sendMessage(ChatUtil.colored("&6[Drone Doré] &f" + player.getName()
                        + " &6a remporté &f$" + reward + " &6en abattant le Drone Doré !"))
        );
        scheduleNextGoldenDrone();
        return true;
    }

    // ── Getters ───────────────────────────────────────────────────────
    public boolean isUfoEventActive()      { return ufoEventActive; }
    public boolean isUfoMultiplierActive() { return ufoMultiplierActive; }
    public boolean isGoldenDroneSpawned()  { return goldenDroneEntityUUID != null; }
    public int     getUfoBoxCount()        { return ufoBoxCount.get(); }
    public int     getUfoQuota()           { return ufoQuota; }

    public void forceStartUfoEvent() {
        if (ufoEventActive) {
            endUfoEvent(false, true);
        }
        startUfoEvent();
    }
}