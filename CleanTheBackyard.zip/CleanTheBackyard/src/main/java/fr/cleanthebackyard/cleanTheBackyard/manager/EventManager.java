package fr.cleanthebackyard.cleanTheBackyard.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
public class EventManager {
    private final CleanTheBackyard plugin;
    private final Random random = new Random();
    // OVNI
    private boolean ufoEventActive      = false;
    private boolean ufoMultiplierActive = false;
    private final AtomicInteger ufoBoxCount = new AtomicInteger(0);
    private int ufoQuota = 0;
    private final Map<String, UfoBoxReward> ufoBoxes = new HashMap<>();
    private final List<Location> ufoBoxLocations = new ArrayList<>();
    private BukkitTask ufoTimeoutTask = null;
    // Drone Doré
    private UUID     goldenDroneEntityUUID = null;
    private int      goldenDroneReward     = 0;
    private BukkitTask goldenDroneTask     = null;
    private Player   goldenDroneTarget     = null;
    public enum UfoBoxReward { BONUS_MONEY, DOUBLE_SELL, UNLIMITED_ENERGY, BLACK_MARKET }
    // Matériaux valides pour la pluie de cartons (sols naturels)
    private static final Set<Material> RAIN_VALID_GROUNDS = EnumSet.of(
            Material.GRASS_BLOCK, Material.DIRT, Material.COARSE_DIRT, Material.PODZOL,
            Material.SAND, Material.RED_SAND, Material.GRAVEL, Material.MYCELIUM,
            Material.ROOTED_DIRT, Material.MUD, Material.MOSS_BLOCK
    );
    public void triggerBoxRainNow() { triggerBoxRain(); }
    public void triggerBlackMarketNow() { triggerBlackMarket(); }
    public EventManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private List<Player> getAllCtbPlayers() {
        String hub = plugin.getPluginConfig().getHubWorldName();
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        List<Player> list = new ArrayList<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            World w = p.getWorld();
            if (w.getName().equals(hub)) continue;
            if (w.getName().startsWith(prefix)) list.add(p);
        }
        return list;
    }
    /** Vrai si le joueur est dans SON monde personnel. */
    private boolean isInOwnWorld(Player p) {
        String expected = plugin.getPluginConfig().getPlayerWorldName(p.getUniqueId());
        return p.getWorld().getName().equals(expected);
    }
    // ── PLANIFICATIONS ────────────────────────────────────────────────
    public void scheduleNextUfoEvent() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getUfoMin() + random.nextInt(Math.max(1, cfg.getUfoMax() - cfg.getUfoMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::startUfoEvent, delay * 20L);
    }
    public void scheduleNextGoldenDrone() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getGoldenDroneMin()
                + random.nextInt(Math.max(1, cfg.getGoldenDroneMax() - cfg.getGoldenDroneMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::spawnGoldenDrone, delay * 20L);
    }
    public void scheduleNextBoxRain() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getBoxRainMin()
                + random.nextInt(Math.max(1, cfg.getBoxRainMax() - cfg.getBoxRainMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::triggerBoxRain, delay * 20L);
    }
    public void scheduleNextBlackMarket() {
        PluginConfig cfg = plugin.getPluginConfig();
        int delay = cfg.getBlackMarketMin()
                + random.nextInt(Math.max(1, cfg.getBlackMarketMax() - cfg.getBlackMarketMin()));
        Bukkit.getScheduler().runTaskLater(plugin, this::triggerBlackMarket, delay * 20L);
    }
    // ── PLUIE DE CARTONS (corrigée) ───────────────────────────────────
    private void triggerBoxRain() {
        List<Player> targets = getAllCtbPlayers();
        if (targets.isEmpty()) {
            scheduleNextBoxRain();
            return;
        }
        Material boxMat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        if (boxMat == null) boxMat = Material.NOTE_BLOCK;
        final Material finalMat = boxMat;
        // Annonce uniquement aux joueurs dans LEUR monde
        for (Player p : targets) {
            if (!isInOwnWorld(p)) continue;
            p.sendMessage(ChatUtil.color("&3[PLUIE DE CARTONS] &fDes cartons tombent du ciel pendant 30 secondes !"));
            p.playSound(p.getLocation(), Sound.WEATHER_RAIN, 1.0f, 1.0f);
        }
        new BukkitRunnable() {
            int ticks = 0;
            final int MAX_TICKS = 30;
            final int MAX_BOXES_PER_TICK_PER_PLAYER = 3;
            final int RADIUS = 12;
            @Override public void run() {
                if (ticks++ > MAX_TICKS) { cancel(); return; }
                for (Player p : getAllCtbPlayers()) {
                    if (!isInOwnWorld(p)) continue;
                    World w = p.getWorld();
                    Location center = p.getLocation();
                    int placed = 0;
                    int attempts = 0;
                    while (placed < MAX_BOXES_PER_TICK_PER_PLAYER && attempts < 12) {
                        attempts++;
                        double angle = random.nextDouble() * Math.PI * 2;
                        double dist = 3 + random.nextDouble() * RADIUS;
                        int x = (int) Math.round(center.getX() + Math.cos(angle) * dist);
                        int z = (int) Math.round(center.getZ() + Math.sin(angle) * dist);
                        // Trouver le sol valide
                        int topY = w.getHighestBlockYAt(x, z);
                        Location ground = new Location(w, x, topY - 1, z);
                        Material groundMat = ground.getBlock().getType();
                        if (!RAIN_VALID_GROUNDS.contains(groundMat)) continue;
                        Location above = new Location(w, x, topY, z);
                        if (above.getBlock().getType() != Material.AIR) continue;
                        above.getBlock().setType(finalMat, false);
                        w.spawnParticle(Particle.CLOUD, above.clone().add(0.5, 0.5, 0.5), 4, 0.2, 0.2, 0.2, 0.01);
                        placed++;
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
        scheduleNextBoxRain();
    }
    // ── MARCHÉ NOIR ───────────────────────────────────────────────────
    private void triggerBlackMarket() {
        List<Player> targets = getAllCtbPlayers();
        if (targets.isEmpty()) {
            scheduleNextBlackMarket();
            return;
        }
        for (Player p : targets) {
            PlayerData d = plugin.getPlayerDataManager().get(p);
            if (d != null) {
                d.setBlackMarket(60);
                p.sendMessage(ChatUtil.color("&8[MARCHÉ NOIR] &5Vente x3 pendant 60 secondes !"));
                p.playSound(p.getLocation(), Sound.ENTITY_WITHER_AMBIENT, 0.7f, 1.5f);
                if (isInOwnWorld(p)) {
                    p.getWorld().spawnParticle(Particle.WITCH, p.getLocation().add(0, 2, 0), 30, 1, 1, 1, 0.1);
                }
            }
        }
        scheduleNextBlackMarket();
    }
    // ── OVNI ──────────────────────────────────────────────────────────
    private void startUfoEvent() {
        List<Player> ctbPlayers = getAllCtbPlayers();
        if (ctbPlayers.isEmpty()) {
            scheduleNextUfoEvent();
            return;
        }
        ufoEventActive = true;
        ufoBoxCount.set(0);
        ufoQuota = Math.max(1, ctbPlayers.size()) * 10;
        spawnUfoBoxes(ctbPlayers);
        Title title = Title.title(
                Component.text(ChatUtil.color("&5ALERTE OVNI !")),
                Component.text(ChatUtil.color("&dDes caisses spéciales sont apparues !")),
                Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(5), Duration.ofMillis(1000))
        );
        String msg = ChatUtil.color("&5[ALERTE] &dUn OVNI ! Détruisez &f" + ufoQuota + " &dcartons pour activer le &fx2 vente &dglobal !");
        for (Player p : ctbPlayers) {
            p.sendMessage(msg);
            p.showTitle(title);
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0f, 0.5f);
        }
        new BukkitRunnable() {
            @Override public void run() { if (ufoEventActive) endUfoEvent(false); }
        }.runTaskLater(plugin, 20L * 600);
        scheduleUfoBoxTimeout();
    }
    private void scheduleUfoBoxTimeout() {
        if (ufoTimeoutTask != null) ufoTimeoutTask.cancel();
        ufoTimeoutTask = new BukkitRunnable() {
            @Override public void run() {
                if (!ufoEventActive) return;
                List<Location> toRemove = new ArrayList<>();
                for (Location loc : ufoBoxLocations) {
                    if (loc.getBlock().getType() == Material.GLOWSTONE) {
                        loc.getBlock().setType(Material.AIR, false);
                        toRemove.add(loc);
                    }
                }
                toRemove.forEach(loc -> ufoBoxes.remove(LocationUtil.locKey(loc)));
                ufoBoxLocations.removeAll(toRemove);
                endUfoEvent(false);
            }
        }.runTaskLater(plugin, 20L * 30);
    }
    private void spawnUfoBoxes(List<Player> ctbPlayers) {
        ufoBoxes.clear();
        ufoBoxLocations.clear();
        if (ctbPlayers.isEmpty()) return;
        UfoBoxReward[] rewards = UfoBoxReward.values();
        for (Player target : ctbPlayers) {
            if (!isInOwnWorld(target)) continue;
            for (int i = 0; i < 5; i++) {
                Location base = target.getLocation();
                double angle = random.nextDouble() * Math.PI * 2;
                double dist  = 8 + random.nextInt(8);
                Location spawnLoc = base.clone().add(
                        Math.cos(angle) * dist, 0, Math.sin(angle) * dist
                );
                spawnLoc.setY(spawnLoc.getWorld().getHighestBlockYAt(spawnLoc));
                if (spawnLoc.getBlock().getType() != Material.AIR) spawnLoc.add(0, 1, 0);
                UfoBoxReward reward = rewards[random.nextInt(rewards.length)];
                spawnLoc.getBlock().setType(Material.GLOWSTONE, false);
                ufoBoxes.put(LocationUtil.locKey(spawnLoc), reward);
                ufoBoxLocations.add(spawnLoc.clone());
            }
        }
    }
    public boolean tryClaimUfoBox(Player player, Location loc) {
        String key = LocationUtil.locKey(loc);
        UfoBoxReward reward = ufoBoxes.remove(key);
        if (reward == null) return false;
        ufoBoxLocations.removeIf(l -> LocationUtil.locKey(l).equals(key));
        loc.getBlock().setType(Material.AIR, false);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;
        int avgLevel = Math.max(1, (data.getBagLevel() + data.getToolLevel() + data.getEnergyLevel()) / 3);
        switch (reward) {
            case BONUS_MONEY -> {
                int bonus = 50 + avgLevel * 75 + random.nextInt(Math.max(1, avgLevel * 50));
                plugin.getEconomyManager().credit(player, bonus);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &fCaisse ! &a+$" + bonus));
            }
            case DOUBLE_SELL -> {
                int duration = 20 + avgLevel * 10;
                data.setDoubleSell(duration);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &ex2 VENTE perso +" + duration + "s"));
            }
            case UNLIMITED_ENERGY -> {
                int duration = 30 + avgLevel * 15;
                data.setUnlimitedEnergy(duration);
                plugin.getBoxManager().removeFatigue(player, data);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &bÉNERGIE ILLIMITÉE +" + duration + "s"));
            }
            case BLACK_MARKET -> {
                int duration = 30 + avgLevel * 5;
                data.setBlackMarket(duration);
                player.sendMessage(ChatUtil.colored("&6[OVNI] &5MARCHÉ NOIR x3 +" + duration + "s"));
            }
        }
        return true;
    }
    public boolean isUfoBox(Location loc) { return ufoBoxes.containsKey(LocationUtil.locKey(loc)); }
    public void onBoxBroken(Location loc) {
        if (!ufoEventActive) return;
        int count = ufoBoxCount.incrementAndGet();
        if (count % 50 == 0) {
            getAllCtbPlayers().forEach(p ->
                    p.sendMessage(ChatUtil.colored("&d[OVNI] &f" + count + " / " + ufoQuota))
            );
        }
        if (count >= ufoQuota) endUfoEvent(true);
    }
    private void endUfoEvent(boolean success, boolean skipNextSchedule) {
        ufoEventActive = false;
        if (ufoTimeoutTask != null) { ufoTimeoutTask.cancel(); ufoTimeoutTask = null; }
        ufoBoxLocations.forEach(l -> {
            if (l.getBlock().getType() == Material.GLOWSTONE) l.getBlock().setType(Material.AIR, false);
        });
        ufoBoxes.clear();
        ufoBoxLocations.clear();
        if (success) activateSellMultiplier();
        if (!skipNextSchedule) scheduleNextUfoEvent();
    }
    private void endUfoEvent(boolean success) { endUfoEvent(success, false); }
    private void activateSellMultiplier() {
        ufoMultiplierActive = true;
        plugin.getPluginConfig().setGlobalSellMultiplier(2.0);
        final int DURATION = 3600;
        getAllCtbPlayers().forEach(p -> {
            p.sendMessage(ChatUtil.colored("&6[SUCCÈS] &ex2 GLOBAL pendant &f1 heure &e!"));
            p.playSound(p.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        });
        Bukkit.getScheduler().runTaskLater(plugin, () -> {
            plugin.getPluginConfig().setGlobalSellMultiplier(1.0);
            ufoMultiplierActive = false;
        }, DURATION * 20L);
    }
    // ── DRONE DORÉ ────────────────────────────────────────────────────
    public void spawnGoldenDrone() {
        if (goldenDroneEntityUUID != null) return;
        List<Player> ctbPlayers = getAllCtbPlayers();
        if (ctbPlayers.isEmpty()) { scheduleNextGoldenDrone(); return; }
        goldenDroneTarget = ctbPlayers.get(random.nextInt(ctbPlayers.size()));
        if (!isInOwnWorld(goldenDroneTarget)) {
            scheduleNextGoldenDrone();
            return;
        }
        PlayerData targetData = plugin.getPlayerDataManager().get(goldenDroneTarget);
        goldenDroneReward = calculateDroneReward(targetData);
        Location spawnLoc = goldenDroneTarget.getLocation().clone().add(
                (random.nextDouble() - 0.5) * 6,
                4 + random.nextDouble() * 2,
                (random.nextDouble() - 0.5) * 6
        );
        Bat drone = (Bat) spawnLoc.getWorld().spawnEntity(spawnLoc, EntityType.BAT);
        drone.setCustomName(ChatUtil.color("&6✦ Drone Doré [$" + goldenDroneReward + "] ✦"));
        drone.setCustomNameVisible(true);
        drone.setRemoveWhenFarAway(false);
        drone.setAware(false);
        goldenDroneEntityUUID = drone.getUniqueId();
        double angle = random.nextDouble() * Math.PI * 2;
        drone.setVelocity(new Vector(Math.cos(angle) * 0.15, 0.05, Math.sin(angle) * 0.15));
        goldenDroneTarget.sendMessage(ChatUtil.color(
                "&6[DRONE DORÉ] &eDrone Doré apparu ! Frappe-le en moins de &f30s &epour &f$" + goldenDroneReward
        ));
        goldenDroneTarget.playSound(goldenDroneTarget.getLocation(), Sound.BLOCK_NOTE_BLOCK_BELL, 1.0f, 1.5f);
        final UUID droneUUID = goldenDroneEntityUUID;
        goldenDroneTask = new BukkitRunnable() {
            int ticks = 0;
            final double baseSpeed = 0.15;
            @Override public void run() {
                ticks += 2;
                Entity entity = Bukkit.getEntity(droneUUID);
                if (entity == null || !entity.isValid()) { expireGoldenDrone(false); cancel(); return; }
                if (ticks >= 600) { expireGoldenDrone(true); entity.remove(); cancel(); return; }
                Vector vel = entity.getVelocity();
                double hSpeed = Math.sqrt(vel.getX()*vel.getX() + vel.getZ()*vel.getZ());
                if (hSpeed < baseSpeed * 0.8) {
                    double a = Math.atan2(vel.getZ(), vel.getX());
                    entity.setVelocity(new Vector(Math.cos(a) * baseSpeed, vel.getY(), Math.sin(a) * baseSpeed));
                }
            }
        }.runTaskTimer(plugin, 2L, 2L);
    }
    private int calculateDroneReward(PlayerData data) {
        if (data == null) return 500 + random.nextInt(500);
        int baseReward = 500 + random.nextInt(500);
        baseReward += data.getBagLevel() * 100;
        baseReward += data.getToolLevel() * 75;
        baseReward += data.getEnergyLevel() * 50;
        baseReward *= (1 + data.getPrestigeLevel() / 2);
        return baseReward;
    }
    private void expireGoldenDrone(boolean timeout) {
        Player target = goldenDroneTarget;
        goldenDroneEntityUUID = null;
        goldenDroneReward = 0;
        goldenDroneTarget = null;
        if (goldenDroneTask != null) { goldenDroneTask.cancel(); goldenDroneTask = null; }
        if (timeout && target != null && target.isOnline()) {
            target.sendMessage(ChatUtil.colored("&7[Drone Doré] Trop tard..."));
        }
        scheduleNextGoldenDrone();
    }
    public boolean claimGoldenDrone(Player player, UUID entityUUID) {
        if (goldenDroneEntityUUID == null || !goldenDroneEntityUUID.equals(entityUUID)) return false;
        int reward = goldenDroneReward;
        goldenDroneEntityUUID = null;
        goldenDroneReward = 0;
        goldenDroneTarget = null;
        if (goldenDroneTask != null) { goldenDroneTask.cancel(); goldenDroneTask = null; }
        Entity drone = Bukkit.getEntity(entityUUID);
        if (drone != null) drone.remove();
        plugin.getEconomyManager().credit(player, reward);
        player.sendMessage(ChatUtil.colored("&6✦ Drone Doré abattu ! +$" + reward + " ✦"));
        scheduleNextGoldenDrone();
        return true;
    }
    public boolean isUfoEventActive()      { return ufoEventActive; }
    public boolean isUfoMultiplierActive() { return ufoMultiplierActive; }
    public boolean isGoldenDroneSpawned()  { return goldenDroneEntityUUID != null; }
    public int     getUfoBoxCount()        { return ufoBoxCount.get(); }
    public int     getUfoQuota()           { return ufoQuota; }
    public void forceStartUfoEvent() {
        if (ufoEventActive) endUfoEvent(false, true);
        startUfoEvent();
    }
}