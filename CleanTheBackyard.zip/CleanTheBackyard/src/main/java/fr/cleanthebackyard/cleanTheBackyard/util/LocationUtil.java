package fr.cleanthebackyard.cleanTheBackyard.util;
import org.bukkit.Location;
public final class LocationUtil {
    private LocationUtil() {}
    /**
     * Génère une clé unique pour une location (basée sur monde + coordonnées entières).
     * IMPORTANT : inclut le nom du monde pour éviter les collisions inter-mondes joueurs.
     */
    public static String locKey(Location l) {
        String worldName = l.getWorld() != null ? l.getWorld().getName() : "";
        return worldName + ":" + l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }
    public static boolean inRadius(Location player, Location target, double radius) {
        if (target == null || target.getWorld() == null) return false;
        if (player.getWorld() == null) return false;
        if (!target.getWorld().equals(player.getWorld())) return false;
        return player.distanceSquared(target) <= radius * radius;
    }
}