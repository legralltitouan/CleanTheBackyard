package fr.cleanthebackyard.cleanTheBackyard.util;

import org.bukkit.Location;

/**
 * Utilitaire pour les opérations sur les localisations.
 */
public final class LocationUtil {

    private LocationUtil() {}

    /**
     * Génère une clé unique pour une location (basée sur les coordonnées entières).
     */
    public static String locKey(Location l) {
        return l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }
}