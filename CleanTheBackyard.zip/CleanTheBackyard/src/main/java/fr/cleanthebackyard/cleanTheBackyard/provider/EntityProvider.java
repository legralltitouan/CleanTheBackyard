package fr.cleanthebackyard.cleanTheBackyard.provider;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.persistence.PersistentDataType;
import java.lang.reflect.Method;
import java.util.Optional;
/**
 * Spawn des entités CTB en vanilla ou via MythicMobs 5.x.
 * Si MM est absent ou échoue, on fallback automatiquement sur l'entité vanilla
 * passée en paramètre.
 *
 * Toutes les entités spawnées sont taggées avec un PDC pour permettre :
 *  ─ leur identification dans les listeners ({@link #isCtbEntity})
 *  ─ leur nettoyage (drones résiduels au reload, etc.)
 */
public class EntityProvider {
    private final CleanTheBackyard plugin;
    private final boolean mythicPresent;
    private final NamespacedKey ctbEntityKey;
    // Cache réflexion MM 5.x (API publique io.lumine.mythic.api.*)
    private Object mythicBukkitInstance;
    private Object mobManagerInstance;
    private Method mmGetMythicMob;
    private Method mmMobSpawn;
    private Method mmActiveMobGetEntity;
    private Method mmAbstractEntityBukkit;
    private Method mmBukkitAdapterAdapt;
    public EntityProvider(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.ctbEntityKey = new NamespacedKey(plugin, "ctb-entity-source");
        this.mythicPresent = Bukkit.getPluginManager().isPluginEnabled("MythicMobs");
        if (mythicPresent) initMythicReflection();
    }
    private void initMythicReflection() {
        try {
            Class<?> mythicBukkitCls = Class.forName("io.lumine.mythic.bukkit.MythicBukkit");
            mythicBukkitInstance = mythicBukkitCls.getMethod("inst").invoke(null);
            mobManagerInstance = mythicBukkitCls.getMethod("getMobManager").invoke(mythicBukkitInstance);
            mmGetMythicMob = mobManagerInstance.getClass().getMethod("getMythicMob", String.class);
            Class<?> mythicMobApi = Class.forName("io.lumine.mythic.api.mobs.MythicMob");
            Class<?> bukkitAdapter = Class.forName("io.lumine.mythic.bukkit.BukkitAdapter");
            mmBukkitAdapterAdapt = bukkitAdapter.getMethod("adapt", Location.class);
            Class<?> abstractLoc = Class.forName("io.lumine.mythic.api.adapters.AbstractLocation");
            mmMobSpawn = mythicMobApi.getMethod("spawn", abstractLoc, double.class);
            Class<?> activeMobCls = Class.forName("io.lumine.mythic.core.mobs.ActiveMob");
            mmActiveMobGetEntity = activeMobCls.getMethod("getEntity");
            Class<?> abstractEntity = Class.forName("io.lumine.mythic.api.adapters.AbstractEntity");
            mmAbstractEntityBukkit = abstractEntity.getMethod("getBukkitEntity");
            plugin.getLogger().info("[CTB] MythicMobs 5.x détecté : support des entités custom activé.");
        } catch (Throwable t) {
            plugin.getLogger().warning("[CTB] MythicMobs présent mais API inaccessible ("
                    + t.getClass().getSimpleName() + " - " + t.getMessage() + "). Bascule en vanilla.");
            mmGetMythicMob = null;
        }
    }
    public boolean isMythicAvailable() { return mythicPresent && mmGetMythicMob != null; }
    public NamespacedKey getCtbEntityKey() { return ctbEntityKey; }
    public CustomEntityHandle spawn(EntityRef ref, Location loc, EntityType vanillaFallback, String tag) {
        // Vanilla direct
        if (ref.getType() == EntityRef.Type.VANILLA) {
            EntityType type = ref.asVanillaType(vanillaFallback);
            Entity e = loc.getWorld().spawnEntity(loc, type);
            markEntity(e, tag);
            return new CustomEntityHandle(e, "vanilla:" + type.name());
        }
        // MythicMobs requis mais absent → fallback
        if (!isMythicAvailable()) {
            return spawnFallback(loc, vanillaFallback, tag, "MM indisponible pour " + ref);
        }
        try {
            Object optional = mmGetMythicMob.invoke(mobManagerInstance, ref.getId());
            Object mythicMob = (optional instanceof Optional<?> opt) ? opt.orElse(null) : optional;
            if (mythicMob == null) {
                return spawnFallback(loc, vanillaFallback, tag, "MythicMob inconnu : " + ref.getId());
            }
            Object abstractLoc = mmBukkitAdapterAdapt.invoke(null, loc);
            Object activeMob = mmMobSpawn.invoke(mythicMob, abstractLoc, 1.0);
            if (activeMob == null) {
                return spawnFallback(loc, vanillaFallback, tag, "Spawn MM null pour " + ref.getId());
            }
            Object abstractEntity = mmActiveMobGetEntity.invoke(activeMob);
            Entity bukkit = (Entity) mmAbstractEntityBukkit.invoke(abstractEntity);
            markEntity(bukkit, tag);
            return new CustomEntityHandle(bukkit, "mythic:" + ref.getId());
        } catch (Throwable t) {
            return spawnFallback(loc, vanillaFallback, tag,
                    "Erreur spawn MM (" + ref + ") : " + t.getClass().getSimpleName() + " - " + t.getMessage());
        }
    }
    private CustomEntityHandle spawnFallback(Location loc, EntityType fallback, String tag, String reason) {
        plugin.getLogger().warning("[CTB] " + reason + " → fallback " + fallback.name());
        Entity e = loc.getWorld().spawnEntity(loc, fallback);
        markEntity(e, tag);
        return new CustomEntityHandle(e, "vanilla-fallback:" + fallback.name());
    }
    public void markEntity(Entity e, String tag) {
        if (e == null || tag == null) return;
        e.getPersistentDataContainer().set(ctbEntityKey, PersistentDataType.STRING, tag);
    }
    public String getTag(Entity e) {
        if (e == null) return null;
        return e.getPersistentDataContainer().get(ctbEntityKey, PersistentDataType.STRING);
    }
    public boolean isCtbEntity(Entity e, String expectedTag) {
        String tag = getTag(e);
        return tag != null && tag.equals(expectedTag);
    }
    public boolean isCtbEntity(Entity e) {
        return getTag(e) != null;
    }
}