package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.util.BoundingBox;

/**
 * Empêche le joueur de franchir la frontière de sa zone de cartons débloquée.
 *
 * La région box-rain (étendue selon le niveau de zone du joueur) sert de
 * référence. Le mur se situe sur l'axe d'extension configuré (cardboard-zone.axis) :
 *   ─ axe "Z" : limite sur max.Z
 *   ─ axe "X" : limite sur max.X
 *
 * Le créatif et les mondes hors-jeu sont ignorés.
 */
public class CardboardWallListener implements Listener {

    private final CleanTheBackyard plugin;
    /** Petite marge pour que le mur soit franc et ne « colle » pas au bord. */
    private static final double MARGIN = 0.30;

    public CardboardWallListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private boolean isPlayerGameWorld(World world) {
        if (world == null) return false;
        String hub = plugin.getPluginConfig().getHubWorldName();
        if (world.getName().equals(hub)) return false;
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        String housePrefix = plugin.getPluginConfig().getHouseWorldPrefix();
        if (world.getName().startsWith(housePrefix)) return false;
        return world.getName().startsWith(prefix);
    }

    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return;
        if (!plugin.getPluginConfig().isCardboardZoneEnabled()) return;
        if (!isPlayerGameWorld(player.getWorld())) return;

        Location to = event.getTo();
        if (to == null) return;

        // Optimisation : on ne fait rien si le bloc n'a pas changé.
        Location from = event.getFrom();
        if (from.getBlockX() == to.getBlockX() && from.getBlockZ() == to.getBlockZ()) return;

        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        // Région débloquée par ce joueur (palier 0 = région de base).
        BoundingBox region = plugin.getPluginConfig().getBoxRainRegion(data.getCardboardZoneLevel());

        // On ne bloque que si le joueur tente de franchir le bord intérieur de la zone.
        // Le mur est posé sur la face d'extension (max de l'axe).
        String axis = plugin.getPluginConfig().getCardboardZoneAxis();
        boolean blocked;
        if ("X".equalsIgnoreCase(axis)) {
            double limit = region.getMaxX() + 1.0; // bord extérieur du dernier bloc de zone
            blocked = to.getX() > limit + MARGIN;
            if (blocked) {
                Location corrected = to.clone();
                corrected.setX(limit + MARGIN);
                applyWall(event, corrected);
            }
        } else { // axe Z par défaut
            double limit = region.getMaxZ() + 1.0;
            blocked = to.getZ() > limit + MARGIN;
            if (blocked) {
                Location corrected = to.clone();
                corrected.setZ(limit + MARGIN);
                applyWall(event, corrected);
            }
        }
    }

    private void applyWall(PlayerMoveEvent event, Location corrected) {
        // Conserve l'orientation du joueur, ne renvoie qu'à la limite.
        corrected.setYaw(event.getTo().getYaw());
        corrected.setPitch(event.getTo().getPitch());
        event.setTo(corrected);
    }
}
