package fr.cleanthebackyard.cleanTheBackyard.automation;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.automation.manager.DroneManager;
import fr.cleanthebackyard.cleanTheBackyard.automation.manager.DroneModuleManager;

/**
 * Drones autonomes et leurs modules spéciaux.
 */
public record AutomationSystem(
        DroneManager       drone,
        DroneModuleManager droneModule) {

    public static AutomationSystem create(CleanTheBackyard plugin) {
        return new AutomationSystem(
                new DroneManager(plugin),
                new DroneModuleManager(plugin));
    }
}
