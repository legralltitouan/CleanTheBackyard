package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.entity.DroneEntity;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.World;
import org.bukkit.entity.Bee;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;

import java.util.*;

public class DroneManager {

    private final CleanTheBackyard plugin;
    private final Map<UUID, List<DroneEntity>> activeDrones = new HashMap<>();

    public DroneManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        cleanAllLegacyDrones();
    }

    private void cleanAllLegacyDrones() {
        World world = plugin.getPluginConfig().getGameWorld();
        if (world == null) return;
        int removed = 0;
        for (Entity e : world.getEntities()) {
            if (e instanceof Bee && e.getCustomName() != null && e.getCustomName().contains("Drone")) {
                e.remove();
                removed++;
            }
        }
        if (removed > 0) plugin.getLogger().info("[CTB] Nettoyé " + removed + " drones résiduels.");
    }

    public boolean purchaseDrone(Player player, String droneKey) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;

        Optional<PluginConfig.DroneConfig> configOpt = plugin.getPluginConfig()
                .getDroneConfigs().stream()
                .filter(d -> d.key().equals(droneKey))
                .findFirst();
        if (configOpt.isEmpty()) {
            player.sendMessage(ChatUtil.color("&cDrone inconnu : " + droneKey));
            return false;
        }

        PluginConfig.DroneConfig dc = configOpt.get();

        if (data.getBagLevel() < dc.bagLevelRequired() ||
                data.getToolLevel() < dc.toolLevelRequired() ||
                data.getEnergyLevel() < dc.energyLevelRequired()) {
            player.sendMessage(ChatUtil.color("&cPrérequis manquants pour ce drone."));
            return false;
        }

        if (data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&eVous possédez déjà ce drone !"));
            return false;
        }

        if (!plugin.getEconomyManager().debit(player, dc.cost(), dc.name())) return false;

        data.addDrone(droneKey);
        spawnDrone(player, dc);
        player.sendMessage(ChatUtil.color("&aDrone &f" + dc.name() + " &aacheté !"));
        return true;
    }

    public void spawnDrone(Player owner, PluginConfig.DroneConfig config) {
        DroneEntity drone = new DroneEntity(owner, config);
        activeDrones.computeIfAbsent(owner.getUniqueId(), k -> new ArrayList<>()).add(drone);
    }

    public void respawnPlayerDrones(Player player) {
        despawnPlayerDrones(player);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        for (PluginConfig.DroneConfig dc : plugin.getPluginConfig().getDroneConfigs()) {
            if (data.hasDrone(dc.key())) {
                spawnDrone(player, dc);
            }
        }
    }

    public void despawnPlayerDrones(Player player) {
        List<DroneEntity> drones = activeDrones.remove(player.getUniqueId());
        if (drones != null) {
            drones.forEach(DroneEntity::stop);
        } else {
            World world = plugin.getPluginConfig().getGameWorld();
            if (world != null) {
                for (Entity e : world.getEntities()) {
                    if (e instanceof Bee && e.getCustomName() != null && e.getCustomName().contains(player.getName())) {
                        e.remove();
                    }
                }
            }
        }
    }

    public void shutdown() {
        for (List<DroneEntity> list : activeDrones.values()) {
            list.forEach(DroneEntity::stop);
        }
        activeDrones.clear();
        cleanAllLegacyDrones();
    }
}