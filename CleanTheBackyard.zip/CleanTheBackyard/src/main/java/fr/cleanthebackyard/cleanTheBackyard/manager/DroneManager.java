package fr.cleanthebackyard.cleanTheBackyard.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.entity.DroneEntity;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.World;
import org.bukkit.entity.Bee;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import java.util.*;
public class DroneManager {
    public static final int SPEED = 0;
    public static final int RANGE = 1;
    public static final int INCOME = 2;
    private final CleanTheBackyard plugin;
    private final Map<UUID, List<DroneEntity>> activeDrones = new HashMap<>();
    public DroneManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        cleanAllLegacyDrones();
    }
    private void cleanAllLegacyDrones() {
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        for (World world : plugin.getServer().getWorlds()) {
            if (!world.getName().startsWith(prefix)) continue;
            int removed = 0;
            for (Entity e : world.getEntities()) {
                if (plugin.getEntityProvider().isCtbEntity(e, "drone")) {
                    e.remove();
                    removed++;
                }
            }
            if (removed > 0) {
                plugin.getLogger().info("[CTB] Nettoyé " + removed + " drones résiduels dans " + world.getName() + ".");
            }
        }
    }
    public boolean purchaseDrone(Player player, String droneKey) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        PluginConfig.DroneConfig dc = plugin.getPluginConfig().getDroneConfig(droneKey);
        if (dc == null) {
            player.sendMessage(ChatUtil.color("&cDrone inconnu : " + droneKey));
            return false;
        }
        if (data.getBagLevel() < dc.bagLevelRequired() ||
                data.getToolLevel() < dc.toolLevelRequired() ||
                data.getEnergyLevel() < dc.energyLevelRequired()) {
            player.sendMessage(ChatUtil.color("&cPrérequis manquants pour ce drone."));
            return false;
        }
        if (data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&eVous possédez déjà ce drone !"));
            return false;
        }
        if (!plugin.getEconomyManager().debit(player, dc.cost(), dc.name())) return false;
        data.addDrone(droneKey);
        spawnDrone(player, dc);
        player.sendMessage(ChatUtil.color("&aDrone &f" + dc.name() + " &aacheté !"));
        return true;
    }
    public boolean upgradeDroneAttribute(Player player, String droneKey, int attribute) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (!data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&cVous ne possédez pas ce drone."));
            return false;
        }
        PluginConfig.DroneConfig dc = plugin.getPluginConfig().getDroneConfig(droneKey);
        if (dc == null) return false;
        int[] tiers = data.getDroneUpgrades(droneKey);
        int currentTier = tiers[attribute];
        int maxTier = switch (attribute) {
            case SPEED -> dc.maxSpeedTier();
            case RANGE -> dc.maxRangeTier();
            case INCOME -> dc.maxIncomeTier();
            default -> 0;
        };
        if (currentTier >= maxTier) {
            player.sendMessage(ChatUtil.color("&eCette amélioration est au maximum."));
            return false;
        }
        String upgradeKey = switch (attribute) {
            case SPEED -> "speed";
            case RANGE -> "range";
            case INCOME -> "income";
            default -> "speed";
        };
        long cost = plugin.getPluginConfig().getDroneUpgradeCost(dc.cost(), upgradeKey, currentTier);
        if (!plugin.getEconomyManager().debit(player, cost, "Upgrade " + dc.name() + " (" + upgradeKey + ")")) {
            return false;
        }
        tiers[attribute]++;
        data.setDroneUpgrades(droneKey, tiers);
        player.sendMessage(ChatUtil.color("&a✦ &f" + dc.name() + " &a- "
                + upgradeKey.toUpperCase() + " niveau &f" + tiers[attribute] + "&a !"));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.2f);
        respawnSingleDrone(player, droneKey);
        return true;
    }
    private void respawnSingleDrone(Player player, String droneKey) {
        List<DroneEntity> drones = activeDrones.get(player.getUniqueId());
        if (drones == null) return;
        drones.removeIf(d -> {
            if (d.getKey().equals(droneKey)) {
                d.stop();
                return true;
            }
            return false;
        });
        PluginConfig.DroneConfig dc = plugin.getPluginConfig().getDroneConfig(droneKey);
        if (dc != null) spawnDrone(player, dc);
    }
    public void spawnDrone(Player owner, PluginConfig.DroneConfig config) {
        String hub = plugin.getPluginConfig().getHubWorldName();
        if (owner.getWorld().getName().equals(hub)) return;
        DroneEntity drone = new DroneEntity(owner, config);
        activeDrones.computeIfAbsent(owner.getUniqueId(), k -> new ArrayList<>()).add(drone);
    }
    public void respawnPlayerDrones(Player player) {
        despawnPlayerDrones(player);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        if (!player.getWorld().getName().startsWith(prefix)) return;
        for (PluginConfig.DroneConfig dc : plugin.getPluginConfig().getDroneConfigs()) {
            if (data.hasDrone(dc.key())) spawnDrone(player, dc);
        }
    }
    public void despawnPlayerDrones(Player player) {
        List<DroneEntity> drones = activeDrones.remove(player.getUniqueId());
        if (drones != null) {
            drones.forEach(DroneEntity::stop);
        }
        // Cleanup résiduel : on retire toutes les entités drones du monde du joueur
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        for (World world : plugin.getServer().getWorlds()) {
            if (!world.getName().startsWith(prefix)) continue;
            for (Entity e : world.getEntities()) {
                if (plugin.getEntityProvider().isCtbEntity(e, "drone")
                        && e.getCustomName() != null
                        && e.getCustomName().contains(player.getName())) {
                    e.remove();
                }
            }
        }
    }
    public List<DroneEntity> getPlayerDrones(Player player) {
        return activeDrones.getOrDefault(player.getUniqueId(), Collections.emptyList());
    }
    public DroneEntity getDroneByKey(Player player, String key) {
        return getPlayerDrones(player).stream()
                .filter(d -> d.getKey().equals(key))
                .findFirst().orElse(null);
    }
    public void shutdown() {
        for (List<DroneEntity> list : activeDrones.values()) {
            list.forEach(DroneEntity::stop);
        }
        activeDrones.clear();
        cleanAllLegacyDrones();
    }
}