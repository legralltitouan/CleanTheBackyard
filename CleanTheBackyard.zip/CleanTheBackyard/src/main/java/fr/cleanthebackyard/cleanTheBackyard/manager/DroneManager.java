package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;

import java.util.Optional;

/**
 * Gere l'achat et la validation des drones passifs.
 * Les gains sont appliques par DroneIncomeTask.
 */
public class DroneManager {

    private final CleanTheBackyard plugin;

    public DroneManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    /**
     * Tente d'acheter un drone pour un joueur.
     */
    public boolean purchaseDrone(Player player, String droneKey) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;

        Optional<PluginConfig.DroneConfig> configOpt = plugin.getPluginConfig()
                .getDroneConfigs().stream()
                .filter(d -> d.key().equals(droneKey))
                .findFirst();

        if (configOpt.isEmpty()) {
            player.sendMessage(ChatUtil.colored("&cDrone inconnu : " + droneKey));
            return false;
        }

        PluginConfig.DroneConfig dc = configOpt.get();

        // Verifie les pre-requis
        if (data.getBagLevel() < dc.bagLevelRequired()) {
            player.sendMessage(ChatUtil.colored("&cRequis : Sac Niveau " + dc.bagLevelRequired()));
            return false;
        }
        if (data.getToolLevel() < dc.toolLevelRequired()) {
            player.sendMessage(ChatUtil.colored("&cRequis : Outil Niveau " + dc.toolLevelRequired()));
            return false;
        }
        if (data.getEnergyLevel() < dc.energyLevelRequired()) {
            player.sendMessage(ChatUtil.colored("&cRequis : Energie Niveau " + dc.energyLevelRequired()));
            return false;
        }

        // Verifie si deja possede
        if (data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.colored("&eVous possedez deja ce drone !"));
            return false;
        }

        // Debit
        if (!plugin.getEconomyManager().debit(player, dc.cost(), dc.name())) return false;

        data.addDrone(droneKey);
        player.sendMessage(ChatUtil.colored(
                "&aDrone &f" + dc.name() + " &aachete ! Il generera &f+$" + dc.income()
                        + " &atoutes les " + dc.intervalSec() + "s."
        ));
        return true;
    }

    /**
     * Applique les revenus passifs de tous les drones de tous les joueurs connectes.
     * Appele par DroneIncomeTask.
     */
    public void applyDroneIncome() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (data == null) continue;

            double totalIncome = 0;
            for (PluginConfig.DroneConfig dc : plugin.getPluginConfig().getDroneConfigs()) {
                if (data.hasDrone(dc.key())) {
                    totalIncome += dc.income();
                }
            }

            if (totalIncome > 0) {
                plugin.getEconomyManager().credit(player, totalIncome);
            }
        }
    }
}
