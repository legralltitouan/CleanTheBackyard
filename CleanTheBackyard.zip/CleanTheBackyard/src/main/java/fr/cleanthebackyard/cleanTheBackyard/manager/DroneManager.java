package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;

import java.util.*;

/**
 * Gere l'achat et la validation des drones passifs.
 * Les gains sont appliques par DroneIncomeTask.
 */
public class DroneManager {

    private final CleanTheBackyard plugin;

    // Stocke le dernier timestamp de paiement pour chaque drone de chaque joueur
    private final Map<UUID, Map<String, Long>> lastPayout = new HashMap<>();

    public DroneManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean purchaseDrone(Player player, String droneKey) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;

        Optional<PluginConfig.DroneConfig> configOpt = plugin.getPluginConfig()
                .getDroneConfigs().stream()
                .filter(d -> d.key().equals(droneKey))
                .findFirst();

        if (configOpt.isEmpty()) {
            player.sendMessage(ChatUtil.color("&cDrone inconnu : " + droneKey));
            return false;
        }

        PluginConfig.DroneConfig dc = configOpt.get();

        if (data.getBagLevel() < dc.bagLevelRequired()) {
            player.sendMessage(ChatUtil.color("&cRequis : Sac Niveau " + dc.bagLevelRequired()));
            return false;
        }
        if (data.getToolLevel() < dc.toolLevelRequired()) {
            player.sendMessage(ChatUtil.color("&cRequis : Outil Niveau " + dc.toolLevelRequired()));
            return false;
        }
        if (data.getEnergyLevel() < dc.energyLevelRequired()) {
            player.sendMessage(ChatUtil.color("&cRequis : Energie Niveau " + dc.energyLevelRequired()));
            return false;
        }

        if (data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&eVous possedez deja ce drone !"));
            return false;
        }

        if (!plugin.getEconomyManager().debit(player, dc.cost(), dc.name())) return false;

        data.addDrone(droneKey);
        player.sendMessage(ChatUtil.color(
                "&aDrone &f" + dc.name() + " &aachete ! Il generera &f+$" + dc.income()
                        + " &atoutes les " + dc.intervalSec() + "s."
        ));
        return true;
    }

    /**
     * Applique les revenus passifs de tous les drones de tous les joueurs connectes.
     * Chaque drone a son propre intervalle configuré.
     */
    public void applyDroneIncome() {
        long now = System.currentTimeMillis();
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (data == null) continue;

            for (PluginConfig.DroneConfig dc : plugin.getPluginConfig().getDroneConfigs()) {
                if (!data.hasDrone(dc.key())) continue;

                Map<String, Long> playerPayouts = lastPayout.computeIfAbsent(player.getUniqueId(), k -> new HashMap<>());
                long last = playerPayouts.getOrDefault(dc.key(), 0L);
                if (now - last >= dc.intervalSec() * 1000L) {
                    playerPayouts.put(dc.key(), now);
                    plugin.getEconomyManager().credit(player, dc.income());
                }
            }
        }
    }
}