package fr.cleanthebackyard.cleanTheBackyard.ui.integration;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

/**
 * Pont vers BetterHUD via PlaceholderAPI.
 * Tous les placeholders sont exposés sous le préfixe %ctb_*%.
 * Configure ton BetterHUD pour afficher ces placeholders à l'emplacement souhaité.
 *
 * Liste :
 *   %ctb_balance%, %ctb_balance_raw%
 *   %ctb_bag%, %ctb_bag_max%, %ctb_bag_pct%
 *   %ctb_energy%, %ctb_energy_max%, %ctb_energy_pct%
 *   %ctb_prestige%, %ctb_talent_points%
 *   %ctb_streak_day%
 *   %ctb_double_sell_seconds%, %ctb_black_market_seconds%, %ctb_unlimited_energy_seconds%
 *   %ctb_recent_gain%, %ctb_recent_multiplier%
 *   %ctb_drones_owned%, %ctb_drones_active%
 */
public class BetterHudBridge extends PlaceholderExpansion {

    private final CleanTheBackyard plugin;
    private boolean active = false;

    public BetterHudBridge(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean tryRegister() {
        if (!plugin.core().config().isBetterHudEnabled()) {
            plugin.getLogger().info("[CTB] BetterHUD bridge désactivé dans la config.");
            return false;
        }
        if (plugin.getServer().getPluginManager().getPlugin("PlaceholderAPI") == null) {
            plugin.getLogger().info("[CTB] PlaceholderAPI absent — bridge BetterHUD inactif.");
            return false;
        }
        boolean ok = register();
        active = ok;
        if (ok) plugin.getLogger().info("[CTB] BetterHUD bridge actif (placeholders %ctb_*%).");
        return ok;
    }

    public boolean isActive() { return active; }

    @Override public @NotNull String getIdentifier() { return "ctb"; }
    @Override public @NotNull String getAuthor() { return "CTB"; }
    @Override public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }
    @Override public boolean persist() { return true; }

    @Override
    public String onRequest(OfflinePlayer p, @NotNull String params) {
        if (p == null || !p.isOnline()) return "";
        Player player = p.getPlayer();
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return "";
        int maxEnergy = plugin.gameplay().box().getMaxEnergyForPlayer(data);
        int bagMax = plugin.gameplay().box().getBagCapacity(data.getBagLevel());

        return switch (params.toLowerCase()) {
            case "balance"            -> NumberFormatUtil.money(data.getBalance());
            case "balance_raw"        -> Long.toString((long) data.getBalance());
            case "bag"                -> Integer.toString(data.getCurrentBoxes());
            case "bag_max"            -> Integer.toString(bagMax);
            case "bag_pct"            -> bagMax == 0 ? "0"
                    : Integer.toString((int) Math.round(100.0 * data.getCurrentBoxes() / bagMax));
            case "energy"             -> Integer.toString((int) Math.round(data.getCurrentEnergy()));
            case "energy_max"         -> Integer.toString(maxEnergy);
            case "energy_pct"         -> maxEnergy == 0 ? "0"
                    : Integer.toString((int) Math.round(100.0 * data.getCurrentEnergy() / maxEnergy));
            case "prestige"           -> Integer.toString(data.getPrestigeLevel());
            case "talent_points"      -> Integer.toString(data.getTalentPoints());
            case "streak_day"         -> Integer.toString(data.getDailyStreak());
            case "double_sell_seconds"      -> Long.toString(data.getDoubleSellRemainingSeconds());
            case "black_market_seconds"     -> Long.toString(data.getBlackMarketRemainingSeconds());
            case "unlimited_energy_seconds" -> Long.toString(data.getUnlimitedEnergyRemainingSeconds());
            case "recent_gain" -> {
                Double g = plugin.ui().hud().getRecentGainAmount(player.getUniqueId());
                yield g == null ? "" : NumberFormatUtil.money(g);
            }
            case "recent_multiplier" -> {
                Double m = plugin.ui().hud().getRecentGainMultiplier(player.getUniqueId());
                yield (m == null || m <= 1.0) ? "" : String.format("x%.1f", m);
            }
            case "drones_owned"  -> Integer.toString(data.getOwnedDrones().size());
            case "drones_active" -> Integer.toString(plugin.automation().drone().getPlayerDrones(player).size());
            default -> null;
        };
    }
}
