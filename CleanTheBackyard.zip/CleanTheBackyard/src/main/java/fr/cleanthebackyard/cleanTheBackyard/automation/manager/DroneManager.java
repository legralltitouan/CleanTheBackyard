package fr.cleanthebackyard.cleanTheBackyard.automation.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.automation.entity.DroneEntity;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.World;
import org.bukkit.entity.Bee;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import java.util.*;
public class DroneManager {
    public static final int SPEED = 0;
    public static final int RANGE = 1;
    public static final int INCOME = 2;
    private final CleanTheBackyard plugin;
    private final Map<UUID, List<DroneEntity>> activeDrones = new HashMap<>();
    public DroneManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        cleanAllLegacyDrones();
    }
    private void cleanAllLegacyDrones() {
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        for (World world : plugin.getServer().getWorlds()) {
            if (!world.getName().startsWith(prefix)) continue;
            if (world.getName().startsWith(housePrefix)) continue;
            int removed = 0;
            // Les drones vanilla sont des Bee ; on cible la classe au lieu de
            // charger toutes les entités du monde.
            for (Bee bee : world.getEntitiesByClass(Bee.class)) {
                if (plugin.providers().entity().isCtbEntity(bee, "drone")) {
                    bee.remove();
                    removed++;
                }
            }
            // Hologrammes résiduels (TextDisplay non persistants avec le marqueur ✦).
            for (TextDisplay td : world.getEntitiesByClass(TextDisplay.class)) {
                if (!td.isPersistent() && td.getText() != null && td.getText().contains("✦")) {
                    td.remove();
                    removed++;
                }
            }
            if (removed > 0)
                plugin.getLogger().info("[CTB] Nettoyé " + removed + " entité(s) drone résiduelle(s) dans " + world.getName() + ".");
        }
    }
    public boolean purchaseDrone(Player player, String droneKey) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        PluginConfig.DroneConfig dc = plugin.core().config().getDroneConfig(droneKey);
        if (dc == null) {
            player.sendMessage(ChatUtil.color("&cDrone inconnu : " + droneKey));
            return false;
        }
        if (data.getBagLevel() < dc.bagLevelRequired() ||
                data.getToolLevel() < dc.toolLevelRequired() ||
                data.getEnergyLevel() < dc.energyLevelRequired()) {
            player.sendMessage(ChatUtil.color("&cPrérequis manquants pour ce drone."));
            return false;
        }
        if (data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&eVous possédez déjà ce drone !"));
            return false;
        }
        if (!plugin.core().economy().debit(player, dc.cost(), dc.name())) return false;
        data.addDrone(droneKey);
        spawnDrone(player, dc);
        player.sendMessage(ChatUtil.color("&aDrone &f" + dc.name() + " &aacheté !"));
        return true;
    }
    public boolean upgradeDroneAttribute(Player player, String droneKey, int attribute) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        if (!data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&cVous ne possédez pas ce drone."));
            return false;
        }
        PluginConfig.DroneConfig dc = plugin.core().config().getDroneConfig(droneKey);
        if (dc == null) return false;
        int[] tiers = data.getDroneUpgrades(droneKey);
        int currentTier = tiers[attribute];
        int maxTier = switch (attribute) {
            case SPEED -> dc.maxSpeedTier();
            case RANGE -> dc.maxRangeTier();
            case INCOME -> dc.maxIncomeTier();
            default -> 0;
        };
        if (currentTier >= maxTier) {
            player.sendMessage(ChatUtil.color("&eCette amélioration est au maximum."));
            return false;
        }
        String upgradeKey = switch (attribute) {
            case SPEED -> "speed";
            case RANGE -> "range";
            case INCOME -> "income";
            default -> "speed";
        };
        long cost = plugin.core().config().getDroneUpgradeCost(dc.cost(), upgradeKey, currentTier);
        if (!plugin.core().economy().debit(player, cost, "Upgrade " + dc.name() + " (" + upgradeKey + ")"))
            return false;
        tiers[attribute]++;
        data.setDroneUpgrades(droneKey, tiers);
        player.sendMessage(ChatUtil.color("&a✦ &f" + dc.name() + " &a- "
                + upgradeKey.toUpperCase() + " niveau &f" + tiers[attribute] + "&a !"));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.2f);
        respawnSingleDrone(player, droneKey);
        return true;
    }
    public void respawnSingleDrone(Player player, String droneKey) {
        List<DroneEntity> drones = activeDrones.get(player.getUniqueId());
        if (drones != null) {
            drones.removeIf(d -> {
                if (d.getKey().equals(droneKey)) { d.stop(); return true; }
                return false;
            });
        }
        PluginConfig.DroneConfig dc = plugin.core().config().getDroneConfig(droneKey);
        if (dc != null) spawnDrone(player, dc);
    }
    public void spawnDrone(Player owner, PluginConfig.DroneConfig config) {
        String hub = plugin.core().config().getHubWorldName();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        String wName = owner.getWorld().getName();
        if (wName.equals(hub) || wName.startsWith(housePrefix)) return;
        DroneEntity drone = new DroneEntity(owner, config);
        activeDrones.computeIfAbsent(owner.getUniqueId(), k -> new ArrayList<>()).add(drone);
    }
    public void respawnPlayerDrones(Player player) {
        despawnPlayerDrones(player);
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return;
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        String wName = player.getWorld().getName();
        if (!wName.startsWith(prefix) || wName.startsWith(housePrefix)) return;
        for (PluginConfig.DroneConfig dc : plugin.core().config().getDroneConfigs())
            if (data.hasDrone(dc.key())) spawnDrone(player, dc);
    }
    public void despawnPlayerDrones(Player player) {
        // Priorité : on s'appuie sur le registre en mémoire (pas de balayage monde).
        List<DroneEntity> drones = activeDrones.remove(player.getUniqueId());
        if (drones != null) drones.forEach(DroneEntity::stop);
        // Filet de sécurité ciblé : uniquement le monde du joueur, classe Bee.
        World world = player.getWorld();
        if (world == null) return;
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        if (!world.getName().startsWith(prefix) || world.getName().startsWith(housePrefix)) return;
        String playerName = player.getName();
        for (Bee bee : world.getEntitiesByClass(Bee.class)) {
            if (plugin.providers().entity().isCtbEntity(bee, "drone")
                    && bee.getCustomName() != null
                    && bee.getCustomName().contains(playerName)) {
                bee.remove();
            }
        }
    }
    public List<DroneEntity> getPlayerDrones(Player player) {
        return activeDrones.getOrDefault(player.getUniqueId(), Collections.emptyList());
    }
    public DroneEntity getDroneByKey(Player player, String key) {
        return getPlayerDrones(player).stream()
                .filter(d -> d.getKey().equals(key))
                .findFirst().orElse(null);
    }
    public void shutdown() {
        for (List<DroneEntity> list : activeDrones.values()) list.forEach(DroneEntity::stop);
        activeDrones.clear();
        cleanAllLegacyDrones();
        DroneEntity.clearAllLocks();
    }
}