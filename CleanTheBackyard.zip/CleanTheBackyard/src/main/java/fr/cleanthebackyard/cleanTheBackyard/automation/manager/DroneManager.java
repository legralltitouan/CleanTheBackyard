package fr.cleanthebackyard.cleanTheBackyard.automation.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.automation.entity.DroneEntity;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.World;
import org.bukkit.entity.Bee;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public class DroneManager {
    public static final int SPEED = 0;
    public static final int RANGE = 1;
    public static final int INCOME = 2;
    private final CleanTheBackyard plugin;
    private final Map<UUID, List<DroneEntity>> activeDrones = new HashMap<>();
    /** Verrou anti double-clic : clé "uuid:droneKey" pendant une recharge en cours. */
    private final Set<String> rechargingLock = ConcurrentHashMap.newKeySet();
    public DroneManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        cleanAllLegacyDrones();
    }
    private void cleanAllLegacyDrones() {
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        for (World world : plugin.getServer().getWorlds()) {
            if (!world.getName().startsWith(prefix)) continue;
            if (world.getName().startsWith(housePrefix)) continue;
            int removed = 0;
            for (Bee bee : world.getEntitiesByClass(Bee.class)) {
                if (plugin.providers().entity().isCtbEntity(bee, "drone")) {
                    bee.remove();
                    removed++;
                }
            }
            for (TextDisplay td : world.getEntitiesByClass(TextDisplay.class)) {
                if (!td.isPersistent() && td.getText() != null && td.getText().contains("✦")) {
                    td.remove();
                    removed++;
                }
            }
            if (removed > 0)
                plugin.getLogger().info("[CTB] Nettoyé " + removed + " entité(s) drone résiduelle(s) dans " + world.getName() + ".");
        }
    }
    public boolean purchaseDrone(Player player, String droneKey) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        PluginConfig.DroneConfig dc = plugin.core().config().getDroneConfig(droneKey);
        if (dc == null) {
            player.sendMessage(ChatUtil.color("&cDrone inconnu : " + droneKey));
            return false;
        }
        if (data.getBagLevel() < dc.bagLevelRequired() ||
                data.getToolLevel() < dc.toolLevelRequired() ||
                data.getEnergyLevel() < dc.energyLevelRequired()) {
            player.sendMessage(ChatUtil.color("&cPrérequis manquants pour ce drone."));
            return false;
        }
        if (data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&eVous possédez déjà ce drone !"));
            return false;
        }
        if (!plugin.core().economy().debit(player, dc.cost(), dc.name())) return false;
        data.addDrone(droneKey);
        // Batterie pleine à l'achat.
        data.setDroneBattery(droneKey, getMaxBatteryCapacity(data, dc));
        spawnDrone(player, dc);
        player.sendMessage(ChatUtil.color("&aDrone &f" + dc.name() + " &aacheté !"));
        return true;
    }
    public boolean upgradeDroneAttribute(Player player, String droneKey, int attribute) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        if (!data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&cVous ne possédez pas ce drone."));
            return false;
        }
        PluginConfig.DroneConfig dc = plugin.core().config().getDroneConfig(droneKey);
        if (dc == null) return false;
        int[] tiers = data.getDroneUpgrades(droneKey);
        int currentTier = tiers[attribute];
        int maxTier = switch (attribute) {
            case SPEED -> dc.maxSpeedTier();
            case RANGE -> dc.maxRangeTier();
            case INCOME -> dc.maxIncomeTier();
            default -> 0;
        };
        if (currentTier >= maxTier) {
            player.sendMessage(ChatUtil.color("&eCette amélioration est au maximum."));
            return false;
        }
        String upgradeKey = switch (attribute) {
            case SPEED -> "speed";
            case RANGE -> "range";
            case INCOME -> "income";
            default -> "speed";
        };
        long cost = plugin.core().config().getDroneUpgradeCost(dc.cost(), upgradeKey, currentTier);
        if (!plugin.core().economy().debit(player, cost, "Upgrade " + dc.name() + " (" + upgradeKey + ")"))
            return false;
        tiers[attribute]++;
        data.setDroneUpgrades(droneKey, tiers);
        player.sendMessage(ChatUtil.color("&a✦ &f" + dc.name() + " &a- "
                + upgradeKey.toUpperCase() + " niveau &f" + tiers[attribute] + "&a !"));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.2f);
        respawnSingleDrone(player, droneKey);
        return true;
    }
    /** Capacité max de batterie pour un drone donné selon son tier de capacité. */
    public double getMaxBatteryCapacity(PlayerData data, PluginConfig.DroneConfig dc) {
        var cfg = plugin.core().config();
        int tier = data.getDroneBatteryTier(dc.key());
        return cfg.getDroneBatteryBaseCapacity()
                * (1.0 + tier * cfg.getDroneBatteryCapacityPerTier());
    }
    /** Améliore la capacité de batterie d'un drone. */
    public boolean upgradeBatteryCapacity(Player player, String droneKey) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        if (!data.hasDrone(droneKey)) {
            player.sendMessage(ChatUtil.color("&cVous ne possédez pas ce drone."));
            return false;
        }
        var cfg = plugin.core().config();
        if (!cfg.isDroneBatteryEnabled()) {
            player.sendMessage(ChatUtil.color("&cLe système de batterie est désactivé."));
            return false;
        }
        PluginConfig.DroneConfig dc = cfg.getDroneConfig(droneKey);
        if (dc == null) return false;
        int currentTier = data.getDroneBatteryTier(droneKey);
        int maxTier = cfg.getDroneBatteryMaxTier();
        if (currentTier >= maxTier) {
            player.sendMessage(ChatUtil.color("&eBatterie au maximum."));
            return false;
        }
        long cost = cfg.getDroneBatteryUpgradeCost(dc.cost(), currentTier);
        if (!plugin.core().economy().debit(player, cost,
                "Batterie " + dc.name() + " (capacité)")) return false;
        data.setDroneBatteryTier(droneKey, currentTier + 1);
        // Sécurité : on clampe la charge persistée à la nouvelle capacité (qui ne peut
        // qu'augmenter, donc inoffensif, mais cohérent). On garde la charge courante :
        // respawnSingleDrone (avec persistance) réécrira la charge de l'ancien drone,
        // ce qui est le comportement voulu ici — on ne veut PAS recharger gratuitement.
        double newMax = getMaxBatteryCapacity(data, dc);
        double cur = data.getDroneBattery(droneKey);
        data.setDroneBattery(droneKey, Math.min(cur, newMax));
        player.sendMessage(ChatUtil.color("&a🔋 Capacité de batterie de &f" + dc.name()
                + " &amontée au niveau &f" + (currentTier + 1) + "&a !"));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 0.7f, 1.4f);
        respawnSingleDrone(player, droneKey);
        return true;
    }
    /** Recharge complète d'un drone contre de l'argent. */
    public boolean rechargeDrone(Player player, String droneKey) {
        String lockKey = player.getUniqueId() + ":" + droneKey;
        // Anti double-clic : si une recharge est déjà en cours pour ce drone, on ignore.
        if (!rechargingLock.add(lockKey)) {
            return false;
        }
        try {
            PlayerData data = plugin.core().playerData().get(player);
            if (data == null) return false;
            if (!data.hasDrone(droneKey)) {
                player.sendMessage(ChatUtil.color("&cVous ne possédez pas ce drone."));
                return false;
            }
            var cfg = plugin.core().config();
            if (!cfg.isDroneBatteryEnabled()) {
                player.sendMessage(ChatUtil.color("&cLe système de batterie est désactivé."));
                return false;
            }
            PluginConfig.DroneConfig dc = cfg.getDroneConfig(droneKey);
            if (dc == null) return false;
            double max = getMaxBatteryCapacity(data, dc);
            double current = data.getDroneBattery(droneKey);
            double missing = max - current;
            if (missing <= 0.01) {
                player.sendMessage(ChatUtil.color("&eCette batterie est déjà pleine."));
                return false;
            }
            long cost = Math.max(1, Math.round(missing * cfg.getDroneBatteryRechargeCostPerUnit()));
            if (!plugin.core().economy().debit(player, cost, "Recharge " + dc.name())) return false;
            // On écrit la charge max APRÈS le débit, puis on respawn SANS persister
            // l'ancienne charge basse (sinon stop() l'écraserait juste après).
            data.setDroneBattery(droneKey, max);
            player.sendMessage(ChatUtil.color("&a⚡ &f" + dc.name()
                    + " &arechargé à 100% &7(&f" + NumberFormatUtil.money(cost) + "&7)"));
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BEACON_ACTIVATE, 0.6f, 1.5f);
            respawnSingleDroneNoPersist(player, droneKey);
            return true;
        } finally {
            rechargingLock.remove(lockKey);
        }
    }
    /** Coût d'une recharge complète (pour l'affichage GUI). */
    public long getRechargeCost(PlayerData data, String droneKey) {
        var cfg = plugin.core().config();
        PluginConfig.DroneConfig dc = cfg.getDroneConfig(droneKey);
        if (dc == null) return 0;
        double max = getMaxBatteryCapacity(data, dc);
        double current = data.getDroneBattery(droneKey);
        double missing = Math.max(0, max - current);
        return Math.max(1, Math.round(missing * cfg.getDroneBatteryRechargeCostPerUnit()));
    }
    /** Respawn standard : l'ancien drone persiste sa charge courante avant d'être recréé. */
    public void respawnSingleDrone(Player player, String droneKey) {
        List<DroneEntity> drones = activeDrones.get(player.getUniqueId());
        if (drones != null) {
            drones.removeIf(d -> {
                if (d.getKey().equals(droneKey)) { d.stop(); return true; }
                return false;
            });
        }
        PluginConfig.DroneConfig dc = plugin.core().config().getDroneConfig(droneKey);
        if (dc != null) spawnDrone(player, dc);
    }
    /**
     * Respawn SANS persister l'ancienne batterie.
     * À utiliser après une modification externe de la charge (recharge GUI) :
     * évite que stop() ne réécrive la charge basse de l'ancienne instance par-dessus
     * la valeur fraîchement écrite dans PlayerData.
     */
    public void respawnSingleDroneNoPersist(Player player, String droneKey) {
        List<DroneEntity> drones = activeDrones.get(player.getUniqueId());
        if (drones != null) {
            drones.removeIf(d -> {
                if (d.getKey().equals(droneKey)) { d.stop(false); return true; }
                return false;
            });
        }
        PluginConfig.DroneConfig dc = plugin.core().config().getDroneConfig(droneKey);
        if (dc != null) spawnDrone(player, dc);
    }
    public void spawnDrone(Player owner, PluginConfig.DroneConfig config) {
        String hub = plugin.core().config().getHubWorldName();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        String wName = owner.getWorld().getName();
        if (wName.equals(hub) || wName.startsWith(housePrefix)) return;
        DroneEntity drone = new DroneEntity(owner, config);
        activeDrones.computeIfAbsent(owner.getUniqueId(), k -> new ArrayList<>()).add(drone);
    }
    public void respawnPlayerDrones(Player player) {
        despawnPlayerDrones(player);
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return;
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        String wName = player.getWorld().getName();
        if (!wName.startsWith(prefix) || wName.startsWith(housePrefix)) return;
        for (PluginConfig.DroneConfig dc : plugin.core().config().getDroneConfigs())
            if (data.hasDrone(dc.key())) spawnDrone(player, dc);
    }
    public void despawnPlayerDrones(Player player) {
        List<DroneEntity> drones = activeDrones.remove(player.getUniqueId());
        boolean hadRegistered = drones != null && !drones.isEmpty();
        if (drones != null) drones.forEach(DroneEntity::stop);
        if (!hadRegistered) return;
        World world = player.getWorld();
        if (world == null) return;
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        if (!world.getName().startsWith(prefix) || world.getName().startsWith(housePrefix)) return;
        String playerName = player.getName();
        for (Bee bee : world.getEntitiesByClass(Bee.class)) {
            if (plugin.providers().entity().isCtbEntity(bee, "drone")
                    && bee.getCustomName() != null
                    && bee.getCustomName().contains(playerName)) {
                bee.remove();
            }
        }
    }
    public List<DroneEntity> getPlayerDrones(Player player) {
        return activeDrones.getOrDefault(player.getUniqueId(), Collections.emptyList());
    }
    public DroneEntity getDroneByKey(Player player, String key) {
        return getPlayerDrones(player).stream()
                .filter(d -> d.getKey().equals(key))
                .findFirst().orElse(null);
    }
    public void shutdown() {
        for (List<DroneEntity> list : activeDrones.values()) list.forEach(DroneEntity::stop);
        activeDrones.clear();
        cleanAllLegacyDrones();
        DroneEntity.clearAllLocks();
    }
}
