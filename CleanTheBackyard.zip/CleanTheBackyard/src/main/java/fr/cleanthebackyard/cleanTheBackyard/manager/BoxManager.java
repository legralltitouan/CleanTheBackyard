package fr.cleanthebackyard.cleanTheBackyard.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.LocationUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
public class BoxManager {
    private final CleanTheBackyard plugin;
    private final Set<UUID> fatiguedPlayers = ConcurrentHashMap.newKeySet();
    private final Set<String> blocksBeingCollected = ConcurrentHashMap.newKeySet();
    private record CollectionState(Location location, long startTime, long durationMs, BukkitTask task) {}
    private final Map<UUID, CollectionState> activeCollections = new HashMap<>();
    public BoxManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public boolean startCollection(Player player, Location boxLocation) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        double maxDist = plugin.getPluginConfig().getMaxBreakDistance();
        if (player.getLocation().distance(boxLocation) > maxDist) {
            player.sendMessage(ChatUtil.color("&cVous êtes trop loin de ce carton !"));
            return false;
        }
        if (!data.hasUnlimitedEnergy() && data.getCurrentEnergy() <= 0) {
            applyFatigue(player, data);
            player.sendActionBar(Component.text(
                    ChatUtil.color("&c[Énergie épuisée] Reposez-vous ou achetez une boisson !")
            ));
            return false;
        }
        int maxCapacity = getBagCapacity(data.getBagLevel());
        if (data.getCurrentBoxes() >= maxCapacity) {
            // Quête : remplir son sac
            plugin.getQuestManager().onProgress(player, DailyQuest.Type.REACH_BAG_FULL, 0);
            player.sendActionBar(Component.text(
                    ChatUtil.color("&eSac plein ! Va vendre tes cartons dans la zone de vente.")
            ));
            return false;
        }
        CollectionState existing = activeCollections.get(player.getUniqueId());
        if (existing != null) {
            String existingKey = LocationUtil.locKey(existing.location());
            String newKey      = LocationUtil.locKey(boxLocation);
            if (existingKey.equals(newKey)) return false;
            cancelCollection(player);
        }
        String blockKey = LocationUtil.locKey(boxLocation);
        if (blocksBeingCollected.contains(blockKey)) {
            player.sendActionBar(Component.text(ChatUtil.color("&eCe carton est déjà en cours de collecte !")));
            return false;
        }
        blocksBeingCollected.add(blockKey);
        long durationMs = getToolCooldown(data.getToolLevel());
        long startTime  = System.currentTimeMillis();
        player.playSound(player.getLocation(), Sound.BLOCK_CHISELED_BOOKSHELF_BREAK, 0.5f, 0.8f);
        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            long elapsed = System.currentTimeMillis() - startTime;
            float progress = Math.min(1.0f, (float) elapsed / durationMs);
            if (boxLocation.getBlock().getType() == Material.AIR) {
                blocksBeingCollected.remove(blockKey);
                CollectionState s = activeCollections.remove(player.getUniqueId());
                if (s != null) s.task().cancel();
                return;
            }
            if (player.getLocation().distance(boxLocation) > maxDist + 1.0) {
                blocksBeingCollected.remove(blockKey);
                cancelCollection(player);
                player.sendActionBar(Component.text(ChatUtil.color("&cCollecte annulée ! Trop loin.")));
                return;
            }
            if (progress >= 1.0f) {
                blocksBeingCollected.remove(blockKey);
                CollectionState done = activeCollections.remove(player.getUniqueId());
                if (done != null) done.task().cancel();
                finalizeCollection(player, boxLocation, data);
            } else {
                player.sendActionBar(Component.text(
                        ChatUtil.color("&b" + buildProgressBar(progress) + " &fCollecte en cours...")
                ));
            }
        }, 0L, 2L);
        activeCollections.put(player.getUniqueId(), new CollectionState(boxLocation, startTime, durationMs, task));
        return true;
    }
    private void finalizeCollection(Player player, Location boxLocation, PlayerData data) {
        if (!data.hasUnlimitedEnergy() && data.getCurrentEnergy() <= 0) {
            applyFatigue(player, data);
            return;
        }
        int maxCapacity = getBagCapacity(data.getBagLevel());
        if (data.getCurrentBoxes() >= maxCapacity) {
            player.sendActionBar(Component.text(ChatUtil.color("&eSac plein !")));
            return;
        }
        int boxesToCollect = calculateBoxesWithProbability(data.getToolLevel());
        Material boxMat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        if (boxMat == null) boxMat = Material.NOTE_BLOCK;
        List<Location> targets = new ArrayList<>();
        targets.add(boxLocation);
        if (boxesToCollect > 1 && boxLocation.getWorld() != null) {
            outer:
            for (int dx = -1; dx <= 1; dx++) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dz = -1; dz <= 1; dz++) {
                        if (dx == 0 && dy == 0 && dz == 0) continue;
                        if (targets.size() >= boxesToCollect) break outer;
                        Location nearby = boxLocation.clone().add(dx, dy, dz);
                        if (nearby.getBlock().getType() == boxMat
                                && !blocksBeingCollected.contains(LocationUtil.locKey(nearby))) {
                            targets.add(nearby);
                        }
                    }
                }
            }
        }
        int collected = 0;
        double costPerBox = getEnergyCostForLevel(data.getToolLevel());
        for (Location loc : targets) {
            if (data.getCurrentBoxes() >= maxCapacity) break;
            if (!data.hasUnlimitedEnergy() && data.getCurrentEnergy() < costPerBox) break;
            String key = LocationUtil.locKey(loc);
            blocksBeingCollected.add(key);
            if (!data.hasUnlimitedEnergy()) data.removeEnergy(costPerBox);
            loc.getBlock().setType(Material.AIR, false);
            plugin.getEventManager().onBoxBroken(loc);
            plugin.getSectorManager().markBroken(loc);
            data.addBox();
            data.incrementBoxesBroken();
            collected++;
            blocksBeingCollected.remove(key);
        }
        if (collected == 0) {
            player.sendActionBar(Component.text(ChatUtil.color("&eSac plein !")));
            return;
        }
        // Quête : casser des cartons
        plugin.getQuestManager().onProgress(player, DailyQuest.Type.BREAK_BOXES, collected);
        // Quête : sac plein
        if (data.getCurrentBoxes() >= maxCapacity) {
            plugin.getQuestManager().onProgress(player, DailyQuest.Type.REACH_BAG_FULL, 1);
        }
        removeFatigue(player, data);
        player.playSound(player.getLocation(), Sound.BLOCK_CHISELED_BOOKSHELF_BREAK, 1.0f, 1.2f);
        String msg = collected > 1
                ? ChatUtil.color("&a+" + collected + " cartons collectés !")
                : ChatUtil.color("&aSac: &f" + data.getCurrentBoxes() + "/" + maxCapacity
                + " &7| &7Énergie: &f" + String.format("%.0f", data.getCurrentEnergy()));
        player.sendActionBar(Component.text(msg));
    }
    private int calculateBoxesWithProbability(int toolLevel) {
        List<PluginConfig.ToolUpgrade> upgrades = plugin.getPluginConfig().getToolUpgrades();
        PluginConfig.ToolUpgrade current = upgrades.stream()
                .filter(u -> u.level() == toolLevel)
                .findFirst().orElse(null);
        if (current == null) return 1;
        int baseBoxes = current.boxesPerCollection();
        double extraChance = current.extraBoxChance();
        int guaranteedExtra = (int) Math.floor(extraChance);
        double remainder = extraChance - guaranteedExtra;
        return baseBoxes + guaranteedExtra + (Math.random() < remainder ? 1 : 0);
    }
    /** Le coût en énergie augmente légèrement avec le niveau d'outil (équilibrage). */
    public double getEnergyCostForLevel(int toolLevel) {
        double base = plugin.getPluginConfig().getEnergyCostPerBox();
        return base + (toolLevel - 1) * 0.5; // +0.5 par niveau
    }
    public void cancelCollection(Player player) {
        CollectionState state = activeCollections.remove(player.getUniqueId());
        if (state != null) {
            blocksBeingCollected.remove(LocationUtil.locKey(state.location()));
            state.task().cancel();
        }
    }
    public boolean isCollecting(UUID uuid) { return activeCollections.containsKey(uuid); }
    public float getCollectionProgress(UUID uuid) {
        CollectionState state = activeCollections.get(uuid);
        if (state == null) return -1f;
        long elapsed = System.currentTimeMillis() - state.startTime();
        return Math.min(1.0f, (float) elapsed / state.durationMs());
    }
    private String buildProgressBar(float progress) {
        int total  = 20;
        int filled = Math.round(progress * total);
        StringBuilder bar = new StringBuilder("&b[");
        for (int i = 0; i < total; i++) {
            bar.append(i < filled ? "&b█" : "&8░");
        }
        bar.append("&b]");
        return bar.toString();
    }
    public void flushDestructionQueue() { /* plus rien à flusher */ }
    public void queueDestruction(Location loc) { loc.getBlock().setType(Material.AIR, false); }
    public void applyFatigue(Player player, PlayerData data) {
        UUID uuid = player.getUniqueId();
        if (fatiguedPlayers.add(uuid)) {
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 2, false, false, false
            ));
        }
    }
    public void removeFatigue(Player player, PlayerData data) {
        UUID uuid = player.getUniqueId();
        if (fatiguedPlayers.remove(uuid) && data.getCurrentEnergy() > 0) {
            player.removePotionEffect(PotionEffectType.SLOWNESS);
        }
    }
    public boolean isFatigued(UUID uuid) { return fatiguedPlayers.contains(uuid); }
    public int getBagCapacity(int level) {
        return plugin.getPluginConfig().getBagUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToInt(PluginConfig.BagUpgrade::capacity)
                .findFirst().orElse(10);
    }
    public long getToolCooldown(int level) {
        return plugin.getPluginConfig().getToolUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToLong(PluginConfig.ToolUpgrade::cooldownMs)
                .findFirst().orElse(1000L);
    }
    public int getMaxEnergyForLevel(int level) {
        return plugin.getPluginConfig().getEnergyUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToInt(PluginConfig.EnergyUpgrade::maxEnergy)
                .findFirst().orElse(100);
    }
    public double getEnergyRegenForLevel(int level) {
        return plugin.getPluginConfig().getEnergyUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToDouble(PluginConfig.EnergyUpgrade::regenPerSec)
                .findFirst().orElse(1.0);
    }
}