package fr.cleanthebackyard.cleanTheBackyard.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class BoxManager {

    private final CleanTheBackyard plugin;

    private final Set<UUID> fatiguedPlayers = new HashSet<>();

    // Blocs en cours de collecte (empêche le re-clic par un autre joueur)
    private final Set<String> blocksBeingCollected = new HashSet<>();

    private record CollectionState(Location location, long startTime, long durationMs, BukkitTask task) {}
    private final Map<UUID, CollectionState> activeCollections = new HashMap<>();

    public BoxManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean startCollection(Player player, Location boxLocation) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;

        double maxDist = plugin.getPluginConfig().getMaxBreakDistance();
        if (player.getLocation().distance(boxLocation) > maxDist) {
            player.sendMessage(ChatUtil.colored("&cVous êtes trop loin de ce carton !"));
            return false;
        }

        // Énergie (sauf si unlimited energy active)
        if (!data.hasUnlimitedEnergy() && data.getCurrentEnergy() <= 0) {
            applyFatigue(player, data);
            player.sendActionBar(Component.text(
                    ChatUtil.color("&c[Énergie épuisée] Reposez-vous ou achetez une boisson !")
            ));
            return false;
        }

        int maxCapacity = getBagCapacity(data.getBagLevel());
        if (data.getCurrentBoxes() >= maxCapacity) {
            player.sendActionBar(Component.text(
                    ChatUtil.color("&eSac plein ! Va vendre tes cartons dans la zone de vente.")
            ));
            return false;
        }

        CollectionState existing = activeCollections.get(player.getUniqueId());
        if (existing != null) {
            String existingKey = locKey(existing.location());
            String newKey      = locKey(boxLocation);
            if (existingKey.equals(newKey)) return false;
            cancelCollection(player);
        }

        // Empêche un autre joueur de cliquer le même bloc
        String blockKey = locKey(boxLocation);
        if (blocksBeingCollected.contains(blockKey)) {
            player.sendActionBar(Component.text(ChatUtil.color("&eCe carton est déjà en cours de collecte !")));
            return false;
        }
        blocksBeingCollected.add(blockKey);

        long durationMs = getToolCooldown(data.getToolLevel());
        long startTime  = System.currentTimeMillis();

        player.playSound(player.getLocation(), Sound.BLOCK_CHISELED_BOOKSHELF_BREAK, 0.5f, 0.8f);

        BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
            long elapsed = System.currentTimeMillis() - startTime;
            float progress = Math.min(1.0f, (float) elapsed / durationMs);

            if (boxLocation.getBlock().getType() == Material.AIR) {
                // Bloc déjà disparu (collecté par regen ou autre)
                blocksBeingCollected.remove(blockKey);
                CollectionState s = activeCollections.remove(player.getUniqueId());
                if (s != null) s.task().cancel();
                return;
            }

            if (player.getLocation().distance(boxLocation) > maxDist + 1.0) {
                blocksBeingCollected.remove(blockKey);
                cancelCollection(player);
                player.sendActionBar(Component.text(ChatUtil.color("&cCollecte annulée ! Trop loin.")));
                return;
            }

            if (progress >= 1.0f) {
                blocksBeingCollected.remove(blockKey);
                CollectionState done = activeCollections.remove(player.getUniqueId());
                if (done != null) done.task().cancel();
                finalizeCollection(player, boxLocation, data);
            } else {
                player.sendActionBar(Component.text(
                        ChatUtil.color("&b" + buildProgressBar(progress) + " &fCollecte en cours...")
                ));
            }
        }, 0L, 2L);

        activeCollections.put(player.getUniqueId(), new CollectionState(boxLocation, startTime, durationMs, task));
        return true;
    }

    private void finalizeCollection(Player player, Location boxLocation, PlayerData data) {
        if (!data.hasUnlimitedEnergy() && data.getCurrentEnergy() <= 0) {
            applyFatigue(player, data);
            return;
        }

        int boxesPerCollection = getBoxesPerCollection(data.getToolLevel());
        int maxCapacity        = getBagCapacity(data.getBagLevel());
        int toCollect          = Math.min(boxesPerCollection, maxCapacity - data.getCurrentBoxes());

        if (toCollect <= 0) {
            player.sendActionBar(Component.text(ChatUtil.color("&eSac plein !")));
            return;
        }

        if (!data.hasUnlimitedEnergy()) {
            data.removeEnergy(plugin.getPluginConfig().getEnergyCostPerBox() * toCollect);
        }
        for (int i = 0; i < toCollect; i++) {
            data.addBox();
            data.incrementBoxesBroken();
        }

        removeFatigue(player, data);

        // Destruction IMMÉDIATE — plus de queue
        boxLocation.getBlock().setType(Material.AIR, false);

        plugin.getEventManager().onBoxBroken(boxLocation);

        player.playSound(player.getLocation(), Sound.BLOCK_CHISELED_BOOKSHELF_BREAK, 1.0f, 1.2f);

        String msg = toCollect > 1
                ? ChatUtil.color("&a+" + toCollect + " cartons collectés !")
                : ChatUtil.color("&aSac: &f" + data.getCurrentBoxes() + "/" + maxCapacity
                + " &7| &7Énergie: &f" + String.format("%.0f", data.getCurrentEnergy()));
        player.sendActionBar(Component.text(msg));
    }

    public void cancelCollection(Player player) {
        CollectionState state = activeCollections.remove(player.getUniqueId());
        if (state != null) {
            blocksBeingCollected.remove(locKey(state.location()));
            state.task().cancel();
        }
    }

    public boolean isCollecting(UUID uuid) {
        return activeCollections.containsKey(uuid);
    }

    public float getCollectionProgress(UUID uuid) {
        CollectionState state = activeCollections.get(uuid);
        if (state == null) return -1f;
        long elapsed = System.currentTimeMillis() - state.startTime();
        return Math.min(1.0f, (float) elapsed / state.durationMs());
    }

    private String buildProgressBar(float progress) {
        int total  = 20;
        int filled = Math.round(progress * total);
        StringBuilder bar = new StringBuilder("&b[");
        for (int i = 0; i < total; i++) {
            bar.append(i < filled ? "&b█" : "&8░");
        }
        bar.append("&b]");
        return bar.toString();
    }

    // Conservé pour la compatibilité SectorManager (regen flush)
    public void flushDestructionQueue() { /* plus rien à flusher */ }
    public void queueDestruction(Location loc) { loc.getBlock().setType(Material.AIR, false); }

    public void applyFatigue(Player player, PlayerData data) {
        UUID uuid = player.getUniqueId();
        if (!fatiguedPlayers.contains(uuid)) {
            fatiguedPlayers.add(uuid);
            player.addPotionEffect(new PotionEffect(
                    PotionEffectType.SLOWNESS, Integer.MAX_VALUE, 2, false, false, false
            ));
        }
    }

    public void removeFatigue(Player player, PlayerData data) {
        UUID uuid = player.getUniqueId();
        if (fatiguedPlayers.contains(uuid) && data.getCurrentEnergy() > 0) {
            fatiguedPlayers.remove(uuid);
            player.removePotionEffect(PotionEffectType.SLOWNESS);
        }
    }

    public boolean isFatigued(UUID uuid) { return fatiguedPlayers.contains(uuid); }

    public int getBagCapacity(int level) {
        return plugin.getPluginConfig().getBagUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToInt(PluginConfig.BagUpgrade::capacity)
                .findFirst().orElse(10);
    }

    public long getToolCooldown(int level) {
        return plugin.getPluginConfig().getToolUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToLong(PluginConfig.ToolUpgrade::cooldownMs)
                .findFirst().orElse(1000L);
    }

    public int getBoxesPerCollection(int level) {
        return plugin.getPluginConfig().getToolUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToInt(PluginConfig.ToolUpgrade::boxesPerCollection)
                .findFirst().orElse(1);
    }

    public int getMaxEnergyForLevel(int level) {
        return plugin.getPluginConfig().getEnergyUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToInt(PluginConfig.EnergyUpgrade::maxEnergy)
                .findFirst().orElse(100);
    }

    public double getEnergyRegenForLevel(int level) {
        return plugin.getPluginConfig().getEnergyUpgrades().stream()
                .filter(u -> u.level() == level)
                .mapToDouble(PluginConfig.EnergyUpgrade::regenPerSec)
                .findFirst().orElse(1.0);
    }

    private String locKey(Location l) {
        return l.getBlockX() + ":" + l.getBlockY() + ":" + l.getBlockZ();
    }
}