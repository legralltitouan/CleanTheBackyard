package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.List;

/**
 * GUI du Garage d'ameliorations.
 * 3 colonnes : Sac | Outil | Energie
 */
public class UpgradeGui {

    private static final String TITLE = ChatUtil.color("&8[&6Garage&8] &7Ameliorations");

    private final CleanTheBackyard plugin;

    public UpgradeGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        Inventory inv = Bukkit.createInventory(null, 27, TITLE);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;

        buildGui(inv, data);
        player.openInventory(inv);
    }

    private void buildGui(Inventory inv, PlayerData data) {
        // Fond decoratif
        ItemStack glass = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE)
                .name(" ").build();
        for (int i = 0; i < 27; i++) inv.setItem(i, glass);

        // ── Colonne Sac (slots 2, 11, 20) ─────────────────────────
        ItemStack bagItem = buildUpgradeItem(
                Material.CHEST,
                "&6Ameliorer le Sac",
                data.getBagLevel(),
                plugin.getPluginConfig().getBagUpgrades().size(),
                plugin.getBoxManager().getBagCapacity(data.getBagLevel()),
                getNextBagCost(data.getBagLevel()),
                "capacite: " + plugin.getBoxManager().getBagCapacity(data.getBagLevel()) + " cartons",
                "prochaine: " + getNextBagCapacity(data.getBagLevel()) + " cartons"
        );
        inv.setItem(2, bagItem);

        // ── Colonne Outil (slots 4, 13, 22) ──────────────────────
        ItemStack toolItem = buildUpgradeItem(
                Material.IRON_PICKAXE,
                "&bAmeliorer l'Outil",
                data.getToolLevel(),
                plugin.getPluginConfig().getToolUpgrades().size(),
                (int) plugin.getBoxManager().getToolCooldown(data.getToolLevel()),
                getNextToolCost(data.getToolLevel()),
                "cooldown: " + plugin.getBoxManager().getToolCooldown(data.getToolLevel()) + "ms",
                "prochain: " + getNextToolCooldown(data.getToolLevel()) + "ms"
        );
        inv.setItem(4, toolItem);

        // ── Colonne Energie (slots 6, 15, 24) ─────────────────────
        ItemStack energyItem = buildUpgradeItem(
                Material.GLOWSTONE,
                "&eAmeliorer l'Energie",
                data.getEnergyLevel(),
                plugin.getPluginConfig().getEnergyUpgrades().size(),
                plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel()),
                getNextEnergyCost(data.getEnergyLevel()),
                "max: " + plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel()),
                "regen: " + plugin.getBoxManager().getEnergyRegenForLevel(data.getEnergyLevel()) + "/s"
        );
        inv.setItem(6, energyItem);

        // Solde
        ItemStack balanceItem = new ItemBuilder(Material.GOLD_INGOT)
                .name("&aSolde: &f$" + String.format("%.0f", data.getBalance()))
                .build();
        inv.setItem(22, balanceItem);
    }

    private ItemStack buildUpgradeItem(Material mat, String title, int currentLevel,
                                       int maxLevel, int currentValue, long nextCost,
                                       String currentInfo, String nextInfo) {
        boolean isMax = currentLevel >= maxLevel;
        return new ItemBuilder(mat)
                .name(title + " &8(Niv " + currentLevel + "/" + maxLevel + ")")
                .lore(List.of(
                        ChatUtil.color("&7Actuel : &f" + currentInfo),
                        ChatUtil.color(isMax ? "&aMAXIMUM ATTEINT" : "&7Prochain : &f" + nextInfo),
                        " ",
                        ChatUtil.color(isMax ? "&8[MAX]" : "&eCout : &f$" + nextCost),
                        ChatUtil.color(isMax ? "" : "&aCliquez pour ameliorer !")
                ))
                .build();
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        int slot = event.getRawSlot();
        switch (slot) {
            case 2 -> upgradeBag(player, data);
            case 4 -> upgradeTool(player, data);
            case 6 -> upgradeEnergy(player, data);
        }

        // Rafraichit le GUI
        buildGui(event.getInventory(), data);
        return true;
    }

    // ── Upgrade Logic ──────────────────────────────────────────────────

    private void upgradeBag(Player player, PlayerData data) {
        List<PluginConfig.BagUpgrade> upgrades = plugin.getPluginConfig().getBagUpgrades();
        int nextLevel = data.getBagLevel() + 1;
        if (nextLevel > upgrades.size()) { player.sendMessage(ChatUtil.colored("&cNiveau maximum atteint !")); return; }

        PluginConfig.BagUpgrade next = upgrades.stream().filter(u -> u.level() == nextLevel).findFirst().orElse(null);
        if (next == null) return;

        if (plugin.getEconomyManager().debit(player, next.cost(), "Amelioration Sac Niv " + nextLevel)) {
            data.setBagLevel(nextLevel);
            player.sendMessage(ChatUtil.colored("&aSac ameliore ! Capacite : " + next.capacity() + " cartons"));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        }
    }

    private void upgradeTool(Player player, PlayerData data) {
        List<PluginConfig.ToolUpgrade> upgrades = plugin.getPluginConfig().getToolUpgrades();
        int nextLevel = data.getToolLevel() + 1;
        if (nextLevel > upgrades.size()) { player.sendMessage(ChatUtil.colored("&cNiveau maximum atteint !")); return; }

        PluginConfig.ToolUpgrade next = upgrades.stream().filter(u -> u.level() == nextLevel).findFirst().orElse(null);
        if (next == null) return;

        if (plugin.getEconomyManager().debit(player, next.cost(), "Amelioration Outil Niv " + nextLevel)) {
            data.setToolLevel(nextLevel);
            player.sendMessage(ChatUtil.colored("&aOutil ameliore ! Cooldown : " + next.cooldownMs() + "ms"));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        }
    }

    private void upgradeEnergy(Player player, PlayerData data) {
        List<PluginConfig.EnergyUpgrade> upgrades = plugin.getPluginConfig().getEnergyUpgrades();
        int nextLevel = data.getEnergyLevel() + 1;
        if (nextLevel > upgrades.size()) { player.sendMessage(ChatUtil.colored("&cNiveau maximum atteint !")); return; }

        PluginConfig.EnergyUpgrade next = upgrades.stream().filter(u -> u.level() == nextLevel).findFirst().orElse(null);
        if (next == null) return;

        if (plugin.getEconomyManager().debit(player, next.cost(), "Amelioration Energie Niv " + nextLevel)) {
            data.setEnergyLevel(nextLevel);
            // Remplit l'energie au nouveau max
            data.setCurrentEnergy(next.maxEnergy());
            player.sendMessage(ChatUtil.colored("&aEnergie amelioree ! Max : " + next.maxEnergy() + " | Regen : " + next.regenPerSec() + "/s"));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        }
    }

    // ── Helpers pour les niveaux suivants ─────────────────────────────

    private long getNextBagCost(int currentLevel) {
        return plugin.getPluginConfig().getBagUpgrades().stream()
                .filter(u -> u.level() == currentLevel + 1)
                .mapToLong(PluginConfig.BagUpgrade::cost).findFirst().orElse(-1);
    }

    private int getNextBagCapacity(int currentLevel) {
        return plugin.getPluginConfig().getBagUpgrades().stream()
                .filter(u -> u.level() == currentLevel + 1)
                .mapToInt(PluginConfig.BagUpgrade::capacity).findFirst().orElse(-1);
    }

    private long getNextToolCost(int currentLevel) {
        return plugin.getPluginConfig().getToolUpgrades().stream()
                .filter(u -> u.level() == currentLevel + 1)
                .mapToLong(PluginConfig.ToolUpgrade::cost).findFirst().orElse(-1);
    }

    private long getNextToolCooldown(int currentLevel) {
        return plugin.getPluginConfig().getToolUpgrades().stream()
                .filter(u -> u.level() == currentLevel + 1)
                .mapToLong(PluginConfig.ToolUpgrade::cooldownMs).findFirst().orElse(-1);
    }

    private long getNextEnergyCost(int currentLevel) {
        return plugin.getPluginConfig().getEnergyUpgrades().stream()
                .filter(u -> u.level() == currentLevel + 1)
                .mapToLong(PluginConfig.EnergyUpgrade::cost).findFirst().orElse(-1);
    }
}
