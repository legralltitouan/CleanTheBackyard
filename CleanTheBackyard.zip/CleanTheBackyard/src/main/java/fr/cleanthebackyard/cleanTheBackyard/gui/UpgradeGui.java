package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.ItemBuilder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class UpgradeGui {

    private static final String TITLE = ChatUtil.color("&8[&6Garage&8] &7Ameliorations");
    private final CleanTheBackyard plugin;

    public UpgradeGui(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public void open(Player player) {
        CtbHolder holder = new CtbHolder(GuiManager.GuiType.UPGRADE);
        Inventory inv = Bukkit.createInventory(holder, 27, TITLE);
        holder.setInventory(inv);
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        buildGui(inv, data);
        player.openInventory(inv);
    }

    private void buildGui(Inventory inv, PlayerData data) {
        ItemStack glass = new ItemBuilder(Material.GRAY_STAINED_GLASS_PANE).name(" ").build();
        for (int i = 0; i < 27; i++) inv.setItem(i, glass);

        ItemStack bagItem = buildUpgradeItem(
                Material.CHEST,
                "&6Ameliorer le Sac",
                data.getBagLevel(),
                plugin.getPluginConfig().getBagUpgrades().size(),
                plugin.getBoxManager().getBagCapacity(data.getBagLevel()),
                getNextBagCost(data.getBagLevel()),
                "capacite: " + plugin.getBoxManager().getBagCapacity(data.getBagLevel()) + " cartons",
                "prochaine: " + getNextBagCapacity(data.getBagLevel()) + " cartons"
        );
        inv.setItem(2, bagItem);

        ItemStack toolItem = buildToolUpgradeItem(data);
        inv.setItem(4, toolItem);

        ItemStack energyItem = buildUpgradeItem(
                Material.GLOWSTONE,
                "&eAmeliorer l'Energie",
                data.getEnergyLevel(),
                plugin.getPluginConfig().getEnergyUpgrades().size(),
                plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel()),
                getNextEnergyCost(data.getEnergyLevel()),
                "max: " + plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel()),
                "regen: " + plugin.getBoxManager().getEnergyRegenForLevel(data.getEnergyLevel()) + "/s"
        );
        inv.setItem(6, energyItem);

        ItemStack balanceItem = new ItemBuilder(Material.GOLD_INGOT)
                .name("&aSolde: &f$" + String.format("%.0f", data.getBalance()))
                .build();
        inv.setItem(22, balanceItem);
    }

    private ItemStack buildToolUpgradeItem(PlayerData data) {
        int currentLevel = data.getToolLevel();
        int maxLevel = plugin.getPluginConfig().getToolUpgrades().size();
        boolean isMax = currentLevel >= maxLevel;

        long currentValue = plugin.getBoxManager().getToolCooldown(currentLevel);
        long nextCost = getNextToolCost(currentLevel);
        String currentInfo = "cooldown: " + currentValue + "ms";
        String nextInfo = "";
        String chanceStr = "";

        if (!isMax) {
            PluginConfig.ToolUpgrade nextUpgrade = plugin.getPluginConfig().getToolUpgrade(currentLevel + 1);
            if (nextUpgrade != null) {
                nextInfo = "cooldown: " + nextUpgrade.cooldownMs() + "ms";
                double extraChance = nextUpgrade.extraBoxChance();
                int guaranteedExtra = (int) Math.floor(extraChance);
                double probaRemainder = extraChance - guaranteedExtra;

                if (extraChance > 0) {
                    List<String> parts = new ArrayList<>();
                    if (guaranteedExtra > 0) parts.add("+" + guaranteedExtra + " boîte(s) garantie(s)");
                    if (probaRemainder > 0) parts.add((int) (probaRemainder * 100) + "% pour +1 boîte supplémentaire");
                    if (!parts.isEmpty()) chanceStr = "&7Probabilité: &f" + String.join(", ", parts);
                }
            }
        }

        List<String> lore = new ArrayList<>();
        lore.add(ChatUtil.color("&7Actuel : &f" + currentInfo));
        lore.add(ChatUtil.color(isMax ? "&aMAXIMUM ATTEINT" : "&7Prochain : &f" + nextInfo));
        if (!chanceStr.isEmpty()) lore.add(ChatUtil.color(chanceStr));
        lore.add(" ");
        lore.add(ChatUtil.color(isMax ? "&8[MAX]" : "&eCout : &f$" + nextCost));
        if (!isMax) lore.add(ChatUtil.color("&aCliquez pour ameliorer !"));

        return new ItemBuilder(Material.IRON_PICKAXE)
                .name("&bAmeliorer l'Outil &8(Niv " + currentLevel + "/" + maxLevel + ")")
                .lore(lore)
                .build();
    }

    private ItemStack buildUpgradeItem(Material mat, String title, int currentLevel,
                                       int maxLevel, int currentValue, long nextCost,
                                       String currentInfo, String nextInfo) {
        boolean isMax = currentLevel >= maxLevel;
        List<String> lore = new ArrayList<>();
        lore.add(ChatUtil.color("&7Actuel : &f" + currentInfo));
        lore.add(ChatUtil.color(isMax ? "&aMAXIMUM ATTEINT" : "&7Prochain : &f" + nextInfo));
        lore.add(" ");
        lore.add(ChatUtil.color(isMax ? "&8[MAX]" : "&eCout : &f$" + nextCost));
        if (!isMax) lore.add(ChatUtil.color("&aCliquez pour ameliorer !"));
        return new ItemBuilder(mat)
                .name(title + " &8(Niv " + currentLevel + "/" + maxLevel + ")")
                .lore(lore)
                .build();
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return true;

        int slot = event.getRawSlot();
        switch (slot) {
            case 2 -> upgradeBag(player, data);
            case 4 -> upgradeTool(player, data);
            case 6 -> upgradeEnergy(player, data);
        }

        buildGui(event.getInventory(), data);
        return true;
    }

    private void upgradeBag(Player player, PlayerData data) {
        int nextLevel = data.getBagLevel() + 1;
        PluginConfig.BagUpgrade next = plugin.getPluginConfig().getBagUpgrade(nextLevel);
        if (next == null) { player.sendMessage(ChatUtil.color("&cNiveau maximum atteint !")); return; }
        if (plugin.getEconomyManager().debit(player, next.cost(), "Amelioration Sac Niv " + nextLevel)) {
            data.setBagLevel(nextLevel);
            player.sendMessage(ChatUtil.color("&aSac ameliore ! Capacite : " + next.capacity() + " cartons"));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        }
    }

    private void upgradeTool(Player player, PlayerData data) {
        int nextLevel = data.getToolLevel() + 1;
        PluginConfig.ToolUpgrade next = plugin.getPluginConfig().getToolUpgrade(nextLevel);
        if (next == null) { player.sendMessage(ChatUtil.color("&cNiveau maximum atteint !")); return; }
        if (plugin.getEconomyManager().debit(player, next.cost(), "Amelioration Outil Niv " + nextLevel)) {
            data.setToolLevel(nextLevel);
            player.sendMessage(ChatUtil.color("&aOutil ameliore ! Cooldown : " + next.cooldownMs() + "ms"));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        }
    }

    private void upgradeEnergy(Player player, PlayerData data) {
        int nextLevel = data.getEnergyLevel() + 1;
        PluginConfig.EnergyUpgrade next = plugin.getPluginConfig().getEnergyUpgrade(nextLevel);
        if (next == null) { player.sendMessage(ChatUtil.color("&cNiveau maximum atteint !")); return; }
        if (plugin.getEconomyManager().debit(player, next.cost(), "Amelioration Energie Niv " + nextLevel)) {
            data.setEnergyLevel(nextLevel);
            data.setCurrentEnergy(next.maxEnergy());
            player.sendMessage(ChatUtil.color("&aEnergie amelioree ! Max : " + next.maxEnergy() + " | Regen : " + next.regenPerSec() + "/s"));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.0f);
        }
    }

    private long getNextBagCost(int currentLevel) {
        PluginConfig.BagUpgrade u = plugin.getPluginConfig().getBagUpgrade(currentLevel + 1);
        return u != null ? u.cost() : -1;
    }

    private int getNextBagCapacity(int currentLevel) {
        PluginConfig.BagUpgrade u = plugin.getPluginConfig().getBagUpgrade(currentLevel + 1);
        return u != null ? u.capacity() : -1;
    }

    private long getNextToolCost(int currentLevel) {
        PluginConfig.ToolUpgrade u = plugin.getPluginConfig().getToolUpgrade(currentLevel + 1);
        return u != null ? u.cost() : -1;
    }

    private long getNextEnergyCost(int currentLevel) {
        PluginConfig.EnergyUpgrade u = plugin.getPluginConfig().getEnergyUpgrade(currentLevel + 1);
        return u != null ? u.cost() : -1;
    }
}
