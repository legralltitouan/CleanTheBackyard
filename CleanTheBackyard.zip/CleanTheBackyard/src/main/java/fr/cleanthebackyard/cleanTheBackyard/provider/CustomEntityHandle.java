package fr.cleanthebackyard.cleanTheBackyard.provider;

import org.bukkit.entity.Entity;

/**
 * Représente une entité spawnée par le plugin, quelle qu'en soit la source
 * (vanilla, MythicMobs, ModelEngine).
 *
 * On s'appuie toujours sur une Entity Bukkit sous-jacente (le bukkitEntity)
 * pour pouvoir téléporter, lire la position, supprimer, etc.
 */
public class CustomEntityHandle {

    private final Entity bukkitEntity;
    private final String sourceTag; // "vanilla:BEE", "mythic:GoldenDrone", …

    public CustomEntityHandle(Entity bukkitEntity, String sourceTag) {
        this.bukkitEntity = bukkitEntity;
        this.sourceTag = sourceTag;
    }

    public Entity getBukkitEntity() { return bukkitEntity; }
    public String getSourceTag() { return sourceTag; }

    public boolean isValid() {
        return bukkitEntity != null && bukkitEntity.isValid() && !bukkitEntity.isDead();
    }

    public void remove() {
        if (bukkitEntity != null && bukkitEntity.isValid()) {
            bukkitEntity.remove();
        }
    }
}
