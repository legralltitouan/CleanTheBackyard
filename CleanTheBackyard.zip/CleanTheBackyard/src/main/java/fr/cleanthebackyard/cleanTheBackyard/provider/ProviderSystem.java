package fr.cleanthebackyard.cleanTheBackyard.provider;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;

/**
 * Abstractions vanilla / ItemsAdder / MythicMobs.
 */
public record ProviderSystem(
        BlockProvider     block,
        EntityProvider    entity,
        FurnitureProvider furniture) {

    public static ProviderSystem create(CleanTheBackyard plugin) {
        return new ProviderSystem(
                new BlockProvider(plugin),
                new EntityProvider(plugin),
                new FurnitureProvider(plugin));
    }
}
