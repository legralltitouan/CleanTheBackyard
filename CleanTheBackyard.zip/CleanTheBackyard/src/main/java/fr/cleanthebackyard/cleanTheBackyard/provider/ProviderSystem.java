package fr.cleanthebackyard.cleanTheBackyard.provider;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
/**
 * Abstractions vanilla / ItemsAdder / MythicMobs + index spatial des cartons.
 */
public record ProviderSystem(
        BlockProvider     block,
        EntityProvider    entity,
        FurnitureProvider furniture,
        CartonIndex       cartonIndex) {
    public static ProviderSystem create(CleanTheBackyard plugin) {
        CartonIndex index = new CartonIndex();
        return new ProviderSystem(
                new BlockProvider(plugin, index),
                new EntityProvider(plugin),
                new FurnitureProvider(plugin),
                index);
    }
}