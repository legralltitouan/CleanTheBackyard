package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.InventoryView;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GuiManager {

    public enum GuiType {
        UPGRADE, VENDING_MACHINE, DRONE_SHOP, QUEST, PRESTIGE, SECURITY, COLLECTION,
        HOUSE_PORTAL, HOUSE_EXIT, FURNITURE_SHOP, FURNITURE_INVENTORY
    }

    private final CleanTheBackyard plugin;
    private final Map<UUID, GuiType> openGuis = new HashMap<>();

    private final UpgradeGui upgradeGui;
    private final VendingMachineGui vendingMachineGui;
    private final ShopGui shopGui;
    private final QuestGui questGui;
    private final PrestigeGui prestigeGui;
    private final SecurityGui securityGui;
    private final CollectionGui collectionGui;
    private final HousePortalGui housePortalGui;
    private final HouseExitGui houseExitGui;
    private final FurnitureShopGui furnitureShopGui;
    private final FurnitureInventoryGui furnitureInventoryGui;

    public GuiManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.upgradeGui = new UpgradeGui(plugin);
        this.vendingMachineGui = new VendingMachineGui(plugin);
        this.shopGui = new ShopGui(plugin);
        this.questGui = new QuestGui(plugin);
        this.prestigeGui = new PrestigeGui(plugin);
        this.securityGui = new SecurityGui(plugin);
        this.collectionGui = new CollectionGui(plugin);
        this.housePortalGui = new HousePortalGui(plugin);
        this.houseExitGui = new HouseExitGui(plugin);
        this.furnitureShopGui = new FurnitureShopGui(plugin);
        this.furnitureInventoryGui = new FurnitureInventoryGui(plugin);
    }

    public void openUpgradeGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.UPGRADE);
        upgradeGui.open(player);
    }

    public void openVendingMachine(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.VENDING_MACHINE);
        vendingMachineGui.open(player);
    }

    public void openDroneShop(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.DRONE_SHOP);
        shopGui.open(player);
    }

    public void openQuestGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.QUEST);
        questGui.open(player);
    }

    public void openPrestigeGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.PRESTIGE);
        prestigeGui.open(player);
    }

    public void openSecurityGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.SECURITY);
        securityGui.open(player);
    }

    public void openCollectionGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.COLLECTION);
        collectionGui.open(player);
    }

    public void openHousePortal(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.HOUSE_PORTAL);
        housePortalGui.open(player);
    }

    public void openHouseExit(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.HOUSE_EXIT);
        houseExitGui.open(player);
    }

    public void openFurnitureShop(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.FURNITURE_SHOP);
        furnitureShopGui.open(player);
    }

    public void openFurnitureInventory(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.FURNITURE_INVENTORY);
        furnitureInventoryGui.open(player);
    }

    public boolean handleClick(Player player, InventoryClickEvent event) {
        GuiType type = openGuis.get(player.getUniqueId());
        if (type == null) return false;
        return switch (type) {
            case UPGRADE -> upgradeGui.handleClick(player, event);
            case VENDING_MACHINE -> vendingMachineGui.handleClick(player, event);
            case DRONE_SHOP -> shopGui.handleClick(player, event);
            case QUEST -> questGui.handleClick(player, event);
            case PRESTIGE -> prestigeGui.handleClick(player, event);
            case SECURITY -> securityGui.handleClick(player, event);
            case COLLECTION -> collectionGui.handleClick(player, event);
            case HOUSE_PORTAL -> housePortalGui.handleClick(player, event);
            case HOUSE_EXIT -> houseExitGui.handleClick(player, event);
            case FURNITURE_SHOP -> furnitureShopGui.handleClick(player, event);
            case FURNITURE_INVENTORY -> furnitureInventoryGui.handleClick(player, event);
        };
    }

    public boolean isCtbInventory(Inventory inv) {
        if (inv == null) return false;
        InventoryHolder holder = inv.getHolder();
        return holder instanceof CtbHolder;
    }

    public boolean isCtbView(InventoryView view) {
        if (view == null) return false;
        return isCtbInventory(view.getTopInventory());
    }

    public void onClose(Player player, Inventory inv) {
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) {
                cleanup(player);
                return;
            }
            InventoryView view = player.getOpenInventory();
            if (!isCtbView(view)) {
                cleanup(player);
            }
        });
    }

    private void cleanup(Player player) {
        GuiType type = openGuis.remove(player.getUniqueId());
        if (type == GuiType.DRONE_SHOP) shopGui.forceClear(player);
        if (type == GuiType.FURNITURE_SHOP) furnitureShopGui.forceClear(player);
        if (type == GuiType.FURNITURE_INVENTORY) furnitureInventoryGui.forceClear(player);
    }

    public boolean hasOpenGui(Player player) {
        return openGuis.containsKey(player.getUniqueId());
    }
}
