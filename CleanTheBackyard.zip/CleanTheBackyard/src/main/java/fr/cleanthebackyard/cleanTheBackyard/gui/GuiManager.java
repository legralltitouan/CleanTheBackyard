package fr.cleanthebackyard.cleanTheBackyard.gui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Registre central des GUIs ouverts.
 * Associe chaque joueur a son GUI actif pour router les clics correctement.
 */
public class GuiManager {

    public enum GuiType { UPGRADE, VENDING_MACHINE, DRONE_SHOP }

    private final CleanTheBackyard plugin;
    private final Map<UUID, GuiType> openGuis = new HashMap<>();

    private final UpgradeGui         upgradeGui;
    private final VendingMachineGui   vendingMachineGui;
    private final ShopGui             shopGui;

    public GuiManager(CleanTheBackyard plugin) {
        this.plugin           = plugin;
        this.upgradeGui       = new UpgradeGui(plugin);
        this.vendingMachineGui = new VendingMachineGui(plugin);
        this.shopGui          = new ShopGui(plugin);
    }

    public void openUpgradeGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.UPGRADE);
        upgradeGui.open(player);
    }

    public void openVendingMachine(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.VENDING_MACHINE);
        vendingMachineGui.open(player);
    }

    public void openDroneShop(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.DRONE_SHOP);
        shopGui.open(player);
    }

    /**
     * Route un clic vers le bon GUI.
     * @return true si le clic a ete pris en charge (annuler l'event).
     */
    public boolean handleClick(Player player, InventoryClickEvent event) {
        GuiType type = openGuis.get(player.getUniqueId());
        if (type == null) return false;

        return switch (type) {
            case UPGRADE        -> upgradeGui.handleClick(player, event);
            case VENDING_MACHINE-> vendingMachineGui.handleClick(player, event);
            case DRONE_SHOP     -> shopGui.handleClick(player, event);
        };
    }

    public void onClose(Player player, Inventory inv) {
        openGuis.remove(player.getUniqueId());
    }

    public boolean hasOpenGui(Player player) {
        return openGuis.containsKey(player.getUniqueId());
    }
}
