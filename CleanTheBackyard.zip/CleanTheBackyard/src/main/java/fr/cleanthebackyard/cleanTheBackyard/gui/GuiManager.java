package fr.cleanthebackyard.cleanTheBackyard.gui;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryView;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
public class GuiManager {
    public enum GuiType { UPGRADE, VENDING_MACHINE, DRONE_SHOP, QUEST, PRESTIGE }
    private final CleanTheBackyard plugin;
    private final Map<UUID, GuiType> openGuis = new HashMap<>();
    private final UpgradeGui         upgradeGui;
    private final VendingMachineGui  vendingMachineGui;
    private final ShopGui            shopGui;
    private final QuestGui           questGui;
    private final PrestigeGui        prestigeGui;
    public GuiManager(CleanTheBackyard plugin) {
        this.plugin            = plugin;
        this.upgradeGui        = new UpgradeGui(plugin);
        this.vendingMachineGui = new VendingMachineGui(plugin);
        this.shopGui           = new ShopGui(plugin);
        this.questGui          = new QuestGui(plugin);
        this.prestigeGui       = new PrestigeGui(plugin);
    }
    public void openUpgradeGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.UPGRADE);
        upgradeGui.open(player);
    }
    public void openVendingMachine(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.VENDING_MACHINE);
        vendingMachineGui.open(player);
    }
    public void openDroneShop(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.DRONE_SHOP);
        shopGui.open(player);
    }
    public void openQuestGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.QUEST);
        questGui.open(player);
    }
    public void openPrestigeGui(Player player) {
        openGuis.put(player.getUniqueId(), GuiType.PRESTIGE);
        prestigeGui.open(player);
    }
    public boolean handleClick(Player player, InventoryClickEvent event) {
        GuiType type = openGuis.get(player.getUniqueId());
        if (type == null) return false;
        return switch (type) {
            case UPGRADE         -> upgradeGui.handleClick(player, event);
            case VENDING_MACHINE -> vendingMachineGui.handleClick(player, event);
            case DRONE_SHOP      -> shopGui.handleClick(player, event);
            case QUEST           -> questGui.handleClick(player, event);
            case PRESTIGE        -> prestigeGui.handleClick(player, event);
        };
    }
    /**
     * Appelé quand un inventaire se ferme. On détecte si c'est une *vraie* fermeture
     * (le joueur n'a plus d'inventaire CTB ouvert) ou juste une transition.
     */
    public void onClose(Player player, Inventory inv) {
        // On vérifie au tick suivant si le joueur a réellement un autre inventaire CTB ouvert
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) {
                cleanup(player);
                return;
            }
            InventoryView view = player.getOpenInventory();
            String title = view.getTitle();
            // Si plus aucun titre CTB connu, on nettoie tout
            if (!isCtbTitle(title)) {
                cleanup(player);
            }
        });
    }
    private boolean isCtbTitle(String title) {
        if (title == null) return false;
        return title.contains("Garage")
                || title.contains("Distributeur")
                || title.contains("Boutique")
                || title.contains("Upgrade")
                || title.contains("Quêtes")
                || title.contains("PRESTIGE");
    }
    private void cleanup(Player player) {
        GuiType type = openGuis.remove(player.getUniqueId());
        if (type == GuiType.DRONE_SHOP) shopGui.forceClear(player);
    }
    public boolean hasOpenGui(Player player) {
        return openGuis.containsKey(player.getUniqueId());
    }
}