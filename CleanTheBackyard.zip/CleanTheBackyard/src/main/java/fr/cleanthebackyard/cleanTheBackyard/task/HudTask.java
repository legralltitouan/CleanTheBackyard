package fr.cleanthebackyard.cleanTheBackyard.task;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class HudTask extends BukkitRunnable {
    private final CleanTheBackyard plugin;
    private final Map<UUID, Long> recentGains = new HashMap<>();
    private final Map<UUID, Double> gainAmounts = new HashMap<>();
    private final Map<UUID, Double> gainMultiplier = new HashMap<>();
    private final java.util.Set<UUID> hudDisabled = ConcurrentHashMap.newKeySet();

    public HudTask(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    public boolean toggleHud(UUID uuid) {
        if (hudDisabled.contains(uuid)) {
            hudDisabled.remove(uuid);
            return true;
        }
        hudDisabled.add(uuid);
        return false;
    }

    @Override
    public void run() {

        // ItemsAdder HUD prend le relais : on coupe l'actionbar.
        boolean iaHud = plugin.getItemsAdderHudBridge() != null
                && plugin.getItemsAdderHudBridge().isActive()
                && plugin.getPluginConfig().shouldHideActionBarForIa();
        if (iaHud) {
            // On rafraîchit quand même les valeurs du HUD IA
            plugin.getItemsAdderHudBridge().pushAll();
            return;
        }
        boolean betterHud = plugin.getBetterHudBridge() != null
                && plugin.getBetterHudBridge().isActive()
                && plugin.getPluginConfig().shouldHideActionBar();
        if (betterHud) return;

        long now = System.currentTimeMillis();
        String hubName = plugin.getPluginConfig().getHubWorldName();

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            var world = player.getWorld();
            if (world != null && world.getName().equals(hubName)) continue;
            UUID uuid = player.getUniqueId();
            if (hudDisabled.contains(uuid)) continue;
            if (plugin.getBoxManager().isCollecting(uuid)) continue;
            if (plugin.getCleaningGameManager().isPlaying(uuid)) continue;
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (data == null) continue;

            boolean hasRecentGain = false;
            String gainStr = "";
            Long gainTime = recentGains.get(uuid);
            if (gainTime != null) {
                long elapsed = now - gainTime;
                if (elapsed < 1000) {
                    hasRecentGain = true;
                    Double amt = gainAmounts.get(uuid);
                    Double mul = gainMultiplier.get(uuid);
                    gainStr = buildGainString(amt != null ? amt : 0.0, mul != null ? mul : 1.0);
                } else {
                    recentGains.remove(uuid);
                    gainAmounts.remove(uuid);
                    gainMultiplier.remove(uuid);
                }
            }
            String hud = buildPermanentHud(data, hasRecentGain ? null : player);
            if (hasRecentGain) hud += ChatUtil.color(" &7| " + gainStr);
            player.sendActionBar(Component.text(hud));
        }
    }

    private String buildPermanentHud(PlayerData data, Player player) {
        double globalMult = plugin.getPluginConfig().getGlobalSellMultiplier();
        StringBuilder hud = new StringBuilder(96);
        if (data.getPrestigeLevel() > 0) hud.append(String.format("&6P%d &7| ", data.getPrestigeLevel()));
        if (data.getTalentPoints() > 0) hud.append(String.format("&d✦%d &7| ", data.getTalentPoints()));
        int maxEnergy = plugin.getBoxManager().getMaxEnergyForPlayer(data);
        hud.append("&aSolde: &f").append(NumberFormatUtil.money(data.getBalance()))
                .append(" &7| &fSac: &f").append(data.getCurrentBoxes())
                .append("/").append(plugin.getBoxManager().getBagCapacity(data.getBagLevel()))
                .append(" &7| &7Énergie: &f").append(String.format("%.0f", data.getCurrentEnergy()))
                .append("/").append(maxEnergy);
        if (player != null) {
            if (globalMult > 1.0) hud.append(String.format(" &7| &ex%.1f &fGLOBAL", globalMult));
            if (data.hasDoubleSell()) hud.append(String.format(" &7| &ex2 &f%ds", data.getDoubleSellRemainingSeconds()));
            if (data.hasBlackMarket()) hud.append(String.format(" &7| &5x3MN &f%ds", data.getBlackMarketRemainingSeconds()));
            if (data.hasUnlimitedEnergy()) hud.append(String.format(" &7| &b⚡∞ &f%ds", data.getUnlimitedEnergyRemainingSeconds()));
        }
        return ChatUtil.color(hud.toString());
    }

    public void registerGain(Player player, double amount, double multiplier) {
        UUID uuid = player.getUniqueId();
        recentGains.put(uuid, System.currentTimeMillis());
        gainAmounts.put(uuid, amount);
        gainMultiplier.put(uuid, multiplier);
    }

    public void forgetPlayer(UUID uuid) {
        recentGains.remove(uuid);
        gainAmounts.remove(uuid);
        gainMultiplier.remove(uuid);
        hudDisabled.remove(uuid);
    }

    public Double getRecentGainAmount(UUID uuid) { return gainAmounts.get(uuid); }
    public Double getRecentGainMultiplier(UUID uuid) { return gainMultiplier.get(uuid); }

    private String buildGainString(double amount, double multiplier) {
        StringBuilder gain = new StringBuilder(ChatUtil.color("&a💰 +" + NumberFormatUtil.money(amount)));
        if (multiplier > 1.0) gain.append(ChatUtil.color(" &e[x" + String.format("%.1f", multiplier) + "]"));
        return gain.toString();
    }
}
