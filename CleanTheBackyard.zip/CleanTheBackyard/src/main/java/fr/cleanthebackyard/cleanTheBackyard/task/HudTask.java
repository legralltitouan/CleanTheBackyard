package fr.cleanthebackyard.cleanTheBackyard.task;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

/**
 * Tâche responsable de l'affichage des informations du joueur en temps réel dans la barre d'action.
 */
public class HudTask extends BukkitRunnable {

    private final CleanTheBackyard plugin;

    public HudTask(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (data == null) continue;

            // Si une collecte est active, la barre de BoxManager prend le relais
            if (plugin.getBoxManager().isCollecting(player.getUniqueId())) continue;

            String actionBar = String.format("&aSolde: &f$%.0f &7| &fSac: &f%d/%d &7| &7Énergie: &f%.0f/%.0f",
                    data.getBalance(),
                    data.getCurrentBoxes(),
                    plugin.getBoxManager().getBagCapacity(data.getBagLevel()),
                    data.getCurrentEnergy(),
                    (double) plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel())
            );

            player.sendActionBar(net.kyori.adventure.text.Component.text(ChatUtil.color(actionBar)));
        }
    }
}
