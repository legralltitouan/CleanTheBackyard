package fr.cleanthebackyard.cleanTheBackyard.task;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.*;

public class HudTask extends BukkitRunnable {

    private final CleanTheBackyard plugin;

    // Gains récents (affichés 1 seconde)
    private final Map<UUID, Long> recentGains = new HashMap<>();
    private final Map<UUID, Double> gainAmounts = new HashMap<>();
    private final Map<UUID, Double> gainMultiplier = new HashMap<>();

    public HudTask(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        long now = System.currentTimeMillis();

        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (data == null) continue;
            if (plugin.getBoxManager().isCollecting(player.getUniqueId())) continue;

            UUID uuid = player.getUniqueId();

            // Vérifie si un gain récent doit être affiché
            boolean hasRecentGain = false;
            String gainStr = "";
            if (recentGains.containsKey(uuid)) {
                long elapsed = now - recentGains.get(uuid);
                if (elapsed < 1000) {
                    hasRecentGain = true;
                    double amount = gainAmounts.getOrDefault(uuid, 0.0);
                    double mult = gainMultiplier.getOrDefault(uuid, 1.0);
                    gainStr = buildGainString(amount, mult);
                } else {
                    recentGains.remove(uuid);
                    gainAmounts.remove(uuid);
                    gainMultiplier.remove(uuid);
                }
            }

            String hud = buildPermanentHud(data, hasRecentGain ? null : player);

            if (hasRecentGain) {
                hud += ChatUtil.color(" &7| " + gainStr);
            }

            player.sendActionBar(Component.text(hud));
        }
    }

    /**
     * Construit la partie permanente du HUD (solde, sac, énergie, buffs).
     * @param player si non null, on ajoute les buffs persistants (quand aucun gain n'est affiché)
     */
    private String buildPermanentHud(PlayerData data, Player player) {
        double globalMult = plugin.getPluginConfig().getGlobalSellMultiplier();

        StringBuilder hud = new StringBuilder(String.format(
                "&aSolde: &f$%.0f &7| &fSac: &f%d/%d &7| &7Énergie: &f%.0f/%d",
                data.getBalance(),
                data.getCurrentBoxes(),
                plugin.getBoxManager().getBagCapacity(data.getBagLevel()),
                data.getCurrentEnergy(),
                plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel())
        ));

        // Ajout des buffs uniquement si aucun gain n'est affiché (player non null)
        if (player != null) {
            if (globalMult > 1.0) {
                hud.append(String.format(" &7| &ex%.1f &f(GLOBAL)", globalMult));
            }
            if (data.hasDoubleSell()) {
                hud.append(String.format(" &7| &ex2 &f%ds", data.getDoubleSellRemainingSeconds()));
            }
            if (data.hasUnlimitedEnergy()) {
                hud.append(String.format(" &7| &b⚡∞ &f%ds", data.getUnlimitedEnergyRemainingSeconds()));
            }
        }

        return ChatUtil.color(hud.toString());
    }

    // Enregistre un gain récent
    public void registerGain(Player player, double amount, double multiplier) {
        UUID uuid = player.getUniqueId();
        recentGains.put(uuid, System.currentTimeMillis());
        gainAmounts.put(uuid, amount);
        gainMultiplier.put(uuid, multiplier);
    }

    // Nettoie les données d'un joueur lors de sa déconnexion
    public void forgetPlayer(UUID uuid) {
        recentGains.remove(uuid);
        gainAmounts.remove(uuid);
        gainMultiplier.remove(uuid);
    }

    private String buildGainString(double amount, double multiplier) {
        StringBuilder gain = new StringBuilder(ChatUtil.color("&a💰 +$" + String.format("%.0f", amount)));

        if (multiplier > 1.0) {
            List<String> mults = new ArrayList<>();
            double globalMult = plugin.getPluginConfig().getGlobalSellMultiplier();
            if (globalMult > 1.0) {
                mults.add("x" + String.format("%.1f", globalMult) + " GLOBAL");
            }
            if (multiplier > globalMult) {
                mults.add("x2 PERSO");
            }
            if (!mults.isEmpty()) {
                gain.append(ChatUtil.color(" &e[")).append(String.join(" + ", mults)).append(ChatUtil.color("]"));
            }
        }
        return gain.toString();
    }
}