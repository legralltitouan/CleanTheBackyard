package fr.cleanthebackyard.cleanTheBackyard.task;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.*;
public class HudTask extends BukkitRunnable {
    private final CleanTheBackyard plugin;
    private final Map<UUID, Long> recentGains = new HashMap<>();
    private final Map<UUID, Double> gainAmounts = new HashMap<>();
    private final Map<UUID, Double> gainMultiplier = new HashMap<>();
    public HudTask(CleanTheBackyard plugin) { this.plugin = plugin; }

    private final java.util.Set<UUID> hudDisabled = java.util.concurrent.ConcurrentHashMap.newKeySet();
    public boolean toggleHud(UUID uuid) {
        if (hudDisabled.contains(uuid)) {
            hudDisabled.remove(uuid);
            return true;
        }
        hudDisabled.add(uuid);
        return false;
    }
    @Override
    public void run() {
        long now = System.currentTimeMillis();
        for (Player player : plugin.getServer().getOnlinePlayers()) {
            PlayerData data = plugin.getPlayerDataManager().get(player);
            if (data == null) continue;
            if (hudDisabled.contains(player.getUniqueId())) continue;
            if (plugin.getBoxManager().isCollecting(player.getUniqueId())) continue;
            UUID uuid = player.getUniqueId();
            boolean hasRecentGain = false;
            String gainStr = "";
            if (recentGains.containsKey(uuid)) {
                long elapsed = now - recentGains.get(uuid);
                if (elapsed < 1000) {
                    hasRecentGain = true;
                    gainStr = buildGainString(gainAmounts.getOrDefault(uuid, 0.0), gainMultiplier.getOrDefault(uuid, 1.0));
                } else {
                    recentGains.remove(uuid);
                    gainAmounts.remove(uuid);
                    gainMultiplier.remove(uuid);
                }
            }
            String hud = buildPermanentHud(data, hasRecentGain ? null : player);
            if (hasRecentGain) hud += ChatUtil.color(" &7| " + gainStr);
            player.sendActionBar(Component.text(hud));
        }
    }
    private String buildPermanentHud(PlayerData data, Player player) {
        double globalMult = plugin.getPluginConfig().getGlobalSellMultiplier();
        StringBuilder hud = new StringBuilder();
        if (data.getPrestigeLevel() > 0) {
            hud.append(String.format("&6P%d &7| ", data.getPrestigeLevel()));
        }
        hud.append(String.format(
                "&aSolde: &f$%.0f &7| &fSac: &f%d/%d &7| &7Énergie: &f%.0f/%d",
                data.getBalance(),
                data.getCurrentBoxes(),
                plugin.getBoxManager().getBagCapacity(data.getBagLevel()),
                data.getCurrentEnergy(),
                plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel())
        ));
        if (player != null) {
            if (globalMult > 1.0) hud.append(String.format(" &7| &ex%.1f &fGLOBAL", globalMult));
            if (data.hasDoubleSell()) hud.append(String.format(" &7| &ex2 &f%ds", data.getDoubleSellRemainingSeconds()));
            if (data.hasBlackMarket()) hud.append(String.format(" &7| &5x3MN &f%ds", data.getBlackMarketRemainingSeconds()));
            if (data.hasUnlimitedEnergy()) hud.append(String.format(" &7| &b⚡∞ &f%ds", data.getUnlimitedEnergyRemainingSeconds()));
        }
        return ChatUtil.color(hud.toString());
    }
    public void registerGain(Player player, double amount, double multiplier) {
        UUID uuid = player.getUniqueId();
        recentGains.put(uuid, System.currentTimeMillis());
        gainAmounts.put(uuid, amount);
        gainMultiplier.put(uuid, multiplier);
    }
    public void forgetPlayer(UUID uuid) {
        recentGains.remove(uuid);
        gainAmounts.remove(uuid);
        gainMultiplier.remove(uuid);
        hudDisabled.remove(uuid);
    }
    private String buildGainString(double amount, double multiplier) {
        StringBuilder gain = new StringBuilder(ChatUtil.color("&a💰 +$" + String.format("%.0f", amount)));
        if (multiplier > 1.0) {
            gain.append(ChatUtil.color(" &e[x" + String.format("%.1f", multiplier) + "]"));
        }
        return gain.toString();
    }
}