package fr.cleanthebackyard.cleanTheBackyard.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.entity.Player;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
public class QuestManager {
    private final CleanTheBackyard plugin;
    private final Random random = new Random();
    public QuestManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    public void checkAndResetQuests(PlayerData data) {
        long today = LocalDate.now(ZoneId.systemDefault()).toEpochDay();
        if (data.getQuestResetTimestamp() != today) {
            generateNewQuests(data);
            data.setQuestResetTimestamp(today);
        }
    }
    private void generateNewQuests(PlayerData data) {
        List<DailyQuest> quests = new ArrayList<>();
        int playerScale = Math.max(1, (data.getBagLevel() + data.getToolLevel() + data.getEnergyLevel()) / 3);
        DailyQuest.Type[] types = DailyQuest.Type.values();
        List<DailyQuest.Type> available = new ArrayList<>(List.of(types));
        for (int i = 0; i < 3 && !available.isEmpty(); i++) {
            DailyQuest.Type chosen = available.remove(random.nextInt(available.size()));
            quests.add(buildQuest(chosen, playerScale));
        }
        data.setDailyQuests(quests);
    }
    private DailyQuest buildQuest(DailyQuest.Type type, int scale) {
        return switch (type) {
            case BREAK_BOXES -> new DailyQuest(type, 50L * scale, 200L * scale);
            case EARN_MONEY -> new DailyQuest(type, 500L * scale, 300L * scale);
            case BUY_VENDING -> new DailyQuest(type, 3 + scale, 150L * scale);
            case SELL_TIMES -> new DailyQuest(type, 5L + scale, 200L * scale);
            case REACH_BAG_FULL -> new DailyQuest(type, 3L + scale / 2, 250L * scale);
        };
    }
    public void onProgress(Player player, DailyQuest.Type type, long amount) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return;
        checkAndResetQuests(data);
        for (DailyQuest q : data.getDailyQuests()) {
            if (q.getType() == type && !q.isCompleted()) {
                long before = q.getProgress();
                q.addProgress(amount);
                if (q.isCompleted() && before < q.getTarget()) {
                    player.sendMessage(ChatUtil.color("&6[Quête] &aTerminée : &f" + q.getFormattedDescription()
                            + " &7(récupère ta récompense au tableau des quêtes !)"));
                    player.playSound(player.getLocation(), org.bukkit.Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.7f, 1.2f);
                }
            }
        }
    }
    public boolean claimReward(Player player, int questIndex) {
        PlayerData data = plugin.getPlayerDataManager().get(player);
        if (data == null) return false;
        if (questIndex < 0 || questIndex >= data.getDailyQuests().size()) return false;
        DailyQuest q = data.getDailyQuests().get(questIndex);
        if (!q.isCompleted() || q.isClaimed()) return false;
        q.setClaimed(true);
        plugin.getEconomyManager().credit(player, q.getReward());
        player.sendMessage(ChatUtil.color("&aRécompense récupérée : &f$" + q.getReward()));
        return true;
    }
}