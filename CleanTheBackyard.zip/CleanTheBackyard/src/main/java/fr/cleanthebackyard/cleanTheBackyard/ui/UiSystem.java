package fr.cleanthebackyard.cleanTheBackyard.ui;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.ui.gui.GuiManager;
import fr.cleanthebackyard.cleanTheBackyard.ui.integration.BetterHudBridge;
import fr.cleanthebackyard.cleanTheBackyard.ui.integration.ItemsAdderHudBridge;
import fr.cleanthebackyard.cleanTheBackyard.ui.hud.HudTask;

/**
 * Interfaces graphiques et affichage HUD (action bar / BetterHUD / ItemsAdder).
 *
 * Remarque : GuiManager, les bridges et HudTask conservent leur cycle de vie
 * propre (HudTask est une BukkitRunnable schedulée, les bridges sont
 * tryRegister() au démarrage). Le record ne fait qu'agréger les accès.
 */
public record UiSystem(
        GuiManager          gui,
        HudTask             hud,
        BetterHudBridge     betterHud,
        ItemsAdderHudBridge itemsAdderHud) {

    public static UiSystem create(CleanTheBackyard plugin,
                                  HudTask hudTask,
                                  BetterHudBridge betterHud,
                                  ItemsAdderHudBridge itemsAdderHud) {
        return new UiSystem(new GuiManager(plugin), hudTask, betterHud, itemsAdderHud);
    }
}
