package fr.cleanthebackyard.cleanTheBackyard.ui;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.ui.gui.GuiManager;
import fr.cleanthebackyard.cleanTheBackyard.ui.integration.BetterHudBridge;
import fr.cleanthebackyard.cleanTheBackyard.ui.hud.HudTask;
/**
 * Interfaces graphiques et affichage HUD (action bar / BetterHUD).
 *
 * Remarque : GuiManager, le bridge BetterHUD et HudTask conservent leur cycle
 * de vie propre (HudTask est une BukkitRunnable schedulée, le bridge est
 * tryRegister() au démarrage). Le record ne fait qu'agréger les accès.
 */
public record UiSystem(
        GuiManager      gui,
        HudTask         hud,
        BetterHudBridge betterHud) {
    public static UiSystem create(CleanTheBackyard plugin,
                                  HudTask hudTask,
                                  BetterHudBridge betterHud) {
        return new UiSystem(new GuiManager(plugin), hudTask, betterHud);
    }
}