package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.DailyQuest;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

/**
 * Détecte les achats au distributeur (item donné = energy-restore key).
 * En réalité, le compteur est incrémenté quand un item est ajouté à l'inventaire
 * du joueur via VendingMachineGui. On utilise un événement custom plus simple :
 * on hook directement dans VendingMachineGui pour appeler QuestManager.
 *
 * Ce listener garde une trace de fallback : si un item energy-restore disparaît
 * de l'inventaire (consommation), on enregistre la progression.
 */
public class VendingPurchaseListener implements Listener {

    private final CleanTheBackyard plugin;

    public VendingPurchaseListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClickVending(InventoryClickEvent event) {
        // Le compteur est en réalité géré dans VendingMachineGui (cf. fichier suivant)
        // Ce listener est laissé pour extensions futures.
    }

    public static void incrementOnPurchase(CleanTheBackyard plugin, Player player) {
        plugin.getQuestManager().onProgress(player, DailyQuest.Type.BUY_VENDING, 1);
    }
}
