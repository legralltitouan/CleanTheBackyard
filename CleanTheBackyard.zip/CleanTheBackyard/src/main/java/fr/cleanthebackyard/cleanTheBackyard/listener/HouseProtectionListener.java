package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Protection du monde-maison :
 *  ─ Aucun bloc vanilla cassé/posé (sauf créatif).
 *  ─ Les meubles du shop (taggés) peuvent être posés (clic droit) et cassés (clic gauche).
 *  ─ Toute autre interaction destructrice est bloquée.
 */
public class HouseProtectionListener implements Listener {

    private final CleanTheBackyard plugin;

    public HouseProtectionListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private boolean isInAnyHouse(Player p) {
        return plugin.getHouseManager().isAnyHouseWorld(p.getWorld());
    }

    private boolean isInAnyHouse(Entity e) {
        return e != null && plugin.getHouseManager().isAnyHouseWorld(e.getWorld());
    }

    private boolean isCreative(Player p) {
        return p.getGameMode() == GameMode.CREATIVE;
    }

    // ── Casse de blocs ──
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (!isInAnyHouse(event.getPlayer())) return;
        if (isCreative(event.getPlayer())) return;
        // Les meubles ItemsAdder sont des entités, pas des blocs : ce handler ne les touche pas.
        event.setCancelled(true);
    }

    // ── Pose de blocs ──
    // ItemsAdder pose la furniture comme une ENTITÉ (ArmorStand/ItemDisplay), donc ce
    // BlockPlaceEvent ne se déclenche que pour des vrais blocs. On bloque tout sauf
    // les items taggés "shop-furniture" qui auraient un fallback bloc.
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (!isInAnyHouse(event.getPlayer())) return;
        if (isCreative(event.getPlayer())) return;

        ItemStack inHand = event.getItemInHand();
        if (plugin.getFurnitureShopManager().isShopFurniture(inHand)) {
            // Autorisé : c'est un meuble du shop
            return;
        }
        event.setCancelled(true);
    }

    /**
     * Clic droit dans la maison :
     *  ─ Si on tient un meuble du shop : on laisse passer (ItemsAdder gère le placement).
     *  ─ Sinon, si l'item est un bloc plaçable, on bloque le clic droit pour éviter
     *    toute pose d'un item non autorisé qui passerait sous le radar de BlockPlaceEvent.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (!isInAnyHouse(event.getPlayer())) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (isCreative(event.getPlayer())) return;

        ItemStack item = event.getPlayer().getInventory().getItemInMainHand();
        if (item == null || item.getType().isAir()) return;

        if (plugin.getFurnitureShopManager().isShopFurniture(item)) {
            // Meuble shop : on laisse ItemsAdder poser
            return;
        }
        // Bloc vanilla en main → on annule pour empêcher la pose
        if (item.getType().isBlock() && item.getType().isSolid()) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatUtil.color("&cTu ne peux pas poser ça ici."));
        }
    }

    // ── Casse d'un meuble (clic gauche sur l'entité ItemsAdder) ──
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player p)) return;
        if (!isInAnyHouse(p)) return;

        Entity victim = event.getEntity();

        // Si c'est une furniture ItemsAdder → on la détruit proprement
        String furnitureId = plugin.getFurnitureProvider().getFurnitureId(victim);
        if (furnitureId != null) {
            plugin.getFurnitureProvider().removeFurniture(victim);
            p.sendMessage(ChatUtil.color("&aMeuble détruit."));
            event.setCancelled(true);
            return;
        }

        // Autres entités : bloquer (sauf créatif)
        if (!isCreative(p)) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        if (!isInAnyHouse(event.getEntity())) return;
        if (!(event.getRemover() instanceof Player p)) return;
        if (isCreative(p)) return;
        event.setCancelled(true);
    }
}
