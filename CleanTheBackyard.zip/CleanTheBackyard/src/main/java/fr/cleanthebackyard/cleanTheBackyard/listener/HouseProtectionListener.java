package fr.cleanthebackyard.cleanTheBackyard.listener;

import dev.lone.itemsadder.api.Events.CustomBlockBreakEvent;
import dev.lone.itemsadder.api.Events.CustomBlockPlaceEvent;
import dev.lone.itemsadder.api.Events.FurnitureBreakEvent;
import dev.lone.itemsadder.api.Events.FurniturePlaceEvent;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;

/**
 * Protection du monde-maison.
 *
 * PRINCIPE CLÉ :
 *  - Une furniture ItemsAdder N'EST PAS un bloc. C'est une entité (+ parfois une
 *    barrière technique). On NE doit donc PAS la gérer via BlockPlaceEvent /
 *    EntityDamageByEntityEvent : on utilise les events dédiés d'ItemsAdder
 *    (FurniturePlaceEvent / FurnitureBreakEvent / CustomBlock*).
 *  - Tout le reste (blocs vanilla) est interdit hors créatif.
 */
public class HouseProtectionListener implements Listener {

    private final CleanTheBackyard plugin;
    private final boolean debug = false; // passe à false en prod

    public HouseProtectionListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private void log(String msg) {
        if (debug) plugin.getLogger().info("[CTB-House] " + msg);
    }

    private boolean isInAnyHouse(Player p) {
        return p != null && plugin.getHouseManager().isAnyHouseWorld(p.getWorld());
    }

    private boolean isInAnyHouse(Entity e) {
        return e != null && plugin.getHouseManager().isAnyHouseWorld(e.getWorld());
    }

    private boolean isCreative(Player p) {
        return p.getGameMode() == GameMode.CREATIVE;
    }

    // ════════════════════════════════════════════════════════════════
    //  FURNITURES ITEMSADDER — autorisées dans la maison
    // ════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onFurniturePlace(FurniturePlaceEvent event) {
        Player p = event.getPlayer();
        log("FurniturePlaceEvent | player=" + (p != null ? p.getName() : "null")
                + " | world=" + (p != null ? p.getWorld().getName() : "?")
                + " | furniture=" + event.getNamespacedID()
                + " | cancelled(before)=" + event.isCancelled());

        if (p == null || !isInAnyHouse(p)) {
            log("  -> hors maison, on ne touche à rien.");
            return;
        }

        // On force l'autorisation dans la maison (au cas où un autre listener annule)
        if (event.isCancelled()) {
            event.setCancelled(false);
            log("  -> dé-annulation : pose furniture AUTORISÉE dans la maison.");
        } else {
            log("  -> pose furniture AUTORISÉE dans la maison.");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onFurnitureBreak(FurnitureBreakEvent event) {
        Player p = event.getPlayer();
        log("FurnitureBreakEvent | player=" + (p != null ? p.getName() : "null")
                + " | world=" + (p != null ? p.getWorld().getName() : "?")
                + " | furniture=" + event.getNamespacedID()
                + " | cancelled(before)=" + event.isCancelled());

        if (p == null || !isInAnyHouse(p)) {
            log("  -> hors maison, on ne touche à rien.");
            return;
        }

        if (event.isCancelled()) {
            event.setCancelled(false);
            log("  -> dé-annulation : casse furniture AUTORISÉE dans la maison.");
        } else {
            log("  -> casse furniture AUTORISÉE dans la maison.");
        }
    }

    // ItemsAdder pose une barrière technique pour la hitbox de certaines
    // furnitures : ce CustomBlockPlaceEvent doit aussi être autorisé.
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onCustomBlockPlace(CustomBlockPlaceEvent event) {
        Player p = event.getPlayer();
        log("CustomBlockPlaceEvent | player=" + (p != null ? p.getName() : "null")
                + " | block=" + event.getNamespacedID()
                + " | world=" + (event.getBlock() != null ? event.getBlock().getWorld().getName() : "?"));
        if (p == null || !isInAnyHouse(p)) return;
        if (event.isCancelled()) {
            event.setCancelled(false);
            log("  -> dé-annulation CustomBlockPlace dans la maison.");
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onCustomBlockBreak(CustomBlockBreakEvent event) {
        Player p = event.getPlayer();
        log("CustomBlockBreakEvent | player=" + (p != null ? p.getName() : "null")
                + " | block=" + event.getNamespacedID());
        if (p == null || !isInAnyHouse(p)) return;
        if (event.isCancelled()) {
            event.setCancelled(false);
            log("  -> dé-annulation CustomBlockBreak dans la maison.");
        }
    }

    // ════════════════════════════════════════════════════════════════
    //  BLOCS VANILLA — interdits dans la maison (hors créatif)
    // ════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player p = event.getPlayer();
        if (!isInAnyHouse(p)) return;
        if (isCreative(p)) {
            log("BlockBreak créatif autorisé : " + event.getBlock().getType());
            return;
        }
        log("BlockBreak vanilla REFUSÉ : " + event.getBlock().getType()
                + " @ " + event.getBlock().getLocation().toVector());
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {

        Player p = event.getPlayer();

        if (!isInAnyHouse(p)) return;

        if (isCreative(p)) {
            return;
        }

        ItemStack inHand = event.getItemInHand();

        // TOUJOURS laisser passer les meubles du shop
        if (plugin.getFurnitureShopManager().isShopFurniture(inHand)) {
            log("BlockPlace furniture détecté -> autorisé.");
            return;
        }

        // AIR = souvent utilisé par ItemsAdder
        if (event.getBlock().getType().isAir()) {
            log("BlockPlace AIR détecté -> ignoré.");
            return;
        }

        log("BlockPlace vanilla REFUSÉ : " + event.getBlock().getType());

        event.setCancelled(true);

        p.sendMessage(ChatUtil.color("&cTu ne peux poser que des meubles ici."));
    }

    // ════════════════════════════════════════════════════════════════
    //  CLIC DROIT — on ne bloque QUE les blocs vanilla pleins.
    //  On NE TOUCHE PAS aux items furniture : ItemsAdder doit recevoir le clic.
    // ════════════════════════════════════════════════════════════════

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        Player p = event.getPlayer();
        if (!isInAnyHouse(p)) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (isCreative(p)) return;

        ItemStack item = p.getInventory().getItemInMainHand();
        if (item == null || item.getType().isAir()) return;

        // Furniture du shop : NE PAS intercepter, laisser ItemsAdder poser.
        if (plugin.getFurnitureShopManager().isShopFurniture(item)) {
            log("Interact clic-droit : furniture shop -> laissé à ItemsAdder ("
                    + item.getType() + ").");
            return;
        }

        // Bloc vanilla plaçable en main → on bloque la pose.
        if (item.getType().isBlock() && item.getType().isSolid()) {
            log("Interact clic-droit : bloc vanilla REFUSÉ (" + item.getType() + ").");
            event.setCancelled(true);
            p.sendMessage(ChatUtil.color("&cTu ne peux pas poser ça ici."));
        }
    }

    @EventHandler(priority = EventPriority.NORMAL, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        if (!isInAnyHouse(event.getEntity())) return;
        if (!(event.getRemover() instanceof Player p)) return;
        if (isCreative(p)) return;
        // Une furniture frame est gérée par FurnitureBreakEvent ; ici on bloque
        // uniquement les vrais hangings vanilla.
        String furnitureId = plugin.getFurnitureProvider().getFurnitureId(event.getEntity());
        if (furnitureId != null) {
            log("HangingBreak : c'est une furniture (" + furnitureId + ") -> laissé à IA.");
            return;
        }
        log("HangingBreak vanilla REFUSÉ.");
        event.setCancelled(true);
    }
}
