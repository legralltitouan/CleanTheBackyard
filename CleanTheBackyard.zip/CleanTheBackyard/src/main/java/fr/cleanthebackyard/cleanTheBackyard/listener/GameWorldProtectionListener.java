package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Openable;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
/**
 * Règles du monde de jeu personnel hors mouvement (le confinement et le mur
 * sont gérés par {@link WorldMovementListener}) :
 *   ─ interdiction d'ouvrir portes / trappes / portails,
 *   ─ interdiction de drop et de ramasser des items au sol.
 */
public class GameWorldProtectionListener implements Listener {
    private final CleanTheBackyard plugin;
    public GameWorldProtectionListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private boolean isPlayerGameWorld(Player player) {
        World world = player.getWorld();
        if (world == null) return false;
        String hub = plugin.core().config().getHubWorldName();
        if (world.getName().equals(hub)) return false;
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        if (world.getName().startsWith(housePrefix)) return false;
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        return world.getName().startsWith(prefix);
    }
    private boolean isBypassMode(Player player) {
        return player.getGameMode() == GameMode.CREATIVE
                || player.getGameMode() == GameMode.SPECTATOR;
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        if (isBypassMode(player)) return;
        if (!isPlayerGameWorld(player)) return;
        Block block = event.getClickedBlock();
        if (block == null) return;
        if (block.getBlockData() instanceof Openable) {
            event.setCancelled(true);
            return;
        }
        Material type = block.getType();
        String name = type.name();
        if (name.endsWith("_DOOR") || name.endsWith("_TRAPDOOR") || name.endsWith("_FENCE_GATE")) {
            event.setCancelled(true);
        }
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (isBypassMode(player)) return;
        if (!isPlayerGameWorld(player)) return;
        event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (isBypassMode(player)) return;
        if (!isPlayerGameWorld(player)) return;
        event.setCancelled(true);
    }
}