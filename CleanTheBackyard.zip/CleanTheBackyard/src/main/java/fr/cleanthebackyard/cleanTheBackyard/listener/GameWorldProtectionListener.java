package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.data.Openable;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.util.BoundingBox;

/**
 * Règles spécifiques au monde de jeu personnel du joueur (/go) :
 *   ─ interdiction d'ouvrir les portes / trappes / portails,
 *   ─ interdiction de drop et de ramasser des items au sol,
 *   ─ confinement dans la zone player-bounds.
 *
 * N'affecte ni le hub ni les mondes-maison.
 */
public class GameWorldProtectionListener implements Listener {

    private final CleanTheBackyard plugin;
    private static final double MARGIN = 0.30;

    public GameWorldProtectionListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    /** Monde de jeu personnel uniquement (pas le hub, pas la maison). */
    private boolean isPlayerGameWorld(Player player) {
        World world = player.getWorld();
        if (world == null) return false;
        String hub = plugin.getPluginConfig().getHubWorldName();
        if (world.getName().equals(hub)) return false;
        String housePrefix = plugin.getPluginConfig().getHouseWorldPrefix();
        if (world.getName().startsWith(housePrefix)) return false;
        String prefix = plugin.getPluginConfig().getPlayerWorldPrefix();
        return world.getName().startsWith(prefix);
    }

    // ── Interdiction d'ouvrir portes / trappes / portails ──
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) return;
        if (!isPlayerGameWorld(player)) return;

        Block block = event.getClickedBlock();
        if (block == null) return;

        // Tout bloc "ouvrable" (portes, portillons, trappes) est bloqué.
        if (block.getBlockData() instanceof Openable) {
            event.setCancelled(true);
            return;
        }
        // Sécurité supplémentaire pour les portes vanilla.
        Material type = block.getType();
        String name = type.name();
        if (name.endsWith("_DOOR") || name.endsWith("_TRAPDOOR") || name.endsWith("_FENCE_GATE")) {
            event.setCancelled(true);
        }
    }

    // ── Interdiction de drop des items au sol ──
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        Player player = event.getPlayer();
        if (player.getGameMode() == GameMode.CREATIVE) return;
        if (!isPlayerGameWorld(player)) return;
        event.setCancelled(true);
    }

    // ── Interdiction de ramasser des items au sol ──
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPickup(EntityPickupItemEvent event) {
        if (!(event.getEntity() instanceof Player player)) return;
        if (player.getGameMode() == GameMode.CREATIVE) return;
        if (!isPlayerGameWorld(player)) return;
        event.setCancelled(true);
    }

    // ── Confinement : empêche de sortir de player-bounds ──
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getPluginConfig().isPlayerBoundsEnabled()) return;
        if (player.getGameMode() == GameMode.SPECTATOR) return;
        if (!isPlayerGameWorld(player)) return;

        Location to = event.getTo();
        if (to == null) return;
        Location from = event.getFrom();
        // Optimisation : ne traite que les changements de bloc.
        if (from.getBlockX() == to.getBlockX()
                && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) return;

        BoundingBox b = plugin.getPluginConfig().getPlayerBounds();
        double x = to.getX();
        double y = to.getY();
        double z = to.getZ();

        boolean outside = x < b.getMinX() + MARGIN || x > b.getMaxX() + 1 - MARGIN
                || z < b.getMinZ() + MARGIN || z > b.getMaxZ() + 1 - MARGIN
                || y < b.getMinY() || y > b.getMaxY() + 2;

        if (!outside) return;

        Location corrected = to.clone();
        corrected.setX(clamp(x, b.getMinX() + MARGIN, b.getMaxX() + 1 - MARGIN));
        corrected.setZ(clamp(z, b.getMinZ() + MARGIN, b.getMaxZ() + 1 - MARGIN));
        corrected.setY(clamp(y, b.getMinY(), b.getMaxY() + 2));
        corrected.setYaw(to.getYaw());
        corrected.setPitch(to.getPitch());
        event.setTo(corrected);
    }

    private double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
