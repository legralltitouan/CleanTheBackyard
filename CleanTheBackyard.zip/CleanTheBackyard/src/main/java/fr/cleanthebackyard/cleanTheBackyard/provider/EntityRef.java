package fr.cleanthebackyard.cleanTheBackyard.provider;

import org.bukkit.entity.EntityType;

/**
 * Référence vers un type d'entité, vanilla ou MythicMob.
 * Syntaxe config :
 *   "vanilla:BEE"
 *   "mythic:GoldenDrone"
 *   "mythicmob:Rat_Voleur"
 */
public final class EntityRef {

    public enum Type { VANILLA, MYTHIC }

    private final Type type;
    private final String id;        // vanilla : "BEE" ; mythic : "GoldenDrone"
    private final String rawConfig;

    public EntityRef(Type type, String id, String rawConfig) {
        this.type = type;
        this.id = id;
        this.rawConfig = rawConfig;
    }

    public Type getType() { return type; }
    public String getId() { return id; }
    public String getRawConfig() { return rawConfig; }

    public EntityType asVanillaType(EntityType fallback) {
        if (type != Type.VANILLA) return fallback;
        try {
            return EntityType.valueOf(id.toUpperCase());
        } catch (IllegalArgumentException ex) {
            return fallback;
        }
    }

    @Override
    public String toString() {
        return type + ":" + id;
    }

    public static EntityRef parse(String raw, EntityType vanillaDefault) {
        if (raw == null || raw.isBlank()) {
            return new EntityRef(Type.VANILLA, vanillaDefault.name(), vanillaDefault.name());
        }
        String trimmed = raw.trim();
        String lower = trimmed.toLowerCase();
        if (lower.startsWith("mythic:") || lower.startsWith("mythicmob:") || lower.startsWith("mm:")) {
            String id = trimmed.substring(trimmed.indexOf(':') + 1);
            return new EntityRef(Type.MYTHIC, id, raw);
        }
        if (lower.startsWith("vanilla:")) {
            String id = trimmed.substring("vanilla:".length());
            return new EntityRef(Type.VANILLA, id.toUpperCase(), raw);
        }
        // Pas de préfixe : tente vanilla, sinon mythic
        try {
            EntityType.valueOf(trimmed.toUpperCase());
            return new EntityRef(Type.VANILLA, trimmed.toUpperCase(), raw);
        } catch (IllegalArgumentException ex) {
            return new EntityRef(Type.MYTHIC, trimmed, raw);
        }
    }
}
