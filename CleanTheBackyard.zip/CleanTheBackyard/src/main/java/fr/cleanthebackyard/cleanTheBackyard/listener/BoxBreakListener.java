package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.block.Action;

/**
 * Intercepte les interactions avec les blocs de cartons.
 * Utilise PlayerInteractEvent en clic gauche pour un retour immediat
 * et annule le BlockBreakEvent natif (la destruction est geree par BoxManager).
 */
public class BoxBreakListener implements Listener {

    private final CleanTheBackyard plugin;
    private final Material boxMaterial;

    public BoxBreakListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
        Material mat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        this.boxMaterial = (mat != null) ? mat : Material.NOTE_BLOCK;
    }

    /** Intercepte le clic gauche sur un carton. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_BLOCK) return;

        Block block = event.getClickedBlock();
        if (block == null) return;

        Player player = event.getPlayer();
        Location loc  = block.getLocation();

        // Boite OVNI (GLOWSTONE) - priorité avant la boite normale
        if (block.getType() == Material.GLOWSTONE
                && plugin.getEventManager().isUfoBox(loc)) {
            event.setCancelled(true);
            plugin.getEventManager().tryClaimUfoBox(player, loc);
            return;
        }

        if (block.getType() != boxMaterial) return;

        event.setCancelled(true);

        boolean started = plugin.getBoxManager().startCollection(player, loc);
        if (started) {
            plugin.getSectorManager().markBroken(loc);
        }
    }

    /** Annule le cassage natif de blocs de cartons (prevention drop items). */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (event.getBlock().getType() == boxMaterial) {
            event.setDropItems(false);
            event.setCancelled(true);
        }
    }
}
