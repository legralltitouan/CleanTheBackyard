package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class BoxBreakListener implements Listener {

    private final CleanTheBackyard plugin;
    private final Material boxMaterial;

    public BoxBreakListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
        Material mat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        this.boxMaterial = (mat != null) ? mat : Material.NOTE_BLOCK;
    }

    private boolean isInHubWorld(Player player) {
        String hub = plugin.getPluginConfig().getHubWorldName();
        return player.getWorld().getName().equals(hub);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_BLOCK) return;

        Block block = event.getClickedBlock();
        if (block == null) return;

        Player player = event.getPlayer();
        if (isInHubWorld(player)) return;

        Location loc = block.getLocation();

        // Boîte OVNI prioritaire
        if (block.getType() == Material.GLOWSTONE
                && plugin.getEventManager().isUfoBox(loc)) {
            event.setCancelled(true);
            plugin.getEventManager().tryClaimUfoBox(player, loc);
            return;
        }

        if (block.getType() != boxMaterial) return;

        event.setCancelled(true);

        // Les joueurs en créatif collectent aussi (sinon ça casse instant en vanilla)
        boolean started = plugin.getBoxManager().startCollection(player, loc);
        if (started) {
            plugin.getSectorManager().markBroken(loc);
        }
    }

    /** Bloque le cassage vanilla des cartons ET boîtes OVNI, même pour les créatifs. */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block b = event.getBlock();
        Player player = event.getPlayer();

        if (b.getType() == boxMaterial) {
            event.setDropItems(false);
            event.setCancelled(true);
            // En créatif on déclenche tout de même la collecte
            if (player.getGameMode() == GameMode.CREATIVE && !isInHubWorld(player)) {
                plugin.getBoxManager().startCollection(player, b.getLocation());
            }
            return;
        }
        if (b.getType() == Material.GLOWSTONE
                && plugin.getEventManager().isUfoBox(b.getLocation())) {
            event.setDropItems(false);
            event.setCancelled(true);
            if (player.getGameMode() == GameMode.CREATIVE) {
                plugin.getEventManager().tryClaimUfoBox(player, b.getLocation());
            }
        }
    }
}
