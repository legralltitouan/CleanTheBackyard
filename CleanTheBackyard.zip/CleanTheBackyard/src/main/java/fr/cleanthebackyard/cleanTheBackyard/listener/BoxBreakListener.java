package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
public class BoxBreakListener implements Listener {
    private final CleanTheBackyard plugin;
    public BoxBreakListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private boolean isInHubWorld(Player player) {
        String hub = plugin.core().config().getHubWorldName();
        return player.getWorld().getName().equals(hub);
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null) return;
        Player player = event.getPlayer();
        if (isInHubWorld(player)) return;
        // ── Si le joueur est en mini-jeu, on ne casse rien
        if (plugin.gameplay().cleaningGame().isPlaying(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }
        Location loc = block.getLocation();
        BlockRef boxRef = plugin.core().config().getBoxBlockRef();
        BlockRef ufoRef = plugin.core().config().getUfoBlockRef();
        if (plugin.events().isUfoBox(loc) && plugin.providers().block().isCarton(block, ufoRef)) {
            event.setCancelled(true);
            plugin.events().tryClaimUfoBox(player, loc);
            return;
        }
        if (!plugin.providers().block().isCarton(block, boxRef)) return;
        event.setCancelled(true);
        plugin.gameplay().box().startCollection(player, loc);
    }
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block b = event.getBlock();
        Player player = event.getPlayer();
        if (plugin.gameplay().cleaningGame().isPlaying(player.getUniqueId())) {
            event.setCancelled(true);
            return;
        }
        BlockRef boxRef = plugin.core().config().getBoxBlockRef();
        BlockRef ufoRef = plugin.core().config().getUfoBlockRef();
        if (plugin.providers().block().isCarton(b, boxRef)) {
            event.setDropItems(false);
            event.setCancelled(true);
            if (player.getGameMode() == GameMode.CREATIVE && !isInHubWorld(player)) {
                plugin.gameplay().box().startCollection(player, b.getLocation());
            }
            return;
        }
        if (plugin.events().isUfoBox(b.getLocation()) && plugin.providers().block().isCarton(b, ufoRef)) {
            event.setDropItems(false);
            event.setCancelled(true);
            if (player.getGameMode() == GameMode.CREATIVE) {
                plugin.events().tryClaimUfoBox(player, b.getLocation());
            }
        }
    }
}