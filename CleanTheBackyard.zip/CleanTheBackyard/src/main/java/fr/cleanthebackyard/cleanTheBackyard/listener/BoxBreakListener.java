package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;

public class BoxBreakListener implements Listener {

    private final CleanTheBackyard plugin;

    public BoxBreakListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private boolean isInHubWorld(Player player) {
        String hub = plugin.getPluginConfig().getHubWorldName();
        return player.getWorld().getName().equals(hub);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.LEFT_CLICK_BLOCK) return;
        Block block = event.getClickedBlock();
        if (block == null) return;
        Player player = event.getPlayer();
        if (isInHubWorld(player)) return;

        Location loc = block.getLocation();
        BlockRef boxRef = plugin.getPluginConfig().getBoxBlockRef();
        BlockRef ufoRef = plugin.getPluginConfig().getUfoBlockRef();

        // OVNI box ?
        if (plugin.getEventManager().isUfoBox(loc) && plugin.getBlockProvider().isCarton(block, ufoRef)) {
            event.setCancelled(true);
            plugin.getEventManager().tryClaimUfoBox(player, loc);
            return;
        }

        // Carton normal ?
        if (!plugin.getBlockProvider().isCarton(block, boxRef)) return;
        event.setCancelled(true);
        plugin.getBoxManager().startCollection(player, loc);
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Block b = event.getBlock();
        Player player = event.getPlayer();

        BlockRef boxRef = plugin.getPluginConfig().getBoxBlockRef();
        BlockRef ufoRef = plugin.getPluginConfig().getUfoBlockRef();

        if (plugin.getBlockProvider().isCarton(b, boxRef)) {
            event.setDropItems(false);
            event.setCancelled(true);
            if (player.getGameMode() == GameMode.CREATIVE && !isInHubWorld(player)) {
                plugin.getBoxManager().startCollection(player, b.getLocation());
            }
            return;
        }
        if (plugin.getEventManager().isUfoBox(b.getLocation())
                && plugin.getBlockProvider().isCarton(b, ufoRef)) {
            event.setDropItems(false);
            event.setCancelled(true);
            if (player.getGameMode() == GameMode.CREATIVE) {
                plugin.getEventManager().tryClaimUfoBox(player, b.getLocation());
            }
        }
    }
}
