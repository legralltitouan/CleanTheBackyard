package fr.cleanthebackyard.cleanTheBackyard.security.entity;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.CustomEntityHandle;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Rabbit;
import org.bukkit.util.Vector;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;
public class RatEntity {
    private static final long TASK_PERIOD = 1L;
    // Fenêtre verticale de recherche de sol autour du stash (évite de viser le plafond).
    // On scanne surtout vers le bas : le sol est sous le niveau du stash.
    private static final int GROUND_SEARCH_UP = 2;
    private static final int GROUND_SEARCH_DOWN = 16;
    // Anti-blocage : nombre de ticks sans progression avant intervention.
    private static final int STUCK_THRESHOLD_TICKS = 30;
    // Au-delà, on téléporte légèrement / on force la fuite définitive.
    private static final int STUCK_HARD_LIMIT_TICKS = 80;
    private final CleanTheBackyard plugin;
    private final Player owner;
    private final World world;
    private final CustomEntityHandle entity;
    private final Location stashLoc;
    private final long stealAmount;
    private final UUID id;
    private enum State { APPROACHING, STEALING, ESCAPING }
    private State state = State.APPROACHING;
    private org.bukkit.scheduler.BukkitRunnable task;
    private long startTime;
    private boolean detected = false;
    private Vector currentVelocity = new Vector(0, 0, 0);
    // Anti-blocage : suivi de la dernière position et compteur d'immobilité.
    private double lastX = Double.NaN;
    private double lastZ = Double.NaN;
    private int stuckTicks = 0;
    public RatEntity(Player owner, Location stashLoc, long stealAmount) {
        this.plugin = CleanTheBackyard.getInstance();
        this.owner = owner;
        this.world = owner.getWorld();
        this.stashLoc = stashLoc;
        this.stealAmount = stealAmount;
        this.id = UUID.randomUUID();
        PluginConfig cfg = plugin.core().config();
        double radius = cfg.getRatsSpawnRadius();
        Location spawnLoc = findSafeSpawnLocation(stashLoc, radius);
        this.entity = plugin.providers().entity().spawn(
                cfg.getRatEntityRef(), spawnLoc, EntityType.RABBIT, "rat"
        );
        Entity bukkit = entity.getBukkitEntity();
        bukkit.setCustomNameVisible(true);
        updateName();
        if (bukkit instanceof Rabbit r) {
            try { r.setRabbitType(Rabbit.Type.BLACK); } catch (Throwable ignored) {}
            r.setAdult();
            r.setAware(false);
        }
        if (bukkit instanceof LivingEntity le) {
            le.setRemoveWhenFarAway(false);
        }
        bukkit.setInvulnerable(false);
        this.startTime = System.currentTimeMillis();
        startTask();
        rollDetection();
    }
    private void updateName() {
        if (!entity.isValid()) return;
        String stateLabel = switch (state) {
            case APPROACHING -> "&eAPPROCHE";
            case STEALING -> "&cVOL EN COURS";
            case ESCAPING -> "&6FUITE";
        };
        entity.getBukkitEntity().setCustomName(ChatUtil.color(
                "&8🐀 Rat voleur " + stateLabel + " &7[&c-" + NumberFormatUtil.money(stealAmount) + "&7]"
        ));
    }
    /**
     * Cherche un sol valide (bloc plein avec 2 blocs traversables au-dessus) à
     * proximité du stash. On part toujours du niveau du stash et on scanne en
     * priorité vers le bas, ce qui garantit un spawn AU SOL et jamais sur le plafond.
     */
    private Location findSafeSpawnLocation(Location center, double radius) {
        for (int attempts = 0; attempts < 24; attempts++) {
            double angle = ThreadLocalRandom.current().nextDouble(0, Math.PI * 2);
            double dist = radius * 0.5 + ThreadLocalRandom.current().nextDouble() * (radius * 0.5);
            int bx = (int) Math.floor(center.getX() + Math.cos(angle) * dist);
            int bz = (int) Math.floor(center.getZ() + Math.sin(angle) * dist);
            Integer groundY = findGroundY(bx, bz, center.getBlockY());
            if (groundY != null) {
                return new Location(world, bx + 0.5, groundY, bz + 0.5);
            }
        }
        // Fallback : sol directement sous le stash.
        Integer fallbackY = findGroundY(stashLoc.getBlockX(), stashLoc.getBlockZ(), stashLoc.getBlockY());
        int y = fallbackY != null ? fallbackY : stashLoc.getBlockY();
        return new Location(world, stashLoc.getX(), y, stashLoc.getZ());
    }
    /**
     * Un bloc est "traversable" pour le rat s'il est de l'air OU s'il ne gêne pas
     * physiquement le déplacement : barrière technique ItemsAdder, plantes,
     * tapis, etc. (passable = pas de collision solide).
     */
    private boolean isPassable(Block b) {
        if (b.getType().isAir()) return true;
        // Bloc sans boîte de collision = traversable (barrière IA, herbe, etc.)
        return b.isPassable();
    }
    /**
     * Trouve le Y de spawn : on cherche le PREMIER sol valide en partant du niveau
     * du stash et en descendant. "Valide" = bloc plein dessous + 2 blocs
     * traversables (pieds + tête). Le scan vers le bas en priorité évite de se
     * coller au plafond et les furnitures (barrières) ne bloquent plus la détection.
     */
    private Integer findGroundY(int bx, int bz, int refY) {
        int top = refY + GROUND_SEARCH_UP;
        int bottom = refY - GROUND_SEARCH_DOWN;
        // Descente prioritaire : on privilégie le sol le plus proche sous le stash.
        for (int y = top; y >= bottom; y--) {
            Block ground = world.getBlockAt(bx, y - 1, bz);
            Block feet = world.getBlockAt(bx, y, bz);
            Block head = world.getBlockAt(bx, y + 1, bz);
            if (!ground.getType().isAir() && ground.getType().isSolid()
                    && isPassable(feet) && isPassable(head)) {
                return y;
            }
        }
        return null;
    }
    public UUID getId() { return id; }
    public Player getOwner() { return owner; }
    public long getStealAmount() { return stealAmount; }
    public boolean isDetected() { return detected; }
    public CustomEntityHandle getHandle() { return entity; }
    private void rollDetection() {
        PlayerData data = plugin.core().playerData().get(owner);
        if (data == null) return;
        int level = data.getSecurityLevel();
        if (level <= 0) return;
        PluginConfig.SecurityUpgrade up = plugin.core().config().getSecurityUpgrade(level);
        if (up == null) return;
        if (ThreadLocalRandom.current().nextDouble() < up.detectionChance()) {
            detected = true;
            if (owner.isOnline()) {
                owner.sendMessage(ChatUtil.color("&c[Caméra] &fUn rat tente de te voler de l'argent !"));
                owner.playSound(owner.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1.0f, 0.5f);
            }
        }
    }
    private void rollTrap() {
        PlayerData data = plugin.core().playerData().get(owner);
        if (data == null) return;
        int level = data.getTrapLevel();
        if (level <= 0) return;
        PluginConfig.TrapUpgrade up = plugin.core().config().getTrapUpgrade(level);
        if (up == null) return;
        if (ThreadLocalRandom.current().nextDouble() < up.killChance()) {
            if (owner.isOnline()) {
                owner.sendMessage(ChatUtil.color("&a[Piège] &fUn rat a été éliminé !"));
                owner.playSound(owner.getLocation(), Sound.BLOCK_TRIPWIRE_CLICK_ON, 1.0f, 1.5f);
            }
            data.incrementRatsKilled();
            killByTrap();
        }
    }
    private void startTask() {
        task = new org.bukkit.scheduler.BukkitRunnable() {
            long localTick = 0;
            @Override
            public void run() {
                localTick++;
                if (!entity.isValid()) {
                    stop(false);
                    return;
                }
                if (!owner.isOnline() || !owner.getWorld().equals(world)) {
                    stop(false);
                    return;
                }
                switch (state) {
                    case APPROACHING -> approachStash();
                    case STEALING -> doSteal();
                    case ESCAPING -> escape();
                }
                if (localTick % 20 == 0) updateName();
            }
        };
        task.runTaskTimer(plugin, 2L, TASK_PERIOD);
        plugin.getServer().getScheduler().runTaskLater(plugin, this::rollTrap, 20L);
    }
    private void approachStash() {
        Location current = entity.getBukkitEntity().getLocation();
        double dist = current.distance(stashLoc);
        if (dist < 1.8) {
            state = State.STEALING;
            updateName();
            startTime = System.currentTimeMillis();
            currentVelocity = new Vector(0, 0, 0);
            stuckTicks = 0;
            world.spawnParticle(Particle.SMOKE, stashLoc, 10, 0.3, 0.3, 0.3, 0.02);
            return;
        }
        moveTowards(stashLoc);
    }
    private void doSteal() {
        long elapsed = System.currentTimeMillis() - startTime;
        long required = plugin.core().config().getRatsTimeToStealSec() * 1000L;
        world.spawnParticle(Particle.ANGRY_VILLAGER, entity.getBukkitEntity().getLocation().add(0, 0.5, 0), 1);
        if (elapsed >= required) {
            PlayerData data = plugin.core().playerData().get(owner);
            if (data != null) {
                long actual = Math.min(stealAmount, (long) data.getBalance());
                if (actual > 0) {
                    data.removeBalance(actual);
                    data.addStolenByRats(actual);
                    if (owner.isOnline()) {
                        owner.sendMessage(ChatUtil.color(
                                "&c[VOL] &fUn rat t'a volé &c" + NumberFormatUtil.money(actual) + " &f!"));
                        owner.playSound(owner.getLocation(), Sound.ENTITY_ITEM_BREAK, 0.8f, 0.7f);
                    }
                }
            }
            state = State.ESCAPING;
            updateName();
            startTime = System.currentTimeMillis();
            stuckTicks = 0;
        }
    }
    private void escape() {
        Location current = entity.getBukkitEntity().getLocation();
        Vector away = current.toVector().subtract(stashLoc.toVector()).normalize();
        if (away.lengthSquared() < 0.01) {
            away = new Vector(1, 0, 0);
        }
        Location target = current.clone().add(away.multiply(15));
        moveTowards(target);
        if (current.distance(stashLoc) > 20 || System.currentTimeMillis() - startTime > 15_000) {
            stop(false);
        }
    }
    private void moveTowards(Location target) {
        Entity bukkit = entity.getBukkitEntity();
        Location current = bukkit.getLocation();
        // ── Anti-blocage : mesure de la progression réelle au sol ──
        if (!Double.isNaN(lastX)) {
            double moved = Math.hypot(current.getX() - lastX, current.getZ() - lastZ);
            if (moved < 0.02) {
                stuckTicks++;
            } else {
                stuckTicks = 0;
            }
        }
        lastX = current.getX();
        lastZ = current.getZ();
        if (stuckTicks > STUCK_HARD_LIMIT_TICKS) {
            // Bloqué durablement (coincé dans un meuble / coin) : on fuit direct.
            if (state != State.ESCAPING) {
                state = State.ESCAPING;
                updateName();
                startTime = System.currentTimeMillis();
            } else {
                stop(false);
                return;
            }
            stuckTicks = 0;
        }
        Vector direction = target.toVector().subtract(current.toVector());
        direction.setY(0);
        if (direction.lengthSquared() < 0.001) return;
        double stepPerTick = plugin.core().config().getRatsSpeed() / 20.0;
        Vector desiredVelocity = direction.normalize().multiply(stepPerTick);
        double smoothing = 0.4;
        currentVelocity.setX(currentVelocity.getX() + (desiredVelocity.getX() - currentVelocity.getX()) * smoothing);
        currentVelocity.setZ(currentVelocity.getZ() + (desiredVelocity.getZ() - currentVelocity.getZ()) * smoothing);
        double horizontal = Math.hypot(currentVelocity.getX(), currentVelocity.getZ());
        if (horizontal > stepPerTick) {
            double scale = stepPerTick / horizontal;
            currentVelocity.setX(currentVelocity.getX() * scale);
            currentVelocity.setZ(currentVelocity.getZ() * scale);
        }
        Location newLoc = current.clone().add(currentVelocity.getX(), 0, currentVelocity.getZ());
        int bx = newLoc.getBlockX();
        int bz = newLoc.getBlockZ();
        // Recalage au sol : on cherche le sol le plus proche autour du Y courant,
        // en scannant prioritairement vers le bas (ignore le plafond).
        Integer safeY = findGroundY(bx, bz, current.getBlockY());
        if (safeY == null) {
            // Pas de sol valide devant : on incrémente le blocage. Si on est
            // immobilisé depuis un moment, on tente un petit pas latéral aléatoire
            // pour se dégager d'un meuble/coin plutôt que de figer indéfiniment.
            stuckTicks++;
            if (stuckTicks > STUCK_THRESHOLD_TICKS) {
                Location nudge = tryNudge(current);
                if (nudge != null) {
                    currentVelocity = new Vector(0, 0, 0);
                    bukkit.teleport(nudge);
                    lastX = nudge.getX();
                    lastZ = nudge.getZ();
                    return;
                }
            }
            currentVelocity = new Vector(0, 0, 0);
            return;
        }
        newLoc.setY(safeY);
        if (currentVelocity.lengthSquared() > 0.0001) {
            float targetYaw = (float) Math.toDegrees(Math.atan2(-currentVelocity.getX(), currentVelocity.getZ()));
            newLoc.setYaw(lerpAngle(current.getYaw(), targetYaw, 0.35f));
        } else {
            newLoc.setYaw(current.getYaw());
        }
        newLoc.setPitch(current.getPitch());
        bukkit.teleport(newLoc);
    }
    /**
     * Cherche une case adjacente dégagée (sol valide) pour se sortir d'un blocage.
     * Renvoie une Location de téléport, ou null si rien de praticable autour.
     */
    private Location tryNudge(Location current) {
        int cx = current.getBlockX();
        int cz = current.getBlockZ();
        int[][] offsets = { {1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {-1, -1}, {1, -1}, {-1, 1} };
        // Ordre aléatoire léger pour éviter un va-et-vient déterministe.
        int start = ThreadLocalRandom.current().nextInt(offsets.length);
        for (int i = 0; i < offsets.length; i++) {
            int[] o = offsets[(start + i) % offsets.length];
            int nx = cx + o[0];
            int nz = cz + o[1];
            Integer y = findGroundY(nx, nz, current.getBlockY());
            if (y != null) {
                return new Location(world, nx + 0.5, y, nz + 0.5,
                        current.getYaw(), current.getPitch());
            }
        }
        return null;
    }
    private float lerpAngle(float from, float to, float t) {
        float diff = ((to - from) % 360 + 540) % 360 - 180;
        return from + diff * t;
    }
    public void killByTrap() {
        Entity bukkit = entity.getBukkitEntity();
        if (entity.isValid()) {
            world.spawnParticle(Particle.CRIT, bukkit.getLocation(), 15, 0.3, 0.3, 0.3, 0.1);
            world.playSound(bukkit.getLocation(), Sound.ENTITY_RABBIT_DEATH, 1.0f, 0.5f);
        }
        stop(true);
    }
    public void killByPlayer() {
        PlayerData data = plugin.core().playerData().get(owner);
        if (data != null) {
            if (state == State.STEALING || state == State.APPROACHING) {
                data.incrementRatsScared();
            } else {
                data.incrementRatsKilled();
            }
        }
        if (entity.isValid()) {
            Entity bukkit = entity.getBukkitEntity();
            world.spawnParticle(Particle.CRIT, bukkit.getLocation(), 15, 0.3, 0.3, 0.3, 0.1);
            world.playSound(bukkit.getLocation(), Sound.ENTITY_RABBIT_DEATH, 1.0f, 0.5f);
        }
        if (owner.isOnline()) {
            owner.sendMessage(ChatUtil.color("&aTu as éliminé un rat voleur !"));
        }
        stop(true);
    }
    public void stop(boolean killed) {
        if (task != null && !task.isCancelled()) task.cancel();
        entity.remove();
        plugin.security().rat().unregister(this);
    }
}