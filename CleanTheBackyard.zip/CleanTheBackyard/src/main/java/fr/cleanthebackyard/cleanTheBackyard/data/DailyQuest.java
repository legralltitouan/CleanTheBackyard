package fr.cleanthebackyard.cleanTheBackyard.data;
public class DailyQuest {
    public enum Type {
        BREAK_BOXES("Détruire %d cartons"),
        EARN_MONEY("Gagner $%d"),
        BUY_VENDING("Acheter %d items au distributeur"),
        SELL_TIMES("Vendre son sac %d fois"),
        REACH_BAG_FULL("Remplir son sac %d fois");
        private final String description;
        Type(String description) { this.description = description; }
        public String getDescription() { return description; }
    }
    private final Type type;
    private final long target;
    private long progress;
    private final long reward;
    private boolean claimed;
    public DailyQuest(Type type, long target, long reward) {
        this(type, target, reward, 0, false);
    }
    public DailyQuest(Type type, long target, long reward, long progress, boolean claimed) {
        this.type = type;
        this.target = target;
        this.reward = reward;
        this.progress = progress;
        this.claimed = claimed;
    }
    public Type getType() { return type; }
    public long getTarget() { return target; }
    public long getProgress() { return progress; }
    public long getReward() { return reward; }
    public boolean isClaimed() { return claimed; }
    public boolean isCompleted() { return progress >= target; }
    public void addProgress(long amount) { this.progress = Math.min(target, progress + amount); }
    public void setProgress(long v) { this.progress = Math.min(target, v); }
    public void setClaimed(boolean v) { this.claimed = v; }
    public String getFormattedDescription() {
        return String.format(type.getDescription(), target);
    }
}