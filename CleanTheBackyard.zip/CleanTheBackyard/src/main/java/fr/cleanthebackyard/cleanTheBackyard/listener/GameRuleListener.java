package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.GameRule;
import org.bukkit.World;
import org.bukkit.entity.Monster;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.weather.ThunderChangeEvent;
import org.bukkit.event.weather.WeatherChangeEvent;
import org.bukkit.event.world.WorldLoadEvent;
public class GameRuleListener implements Listener {
    private final CleanTheBackyard plugin;
    public GameRuleListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    /**
     * Verrouille tous les mondes déjà chargés au démarrage. Appelé une fois
     * depuis onEnable — plus de boucle périodique : les game rules typées
     * désactivent durablement le cycle jour/nuit et météo, et les listeners
     * WeatherChange/ThunderChange bloquent toute tentative résiduelle.
     */
    public static void lockAllLoadedWorlds(CleanTheBackyard plugin) {
        for (World world : plugin.getServer().getWorlds()) {
            enforceDayAndClear(world);
        }
    }
    /** Verrouille un monde sur "jour + beau temps" (game rules typées). */
    private static void enforceDayAndClear(World world) {
        if (world == null) return;
        try {
            world.setGameRule(GameRule.DO_DAYLIGHT_CYCLE, false);
            world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        } catch (Throwable ignored) {}
        if (world.getTime() != 6000L) world.setTime(6000L);
        if (world.hasStorm() || world.isThundering()) {
            world.setStorm(false);
            world.setThundering(false);
        }
        world.setWeatherDuration(Integer.MAX_VALUE);
    }
    @EventHandler
    public void onWorldLoad(WorldLoadEvent event) {
        enforceDayAndClear(event.getWorld());
    }
    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        enforceDayAndClear(event.getPlayer().getWorld());
    }
    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        enforceDayAndClear(event.getPlayer().getWorld());
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onWeatherChange(WeatherChangeEvent event) {
        if (event.toWeatherState()) {
            event.setCancelled(true);
        }
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onThunderChange(ThunderChangeEvent event) {
        if (event.toThunderState()) {
            event.setCancelled(true);
        }
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageEvent event) {
        if (event.getEntity() instanceof Player) {
            event.setCancelled(true);
        }
    }
    @EventHandler(priority = EventPriority.HIGH)
    public void onFoodLevelChange(FoodLevelChangeEvent event) {
        if (event.getEntity() instanceof Player player) {
            event.setCancelled(true);
            player.setFoodLevel(20);
            player.setSaturation(20f);
        }
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCreatureSpawn(CreatureSpawnEvent event) {
        if (event.getEntity() instanceof Monster) {
            event.setCancelled(true);
        }
    }
}