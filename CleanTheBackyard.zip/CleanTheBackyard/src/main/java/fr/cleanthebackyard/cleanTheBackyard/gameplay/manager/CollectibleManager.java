package fr.cleanthebackyard.cleanTheBackyard.gameplay.manager;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.CollectibleItem;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

public class CollectibleManager {

    private final CleanTheBackyard plugin;
    private final Map<String, CollectibleItem> registry = new LinkedHashMap<>();
    private final NamespacedKey collectibleKey;
    private final NamespacedKey dirtyKey;

    public CollectibleManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.collectibleKey = new NamespacedKey(plugin, "collectible-key");
        this.dirtyKey = new NamespacedKey(plugin, "collectible-dirty");
        loadFromConfig();
    }

    public void loadFromConfig() {
        registry.clear();
        var section = plugin.getConfig().getConfigurationSection("collectibles");
        if (section == null) {
            plugin.getLogger().info("[CTB] Aucun collectible configuré.");
            return;
        }
        for (String key : section.getKeys(false)) {
            var sub = section.getConfigurationSection(key);
            if (sub == null) continue;
            try {
                CollectibleItem item = new CollectibleItem(
                        key,
                        sub.getString("name", key),
                        sub.getString("furniture-id", "ctb:" + key),
                        sub.getString("dirty-furniture-id", "ctb:dirty_" + key),
                        sub.getLong("sell-value", 100),
                        sub.getDouble("drop-chance", 0.01),
                        CollectibleItem.Rarity.valueOf(sub.getString("rarity", "COMMON").toUpperCase()),
                        sub.getInt("cleaning-difficulty", 3)
                );
                registry.put(key, item);
            } catch (Exception e) {
                plugin.getLogger().warning("[CTB] Collectible '" + key + "' invalide : " + e.getMessage());
            }
        }
        plugin.getLogger().info("[CTB] " + registry.size() + " collectibles chargés.");
    }

    public Collection<CollectibleItem> getAll() {
        return registry.values();
    }

    public CollectibleItem get(String key) {
        return registry.get(key);
    }

    /**
     * Appelé à chaque cassure de carton : roll global pour décider si un drop sale tombe.
     * Filtre automatiquement les items déjà collectés par le joueur.
     */
    public void rollDrop(Player player, Location boxLocation) {
        if (registry.isEmpty()) return;
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return;

        // Filtre : on ne propose que les items NON encore collectés ET non déjà dans l'inventaire
        List<CollectibleItem> eligible = new ArrayList<>();
        for (CollectibleItem item : registry.values()) {
            if (data.hasCollectedItem(item.getKey())) continue;
            if (playerAlreadyHasInInventory(player, item.getKey())) continue;
            eligible.add(item);
        }
        if (eligible.isEmpty()) return;

        double totalChance = eligible.stream().mapToDouble(CollectibleItem::getDropChance).sum();
        if (ThreadLocalRandom.current().nextDouble() > totalChance) return;

        double roll = ThreadLocalRandom.current().nextDouble() * totalChance;
        double cumulative = 0;
        for (CollectibleItem item : eligible) {
            cumulative += item.getDropChance();
            if (roll <= cumulative) {
                giveDirtyItem(player, item, boxLocation);
                return;
            }
        }
    }

    /** Vérifie si le joueur possède déjà ce collectible (sale ou propre) dans son inventaire. */
    private boolean playerAlreadyHasInInventory(Player player, String key) {
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack == null) continue;
            String k = getCollectibleKey(stack);
            if (key.equals(k)) return true;
        }
        return false;
    }

    private void giveDirtyItem(Player player, CollectibleItem item, Location boxLocation) {
        ItemStack stack = plugin.providers().furniture().getItemStack(item.getDirtyFurnitureNamespacedId());
        if (stack == null) {
            plugin.getLogger().warning("[CTB] Item sale introuvable : " + item.getDirtyFurnitureNamespacedId());
            return;
        }
        stack = tagItem(stack, item, true);

        var leftover = player.getInventory().addItem(stack);
        if (!leftover.isEmpty()) {
            leftover.values().forEach(i -> player.getWorld().dropItemNaturally(boxLocation, i));
        }

        String msg = ChatUtil.color("&6✦ Trouvaille ! &fUn objet sale est apparu : "
                + item.getRarity().getDisplayName() + " &f" + item.getDisplayName());
        player.sendMessage(msg);
        player.playSound(player.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0f, 0.5f);
        player.playSound(player.getLocation(), Sound.BLOCK_AMETHYST_BLOCK_CHIME, 0.8f, 1.5f);
    }

    /**
     * Tague un ItemStack avec le collectible (sale ou propre).
     */
    public ItemStack tagItem(ItemStack stack, CollectibleItem item, boolean dirty) {
        if (stack == null) return null;
        ItemMeta meta = stack.getItemMeta();
        if (meta == null) return stack;
        meta.getPersistentDataContainer().set(collectibleKey, PersistentDataType.STRING, item.getKey());
        meta.getPersistentDataContainer().set(dirtyKey, PersistentDataType.BYTE, (byte) (dirty ? 1 : 0));

        meta.displayName(ChatUtil.colored((dirty ? "&7[Sale] " : "&a[Propre] ")
                + item.getRarity().getDisplayName() + " &f" + item.getDisplayName()));

        List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
        lore.add(ChatUtil.colored("&7Rareté : " + item.getRarity().getDisplayName()));
        lore.add(ChatUtil.colored("&7Valeur : &a" + NumberFormatUtil.money(item.getSellValue())));
        if (dirty) {
            lore.add(ChatUtil.colored(" "));
            lore.add(ChatUtil.colored("&eClic droit pour le nettoyer"));
            lore.add(ChatUtil.colored("&7Difficulté : " + buildStars(item.getCleaningDifficulty())));
        } else {
            lore.add(ChatUtil.colored(" "));
            lore.add(ChatUtil.colored("&aPlace-le sur ton tableau de collection !"));
        }
        meta.lore(lore);

        stack.setItemMeta(meta);
        return stack;
    }

    private String buildStars(int difficulty) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 5; i++) sb.append(i < difficulty ? "&e★" : "&8★");
        return sb.toString();
    }

    public String getCollectibleKey(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) return null;
        return stack.getItemMeta().getPersistentDataContainer()
                .get(collectibleKey, PersistentDataType.STRING);
    }

    public boolean isDirty(ItemStack stack) {
        if (stack == null || stack.getItemMeta() == null) return false;
        Byte b = stack.getItemMeta().getPersistentDataContainer().get(dirtyKey, PersistentDataType.BYTE);
        return b != null && b == 1;
    }

    public boolean isCollectible(ItemStack stack) {
        return getCollectibleKey(stack) != null;
    }
}
