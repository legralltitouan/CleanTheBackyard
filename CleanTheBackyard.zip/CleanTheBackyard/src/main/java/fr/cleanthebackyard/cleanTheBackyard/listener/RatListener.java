package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.security.entity.RatEntity;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;

public class RatListener implements Listener {

    private final CleanTheBackyard plugin;

    public RatListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        Entity victim = event.getEntity();
        if (!plugin.providers().entity().isCtbEntity(victim, "rat")) return;
        event.setCancelled(true);
        RatEntity rat = plugin.security().rat().findByEntity(victim);
        if (rat != null && rat.getOwner().equals(player)) {
            rat.killByPlayer();
        }
    }

    /** Empêche les rats CTB de mourir par suffocation / dégâts environnementaux. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onEnvironmentalDamage(EntityDamageEvent event) {
        if (event instanceof EntityDamageByEntityEvent) return; // géré au-dessus
        if (!plugin.providers().entity().isCtbEntity(event.getEntity(), "rat")) return;
        switch (event.getCause()) {
            case SUFFOCATION, FALL, FIRE, FIRE_TICK, LAVA, DROWNING, CRAMMING, VOID -> event.setCancelled(true);
            default -> {}
        }
    }
}
