package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.entity.RatEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Rabbit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
public class RatListener implements Listener {
    private final CleanTheBackyard plugin;
    public RatListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (!(event.getEntity() instanceof Rabbit rabbit)) return;
        if (rabbit.getCustomName() == null || !rabbit.getCustomName().contains("Rat voleur")) return;
        event.setCancelled(true); // pas de dégât vanilla : un coup = mort
        RatEntity rat = plugin.getRatManager().findByEntity(rabbit);
        if (rat != null && rat.getOwner().equals(player)) {
            rat.killByPlayer();
        }
    }
}