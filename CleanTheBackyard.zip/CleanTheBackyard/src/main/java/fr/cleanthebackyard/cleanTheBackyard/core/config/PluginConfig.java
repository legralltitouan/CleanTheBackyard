package fr.cleanthebackyard.cleanTheBackyard.core.config;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import fr.cleanthebackyard.cleanTheBackyard.provider.EntityRef;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.EntityType;
import org.bukkit.util.BoundingBox;
import java.util.*;
public class PluginConfig {
    private final CleanTheBackyard plugin;
    private FileConfiguration cfg;
    private List<BagUpgrade> bagUpgrades = List.of();
    private List<ToolUpgrade> toolUpgrades = List.of();
    private List<EnergyUpgrade> energyUpgrades = List.of();
    private List<DroneConfig> droneConfigs = List.of();
    private List<VendingItem> vendingItems = List.of();
    private List<SecurityUpgrade> securityUpgrades = List.of();
    private List<TrapUpgrade> trapUpgrades = List.of();
    private List<FurnitureShopItem> furnitureShopItems = List.of();
    private List<TalentDef> talentDefs = List.of();
    private List<DroneModuleDef> droneModules = List.of();
    private List<DailyReward> dailyRewards = List.of();
    private List<CardboardZoneUpgrade> cardboardZoneUpgrades = List.of();
    private Map<Integer, BagUpgrade> bagByLevel = Map.of();
    private Map<Integer, ToolUpgrade> toolByLevel = Map.of();
    private Map<Integer, EnergyUpgrade> energyByLevel = Map.of();
    private Map<String, DroneConfig> droneByKey = Map.of();
    private Map<Integer, SecurityUpgrade> securityByLevel = Map.of();
    private Map<Integer, TrapUpgrade> trapByLevel = Map.of();
    private Map<String, FurnitureShopItem> furnitureShopByKey = Map.of();
    private Map<String, TalentDef> talentByKey = Map.of();
    private Map<String, DroneModuleDef> droneModuleByKey = Map.of();
    private Map<Integer, CardboardZoneUpgrade> cardboardZoneByLevel = Map.of();
    private BlockRef boxBlockRef;
    private BlockRef ufoBlockRef;
    private EntityRef goldenDroneEntityRef;
    private EntityRef ratEntityRef;
    private final Map<Integer, BoundingBox> boxRainRegionCache = new java.util.concurrent.ConcurrentHashMap<>();
    public PluginConfig(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.cfg = plugin.getConfig();
        loadAll();
    }
    public void reload() {
        plugin.reloadConfig();
        this.cfg = plugin.getConfig();
        boxRainRegionCache.clear();
        loadAll();
    }
    private void loadAll() {
        bagUpgrades      = Collections.unmodifiableList(loadBagUpgrades());
        toolUpgrades     = Collections.unmodifiableList(loadToolUpgrades());
        energyUpgrades   = Collections.unmodifiableList(loadEnergyUpgrades());
        droneConfigs     = Collections.unmodifiableList(loadDroneConfigs());
        vendingItems     = Collections.unmodifiableList(loadVendingItems());
        securityUpgrades = Collections.unmodifiableList(loadSecurityUpgrades());
        trapUpgrades     = Collections.unmodifiableList(loadTrapUpgrades());
        furnitureShopItems = Collections.unmodifiableList(loadFurnitureShopItems());
        talentDefs       = Collections.unmodifiableList(loadTalentDefs());
        droneModules     = Collections.unmodifiableList(loadDroneModules());
        dailyRewards     = Collections.unmodifiableList(loadDailyRewards());
        cardboardZoneUpgrades = Collections.unmodifiableList(loadCardboardZoneUpgrades());
        bagByLevel      = indexByLevel(bagUpgrades, BagUpgrade::level);
        toolByLevel     = indexByLevel(toolUpgrades, ToolUpgrade::level);
        energyByLevel   = indexByLevel(energyUpgrades, EnergyUpgrade::level);
        securityByLevel = indexByLevel(securityUpgrades, SecurityUpgrade::level);
        trapByLevel     = indexByLevel(trapUpgrades, TrapUpgrade::level);
        cardboardZoneByLevel = indexByLevel(cardboardZoneUpgrades, CardboardZoneUpgrade::level);
        Map<String, DroneConfig> dm = new LinkedHashMap<>();
        droneConfigs.forEach(d -> dm.put(d.key(), d));
        droneByKey = Collections.unmodifiableMap(dm);
        Map<String, FurnitureShopItem> fm = new LinkedHashMap<>();
        furnitureShopItems.forEach(f -> fm.put(f.key(), f));
        furnitureShopByKey = Collections.unmodifiableMap(fm);
        Map<String, TalentDef> tm = new LinkedHashMap<>();
        talentDefs.forEach(t -> tm.put(t.key(), t));
        talentByKey = Collections.unmodifiableMap(tm);
        Map<String, DroneModuleDef> mm = new LinkedHashMap<>();
        droneModules.forEach(m -> mm.put(m.key(), m));
        droneModuleByKey = Collections.unmodifiableMap(mm);
        boxBlockRef          = BlockRef.parse(cfg.getString("box-block", "vanilla:NOTE_BLOCK"));
        ufoBlockRef          = BlockRef.parse(cfg.getString("ufo-box-block", "vanilla:GLOWSTONE"));
        goldenDroneEntityRef = EntityRef.parse(cfg.getString("golden-drone-entity", "vanilla:BAT"), EntityType.BAT);
        ratEntityRef         = EntityRef.parse(cfg.getString("rats.entity", "vanilla:RABBIT"), EntityType.RABBIT);
    }
    private <T> Map<Integer, T> indexByLevel(List<T> list, java.util.function.ToIntFunction<T> levelFn) {
        Map<Integer, T> m = new HashMap<>();
        list.forEach(t -> m.put(levelFn.applyAsInt(t), t));
        return Collections.unmodifiableMap(m);
    }
    public BlockRef getBoxBlockRef()             { return boxBlockRef; }
    public BlockRef getUfoBlockRef()             { return ufoBlockRef; }
    public EntityRef getGoldenDroneEntityRef()   { return goldenDroneEntityRef; }
    public EntityRef getRatEntityRef()           { return ratEntityRef; }
    public String getHubWorldName()             { return cfg.getString("hub-world", "world"); }
    public World  getHubWorld()                 { return plugin.getServer().getWorld(getHubWorldName()); }
    public String getTemplateWorldName()        { return cfg.getString("template-world", "ctb_template"); }
    public String getPlayerWorldPrefix()        { return cfg.getString("player-world-prefix", "ctb_"); }
    public String getPlayerWorldName(UUID uuid) { return getPlayerWorldPrefix() + uuid; }
    public World  getPlayerWorld(UUID uuid)     { return plugin.getServer().getWorld(getPlayerWorldName(uuid)); }
    public String getHouseTemplateName()        { return cfg.getString("house-template", "ctb_house_template"); }
    public String getHouseWorldPrefix()         { return cfg.getString("house-world-prefix", "ctb_house_"); }
    public String getHouseWorldName(UUID uuid)  { return getHouseWorldPrefix() + uuid; }
    public World  getHouseWorld(UUID uuid)      { return plugin.getServer().getWorld(getHouseWorldName(uuid)); }
    public Location getHousePortalLocation(World w)  { return zoneLoc(w, "house-portal"); }
    public double   getHousePortalRadius()           { return cfg.getDouble("house-portal.radius", 2.5); }
    public Location getHouseExitLocation(World w)    { return zoneLoc(w, "house-exit"); }
    public double   getHouseExitRadius()             { return cfg.getDouble("house-exit.radius", 2.5); }
    public Location getHouseSpawn(World w) {
        if (w == null) return null;
        return readLocation("house-spawn", w);
    }
    public void setHouseSpawn(Location loc) { writeLocation("house-spawn", loc); }
    public Location getHubSpawnLocation() {
        World hub = getHubWorld();
        if (hub == null) return null;
        return readLocation("hub-spawn", hub);
    }
    public void setHubSpawn(Location loc) { writeLocation("hub-spawn", loc); }
    public Location getPlayerWorldSpawn(World w) {
        if (w == null) return null;
        return readLocation("player-world-spawn", w);
    }
    // ── Player bounds (limites du monde /go) ──
    public boolean isPlayerBoundsEnabled() { return cfg.getBoolean("player-bounds.enabled", true); }
    public BoundingBox getPlayerBounds()   { return readRegion("player-bounds"); }
    // ── Display de frontière de zone ──
    public boolean isZoneBorderDisplayEnabled() { return cfg.getBoolean("zone-border-display.enabled", true); }
    public double  getZoneBorderDisplayY()      { return cfg.getDouble("zone-border-display.y", -58); }
    public String  getZoneBorderText()          { return cfg.getString("zone-border-display.text",
            "&c✦ Limite de zone ✦\n&7Améliore au &eGarage &7pour débloquer plus de terrain !"); }
    public String  getZoneBorderTextMax()       { return cfg.getString("zone-border-display.text-max",
            "&a✦ Zone maximale atteinte ✦"); }
    /** Région étendue jusqu'au niveau MAX d'extension (pour prestige/restauration complète). */
    public BoundingBox getBoxRainRegionMax() {
        return extendRegion(getBoxRainRegionBase(), getMaxCardboardZoneLevel());
    }
    public BoundingBox getPrestigeResetRegionMax() {
        return extendRegion(getPrestigeResetRegionBase(), getMaxCardboardZoneLevel());
    }
    public void setPlayerWorldSpawn(Location loc) { writeLocation("player-world-spawn", loc); }
    private Location readLocation(String path, World fallbackWorld) {
        ConfigurationSection sec = cfg.getConfigurationSection(path);
        if (sec == null) return fallbackWorld.getSpawnLocation();
        return new Location(
                fallbackWorld,
                sec.getDouble("x", fallbackWorld.getSpawnLocation().getX()),
                sec.getDouble("y", fallbackWorld.getSpawnLocation().getY()),
                sec.getDouble("z", fallbackWorld.getSpawnLocation().getZ()),
                (float) sec.getDouble("yaw", 0),
                (float) sec.getDouble("pitch", 0)
        );
    }
    private void writeLocation(String path, Location loc) {
        cfg.set(path + ".x", loc.getX());
        cfg.set(path + ".y", loc.getY());
        cfg.set(path + ".z", loc.getZ());
        cfg.set(path + ".yaw", loc.getYaw());
        cfg.set(path + ".pitch", loc.getPitch());
        plugin.saveConfig();
    }
    public Location getCollectionBoardLocation(World w) { return zoneLoc(w, "collection-board"); }
    public double getCollectionBoardRadius()            { return cfg.getDouble("collection-board.radius", 2.5); }
    public Location getSellZoneCenter(World w)        { return zoneLoc(w, "sell-zone"); }
    public double   getSellZoneRadius()                { return cfg.getDouble("sell-zone.radius", 3.0); }
    public Location getGarageLocation(World w)         { return zoneLoc(w, "garage"); }
    public double   getGarageRadius()                  { return cfg.getDouble("garage.radius", 2.5); }
    public Location getVendingMachineLocation(World w) { return zoneLoc(w, "vending-machine"); }
    public double   getVendingMachineRadius()          { return cfg.getDouble("vending-machine.radius", 2.5); }
    public Location getDroneShopLocation(World w)      { return zoneLoc(w, "drone-shop"); }
    public double   getDroneShopRadius()               { return cfg.getDouble("drone-shop.radius", 2.5); }
    public Location getQuestBoardLocation(World w)     { return zoneLoc(w, "quest-board"); }
    public double   getQuestBoardRadius()              { return cfg.getDouble("quest-board.radius", 2.5); }
    public Location getPrestigeAltarLocation(World w)  { return zoneLoc(w, "prestige-altar"); }
    public double   getPrestigeAltarRadius()           { return cfg.getDouble("prestige-altar.radius", 2.5); }
    public Location getStashLocation(World w)          { return zoneLoc(w, "stash"); }
    public double   getStashRadius()                   { return cfg.getDouble("stash.radius", 2.5); }
    private Location zoneLoc(World w, String path) {
        return new Location(w, cfg.getDouble(path + ".x"), cfg.getDouble(path + ".y"), cfg.getDouble(path + ".z"));
    }
    /** Région de base de la pluie de cartons (palier 0). */
    public BoundingBox getBoxRainRegionBase()    { return readRegion("box-rain-region"); }
    /** Région de reset de prestige de base (palier 0). */
    public BoundingBox getPrestigeResetRegionBase()  { return readRegion("prestige-reset-region"); }
    public BoundingBox getBoxRainRegion(int cardboardZoneLevel) {
        BoundingBox cached = boxRainRegionCache.computeIfAbsent(cardboardZoneLevel,
                lvl -> extendRegion(getBoxRainRegionBase(), lvl));
        return cached.clone();
    }
    public BoundingBox getBoxRainRegion() {
        return getBoxRainRegionBase();
    }
    public BoundingBox getPrestigeResetRegion(int cardboardZoneLevel) {
        return extendRegion(getPrestigeResetRegionBase(), cardboardZoneLevel);
    }
    public BoundingBox getPrestigeResetRegion() {
        return getPrestigeResetRegionBase();
    }
    private BoundingBox extendRegion(BoundingBox base, int cardboardZoneLevel) {
        if (cardboardZoneLevel <= 0 || !isCardboardZoneEnabled()) return base;
        CardboardZoneUpgrade up = getCardboardZoneUpgrade(cardboardZoneLevel);
        if (up == null) return base;
        int depth = up.depthBonus();
        String axis = getCardboardZoneAxis();
        BoundingBox copy = base.clone();
        if ("X".equalsIgnoreCase(axis)) {
            copy.resize(copy.getMinX(), copy.getMinY(), copy.getMinZ(),
                    copy.getMaxX() + depth, copy.getMaxY(), copy.getMaxZ());
        } else {
            copy.resize(copy.getMinX(), copy.getMinY(), copy.getMinZ(),
                    copy.getMaxX(), copy.getMaxY(), copy.getMaxZ() + depth);
        }
        return copy;
    }
    private BoundingBox readRegion(String path) {
        return new BoundingBox(
                cfg.getDouble(path + ".min.x"), cfg.getDouble(path + ".min.y"), cfg.getDouble(path + ".min.z"),
                cfg.getDouble(path + ".max.x"), cfg.getDouble(path + ".max.y"), cfg.getDouble(path + ".max.z")
        );
    }
    public int  getBoxRainBoxesPerIteration() { return cfg.getInt("box-rain-region.boxes-per-iteration-per-player", 4); }
    public int  getBoxRainIterations()        { return cfg.getInt("box-rain-region.iterations", 30); }
    public long getBoxRainIntervalTicks()     { return cfg.getLong("box-rain-region.interval-ticks", 20L); }
    public double getBoxSellPrice()              { return cfg.getDouble("box-sell-price", 5.0); }
    public double getGlobalSellMultiplier()      { return cfg.getDouble("global-sell-multiplier", 1.0); }
    public void   setGlobalSellMultiplier(double v) { cfg.set("global-sell-multiplier", v); plugin.saveConfig(); }
    public double getMaxBreakDistance()          { return cfg.getDouble("max-break-distance", 5.0); }
    public double getEnergyCostPerBox()          { return cfg.getDouble("energy-cost-per-box", 10.0); }
    public int getUfoMultiplierDuration()        { return cfg.getInt("ufo-multiplier-duration", 3600); }
    public int getUfoEventQuota()                { return cfg.getInt("ufo-event-quota", 500); }
    public int getUfoMin()                       { return cfg.getInt("ufo-min", 900); }
    public int getUfoMax()                       { return cfg.getInt("ufo-max", 1800); }
    public int getGoldenDroneMin()               { return cfg.getInt("golden-drone-min", 240); }
    public int getGoldenDroneMax()               { return cfg.getInt("golden-drone-max", 600); }
    public int getGoldenDroneRewardMin()         { return cfg.getInt("golden-drone-reward-min", 500); }
    public int getGoldenDroneRewardMax()         { return cfg.getInt("golden-drone-reward-max", 2000); }
    public double getGoldenDroneSpeed()          { return cfg.getDouble("golden-drone-speed", 0.35); }
    public double getGoldenDroneSpawnDistance()  { return cfg.getDouble("golden-drone-spawn-distance", 8.0); }
    public int getGoldenDroneLifetimeSec()       { return cfg.getInt("golden-drone-lifetime-sec", 30); }
    public int getBoxRainMin()                   { return cfg.getInt("box-rain-min", 1200); }
    public int getBoxRainMax()                   { return cfg.getInt("box-rain-max", 2400); }
    public int getBlackMarketMin()               { return cfg.getInt("black-market-min", 1500); }
    public int getBlackMarketMax()               { return cfg.getInt("black-market-max", 3000); }
    public boolean isRatsEnabled()               { return cfg.getBoolean("rats.enabled", true); }
    public int     getRatsMinSpawnSec()          { return cfg.getInt("rats.spawn-min-sec", 180); }
    public int     getRatsMaxSpawnSec()          { return cfg.getInt("rats.spawn-max-sec", 480); }
    public double  getRatsStealPercentMin()      { return cfg.getDouble("rats.steal-percent-min", 0.01); }
    public double  getRatsStealPercentMax()      { return cfg.getDouble("rats.steal-percent-max", 0.05); }
    public long    getRatsStealCap()             { return cfg.getLong("rats.steal-cap", 5000L); }
    public int     getRatsTimeToStealSec()       { return cfg.getInt("rats.time-to-steal-sec", 20); }
    public double  getRatsSpeed()                { return cfg.getDouble("rats.speed", 0.3); }
    public long    getRatsMinBalanceToTrigger()  { return cfg.getLong("rats.min-balance-to-trigger", 200L); }
    public double  getRatsSpawnRadius()          { return cfg.getDouble("rats.spawn-radius", 6.0); }
    public long   getPrestigeRequiredEarned()    { return cfg.getLong("prestige.required-total-earned", 500_000L); }
    public int    getPrestigeMaxLevel()          { return cfg.getInt("prestige.max-level", 50); }
    public int getAutoSaveIntervalSeconds()      { return cfg.getInt("auto-save-interval-seconds", 300); }
    public long getDroneUpgradeCost(long droneCost, String upgradeType, int currentTier) {
        double base = cfg.getDouble("drone-upgrade.base-multiplier." + upgradeType, 0.4);
        double growth = cfg.getDouble("drone-upgrade.growth-per-tier", 1.75);
        return Math.round(droneCost * base * Math.pow(growth, currentTier));
    }
    public double getDroneSpeedTierBonus()  { return cfg.getDouble("drone-upgrade.speed-bonus-per-tier", 0.20); }
    public double getDroneRangeTierBonus()  { return cfg.getDouble("drone-upgrade.range-bonus-per-tier", 0.25); }
    public double getDroneIncomeTierBonus() { return cfg.getDouble("drone-upgrade.income-bonus-per-tier", 0.30); }
    // ── Batterie des drones ──
    public boolean isDroneBatteryEnabled()   { return cfg.getBoolean("drone-battery.enabled", true); }
    /** Capacité de batterie de base (en charges = nombre de cartons collectables). */
    public double getDroneBatteryBaseCapacity() { return cfg.getDouble("drone-battery.base-capacity", 100.0); }
    /** Bonus de capacité par tier (multiplicatif additif : +X par tier). */
    public double getDroneBatteryCapacityPerTier() { return cfg.getDouble("drone-battery.capacity-bonus-per-tier", 0.50); }
    public int getDroneBatteryMaxTier() { return cfg.getInt("drone-battery.max-capacity-tier", 8); }
    /** Énergie consommée par carton collecté/vendu. */
    public double getDroneBatteryDrainPerBox() { return cfg.getDouble("drone-battery.drain-per-box", 1.0); }
    /** Prix de recharge complète, rapporté à la capacité max (coût = capacité * ce facteur). */
    public double getDroneBatteryRechargeCostPerUnit() { return cfg.getDouble("drone-battery.recharge-cost-per-unit", 2.0); }
    /** Coût de l'amélioration de capacité (utilise le système de tier comme les autres upgrades). */
    public long getDroneBatteryUpgradeCost(long droneCost, int currentTier) {
        double base = cfg.getDouble("drone-battery.upgrade-base-multiplier", 0.5);
        double growth = cfg.getDouble("drone-upgrade.growth-per-tier", 1.75);
        return Math.round(droneCost * base * Math.pow(growth, currentTier));
    }
    // ── Sleep mode ──
    public int    getSleepUnlockPrestige() { return cfg.getInt("sleep-mode.unlock-prestige", 5); }
    public double getSleepEfficiency()     { return cfg.getDouble("sleep-mode.efficiency", 0.30); }
    public int    getSleepCapHours()       { return cfg.getInt("sleep-mode.cap-hours", 8); }
    public int    getSleepMinOfflineSec()  { return cfg.getInt("sleep-mode.min-offline-seconds", 60); }
    // ── BetterHUD ──
    public boolean isBetterHudEnabled()         { return cfg.getBoolean("betterhud.enabled", true); }
    public boolean shouldHideActionBar()        { return cfg.getBoolean("betterhud.hide-actionbar", true); }
    public int     getBetterHudRefreshTicks()   { return cfg.getInt("betterhud.placeholder-refresh-ticks", 4); }
    // ── Cardboard zone ──
    public boolean isCardboardZoneEnabled() { return cfg.getBoolean("cardboard-zone.enabled", true); }
    public String  getCardboardZoneAxis()   { return cfg.getString("cardboard-zone.axis", "Z"); }
    public record BagUpgrade(int level, int capacity, long cost) {}
    public record ToolUpgrade(int level, long cooldownMs, int boxesPerCollection, double extraBoxChance, long cost) {}
    public record EnergyUpgrade(int level, int maxEnergy, double regenPerSec, long cost) {}
    public record DroneConfig(
            String key, String name, double income,
            int intervalSec, long cost,
            int bagLevelRequired, int toolLevelRequired, int energyLevelRequired,
            double speed, int pickupRange,
            int maxSpeedTier, int maxRangeTier, int maxIncomeTier,
            EntityRef entityRef
    ) {}
    public record VendingItem(String key, String name, int energyRestore, long cost) {}
    public record SecurityUpgrade(int level, String name, double detectionChance, long cost) {}
    public record TrapUpgrade(int level, String name, double killChance, long cost) {}
    public record FurnitureShopItem(String key, String name, String furnitureId, long cost, Material iconMaterial) {}
    public record TalentDef(String key, String name, Material icon, int maxTier, double bonusPerTier) {}
    public record DroneModuleDef(String key, String name, Material icon, long cost,
                                 double rangeBonus, double speedBonus,
                                 double collectibleBonus, double saveChance,
                                 double solarChargePerSec) {}
    public record DailyReward(int day, long money, int doubleSellSeconds, String message) {}
    public record CardboardZoneUpgrade(int level, int depthBonus, long cost) {}
    public List<BagUpgrade>      getBagUpgrades()      { return bagUpgrades; }
    public List<ToolUpgrade>     getToolUpgrades()     { return toolUpgrades; }
    public List<EnergyUpgrade>   getEnergyUpgrades()   { return energyUpgrades; }
    public List<DroneConfig>     getDroneConfigs()     { return droneConfigs; }
    public List<VendingItem>     getVendingItems()     { return vendingItems; }
    public List<SecurityUpgrade> getSecurityUpgrades() { return securityUpgrades; }
    public List<TrapUpgrade>     getTrapUpgrades()     { return trapUpgrades; }
    public List<FurnitureShopItem> getFurnitureShopItems() { return furnitureShopItems; }
    public List<TalentDef>       getTalents()          { return talentDefs; }
    public List<DroneModuleDef>  getDroneModules()     { return droneModules; }
    public List<DailyReward>     getDailyRewards()     { return dailyRewards; }
    public List<CardboardZoneUpgrade> getCardboardZoneUpgrades() { return cardboardZoneUpgrades; }
    public BagUpgrade      getBagUpgrade(int level)    { return bagByLevel.get(level); }
    public ToolUpgrade     getToolUpgrade(int level)   { return toolByLevel.get(level); }
    public EnergyUpgrade   getEnergyUpgrade(int level) { return energyByLevel.get(level); }
    public DroneConfig     getDroneConfig(String key)  { return droneByKey.get(key); }
    public SecurityUpgrade getSecurityUpgrade(int l)   { return securityByLevel.get(l); }
    public TrapUpgrade     getTrapUpgrade(int l)       { return trapByLevel.get(l); }
    public FurnitureShopItem getFurnitureShopItem(String key) { return furnitureShopByKey.get(key); }
    public TalentDef       getTalent(String key)       { return talentByKey.get(key); }
    public DroneModuleDef  getDroneModule(String key)  { return droneModuleByKey.get(key); }
    public CardboardZoneUpgrade getCardboardZoneUpgrade(int level) { return cardboardZoneByLevel.get(level); }
    public int getMaxCardboardZoneLevel() { return cardboardZoneUpgrades.size(); }
    public DailyReward     getDailyReward(int day) {
        for (DailyReward r : dailyRewards) if (r.day() == day) return r;
        return null;
    }
    private List<BagUpgrade> loadBagUpgrades() {
        List<BagUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("bag-upgrades");
        if (raw == null) return list;
        for (Object o : raw) if (o instanceof Map<?, ?> m)
            list.add(new BagUpgrade(toInt(m.get("level"), 1), toInt(m.get("capacity"), 10), toLong(m.get("cost"), 0)));
        return list;
    }
    private List<ToolUpgrade> loadToolUpgrades() {
        List<ToolUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("tool-upgrades");
        if (raw == null) return list;
        for (Object o : raw) if (o instanceof Map<?, ?> m)
            list.add(new ToolUpgrade(toInt(m.get("level"), 1), toLong(m.get("cooldown-ms"), 1000),
                    toInt(m.get("boxes-per-collection"), 1), toDouble(m.get("extra-box-chance"), 0.0),
                    toLong(m.get("cost"), 0)));
        return list;
    }
    private List<EnergyUpgrade> loadEnergyUpgrades() {
        List<EnergyUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("energy-upgrades");
        if (raw == null) return list;
        for (Object o : raw) if (o instanceof Map<?, ?> m)
            list.add(new EnergyUpgrade(toInt(m.get("level"), 1), toInt(m.get("max-energy"), 100),
                    toDouble(m.get("regen-per-sec"), 1.0), toLong(m.get("cost"), 0)));
        return list;
    }
    private List<DroneConfig> loadDroneConfigs() {
        List<DroneConfig> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("drone-types");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection d = section.getConfigurationSection(key);
            if (d == null) continue;
            EntityRef ref = EntityRef.parse(d.getString("entity", "vanilla:BEE"), EntityType.BEE);
            list.add(new DroneConfig(key, d.getString("name", key), d.getDouble("income", 2),
                    d.getInt("interval-sec", 10), d.getLong("cost", 500),
                    d.getInt("bag-level-required", 1), d.getInt("tool-level-required", 1),
                    d.getInt("energy-level-required", 1), d.getDouble("speed", 3.0),
                    d.getInt("pickup-range", 20), d.getInt("max-speed-tier", 5),
                    d.getInt("max-range-tier", 5), d.getInt("max-income-tier", 5), ref));
        }
        return list;
    }
    private List<VendingItem> loadVendingItems() {
        List<VendingItem> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("vending-machine-items");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection v = section.getConfigurationSection(key);
            if (v == null) continue;
            list.add(new VendingItem(key, v.getString("name", key),
                    v.getInt("energy-restore", 25), v.getLong("cost", 10)));
        }
        return list;
    }
    private List<SecurityUpgrade> loadSecurityUpgrades() {
        List<SecurityUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("security-upgrades");
        if (raw == null) return list;
        for (Object o : raw) if (o instanceof Map<?, ?> m)
            list.add(new SecurityUpgrade(toInt(m.get("level"), 1), toStr(m.get("name"), "Caméra"),
                    toDouble(m.get("detection-chance"), 0.0), toLong(m.get("cost"), 0)));
        return list;
    }
    private List<TrapUpgrade> loadTrapUpgrades() {
        List<TrapUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("trap-upgrades");
        if (raw == null) return list;
        for (Object o : raw) if (o instanceof Map<?, ?> m)
            list.add(new TrapUpgrade(toInt(m.get("level"), 1), toStr(m.get("name"), "Piège"),
                    toDouble(m.get("kill-chance"), 0.0), toLong(m.get("cost"), 0)));
        return list;
    }
    private List<FurnitureShopItem> loadFurnitureShopItems() {
        List<FurnitureShopItem> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("furniture-shop");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection f = section.getConfigurationSection(key);
            if (f == null) continue;
            Material icon;
            try { icon = Material.valueOf(f.getString("icon-material", "ITEM_FRAME").toUpperCase()); }
            catch (IllegalArgumentException ex) { icon = Material.ITEM_FRAME; }
            list.add(new FurnitureShopItem(key, f.getString("name", key),
                    f.getString("furniture-id", "ctb:" + key), f.getLong("cost", 100), icon));
        }
        return list;
    }
    private List<TalentDef> loadTalentDefs() {
        List<TalentDef> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("talents");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection t = section.getConfigurationSection(key);
            if (t == null) continue;
            Material icon;
            try { icon = Material.valueOf(t.getString("icon", "BOOK").toUpperCase()); }
            catch (IllegalArgumentException ex) { icon = Material.BOOK; }
            list.add(new TalentDef(key, t.getString("name", key), icon,
                    t.getInt("max-tier", 10), t.getDouble("bonus-per-tier", 0.05)));
        }
        return list;
    }
    private List<DroneModuleDef> loadDroneModules() {
        List<DroneModuleDef> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("drone-modules");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            ConfigurationSection m = section.getConfigurationSection(key);
            if (m == null) continue;
            Material icon;
            try { icon = Material.valueOf(m.getString("icon", "REDSTONE").toUpperCase()); }
            catch (IllegalArgumentException ex) { icon = Material.REDSTONE; }
            list.add(new DroneModuleDef(key, m.getString("name", key), icon,
                    m.getLong("cost", 1000),
                    m.getDouble("range-bonus", 0.0),
                    m.getDouble("speed-bonus", 0.0),
                    m.getDouble("collectible-bonus", 0.0),
                    m.getDouble("save-chance", 0.0),
                    m.getDouble("solar-charge-per-sec", 0.0)));
        }
        return list;
    }
    private List<DailyReward> loadDailyRewards() {
        List<DailyReward> list = new ArrayList<>();
        ConfigurationSection section = cfg.getConfigurationSection("daily-rewards");
        if (section == null) return list;
        for (String key : section.getKeys(false)) {
            if (!key.startsWith("day-")) continue;
            int day;
            try { day = Integer.parseInt(key.substring(4)); }
            catch (NumberFormatException ex) { continue; }
            ConfigurationSection r = section.getConfigurationSection(key);
            if (r == null) continue;
            list.add(new DailyReward(day, r.getLong("money", 100),
                    r.getInt("double-sell-seconds", 0),
                    r.getString("message", "&aRécompense !")));
        }
        list.sort(Comparator.comparingInt(DailyReward::day));
        return list;
    }
    private List<CardboardZoneUpgrade> loadCardboardZoneUpgrades() {
        List<CardboardZoneUpgrade> list = new ArrayList<>();
        List<?> raw = cfg.getList("cardboard-zone.upgrades");
        if (raw == null) return list;
        for (Object o : raw) if (o instanceof Map<?, ?> m)
            list.add(new CardboardZoneUpgrade(
                    toInt(m.get("level"), 1),
                    toInt(m.get("depth-bonus"), 0),
                    toLong(m.get("cost"), 0)));
        list.sort(Comparator.comparingInt(CardboardZoneUpgrade::level));
        return list;
    }
    private int    toInt(Object o, int d)        { return o instanceof Number n ? n.intValue() : d; }
    private long   toLong(Object o, long d)      { return o instanceof Number n ? n.longValue() : d; }
    private double toDouble(Object o, double d)  { return o instanceof Number n ? n.doubleValue() : d; }
    private String toStr(Object o, String d)     { return o == null ? d : o.toString(); }
}