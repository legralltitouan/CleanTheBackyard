package fr.cleanthebackyard.cleanTheBackyard.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextColor;

/**
 * Utilitaire pour la gestion des messages de chat.
 */
public class ChatUtil {

    private static final String PREFIX = "&8[&aClean The Backyard&8] ";

    public static String color(String message) {
        return net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&', message);
    }

    public static Component colored(String message) {
        return Component.text(color(message));
    }
}
