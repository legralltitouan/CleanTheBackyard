package fr.cleanthebackyard.cleanTheBackyard.util;
import net.kyori.adventure.text.Component;
public final class ChatUtil {
    private ChatUtil() {}
    public static String color(String message) {
        return net.md_5.bungee.api.ChatColor.translateAlternateColorCodes('&', message);
    }
    public static Component colored(String message) {
        return Component.text(color(message));
    }
}