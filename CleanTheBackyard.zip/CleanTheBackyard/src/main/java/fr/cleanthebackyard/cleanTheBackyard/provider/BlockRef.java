package fr.cleanthebackyard.cleanTheBackyard.provider;

/**
 * Référence vers un type de bloc, vanilla ou custom (ItemsAdder).
 * Syntaxe config :
 *   "vanilla:NOTE_BLOCK"
 *   "itemsadder:mynamespace:carton"
 *   (sans préfixe → tenté en vanilla d'abord, puis ItemsAdder)
 */
public final class BlockRef {

    public enum Type { VANILLA, ITEMSADDER }

    private final Type type;
    private final String id;        // pour vanilla : "NOTE_BLOCK" ; pour IA : "mynamespace:carton"
    private final String rawConfig; // valeur brute pour debug

    public BlockRef(Type type, String id, String rawConfig) {
        this.type = type;
        this.id = id;
        this.rawConfig = rawConfig;
    }

    public Type getType() { return type; }
    public String getId() { return id; }
    public String getRawConfig() { return rawConfig; }

    @Override
    public String toString() {
        return type + ":" + id;
    }

    public static BlockRef parse(String raw) {
        if (raw == null || raw.isBlank()) {
            return new BlockRef(Type.VANILLA, "NOTE_BLOCK", "NOTE_BLOCK");
        }
        String trimmed = raw.trim();
        String lower = trimmed.toLowerCase();
        if (lower.startsWith("itemsadder:") || lower.startsWith("ia:")) {
            String id = trimmed.substring(trimmed.indexOf(':') + 1);
            return new BlockRef(Type.ITEMSADDER, id, raw);
        }
        if (lower.startsWith("vanilla:")) {
            String id = trimmed.substring("vanilla:".length());
            return new BlockRef(Type.VANILLA, id.toUpperCase(), raw);
        }
        // Pas de préfixe : on devine. Si ça contient ":", c'est très probablement ItemsAdder
        if (trimmed.contains(":")) {
            return new BlockRef(Type.ITEMSADDER, trimmed, raw);
        }
        return new BlockRef(Type.VANILLA, trimmed.toUpperCase(), raw);
    }
}
