package fr.cleanthebackyard.cleanTheBackyard.command;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class AdminCommand implements CommandExecutor, TabCompleter {

    private final CleanTheBackyard plugin;

    public AdminCommand(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        String sub = args[0].toLowerCase();
        if (!sender.hasPermission("ctb.admin")) {
            sender.sendMessage(ChatUtil.color("&cPas la permission."));
            return true;
        }
        if (!sender.hasPermission("ctb.admin." + sub)) {
            sender.sendMessage(ChatUtil.color("&cPermission manquante pour cette commande."));
            return true;
        }
        switch (sub) {
            case "stats" -> cmdStats(sender, args);
            case "money" -> cmdMoney(sender, args);
            case "level" -> cmdLevel(sender, args);
            case "bag" -> cmdBag(sender, args);
            case "energy" -> cmdEnergy(sender, args);
            case "drone" -> cmdDrone(sender, args);
            case "buff" -> cmdBuff(sender, args);
            case "event" -> cmdEvent(sender, args);
            case "sell" -> cmdSell(sender, args);
            case "prestige" -> cmdPrestige(sender, args);
            case "quest" -> cmdQuest(sender, args);
            case "rat" -> cmdRat(sender, args);
            case "reload" -> cmdReload(sender);
            case "hud" -> cmdHud(sender);
            default -> sendHelp(sender);
        }
        return true;
    }

    private void cmdHud(CommandSender sender) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage(ChatUtil.color("&cCommande joueur uniquement."));
            return;
        }
        boolean nowEnabled = plugin.getHudTask().toggleHud(p.getUniqueId());
        p.sendMessage(ChatUtil.color(nowEnabled
                ? "&aHUD activé."
                : "&7HUD désactivé."));
    }

    private void cmdRat(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;
        boolean ok = plugin.getRatManager().forceSpawnRat(target);
        if (ok) {
            sender.sendMessage(ChatUtil.color("&aRat forcé sur &f" + target.getName() + "&a !"));
        } else {
            sender.sendMessage(ChatUtil.color("&cImpossible : le joueur n'est pas dans son monde, ou un rat est déjà actif."));
        }
    }

    private void cmdStats(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) {
            sender.sendMessage(ChatUtil.color("&cDonnées introuvables."));
            return;
        }
        double globalMult = plugin.getPluginConfig().getGlobalSellMultiplier();
        sender.sendMessage(ChatUtil.color("&8══ &aStats de &f" + target.getName() + " &8══"));
        sender.sendMessage(ChatUtil.color("&7Prestige       : &6" + data.getPrestigeLevel()));
        sender.sendMessage(ChatUtil.color("&7Solde          : &f" + NumberFormatUtil.money(data.getBalance())));
        sender.sendMessage(ChatUtil.color("&7Total gagné    : &f" + NumberFormatUtil.money(data.getLifetimeEarned())));
        sender.sendMessage(ChatUtil.color("&7Volé par rats  : &c" + NumberFormatUtil.money(data.getTotalStolenByRats())));
        sender.sendMessage(ChatUtil.color("&7Cartons cassés : &f" + NumberFormatUtil.format(data.getTotalBoxesBroken())));
        sender.sendMessage(ChatUtil.color("&7Sac            : &f" + data.getCurrentBoxes() + "/" + plugin.getBoxManager().getBagCapacity(data.getBagLevel()) + " (Niv " + data.getBagLevel() + ")"));
        sender.sendMessage(ChatUtil.color("&7Outil          : &fNiv " + data.getToolLevel()));
        sender.sendMessage(ChatUtil.color("&7Énergie        : &f" + String.format("%.0f", data.getCurrentEnergy()) + "/" + plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel()) + " (Niv " + data.getEnergyLevel() + ")"));
        sender.sendMessage(ChatUtil.color("&7Drones         : &f" + data.getOwnedDrones().size()));
        sender.sendMessage(ChatUtil.color("&7Sécurité       : &fCaméra Niv " + data.getSecurityLevel() + " | Piège Niv " + data.getTrapLevel()));
        sender.sendMessage(ChatUtil.color("&7Buff x2 vente  : &f" + (data.hasDoubleSell() ? "&aActif &f(" + data.getDoubleSellRemainingSeconds() + "s)" : "&cInactif")));
        sender.sendMessage(ChatUtil.color("&7Marché Noir x3 : &f" + (data.hasBlackMarket() ? "&aActif &f(" + data.getBlackMarketRemainingSeconds() + "s)" : "&cInactif")));
        sender.sendMessage(ChatUtil.color("&7Bonus global   : &fx" + String.format("%.1f", globalMult)));
        sender.sendMessage(ChatUtil.color("&7Énergie illim. : &f" + (data.hasUnlimitedEnergy() ? "&aActive &f(" + data.getUnlimitedEnergyRemainingSeconds() + "s)" : "&cInactive")));
        sender.sendMessage(ChatUtil.color("&8══════════════════════"));
    }

    private void cmdMoney(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("money give|set|take <joueur> <montant>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) {
            sender.sendMessage(ChatUtil.color("&cDonnées introuvables."));
            return;
        }
        double amount;
        try {
            amount = Double.parseDouble(args[3]);
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatUtil.color("&cMontant invalide."));
            return;
        }
        if (amount <= 0) {
            sender.sendMessage(ChatUtil.color("&cMontant doit être > 0."));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "give" -> {
                data.addBalance(amount);
                sender.sendMessage(ChatUtil.color("&a+" + NumberFormatUtil.money(amount) + " &fdonné à &a" + target.getName()));
            }
            case "take" -> {
                if (!data.removeBalance(amount)) {
                    sender.sendMessage(ChatUtil.color("&cSolde insuffisant."));
                    return;
                }
                sender.sendMessage(ChatUtil.color("&c-" + NumberFormatUtil.money(amount) + " &fprélevé."));
            }
            case "set" -> {
                data.setBalance(amount);
                sender.sendMessage(ChatUtil.color("&fSolde défini à &f" + NumberFormatUtil.money(amount)));
            }
            default -> sender.sendMessage(usage("money give|set|take <joueur> <montant>"));
        }
    }

    private void cmdLevel(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("level bag|tool|energy <joueur> <niveau>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        int level;
        try {
            level = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            sender.sendMessage(ChatUtil.color("&cNiveau invalide."));
            return;
        }
        if (level < 1) return;
        switch (args[1].toLowerCase()) {
            case "bag" -> {
                int max = plugin.getPluginConfig().getBagUpgrades().size();
                if (level > max) {
                    sender.sendMessage(ChatUtil.color("&cMax : " + max));
                    return;
                }
                data.setBagLevel(level);
                sender.sendMessage(ChatUtil.color("&aSac défini niveau " + level));
            }
            case "tool" -> {
                int max = plugin.getPluginConfig().getToolUpgrades().size();
                if (level > max) {
                    sender.sendMessage(ChatUtil.color("&cMax : " + max));
                    return;
                }
                data.setToolLevel(level);
                sender.sendMessage(ChatUtil.color("&aOutil défini niveau " + level));
            }
            case "energy" -> {
                int max = plugin.getPluginConfig().getEnergyUpgrades().size();
                if (level > max) {
                    sender.sendMessage(ChatUtil.color("&cMax : " + max));
                    return;
                }
                data.setEnergyLevel(level);
                data.setCurrentEnergy(plugin.getBoxManager().getMaxEnergyForLevel(level));
                sender.sendMessage(ChatUtil.color("&aÉnergie définie niveau " + level));
            }
            default -> sender.sendMessage(usage("level bag|tool|energy <joueur> <niveau>"));
        }
    }

    private void cmdBag(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(usage("bag fill|clear|set <joueur> [quantité]"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        switch (args[1].toLowerCase()) {
            case "fill" -> {
                int cap = plugin.getBoxManager().getBagCapacity(data.getBagLevel());
                data.setCurrentBoxes(cap);
                sender.sendMessage(ChatUtil.color("&aSac rempli."));
            }
            case "clear" -> {
                data.clearBag();
                sender.sendMessage(ChatUtil.color("&aSac vidé."));
            }
            case "set" -> {
                if (args.length < 4) return;
                int amount;
                try {
                    amount = Integer.parseInt(args[3]);
                } catch (NumberFormatException e) {
                    return;
                }
                int cap = plugin.getBoxManager().getBagCapacity(data.getBagLevel());
                data.setCurrentBoxes(Math.min(amount, cap));
                sender.sendMessage(ChatUtil.color("&aSac défini à " + Math.min(amount, cap)));
            }
            default -> sender.sendMessage(usage("bag fill|clear|set <joueur> [quantité]"));
        }
    }

    private void cmdEnergy(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(usage("energy fill|set|drain <joueur> [valeur]"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());
        switch (args[1].toLowerCase()) {
            case "fill" -> {
                data.setCurrentEnergy(maxEnergy);
                plugin.getBoxManager().removeFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&aÉnergie remplie."));
            }
            case "drain" -> {
                data.setCurrentEnergy(0);
                plugin.getBoxManager().applyFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&cÉnergie drainée."));
            }
            case "set" -> {
                if (args.length < 4) return;
                double val;
                try {
                    val = Double.parseDouble(args[3]);
                } catch (NumberFormatException e) {
                    return;
                }
                data.setCurrentEnergy(Math.min(val, maxEnergy));
                sender.sendMessage(ChatUtil.color("&aÉnergie : " + val));
            }
            default -> sender.sendMessage(usage("energy fill|set|drain <joueur> [valeur]"));
        }
    }

    private void cmdDrone(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("drone give|remove <joueur> <clé>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        String droneKey = args[3].toLowerCase();
        boolean exists = plugin.getPluginConfig().getDroneConfigs().stream()
                .anyMatch(d -> d.key().equals(droneKey));
        if (!exists) {
            sender.sendMessage(ChatUtil.color("&cDrone inconnu."));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "give" -> {
                if (data.hasDrone(droneKey)) return;
                data.addDrone(droneKey);
                sender.sendMessage(ChatUtil.color("&aDrone donné."));
            }
            case "remove" -> {
                if (!data.hasDrone(droneKey)) return;
                data.getOwnedDrones().remove(droneKey);
                sender.sendMessage(ChatUtil.color("&cDrone retiré."));
            }
            default -> sender.sendMessage(usage("drone give|remove <joueur> <clé>"));
        }
    }

    private void cmdBuff(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("buff doublesell|unlimitedenergy|blackmarket <joueur> <secondes>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        int seconds;
        try {
            seconds = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            return;
        }
        if (seconds <= 0) return;
        switch (args[1].toLowerCase()) {
            case "doublesell" -> {
                data.setDoubleSell(seconds);
                sender.sendMessage(ChatUtil.color("&aBuff x2 vente appliqué."));
            }
            case "unlimitedenergy" -> {
                data.setUnlimitedEnergy(seconds);
                plugin.getBoxManager().removeFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&aÉnergie illimitée appliquée."));
            }
            case "blackmarket" -> {
                data.setBlackMarket(seconds);
                sender.sendMessage(ChatUtil.color("&5Marché Noir x3 appliqué."));
            }
            default -> sender.sendMessage(usage("buff doublesell|unlimitedenergy|blackmarket <joueur> <secondes>"));
        }
    }

    private void cmdEvent(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(usage("event drone|ufo|boxrain|blackmarket"));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "drone" -> {
                if (plugin.getEventManager().isGoldenDroneSpawned()) {
                    sender.sendMessage(ChatUtil.color("&eDéjà actif."));
                    return;
                }
                plugin.getEventManager().spawnGoldenDrone();
                sender.sendMessage(ChatUtil.color("&6Drone Doré invoqué."));
            }
            case "ufo" -> {
                if (plugin.getEventManager().isUfoEventActive()) {
                    sender.sendMessage(ChatUtil.color("&eDéjà actif."));
                    return;
                }
                plugin.getEventManager().forceStartUfoEvent();
                sender.sendMessage(ChatUtil.color("&5OVNI déclenché."));
            }
            case "boxrain" -> {
                plugin.getEventManager().triggerBoxRainNow();
                sender.sendMessage(ChatUtil.color("&3Pluie de cartons déclenchée."));
            }
            case "blackmarket" -> {
                plugin.getEventManager().triggerBlackMarketNow();
                sender.sendMessage(ChatUtil.color("&5Marché Noir déclenché."));
            }
            default -> sender.sendMessage(usage("event drone|ufo|boxrain|blackmarket"));
        }
    }

    private void cmdSell(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;
        plugin.getEconomyManager().sellBag(target);
        sender.sendMessage(ChatUtil.color("&aSac vendu pour " + target.getName()));
    }

    private void cmdPrestige(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(usage("prestige set|add <joueur> <niveau>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        if (args.length < 4) {
            sender.sendMessage(ChatUtil.color("&7Prestige actuel : &6" + data.getPrestigeLevel()));
            return;
        }
        int val;
        try {
            val = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            return;
        }
        switch (args[1].toLowerCase()) {
            case "set" -> {
                data.setPrestigeLevel(Math.max(0, val));
                sender.sendMessage(ChatUtil.color("&6Prestige défini à " + val));
            }
            case "add" -> {
                data.setPrestigeLevel(data.getPrestigeLevel() + val);
                sender.sendMessage(ChatUtil.color("&6Prestige : " + data.getPrestigeLevel()));
            }
            default -> sender.sendMessage(usage("prestige set|add <joueur> <niveau>"));
        }
    }

    private void cmdQuest(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(usage("quest reset|show <joueur>"));
            return;
        }
        Player target = args.length >= 3 ? getOnlinePlayer(sender, args[2]) : (sender instanceof Player ? (Player) sender : null);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        switch (args[1].toLowerCase()) {
            case "reset" -> {
                data.setQuestResetTimestamp(0L);
                plugin.getQuestManager().checkAndResetQuests(data);
                sender.sendMessage(ChatUtil.color("&aQuêtes regénérées."));
            }
            case "show" -> {
                plugin.getQuestManager().checkAndResetQuests(data);
                sender.sendMessage(ChatUtil.color("&6Quêtes de " + target.getName() + " :"));
                data.getDailyQuests().forEach(q ->
                        sender.sendMessage(ChatUtil.color(" &7- &f" + q.getFormattedDescription()
                                + " &7(" + q.getProgress() + "/" + q.getTarget() + ")"
                                + (q.isClaimed() ? " &a✓" : q.isCompleted() ? " &e!" : "")))
                );
            }
            default -> sender.sendMessage(usage("quest reset|show <joueur>"));
        }
    }

    private void cmdReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getPlayerDataManager().saveAll();
        sender.sendMessage(ChatUtil.color("&aConfiguration rechargée."));
    }

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String label, String[] args) {
        List<String> completions = new ArrayList<>();
        List<String> playerNames = Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
        List<String> droneKeys = plugin.getPluginConfig().getDroneConfigs().stream().map(d -> d.key()).toList();
        if (args.length == 1) {
            completions.addAll(List.of("stats", "money", "level", "bag", "energy", "drone",
                    "buff", "event", "sell", "prestige", "quest", "rat", "hud", "reload"));
        } else if (args.length == 2) {
            completions.addAll(switch (args[0].toLowerCase()) {
                case "money" -> List.of("give", "set", "take");
                case "level" -> List.of("bag", "tool", "energy");
                case "bag" -> List.of("fill", "clear", "set");
                case "energy" -> List.of("fill", "set", "drain");
                case "drone" -> List.of("give", "remove");
                case "buff" -> List.of("doublesell", "unlimitedenergy", "blackmarket");
                case "event" -> List.of("drone", "ufo", "boxrain", "blackmarket");
                case "prestige" -> List.of("set", "add");
                case "quest" -> List.of("reset", "show");
                case "stats", "sell", "rat" -> playerNames;
                default -> List.of();
            });
        } else if (args.length == 3) {
            completions.addAll(switch (args[0].toLowerCase()) {
                case "money", "level", "bag", "energy", "drone", "buff", "prestige", "quest" -> playerNames;
                default -> List.of();
            });
        } else if (args.length == 4) {
            if (args[0].equalsIgnoreCase("drone")) completions.addAll(droneKeys);
            else if (args[0].equalsIgnoreCase("money")) completions.addAll(List.of("100", "1000", "10000"));
            else if (args[0].equalsIgnoreCase("level")) completions.addAll(List.of("1", "5", "10", "15"));
            else if (args[0].equalsIgnoreCase("buff")) completions.addAll(List.of("60", "180", "600"));
            else if (args[0].equalsIgnoreCase("prestige")) completions.addAll(List.of("1", "5", "10"));
        }
        String filter = args[args.length - 1].toLowerCase();
        return completions.stream().filter(s -> s.toLowerCase().startsWith(filter)).toList();
    }

    private Player resolveTarget(CommandSender sender, String[] args, int argIndex) {
        if (args.length > argIndex) return getOnlinePlayer(sender, args[argIndex]);
        if (sender instanceof Player p) return p;
        sender.sendMessage(ChatUtil.color("&cSpécifiez un joueur."));
        return null;
    }

    private Player getOnlinePlayer(CommandSender sender, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) sender.sendMessage(ChatUtil.color("&cJoueur introuvable : " + name));
        return p;
    }

    private String usage(String syntax) {
        return ChatUtil.color("&cUsage : &f/ctb " + syntax);
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatUtil.color("&8══ &6CTB Admin &8══"));
        sender.sendMessage(ChatUtil.color("&e/ctb stats &7[joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb money &7give|set|take <joueur> <montant>"));
        sender.sendMessage(ChatUtil.color("&e/ctb level &7bag|tool|energy <joueur> <niveau>"));
        sender.sendMessage(ChatUtil.color("&e/ctb bag &7fill|clear|set <joueur> [quantité]"));
        sender.sendMessage(ChatUtil.color("&e/ctb energy &7fill|set|drain <joueur> [valeur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb drone &7give|remove <joueur> <clé>"));
        sender.sendMessage(ChatUtil.color("&e/ctb buff &7doublesell|unlimitedenergy|blackmarket <joueur> <secondes>"));
        sender.sendMessage(ChatUtil.color("&e/ctb event &7drone|ufo|boxrain|blackmarket"));
        sender.sendMessage(ChatUtil.color("&e/ctb sell &7[joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb prestige &7set|add <joueur> <niveau>"));
        sender.sendMessage(ChatUtil.color("&e/ctb quest &7reset|show [joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb rat &7[joueur] &8- force le spawn d'un rat"));
        sender.sendMessage(ChatUtil.color("&e/ctb reload"));
        sender.sendMessage(ChatUtil.color("&e/ctb hud &7- toggle l'actionbar"));
    }
}
