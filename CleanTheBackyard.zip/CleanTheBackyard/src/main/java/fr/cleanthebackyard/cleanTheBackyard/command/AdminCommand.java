package fr.cleanthebackyard.cleanTheBackyard.command;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class AdminCommand implements CommandExecutor, TabCompleter {

    private final CleanTheBackyard plugin;

    public AdminCommand(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "stats"  -> cmdStats(sender, args);
            case "money"  -> cmdMoney(sender, args);
            case "level"  -> cmdLevel(sender, args);
            case "bag"    -> cmdBag(sender, args);
            case "energy" -> cmdEnergy(sender, args);
            case "drone"  -> cmdDrone(sender, args);
            case "buff"   -> cmdBuff(sender, args);
            case "event"  -> cmdEvent(sender, args);
            case "sell"   -> cmdSell(sender, args);
            case "reload" -> cmdReload(sender);
            default       -> sendHelp(sender);
        }
        return true;
    }

    // ── /ctb stats [player] ───────────────────────────────────────────

    private void cmdStats(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;

        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) { sender.sendMessage(ChatUtil.color("&cDonnées introuvables.")); return; }

        sender.sendMessage(ChatUtil.color("&8══ &aStats de &f" + target.getName() + " &8══"));
        sender.sendMessage(ChatUtil.color("&7Solde          : &f$" + String.format("%.0f", data.getBalance())));
        sender.sendMessage(ChatUtil.color("&7Cartons cassés : &f" + data.getTotalBoxesBroken()));
        sender.sendMessage(ChatUtil.color("&7Sac            : &f" + data.getCurrentBoxes() + "/" + plugin.getBoxManager().getBagCapacity(data.getBagLevel()) + " (Niv " + data.getBagLevel() + ")"));
        sender.sendMessage(ChatUtil.color("&7Outil          : &fNiv " + data.getToolLevel()));
        sender.sendMessage(ChatUtil.color("&7Énergie        : &f" + String.format("%.0f", data.getCurrentEnergy()) + "/" + plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel()) + " (Niv " + data.getEnergyLevel() + ")"));
        sender.sendMessage(ChatUtil.color("&7Drones         : &f" + data.getOwnedDrones()));
        sender.sendMessage(ChatUtil.color("&7Buff x2 vente  : &f" + (data.hasDoubleSell() ? "&aActif" : "&cInactif")));
        sender.sendMessage(ChatUtil.color("&7Énergie illim. : &f" + (data.hasUnlimitedEnergy() ? "&aActive" : "&cInactive")));
        sender.sendMessage(ChatUtil.color("&8══════════════════════"));
    }

    // ── /ctb money <give|set|take> <player> <amount> ─────────────────

    private void cmdMoney(CommandSender sender, String[] args) {

        if (!sender.hasPermission("ctb.admin.money")) {
            sender.sendMessage(ChatUtil.color("&cVous n'avez pas la permission.")); return;
        }

        // args: money <give|set|take> <player> <amount>
        if (args.length < 4) { sender.sendMessage(usage("money give|set|take <joueur> <montant>")); return; }

        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;

        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) { sender.sendMessage(ChatUtil.color("&cDonnées introuvables.")); return; }

        double amount;
        try { amount = Double.parseDouble(args[3]); } catch (NumberFormatException e) {
            sender.sendMessage(ChatUtil.color("&cMontant invalide : " + args[3]));
            return;
        }
        if (amount <= 0) { sender.sendMessage(ChatUtil.color("&cLe montant doit être positif.")); return; }

        switch (args[1].toLowerCase()) {
            case "give" -> {
                data.addBalance(amount);
                sender.sendMessage(ChatUtil.color("&a+$" + String.format("%.0f", amount) + " &fdonné à &a" + target.getName()));
                target.sendMessage(ChatUtil.color("&a[Admin] Vous avez reçu &f$" + String.format("%.0f", amount) + " &a!"));
            }
            case "take" -> {
                if (!data.removeBalance(amount)) {
                    sender.sendMessage(ChatUtil.color("&c" + target.getName() + " n'a pas assez d'argent (solde : $" + String.format("%.0f", data.getBalance()) + ")"));
                    return;
                }
                sender.sendMessage(ChatUtil.color("&c-$" + String.format("%.0f", amount) + " &fprélevé à &c" + target.getName()));
                target.sendMessage(ChatUtil.color("&c[Admin] &f$" + String.format("%.0f", amount) + " &cretirés de votre compte."));
            }
            case "set" -> {
                data.setBalance(amount);
                sender.sendMessage(ChatUtil.color("&fSolde de &a" + target.getName() + " &fdéfini à &f$" + String.format("%.0f", amount)));
                target.sendMessage(ChatUtil.color("&7[Admin] Votre solde a été défini à &f$" + String.format("%.0f", amount)));
            }
            default -> sender.sendMessage(usage("money give|set|take <joueur> <montant>"));
        }
    }

    // ── /ctb level <bag|tool|energy> <player> <level> ────────────────

    private void cmdLevel(CommandSender sender, String[] args) {
        if (args.length < 4) { sender.sendMessage(usage("level bag|tool|energy <joueur> <niveau>")); return; }

        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;

        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) { sender.sendMessage(ChatUtil.color("&cDonnées introuvables.")); return; }

        int level;
        try { level = Integer.parseInt(args[3]); } catch (NumberFormatException e) {
            sender.sendMessage(ChatUtil.color("&cNiveau invalide : " + args[3])); return;
        }
        if (level < 1) { sender.sendMessage(ChatUtil.color("&cLe niveau doit être ≥ 1.")); return; }

        switch (args[1].toLowerCase()) {
            case "bag" -> {
                int max = plugin.getPluginConfig().getBagUpgrades().size();
                if (level > max) { sender.sendMessage(ChatUtil.color("&cNiveau max du sac : " + max)); return; }
                data.setBagLevel(level);
                notifyLevelChange(sender, target, "Sac", level);
            }
            case "tool" -> {
                int max = plugin.getPluginConfig().getToolUpgrades().size();
                if (level > max) { sender.sendMessage(ChatUtil.color("&cNiveau max de l'outil : " + max)); return; }
                data.setToolLevel(level);
                notifyLevelChange(sender, target, "Outil", level);
            }
            case "energy" -> {
                int max = plugin.getPluginConfig().getEnergyUpgrades().size();
                if (level > max) { sender.sendMessage(ChatUtil.color("&cNiveau max de l'énergie : " + max)); return; }
                data.setEnergyLevel(level);
                data.setCurrentEnergy(plugin.getBoxManager().getMaxEnergyForLevel(level));
                notifyLevelChange(sender, target, "Énergie", level);
            }
            default -> sender.sendMessage(usage("level bag|tool|energy <joueur> <niveau>"));
        }
    }

    private void notifyLevelChange(CommandSender sender, Player target, String type, int level) {
        sender.sendMessage(ChatUtil.color("&a" + type + " de &f" + target.getName() + " &adéfini au niveau &f" + level));
        target.sendMessage(ChatUtil.color("&7[Admin] Votre niveau &f" + type + " &7a été défini à &f" + level));
    }

    // ── /ctb bag <fill|clear|set> <player> [amount] ──────────────────

    private void cmdBag(CommandSender sender, String[] args) {
        if (args.length < 3) { sender.sendMessage(usage("bag fill|clear|set <joueur> [quantité]")); return; }

        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;

        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) { sender.sendMessage(ChatUtil.color("&cDonnées introuvables.")); return; }

        switch (args[1].toLowerCase()) {
            case "fill" -> {
                int cap = plugin.getBoxManager().getBagCapacity(data.getBagLevel());
                data.setCurrentBoxes(cap);
                sender.sendMessage(ChatUtil.color("&aSac de &f" + target.getName() + " &arempli (" + cap + "/" + cap + ")"));
                target.sendMessage(ChatUtil.color("&7[Admin] Votre sac a été rempli."));
            }
            case "clear" -> {
                data.clearBag();
                sender.sendMessage(ChatUtil.color("&aSac de &f" + target.getName() + " &avidé."));
                target.sendMessage(ChatUtil.color("&7[Admin] Votre sac a été vidé."));
            }
            case "set" -> {
                if (args.length < 4) { sender.sendMessage(usage("bag set <joueur> <quantité>")); return; }
                int amount;
                try { amount = Integer.parseInt(args[3]); } catch (NumberFormatException e) {
                    sender.sendMessage(ChatUtil.color("&cQuantité invalide.")); return;
                }
                int cap = plugin.getBoxManager().getBagCapacity(data.getBagLevel());
                data.setCurrentBoxes(Math.min(amount, cap));
                sender.sendMessage(ChatUtil.color("&aSac de &f" + target.getName() + " &adéfini à &f" + Math.min(amount, cap)));
            }
            default -> sender.sendMessage(usage("bag fill|clear|set <joueur> [quantité]"));
        }
    }

    // ── /ctb energy <fill|set|drain> <player> [amount] ───────────────

    private void cmdEnergy(CommandSender sender, String[] args) {
        if (args.length < 3) { sender.sendMessage(usage("energy fill|set|drain <joueur> [valeur]")); return; }

        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;

        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) { sender.sendMessage(ChatUtil.color("&cDonnées introuvables.")); return; }

        int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());

        switch (args[1].toLowerCase()) {
            case "fill" -> {
                data.setCurrentEnergy(maxEnergy);
                plugin.getBoxManager().removeFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&aÉnergie de &f" + target.getName() + " &aremplie."));
                target.sendMessage(ChatUtil.color("&7[Admin] Votre énergie a été remplie."));
            }
            case "drain" -> {
                data.setCurrentEnergy(0);
                plugin.getBoxManager().applyFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&cÉnergie de &f" + target.getName() + " &cdrainée."));
                target.sendMessage(ChatUtil.color("&7[Admin] Votre énergie a été drainée."));
            }
            case "set" -> {
                if (args.length < 4) { sender.sendMessage(usage("energy set <joueur> <valeur>")); return; }
                double val;
                try { val = Double.parseDouble(args[3]); } catch (NumberFormatException e) {
                    sender.sendMessage(ChatUtil.color("&cValeur invalide.")); return;
                }
                data.setCurrentEnergy(Math.min(val, maxEnergy));
                sender.sendMessage(ChatUtil.color("&aÉnergie de &f" + target.getName() + " &adéfinie à &f" + String.format("%.0f", val)));
            }
            default -> sender.sendMessage(usage("energy fill|set|drain <joueur> [valeur]"));
        }
    }

    // ── /ctb drone <give|remove> <player> <key> ──────────────────────

    private void cmdDrone(CommandSender sender, String[] args) {
        if (args.length < 4) { sender.sendMessage(usage("drone give|remove <joueur> <clé_drone>")); return; }

        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;

        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) { sender.sendMessage(ChatUtil.color("&cDonnées introuvables.")); return; }

        String droneKey = args[3].toLowerCase();
        boolean exists = plugin.getPluginConfig().getDroneConfigs().stream()
                .anyMatch(d -> d.key().equals(droneKey));
        if (!exists) {
            sender.sendMessage(ChatUtil.color("&cDrone inconnu : &f" + droneKey
                    + " &c| Clés valides : basic, advanced, military, quantum"));
            return;
        }

        switch (args[1].toLowerCase()) {
            case "give" -> {
                if (data.hasDrone(droneKey)) {
                    sender.sendMessage(ChatUtil.color("&e" + target.getName() + " possède déjà ce drone."));
                    return;
                }
                data.addDrone(droneKey);
                sender.sendMessage(ChatUtil.color("&aDrone &f" + droneKey + " &adonné à &f" + target.getName()));
                target.sendMessage(ChatUtil.color("&7[Admin] Vous avez reçu le drone &f" + droneKey + " &7!"));
            }
            case "remove" -> {
                if (!data.hasDrone(droneKey)) {
                    sender.sendMessage(ChatUtil.color("&e" + target.getName() + " ne possède pas ce drone."));
                    return;
                }
                data.getOwnedDrones().remove(droneKey);
                sender.sendMessage(ChatUtil.color("&cDrone &f" + droneKey + " &cretiré à &f" + target.getName()));
                target.sendMessage(ChatUtil.color("&7[Admin] Le drone &f" + droneKey + " &7vous a été retiré."));
            }
            default -> sender.sendMessage(usage("drone give|remove <joueur> <clé_drone>"));
        }
    }

    // ── /ctb buff <doublesell|unlimitedenergy> <player> <seconds> ────

    private void cmdBuff(CommandSender sender, String[] args) {
        if (args.length < 4) { sender.sendMessage(usage("buff doublesell|unlimitedenergy <joueur> <secondes>")); return; }

        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;

        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) { sender.sendMessage(ChatUtil.color("&cDonnées introuvables.")); return; }

        int seconds;
        try { seconds = Integer.parseInt(args[3]); } catch (NumberFormatException e) {
            sender.sendMessage(ChatUtil.color("&cDurée invalide.")); return;
        }
        if (seconds <= 0) { sender.sendMessage(ChatUtil.color("&cLa durée doit être > 0.")); return; }

        switch (args[1].toLowerCase()) {
            case "doublesell" -> {
                data.setDoubleSell(seconds);
                sender.sendMessage(ChatUtil.color("&aBuff &ex2 Vente &aappliqué à &f" + target.getName() + " &apendant &f" + seconds + "s"));
                target.sendMessage(ChatUtil.color("&6[Admin] Buff &ex2 Vente personnel &6activé pendant &f" + seconds + "s &6!"));
            }
            case "unlimitedenergy" -> {
                data.setUnlimitedEnergy(seconds);
                plugin.getBoxManager().removeFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&aBuff &bÉnergie Illimitée &aappliqué à &f" + target.getName() + " &apendant &f" + seconds + "s"));
                target.sendMessage(ChatUtil.color("&6[Admin] Buff &bÉnergie Illimitée &6activé pendant &f" + seconds + "s &6!"));
            }
            default -> sender.sendMessage(usage("buff doublesell|unlimitedenergy <joueur> <secondes>"));
        }
    }

    // ── /ctb event <drone|ufo> ────────────────────────────────────────

    private void cmdEvent(CommandSender sender, String[] args) {
        if (args.length < 2) { sender.sendMessage(usage("event drone|ufo")); return; }

        switch (args[1].toLowerCase()) {
            case "drone" -> {
                if (plugin.getEventManager().isGoldenDroneSpawned()) {
                    sender.sendMessage(ChatUtil.color("&eUn Drone Doré est déjà actif !"));
                    return;
                }
                plugin.getEventManager().spawnGoldenDrone();
                sender.sendMessage(ChatUtil.color("&6[Admin] Drone Doré invoqué avec succès !"));
            }
            case "ufo" -> {
                if (plugin.getEventManager().isUfoEventActive()) {
                    sender.sendMessage(ChatUtil.color("&eUn événement OVNI est déjà en cours !"));
                    return;
                }
                // Accès via la méthode publique
                plugin.getEventManager().forceStartUfoEvent();
                sender.sendMessage(ChatUtil.color("&5[Admin] Événement OVNI déclenché avec succès !"));
            }
            default -> sender.sendMessage(usage("event drone|ufo"));
        }
    }

    // ── /ctb sell <player> ────────────────────────────────────────────

    private void cmdSell(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;

        plugin.getEconomyManager().sellBag(target);
        if (!(sender instanceof Player p) || !p.equals(target)) {
            sender.sendMessage(ChatUtil.color("&aSac de &f" + target.getName() + " &avendu."));
        }
    }

    // ── /ctb reload ───────────────────────────────────────────────────

    private void cmdReload(CommandSender sender) {
        plugin.reloadConfig();
        plugin.getPlayerDataManager().saveAll();
        sender.sendMessage(ChatUtil.color("&aConfiguration rechargée et données sauvegardées."));
    }

    // ── Tab Completion ────────────────────────────────────────────────

    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String label, String[] args) {
        List<String> completions = new ArrayList<>();
        List<String> playerNames = Bukkit.getOnlinePlayers().stream()
                .map(Player::getName).toList();
        List<String> droneKeys = plugin.getPluginConfig().getDroneConfigs().stream()
                .map(d -> d.key()).toList();

        if (args.length == 1) {
            completions.addAll(List.of("stats", "money", "level", "bag", "energy", "drone", "buff", "event", "sell", "reload"));
        } else if (args.length == 2) {
            completions.addAll(switch (args[0].toLowerCase()) {
                case "money"  -> List.of("give", "set", "take");
                case "level"  -> List.of("bag", "tool", "energy");
                case "bag"    -> List.of("fill", "clear", "set");
                case "energy" -> List.of("fill", "set", "drain");
                case "drone"  -> List.of("give", "remove");
                case "buff"   -> List.of("doublesell", "unlimitedenergy");
                case "event"  -> List.of("drone", "ufo");
                case "stats", "sell" -> playerNames;
                default -> List.of();
            });
        } else if (args.length == 3) {
            completions.addAll(switch (args[0].toLowerCase()) {
                case "money", "level", "bag", "energy", "drone", "buff" -> playerNames;
                default -> List.of();
            });
        } else if (args.length == 4) {
            if (args[0].equalsIgnoreCase("drone")) {
                completions.addAll(droneKeys);
            } else if (args[0].equalsIgnoreCase("money")) {
                completions.addAll(List.of("100", "500", "1000", "5000"));
            } else if (args[0].equalsIgnoreCase("level")) {
                completions.addAll(List.of("1", "2", "3", "4", "5", "6", "7", "8"));
            } else if (args[0].equalsIgnoreCase("buff")) {
                completions.addAll(List.of("60", "180", "300", "600"));
            }
        }

        String filter = args[args.length - 1].toLowerCase();
        return completions.stream()
                .filter(s -> s.toLowerCase().startsWith(filter))
                .toList();
    }

    // ── Helpers ───────────────────────────────────────────────────────

    /**
     * Résout la cible : si args[argIndex] existe → joueur en ligne, sinon → sender si Player.
     */
    private Player resolveTarget(CommandSender sender, String[] args, int argIndex) {
        if (args.length > argIndex) {
            return getOnlinePlayer(sender, args[argIndex]);
        }
        if (sender instanceof Player p) return p;
        sender.sendMessage(ChatUtil.color("&cSpécifiez un joueur."));
        return null;
    }

    private Player getOnlinePlayer(CommandSender sender, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) sender.sendMessage(ChatUtil.color("&cJoueur introuvable ou hors ligne : &f" + name));
        return p;
    }

    private String usage(String syntax) {
        return ChatUtil.color("&cUsage : &f/ctb " + syntax);
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatUtil.color("&8══ &6CTB Admin &8══"));
        sender.sendMessage(ChatUtil.color("&e/ctb stats &7[joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb money &7give|set|take <joueur> <montant>"));
        sender.sendMessage(ChatUtil.color("&e/ctb level &7bag|tool|energy <joueur> <niveau>"));
        sender.sendMessage(ChatUtil.color("&e/ctb bag &7fill|clear|set <joueur> [quantité]"));
        sender.sendMessage(ChatUtil.color("&e/ctb energy &7fill|set|drain <joueur> [valeur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb drone &7give|remove <joueur> <clé>"));
        sender.sendMessage(ChatUtil.color("&e/ctb buff &7doublesell|unlimitedenergy <joueur> <secondes>"));
        sender.sendMessage(ChatUtil.color("&e/ctb event &7drone|ufo"));
        sender.sendMessage(ChatUtil.color("&e/ctb sell &7[joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb reload"));
        sender.sendMessage(ChatUtil.color("&8══════════════════"));
    }
}