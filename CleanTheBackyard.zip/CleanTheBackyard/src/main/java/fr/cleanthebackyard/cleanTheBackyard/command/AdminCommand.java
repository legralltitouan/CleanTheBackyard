package fr.cleanthebackyard.cleanTheBackyard.command;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.CollectibleItem;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import fr.cleanthebackyard.cleanTheBackyard.util.NumberFormatUtil;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;
import java.util.ArrayList;
import java.util.List;
public class AdminCommand implements CommandExecutor, TabCompleter {
    private final CleanTheBackyard plugin;
    /** Liste centralisée des sous-commandes pour l'aide et le tab. */
    private static final List<String> SUBCOMMANDS = List.of(
            "stats", "money", "level", "bag", "energy", "drone", "buff", "event",
            "sell", "prestige", "quest", "rat", "collectible", "furniture", "house",
            "talent", "daily", "module", "zone", "reload", "hud"
    );
    public AdminCommand(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }
        String sub = args[0].toLowerCase();
        // hud reste accessible à tous (permission dédiée), le reste exige ctb.admin
        if (!sub.equals("hud")) {
            if (!sender.hasPermission("ctb.admin")) {
                sender.sendMessage(ChatUtil.color("&cTu n'as pas la permission."));
                return true;
            }
            if (!sender.hasPermission("ctb.admin." + sub)) {
                sender.sendMessage(ChatUtil.color("&cPermission manquante pour cette commande : &fctb.admin." + sub));
                return true;
            }
        }
        switch (sub) {
            case "stats"       -> cmdStats(sender, args);
            case "money"       -> cmdMoney(sender, args);
            case "level"       -> cmdLevel(sender, args);
            case "bag"         -> cmdBag(sender, args);
            case "energy"      -> cmdEnergy(sender, args);
            case "drone"       -> cmdDrone(sender, args);
            case "buff"        -> cmdBuff(sender, args);
            case "event"       -> cmdEvent(sender, args);
            case "sell"        -> cmdSell(sender, args);
            case "prestige"    -> cmdPrestige(sender, args);
            case "quest"       -> cmdQuest(sender, args);
            case "rat"         -> cmdRat(sender, args);
            case "collectible" -> cmdCollectible(sender, args);
            case "furniture"   -> cmdFurniture(sender, args);
            case "house"       -> cmdHouse(sender, args);
            case "talent"      -> cmdTalent(sender, args);
            case "daily"       -> cmdDaily(sender, args);
            case "module"      -> cmdModule(sender, args);
            case "zone"        -> cmdZone(sender, args);
            case "reload"      -> cmdReload(sender);
            case "hud"         -> cmdHud(sender);
            default            -> sendHelp(sender);
        }
        return true;
    }
    // ════════════════════════════════════════════════════════════════
    //  SOUS-COMMANDES
    // ════════════════════════════════════════════════════════════════
    private void cmdStats(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) {
            sender.sendMessage(ChatUtil.color("&cDonnées introuvables."));
            return;
        }
        double globalMult = plugin.getPluginConfig().getGlobalSellMultiplier();
        boolean ufoActive = plugin.getEventManager().isUfoMultiplierActive();
        sender.sendMessage(ChatUtil.color("&8══ &aStats de &f" + target.getName() + " &8══"));
        sender.sendMessage(ChatUtil.color("&7Prestige       : &6" + data.getPrestigeLevel()));
        sender.sendMessage(ChatUtil.color("&7Solde          : &f" + NumberFormatUtil.money(data.getBalance())));
        sender.sendMessage(ChatUtil.color("&7Total gagné    : &f" + NumberFormatUtil.money(data.getLifetimeEarned())));
        sender.sendMessage(ChatUtil.color("&7Volé par rats  : &c" + NumberFormatUtil.money(data.getTotalStolenByRats())));
        sender.sendMessage(ChatUtil.color("&7Cartons cassés : &f" + NumberFormatUtil.format(data.getTotalBoxesBroken())));
        sender.sendMessage(ChatUtil.color("&7Sac            : &f" + data.getCurrentBoxes() + "/"
                + plugin.getBoxManager().getBagCapacity(data.getBagLevel()) + " (Niv " + data.getBagLevel() + ")"));
        sender.sendMessage(ChatUtil.color("&7Outil          : &fNiv " + data.getToolLevel()));
        sender.sendMessage(ChatUtil.color("&7Énergie        : &f" + String.format("%.0f", data.getCurrentEnergy())
                + "/" + plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel())
                + " (Niv " + data.getEnergyLevel() + ")"));
        sender.sendMessage(ChatUtil.color("&7Zone cartons   : &fNiv " + data.getCardboardZoneLevel() + "/"
                + plugin.getPluginConfig().getMaxCardboardZoneLevel()));
        sender.sendMessage(ChatUtil.color("&7Drones         : &f" + data.getOwnedDrones().size()));
        sender.sendMessage(ChatUtil.color("&7Meubles stock  : &f" + data.getOwnedFurniture().size() + " type(s)"));
        sender.sendMessage(ChatUtil.color("&7Collectés      : &f" + data.getCollectedItems().size() + " item(s)"));
        sender.sendMessage(ChatUtil.color("&7Sécurité       : &fCaméra Niv " + data.getSecurityLevel()
                + " | Piège Niv " + data.getTrapLevel()));
        sender.sendMessage(ChatUtil.color("&7Buff x2 vente  : &f" + (data.hasDoubleSell()
                ? "&aActif &f(" + data.getDoubleSellRemainingSeconds() + "s)" : "&cInactif")));
        sender.sendMessage(ChatUtil.color("&7Event OVNI x2  : &f" + (ufoActive
                ? "&aActif" : "&cInactif")));
        sender.sendMessage(ChatUtil.color("&7Marché Noir x3 : &f" + (data.hasBlackMarket()
                ? "&aActif &f(" + data.getBlackMarketRemainingSeconds() + "s)" : "&cInactif")));
        sender.sendMessage(ChatUtil.color("&7Bonus global   : &fx" + String.format("%.1f", globalMult)));
        sender.sendMessage(ChatUtil.color("&7Énergie illim. : &f" + (data.hasUnlimitedEnergy()
                ? "&aActive &f(" + data.getUnlimitedEnergyRemainingSeconds() + "s)" : "&cInactive")));
        sender.sendMessage(ChatUtil.color("&8══════════════════════"));
    }
    private void cmdMoney(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("money <give|set|take> <joueur> <montant>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) {
            sender.sendMessage(ChatUtil.color("&cDonnées introuvables."));
            return;
        }
        Double amount = parseDouble(sender, args[3]);
        if (amount == null) return;
        if (amount <= 0) {
            sender.sendMessage(ChatUtil.color("&cLe montant doit être supérieur à 0."));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "give" -> {
                data.addBalance(amount);
                sender.sendMessage(ChatUtil.color("&a+" + NumberFormatUtil.money(amount)
                        + " &fdonné à &a" + target.getName()));
            }
            case "take" -> {
                if (!data.removeBalance(amount)) {
                    sender.sendMessage(ChatUtil.color("&cSolde insuffisant."));
                    return;
                }
                sender.sendMessage(ChatUtil.color("&c-" + NumberFormatUtil.money(amount) + " &fprélevé."));
            }
            case "set" -> {
                data.setBalance(amount);
                sender.sendMessage(ChatUtil.color("&fSolde défini à &f" + NumberFormatUtil.money(amount)));
            }
            default -> sender.sendMessage(usage("money <give|set|take> <joueur> <montant>"));
        }
    }
    private void cmdLevel(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("level <bag|tool|energy> <joueur> <niveau>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        Integer level = parseInt(sender, args[3]);
        if (level == null) return;
        if (level < 1) {
            sender.sendMessage(ChatUtil.color("&cLe niveau doit être >= 1."));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "bag" -> {
                int max = plugin.getPluginConfig().getBagUpgrades().size();
                if (level > max) { sender.sendMessage(ChatUtil.color("&cMax : " + max)); return; }
                data.setBagLevel(level);
                sender.sendMessage(ChatUtil.color("&aSac défini niveau " + level + " pour " + target.getName()));
            }
            case "tool" -> {
                int max = plugin.getPluginConfig().getToolUpgrades().size();
                if (level > max) { sender.sendMessage(ChatUtil.color("&cMax : " + max)); return; }
                data.setToolLevel(level);
                sender.sendMessage(ChatUtil.color("&aOutil défini niveau " + level + " pour " + target.getName()));
            }
            case "energy" -> {
                int max = plugin.getPluginConfig().getEnergyUpgrades().size();
                if (level > max) { sender.sendMessage(ChatUtil.color("&cMax : " + max)); return; }
                data.setEnergyLevel(level);
                data.setCurrentEnergy(plugin.getBoxManager().getMaxEnergyForLevel(level));
                sender.sendMessage(ChatUtil.color("&aÉnergie définie niveau " + level + " pour " + target.getName()));
            }
            default -> sender.sendMessage(usage("level <bag|tool|energy> <joueur> <niveau>"));
        }
    }
    private void cmdBag(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(usage("bag <fill|clear|set> <joueur> [quantité]"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        int cap = plugin.getBoxManager().getBagCapacity(data.getBagLevel());
        switch (args[1].toLowerCase()) {
            case "fill" -> {
                data.setCurrentBoxes(cap);
                sender.sendMessage(ChatUtil.color("&aSac rempli (" + cap + ")."));
            }
            case "clear" -> {
                data.clearBag();
                sender.sendMessage(ChatUtil.color("&aSac vidé."));
            }
            case "set" -> {
                if (args.length < 4) { sender.sendMessage(usage("bag set <joueur> <quantité>")); return; }
                Integer amount = parseInt(sender, args[3]);
                if (amount == null) return;
                int finalAmount = Math.min(Math.max(0, amount), cap);
                data.setCurrentBoxes(finalAmount);
                sender.sendMessage(ChatUtil.color("&aSac défini à " + finalAmount));
            }
            default -> sender.sendMessage(usage("bag <fill|clear|set> <joueur> [quantité]"));
        }
    }
    private void cmdEnergy(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(usage("energy <fill|set|drain> <joueur> [valeur]"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        int maxEnergy = plugin.getBoxManager().getMaxEnergyForLevel(data.getEnergyLevel());
        switch (args[1].toLowerCase()) {
            case "fill" -> {
                data.setCurrentEnergy(maxEnergy);
                plugin.getBoxManager().removeFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&aÉnergie remplie."));
            }
            case "drain" -> {
                data.setCurrentEnergy(0);
                plugin.getBoxManager().applyFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&cÉnergie drainée."));
            }
            case "set" -> {
                if (args.length < 4) { sender.sendMessage(usage("energy set <joueur> <valeur>")); return; }
                Double val = parseDouble(sender, args[3]);
                if (val == null) return;
                data.setCurrentEnergy(Math.min(Math.max(0, val), maxEnergy));
                sender.sendMessage(ChatUtil.color("&aÉnergie : " + Math.min(val, maxEnergy)));
            }
            default -> sender.sendMessage(usage("energy <fill|set|drain> <joueur> [valeur]"));
        }
    }
    private void cmdDrone(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("drone <give|remove> <joueur> <clé>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        String droneKey = args[3].toLowerCase();
        if (plugin.getPluginConfig().getDroneConfig(droneKey) == null) {
            sender.sendMessage(ChatUtil.color("&cDrone inconnu : " + droneKey));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "give" -> {
                if (data.hasDrone(droneKey)) {
                    sender.sendMessage(ChatUtil.color("&eCe joueur possède déjà ce drone."));
                    return;
                }
                data.addDrone(droneKey);
                sender.sendMessage(ChatUtil.color("&aDrone &f" + droneKey + " &adonné à " + target.getName()));
            }
            case "remove" -> {
                if (!data.hasDrone(droneKey)) {
                    sender.sendMessage(ChatUtil.color("&eCe joueur ne possède pas ce drone."));
                    return;
                }
                data.getOwnedDrones().remove(droneKey);
                sender.sendMessage(ChatUtil.color("&cDrone &f" + droneKey + " &cretiré."));
            }
            default -> sender.sendMessage(usage("drone <give|remove> <joueur> <clé>"));
        }
    }
    private void cmdBuff(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("buff <doublesell|unlimitedenergy|blackmarket> <joueur> <secondes>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        Integer seconds = parseInt(sender, args[3]);
        if (seconds == null) return;
        if (seconds <= 0) {
            sender.sendMessage(ChatUtil.color("&cLa durée doit être supérieure à 0."));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "doublesell" -> {
                data.setDoubleSell(seconds);
                sender.sendMessage(ChatUtil.color("&aBuff x2 vente appliqué (" + seconds + "s)."));
            }
            case "unlimitedenergy" -> {
                data.setUnlimitedEnergy(seconds);
                plugin.getBoxManager().removeFatigue(target, data);
                sender.sendMessage(ChatUtil.color("&aÉnergie illimitée appliquée (" + seconds + "s)."));
            }
            case "blackmarket" -> {
                data.setBlackMarket(seconds);
                sender.sendMessage(ChatUtil.color("&5Marché Noir x3 appliqué (" + seconds + "s)."));
            }
            default -> sender.sendMessage(usage("buff <doublesell|unlimitedenergy|blackmarket> <joueur> <secondes>"));
        }
    }
    private void cmdEvent(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(usage("event <drone|ufo|boxrain|blackmarket>"));
            return;
        }
        switch (args[1].toLowerCase()) {
            case "drone" -> {
                if (plugin.getEventManager().isGoldenDroneSpawned()) {
                    sender.sendMessage(ChatUtil.color("&eDrone Doré déjà actif.")); return;
                }
                plugin.getEventManager().spawnGoldenDrone();
                sender.sendMessage(ChatUtil.color("&6Drone Doré invoqué."));
            }
            case "ufo" -> {
                if (plugin.getEventManager().isUfoEventActive()) {
                    sender.sendMessage(ChatUtil.color("&eOVNI déjà actif.")); return;
                }
                plugin.getEventManager().forceStartUfoEvent();
                sender.sendMessage(ChatUtil.color("&5OVNI déclenché."));
            }
            case "boxrain" -> {
                plugin.getEventManager().triggerBoxRainNow();
                sender.sendMessage(ChatUtil.color("&3Pluie de cartons déclenchée."));
            }
            case "blackmarket" -> {
                plugin.getEventManager().triggerBlackMarketNow();
                sender.sendMessage(ChatUtil.color("&5Marché Noir déclenché."));
            }
            default -> sender.sendMessage(usage("event <drone|ufo|boxrain|blackmarket>"));
        }
    }
    private void cmdSell(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;
        plugin.getEconomyManager().sellBag(target);
        sender.sendMessage(ChatUtil.color("&aSac vendu pour " + target.getName()));
    }
    private void cmdPrestige(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(usage("prestige <set|add> <joueur> <niveau>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        if (args.length < 4) {
            sender.sendMessage(ChatUtil.color("&7Prestige actuel : &6" + data.getPrestigeLevel()));
            return;
        }
        Integer val = parseInt(sender, args[3]);
        if (val == null) return;
        switch (args[1].toLowerCase()) {
            case "set" -> {
                data.setPrestigeLevel(Math.max(0, val));
                sender.sendMessage(ChatUtil.color("&6Prestige défini à " + data.getPrestigeLevel()));
            }
            case "add" -> {
                data.setPrestigeLevel(Math.max(0, data.getPrestigeLevel() + val));
                sender.sendMessage(ChatUtil.color("&6Prestige : " + data.getPrestigeLevel()));
            }
            default -> sender.sendMessage(usage("prestige <set|add> <joueur> <niveau>"));
        }
    }
    private void cmdQuest(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(usage("quest <reset|show> [joueur]"));
            return;
        }
        Player target = resolveTarget(sender, args, 2);
        if (target == null) return;
        PlayerData data = plugin.getPlayerDataManager().get(target);
        if (data == null) return;
        switch (args[1].toLowerCase()) {
            case "reset" -> {
                data.setQuestResetTimestamp(0L);
                plugin.getQuestManager().checkAndResetQuests(data);
                sender.sendMessage(ChatUtil.color("&aQuêtes regénérées pour " + target.getName() + "."));
            }
            case "show" -> {
                plugin.getQuestManager().checkAndResetQuests(data);
                sender.sendMessage(ChatUtil.color("&6Quêtes de " + target.getName() + " :"));
                data.getDailyQuests().forEach(q ->
                        sender.sendMessage(ChatUtil.color(" &7- &f" + q.getFormattedDescription()
                                + " &7(" + q.getProgress() + "/" + q.getTarget() + ")"
                                + (q.isClaimed() ? " &a✓" : q.isCompleted() ? " &e!" : "")))
                );
            }
            default -> sender.sendMessage(usage("quest <reset|show> [joueur]"));
        }
    }
    private void cmdRat(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;
        boolean ok = plugin.getRatManager().forceSpawnRat(target);
        if (ok) sender.sendMessage(ChatUtil.color("&aRat forcé sur &f" + target.getName() + "&a !"));
        else sender.sendMessage(ChatUtil.color("&cImpossible : pas dans son monde ou rat déjà actif."));
    }
    private void cmdCollectible(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("collectible <give|giveclean> <joueur> <clé> [quantité]"));
            sender.sendMessage(ChatUtil.color("&7Clés : &f" + String.join(", ",
                    plugin.getCollectibleManager().getAll().stream().map(CollectibleItem::getKey).toList())));
            return;
        }
        if (!args[1].equalsIgnoreCase("give") && !args[1].equalsIgnoreCase("giveclean")) {
            sender.sendMessage(usage("collectible <give|giveclean> <joueur> <clé> [quantité]"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        String key = args[3].toLowerCase();
        CollectibleItem item = plugin.getCollectibleManager().get(key);
        if (item == null) {
            sender.sendMessage(ChatUtil.color("&cCollectible inconnu : " + key));
            return;
        }
        int qty = args.length >= 5 ? Math.max(1, parseIntOr(args[4], 1)) : 1;
        boolean dirty = args[1].equalsIgnoreCase("give");
        String furnId = dirty ? item.getDirtyFurnitureNamespacedId() : item.getFurnitureNamespacedId();
        ItemStack base = plugin.getFurnitureProvider().getItemStack(furnId);
        if (base == null) {
            sender.sendMessage(ChatUtil.color("&cItem ItemsAdder introuvable : " + furnId));
            return;
        }
        for (int i = 0; i < qty; i++) {
            ItemStack stack = base.clone();
            stack = plugin.getCollectibleManager().tagItem(stack, item, dirty);
            stack.setAmount(1);
            var leftover = target.getInventory().addItem(stack);
            if (!leftover.isEmpty())
                leftover.values().forEach(it -> target.getWorld().dropItemNaturally(target.getLocation(), it));
        }
        sender.sendMessage(ChatUtil.color("&aDonné &f" + qty + "x " + (dirty ? "sale" : "propre")
                + " &7- &f" + item.getDisplayName() + " &7à &f" + target.getName()));
    }
    private void cmdFurniture(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(usage("furniture <give|stock> <joueur> <clé> [quantité]"));
            sender.sendMessage(ChatUtil.color("&7Clés : &f" + String.join(", ",
                    plugin.getPluginConfig().getFurnitureShopItems().stream()
                            .map(PluginConfig.FurnitureShopItem::key).toList())));
            return;
        }
        String action = args[1].toLowerCase();
        if (!action.equals("give") && !action.equals("stock")) {
            sender.sendMessage(usage("furniture <give|stock> <joueur> <clé> [quantité]"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[2]);
        if (target == null) return;
        String key = args[3].toLowerCase();
        PluginConfig.FurnitureShopItem item = plugin.getPluginConfig().getFurnitureShopItem(key);
        if (item == null) {
            sender.sendMessage(ChatUtil.color("&cMeuble inconnu : " + key));
            return;
        }
        int qty = args.length >= 5 ? Math.max(1, parseIntOr(args[4], 1)) : 1;
        if (action.equals("give")) {
            ItemStack base = plugin.getFurnitureProvider().getItemStack(item.furnitureId());
            if (base == null) {
                sender.sendMessage(ChatUtil.color("&cItem ItemsAdder introuvable : " + item.furnitureId()));
                return;
            }
            for (int i = 0; i < qty; i++) {
                ItemStack stack = base.clone();
                stack = plugin.getFurnitureShopManager().tagFurnitureItem(stack, item.key());
                stack.setAmount(1);
                var leftover = target.getInventory().addItem(stack);
                if (!leftover.isEmpty())
                    leftover.values().forEach(it -> target.getWorld().dropItemNaturally(target.getLocation(), it));
            }
            sender.sendMessage(ChatUtil.color("&aDonné &f" + qty + "x " + item.name()
                    + " &7(en main) à &f" + target.getName()));
        } else { // stock
            PlayerData data = plugin.getPlayerDataManager().get(target);
            if (data == null) return;
            data.addFurniture(key, qty);
            sender.sendMessage(ChatUtil.color("&aAjouté &f" + qty + "x " + item.name()
                    + " &aau stock de &f" + target.getName()));
        }
    }
    private void cmdHouse(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(usage("house <tp|create> <joueur>"));
            return;
        }
        Player target = resolveTarget(sender, args, 2);
        if (target == null) return;
        switch (args[1].toLowerCase()) {
            case "tp" -> {
                if (plugin.getHouseManager().enterHouse(target))
                    sender.sendMessage(ChatUtil.color("&a" + target.getName() + " téléporté dans sa maison."));
            }
            case "create" -> {
                if (plugin.getHouseManager().ensureHouseExists(target))
                    sender.sendMessage(ChatUtil.color("&aMaison créée pour " + target.getName()));
            }
            default -> sender.sendMessage(usage("house <tp|create> <joueur>"));
        }
    }
    private void cmdTalent(CommandSender sender, String[] args) {
        if (args.length < 2) {
            if (!(sender instanceof Player p)) {
                sender.sendMessage(usage("talent <open|give|reset> [joueur] [points]"));
                return;
            }
            plugin.getGuiManager().openTalent(p);
            return;
        }
        switch (args[1].toLowerCase()) {
            case "open" -> {
                Player target = resolveTarget(sender, args, 2);
                if (target == null) return;
                plugin.getGuiManager().openTalent(target);
            }
            case "give" -> {
                if (args.length < 4) { sender.sendMessage(usage("talent give <joueur> <points>")); return; }
                Player target = getOnlinePlayer(sender, args[2]);
                if (target == null) return;
                Integer pts = parseInt(sender, args[3]);
                if (pts == null) return;
                PlayerData d = plugin.getPlayerDataManager().get(target);
                if (d == null) return;
                d.addTalentPoints(pts);
                sender.sendMessage(ChatUtil.color("&a+" + pts + " points pour " + target.getName()
                        + " (total : " + d.getTalentPoints() + ")"));
            }
            case "reset" -> {
                Player target = resolveTarget(sender, args, 2);
                if (target == null) return;
                PlayerData d = plugin.getPlayerDataManager().get(target);
                if (d == null) return;
                plugin.getTalentManager().resetAndRefund(d);
                sender.sendMessage(ChatUtil.color("&aTalents reset pour " + target.getName()
                        + ". Points : " + d.getTalentPoints()));
            }
            default -> sender.sendMessage(usage("talent <open|give|reset> [joueur] [points]"));
        }
    }
    private void cmdDaily(CommandSender sender, String[] args) {
        Player target = resolveTarget(sender, args, 1);
        if (target == null) return;
        plugin.getGuiManager().openDailyReward(target);
    }
    private void cmdModule(CommandSender sender, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(usage("module <joueur> <droneKey>"));
            return;
        }
        Player target = getOnlinePlayer(sender, args[1]);
        if (target == null) return;
        String droneKey = args[2].toLowerCase();
        if (plugin.getPluginConfig().getDroneConfig(droneKey) == null) {
            sender.sendMessage(ChatUtil.color("&cDrone inconnu : " + droneKey));
            return;
        }
        PlayerData d = plugin.getPlayerDataManager().get(target);
        if (d == null) return;
        if (!d.hasDrone(droneKey)) {
            sender.sendMessage(ChatUtil.color("&cCe joueur ne possède pas le drone : " + droneKey));
            return;
        }
        plugin.getGuiManager().openDroneModule(target, droneKey);
        sender.sendMessage(ChatUtil.color("&aMenu modules ouvert pour &f" + target.getName()
                + " &7(" + droneKey + ")"));
    }
    private void cmdZone(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage(usage("zone <set|add|info> [joueur] [niveau]"));
            return;
        }
        Player target = resolveTarget(sender, args, 2);
        if (target == null) return;
        PlayerData d = plugin.getPlayerDataManager().get(target);
        if (d == null) return;
        int max = plugin.getPluginConfig().getMaxCardboardZoneLevel();
        switch (args[1].toLowerCase()) {
            case "info" -> sender.sendMessage(ChatUtil.color("&7Zone de &f" + target.getName()
                    + " &7: niveau &f" + d.getCardboardZoneLevel() + "&7/&f" + max));
            case "set" -> {
                if (args.length < 4) { sender.sendMessage(usage("zone set <joueur> <niveau>")); return; }
                Integer lvl = parseInt(sender, args[3]);
                if (lvl == null) return;
                d.setCardboardZoneLevel(Math.min(Math.max(0, lvl), max));
                sender.sendMessage(ChatUtil.color("&aZone définie au niveau " + d.getCardboardZoneLevel()
                        + " pour " + target.getName()));
            }
            case "add" -> {
                int add = args.length >= 4 ? parseIntOr(args[3], 1) : 1;
                d.setCardboardZoneLevel(Math.min(d.getCardboardZoneLevel() + add, max));
                sender.sendMessage(ChatUtil.color("&aZone : niveau &f" + d.getCardboardZoneLevel()));
            }
            default -> sender.sendMessage(usage("zone <set|add|info> [joueur] [niveau]"));
        }
    }
    private void cmdReload(CommandSender sender) {
        plugin.getPluginConfig().reload();
        plugin.getCollectibleManager().loadFromConfig();
        plugin.getPlayerDataManager().saveAll();
        sender.sendMessage(ChatUtil.color("&aConfiguration rechargée."));
    }
    private void cmdHud(CommandSender sender) {
        if (!sender.hasPermission("ctb.admin.hud")) {
            sender.sendMessage(ChatUtil.color("&cPermission manquante : &fctb.admin.hud"));
            return;
        }
        if (!(sender instanceof Player p)) {
            sender.sendMessage(ChatUtil.color("&cCommande joueur uniquement."));
            return;
        }
        boolean nowEnabled = plugin.getHudTask().toggleHud(p.getUniqueId());
        p.sendMessage(ChatUtil.color(nowEnabled ? "&aHUD activé." : "&7HUD désactivé."));
    }
    // ════════════════════════════════════════════════════════════════
    //  AUTO-COMPLÉTION
    // ════════════════════════════════════════════════════════════════
    @Override
    public List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command,
                                      @NotNull String label, String[] args) {
        List<String> completions = new ArrayList<>();
        List<String> players = onlinePlayerNames();
        List<String> droneKeys = plugin.getPluginConfig().getDroneConfigs().stream().map(PluginConfig.DroneConfig::key).toList();
        List<String> collectibleKeys = plugin.getCollectibleManager().getAll().stream().map(CollectibleItem::getKey).toList();
        List<String> furnitureKeys = plugin.getPluginConfig().getFurnitureShopItems().stream()
                .map(PluginConfig.FurnitureShopItem::key).toList();
        String sub = args.length >= 1 ? args[0].toLowerCase() : "";
        if (args.length == 1) {
            completions.addAll(SUBCOMMANDS);
        } else if (args.length == 2) {
            completions.addAll(switch (sub) {
                case "money"       -> List.of("give", "set", "take");
                case "level"       -> List.of("bag", "tool", "energy");
                case "bag"         -> List.of("fill", "clear", "set");
                case "energy"      -> List.of("fill", "set", "drain");
                case "drone"       -> List.of("give", "remove");
                case "buff"        -> List.of("doublesell", "unlimitedenergy", "blackmarket");
                case "event"       -> List.of("drone", "ufo", "boxrain", "blackmarket");
                case "prestige"    -> List.of("set", "add");
                case "quest"       -> List.of("reset", "show");
                case "collectible" -> List.of("give", "giveclean");
                case "furniture"   -> List.of("give", "stock");
                case "house"       -> List.of("tp", "create");
                case "zone"        -> List.of("set", "add", "info");
                case "talent"      -> concat(List.of("open", "give", "reset"), players);
                case "module", "stats", "sell", "rat", "daily" -> players;
                default            -> List.of();
            });
        } else if (args.length == 3) {
            completions.addAll(switch (sub) {
                case "money", "level", "bag", "energy", "drone", "buff", "prestige",
                     "quest", "collectible", "furniture", "house", "zone", "talent" -> players;
                case "module" -> droneKeys;
                default -> List.of();
            });
        } else if (args.length == 4) {
            switch (sub) {
                case "drone"       -> completions.addAll(droneKeys);
                case "collectible" -> completions.addAll(collectibleKeys);
                case "furniture"   -> completions.addAll(furnitureKeys);
                case "money"       -> completions.addAll(List.of("100", "1000", "10000"));
                case "level"       -> completions.addAll(List.of("1", "5", "10", "15"));
                case "energy"      -> completions.addAll(List.of("100", "500", "1000"));
                case "bag"         -> completions.addAll(List.of("10", "100", "1000"));
                case "buff"        -> completions.addAll(List.of("60", "180", "600"));
                case "prestige"    -> completions.addAll(List.of("1", "5", "10"));
                case "talent"      -> completions.addAll(List.of("1", "5", "10"));
                case "zone"        -> completions.addAll(List.of("1", "3", "5"));
                default -> { }
            }
        } else if (args.length == 5) {
            if (sub.equals("collectible") || sub.equals("furniture"))
                completions.addAll(List.of("1", "5", "10"));
        }
        String filter = args[args.length - 1].toLowerCase();
        return completions.stream().filter(s -> s.toLowerCase().startsWith(filter)).toList();
    }
    // ════════════════════════════════════════════════════════════════
    //  HELPERS
    // ════════════════════════════════════════════════════════════════
    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatUtil.color("&8══ &6CTB Admin &8══"));
        sender.sendMessage(ChatUtil.color("&e/ctb stats &7[joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb money &7<give|set|take> <joueur> <montant>"));
        sender.sendMessage(ChatUtil.color("&e/ctb level &7<bag|tool|energy> <joueur> <niveau>"));
        sender.sendMessage(ChatUtil.color("&e/ctb bag &7<fill|clear|set> <joueur> [quantité]"));
        sender.sendMessage(ChatUtil.color("&e/ctb energy &7<fill|set|drain> <joueur> [valeur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb drone &7<give|remove> <joueur> <clé>"));
        sender.sendMessage(ChatUtil.color("&e/ctb buff &7<doublesell|unlimitedenergy|blackmarket> <joueur> <secondes>"));
        sender.sendMessage(ChatUtil.color("&e/ctb event &7<drone|ufo|boxrain|blackmarket>"));
        sender.sendMessage(ChatUtil.color("&e/ctb sell &7[joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb prestige &7<set|add> <joueur> <niveau>"));
        sender.sendMessage(ChatUtil.color("&e/ctb quest &7<reset|show> [joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb rat &7[joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb collectible &7<give|giveclean> <joueur> <clé> [qty]"));
        sender.sendMessage(ChatUtil.color("&e/ctb furniture &7<give|stock> <joueur> <clé> [qty]"));
        sender.sendMessage(ChatUtil.color("&e/ctb house &7<tp|create> <joueur>"));
        sender.sendMessage(ChatUtil.color("&e/ctb talent &7<open|give|reset> [joueur] [points]"));
        sender.sendMessage(ChatUtil.color("&e/ctb daily &7[joueur]"));
        sender.sendMessage(ChatUtil.color("&e/ctb module &7<joueur> <droneKey>"));
        sender.sendMessage(ChatUtil.color("&e/ctb zone &7<set|add|info> [joueur] [niveau]"));
        sender.sendMessage(ChatUtil.color("&e/ctb reload"));
        sender.sendMessage(ChatUtil.color("&e/ctb hud"));
    }
    private String usage(String syntax) {
        return ChatUtil.color("&cUsage : &f/ctb " + syntax);
    }
    /** Renvoie le joueur ciblé à argIndex, ou l'émetteur s'il est joueur. */
    private Player resolveTarget(CommandSender sender, String[] args, int argIndex) {
        if (args.length > argIndex) return getOnlinePlayer(sender, args[argIndex]);
        if (sender instanceof Player p) return p;
        sender.sendMessage(ChatUtil.color("&cSpécifie un joueur."));
        return null;
    }
    private Player getOnlinePlayer(CommandSender sender, String name) {
        Player p = Bukkit.getPlayerExact(name);
        if (p == null) sender.sendMessage(ChatUtil.color("&cJoueur introuvable : " + name));
        return p;
    }
    private Integer parseInt(CommandSender sender, String raw) {
        try { return Integer.parseInt(raw); }
        catch (NumberFormatException e) {
            sender.sendMessage(ChatUtil.color("&cNombre invalide : " + raw));
            return null;
        }
    }
    private int parseIntOr(String raw, int def) {
        try { return Integer.parseInt(raw); } catch (NumberFormatException e) { return def; }
    }
    private Double parseDouble(CommandSender sender, String raw) {
        try { return Double.parseDouble(raw); }
        catch (NumberFormatException e) {
            sender.sendMessage(ChatUtil.color("&cMontant invalide : " + raw));
            return null;
        }
    }
    private List<String> onlinePlayerNames() {
        return Bukkit.getOnlinePlayers().stream().map(Player::getName).toList();
    }
    private List<String> concat(List<String> a, List<String> b) {
        List<String> list = new ArrayList<>(a);
        list.addAll(b);
        return list;
    }
}