package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.entity.FallingBlock;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.BoundingBox;

import java.util.UUID;

public class FallingBoxListener implements Listener {

    private final CleanTheBackyard plugin;
    private final NamespacedKey boxRainKey;

    public FallingBoxListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
        this.boxRainKey = new NamespacedKey(plugin, "box-rain");
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFallingBlockLand(EntityChangeBlockEvent event) {
        if (!(event.getEntity() instanceof FallingBlock fb)) return;

        BlockRef boxRef = plugin.core().config().getBoxBlockRef();
        Material fallback = plugin.providers().block().getFallbackMaterial(boxRef);
        if (fb.getBlockData().getMaterial() != fallback) return;

        fb.setDropItem(false);

        boolean isBoxRain = fb.getPersistentDataContainer().has(boxRainKey, PersistentDataType.BYTE);
        Block landing = event.getBlock();

        if (!isBoxRain) {
            return;
        }

        // ── Région étendue selon le niveau de zone du propriétaire du monde ──
        BoundingBox region = resolveRegionForWorld(landing.getWorld().getName());

        double x = landing.getX() + 0.5;
        double y = landing.getY() + 0.5;
        double z = landing.getZ() + 0.5;

        boolean insideXZ = x >= region.getMinX() && x <= region.getMaxX()
                && z >= region.getMinZ() && z <= region.getMaxZ();
        boolean insideY = y >= region.getMinY() - 1 && y <= region.getMaxY() + 1;

        if (!insideXZ || !insideY) {
            event.setCancelled(true);
            return;
        }

        event.setCancelled(true);
        final Block initialTarget = landing;
        final BoundingBox finalRegion = region;
        Bukkit.getScheduler().runTask(plugin, () -> {
            Block target = initialTarget;
            int safety = 0;
            while (!target.getType().isAir() && target.getY() < finalRegion.getMaxY() && safety++ < 5) {
                target = target.getRelative(0, 1, 0);
            }
            if (target.getType().isAir()) {
                plugin.providers().block().placeCarton(target.getLocation(), boxRef);
            }
        });
    }

    /** Déduit la région box-rain étendue à partir du nom de monde (ctb_<UUID>). */
    private BoundingBox resolveRegionForWorld(String worldName) {
        String prefix = plugin.core().config().getPlayerWorldPrefix();
        String housePrefix = plugin.core().config().getHouseWorldPrefix();
        if (!worldName.startsWith(prefix) || worldName.startsWith(housePrefix)) {
            return plugin.core().config().getBoxRainRegion(0);
        }
        String uuidStr = worldName.substring(prefix.length());
        try {
            UUID uuid = UUID.fromString(uuidStr);
            PlayerData data = plugin.core().playerData().get(uuid);
            // Le propriétaire est en ligne dans son monde lors d'une box-rain ;
            // s'il ne l'est pas (cache vide), palier 0 par sécurité.
            int zoneLevel = (data != null) ? data.getCardboardZoneLevel() : 0;
            return plugin.core().config().getBoxRainRegion(zoneLevel);
        } catch (IllegalArgumentException ignored) {
            return plugin.core().config().getBoxRainRegion(0);
        }
    }
}
