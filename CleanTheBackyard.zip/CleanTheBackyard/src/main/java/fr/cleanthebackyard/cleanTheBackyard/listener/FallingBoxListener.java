package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Material;
import org.bukkit.entity.FallingBlock;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityChangeBlockEvent;

public class FallingBoxListener implements Listener {

    private final CleanTheBackyard plugin;
    private final Material boxMaterial;

    public FallingBoxListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
        Material mat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        this.boxMaterial = (mat != null) ? mat : Material.NOTE_BLOCK;
    }

    /**
     * Quand un FallingBlock de notre matériau de carton touche le sol,
     * on s'assure qu'il se transforme bien en bloc (pas en drop d'item).
     */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onFallingBlockLand(EntityChangeBlockEvent event) {
        if (!(event.getEntity() instanceof FallingBlock fb)) return;
        if (fb.getBlockData().getMaterial() != boxMaterial) return;

        fb.setDropItem(false);
        // On laisse l'event continuer pour que le bloc se pose naturellement.
    }
}
