package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.block.Block;
import org.bukkit.entity.FallingBlock;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityChangeBlockEvent;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;

public class FallingBoxListener implements Listener {

    private final CleanTheBackyard plugin;
    private final Material boxMaterial;
    private final NamespacedKey boxRainKey;

    public FallingBoxListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
        Material mat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        this.boxMaterial = (mat != null) ? mat : Material.NOTE_BLOCK;
        this.boxRainKey = new NamespacedKey(plugin, "box-rain");
    }

    /**
     * Quand un FallingBlock de notre matériau de carton touche le sol :
     *  - S'il vient de la box rain (marqueur PDC) et atterrit DANS la région
     *    de pluie, on force la pose en NOTE_BLOCK.
     *  - S'il atterrit hors de la région ou sans marqueur, on annule la pose
     *    et on évite tout drop d'item.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onFallingBlockLand(EntityChangeBlockEvent event) {
        if (!(event.getEntity() instanceof FallingBlock fb)) return;
        if (fb.getBlockData().getMaterial() != boxMaterial) return;

        fb.setDropItem(false);

        boolean isBoxRain = fb.getPersistentDataContainer().has(boxRainKey, PersistentDataType.BYTE);
        Block landing = event.getBlock();

        if (!isBoxRain) {
            // FallingBlock de carton non lié à la box rain : on laisse Paper poser.
            return;
        }

        BoundingBox region = plugin.getPluginConfig().getBoxRainRegion();
        // Vérifie que le point d'atterrissage est dans la région XZ
        // (Y est plus permissif : on accepte tant que c'est dans la fourchette Y de la région)
        double x = landing.getX() + 0.5;
        double y = landing.getY() + 0.5;
        double z = landing.getZ() + 0.5;

        boolean insideXZ = x >= region.getMinX() && x <= region.getMaxX()
                && z >= region.getMinZ() && z <= region.getMaxZ();
        boolean insideY = y >= region.getMinY() - 1 && y <= region.getMaxY() + 1;

        if (!insideXZ || !insideY) {
            // Hors zone : on annule la pose pour ne pas polluer le décor
            event.setCancelled(true);
            return;
        }

        // Dans la zone : on s'assure que le bloc est bien posé en NOTE_BLOCK
        // (au cas où Paper supprimerait le falling block). On force après 1 tick.
        event.setCancelled(true);
        Bukkit.getScheduler().runTask(plugin, () -> {
            Block target = landing;
            // Si la case est occupée, on grimpe jusqu'à trouver une case libre
            int safety = 0;
            while (!target.getType().isAir() && target.getY() < region.getMaxY() && safety++ < 5) {
                target = target.getRelative(0, 1, 0);
            }
            if (target.getType().isAir()) {
                target.setType(boxMaterial, false);
            }
        });
    }
}
