package fr.cleanthebackyard.cleanTheBackyard;

import fr.cleanthebackyard.cleanTheBackyard.command.AdminCommand;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.gui.GuiManager;
import fr.cleanthebackyard.cleanTheBackyard.listener.*;
import fr.cleanthebackyard.cleanTheBackyard.manager.*;
import fr.cleanthebackyard.cleanTheBackyard.task.*;
import org.bukkit.plugin.java.JavaPlugin;

public final class CleanTheBackyard extends JavaPlugin {

    private static CleanTheBackyard instance;

    public HudTask getHudTask() { return hudTask; }

    // Managers
    private PluginConfig       pluginConfig;
    private PlayerDataManager  playerDataManager;
    private EconomyManager     economyManager;
    private BoxManager         boxManager;
    private SectorManager      sectorManager;
    private DroneManager       droneManager;
    private EventManager       eventManager;
    private GuiManager         guiManager;

    // Tasks (handles)
    private HudTask            hudTask;
    private EnergyRegenTask    energyRegenTask;
    private DroneIncomeTask    droneIncomeTask;
    private SectorRegenTask    sectorRegenTask;

    @Override
    public void onEnable() {
        instance = this;

        // ── Config ──────────────────────────────────────────────────
        saveDefaultConfig();
        pluginConfig = new PluginConfig(this);

        // ── Managers ────────────────────────────────────────────────
        playerDataManager = new PlayerDataManager(this);
        economyManager    = new EconomyManager(this);
        boxManager        = new BoxManager(this);
        sectorManager     = new SectorManager(this);
        droneManager      = new DroneManager(this);
        eventManager      = new EventManager(this);
        guiManager        = new GuiManager(this);

        // ── Listeners ───────────────────────────────────────────────
        getServer().getPluginManager().registerEvents(new PlayerListener(this),   this);
        getServer().getPluginManager().registerEvents(new BoxBreakListener(this), this);
        getServer().getPluginManager().registerEvents(new GuiListener(this),      this);
        getServer().getPluginManager().registerEvents(new ConsumableListener(this), this);
        getServer().getPluginManager().registerEvents(new GoldenDroneListener(this), this);
        getServer().getPluginManager().registerEvents(new GameRuleListener(this), this);

        // ── Commands ────────────────────────────────────────────────
        // Remplacer la ligne existante
        var ctbCmd = getCommand("ctb");
        AdminCommand adminCommand = new AdminCommand(this);
        ctbCmd.setExecutor(adminCommand);
        ctbCmd.setTabCompleter(adminCommand);  // ← ajout

        // ── Tasks ───────────────────────────────────────────────────
        hudTask         = new HudTask(this);

        energyRegenTask = new EnergyRegenTask(this);
        droneIncomeTask = new DroneIncomeTask(this);
        sectorRegenTask = new SectorRegenTask(this);

        hudTask.runTaskTimer(this, 0L, 4L);            // 4 ticks = ~200ms
        energyRegenTask.runTaskTimer(this, 20L, 20L);  // toutes les secondes
        droneIncomeTask.runTaskTimer(this, 20L, 200L); // toutes les 10s
        sectorRegenTask.runTaskTimer(this, 40L, 80L);  // toutes les 4s
        eventManager.scheduleNextUfoEvent();
        eventManager.scheduleNextGoldenDrone(); // remplace le GoldenDroneTask

        getLogger().info("[CleanTheBackyard] Plugin charge avec succes !");
    }

    @Override
    public void onDisable() {
        // Sauvegarde tous les profils en memoire
        if (playerDataManager != null) {
            playerDataManager.saveAll();
        }
        getLogger().info("[CleanTheBackyard] Plugin decharge. Donnees sauvegardees.");
    }

    // ── Getters ─────────────────────────────────────────────────────

    public static CleanTheBackyard getInstance() { return instance; }
    public PluginConfig      getPluginConfig()    { return pluginConfig; }
    public PlayerDataManager getPlayerDataManager(){ return playerDataManager; }
    public EconomyManager    getEconomyManager()  { return economyManager; }
    public BoxManager        getBoxManager()      { return boxManager; }
    public SectorManager     getSectorManager()   { return sectorManager; }
    public DroneManager      getDroneManager()    { return droneManager; }
    public EventManager      getEventManager()    { return eventManager; }
    public GuiManager        getGuiManager()      { return guiManager; }
}
