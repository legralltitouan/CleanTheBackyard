package fr.cleanthebackyard.cleanTheBackyard;

import fr.cleanthebackyard.cleanTheBackyard.automation.AutomationSystem;
import fr.cleanthebackyard.cleanTheBackyard.automation.manager.DroneManager;
import fr.cleanthebackyard.cleanTheBackyard.automation.manager.DroneModuleManager;
import fr.cleanthebackyard.cleanTheBackyard.command.AdminCommand;
import fr.cleanthebackyard.cleanTheBackyard.command.PlayCommand;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.core.CoreSystem;
import fr.cleanthebackyard.cleanTheBackyard.core.manager.EconomyManager;
import fr.cleanthebackyard.cleanTheBackyard.core.manager.PlayerDataManager;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.GameplaySystem;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.manager.BoxManager;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.manager.CleaningGameManager;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.manager.CollectibleManager;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.manager.CollectionBoardManager;
import fr.cleanthebackyard.cleanTheBackyard.progression.manager.*;
import fr.cleanthebackyard.cleanTheBackyard.security.manager.RatManager;
import fr.cleanthebackyard.cleanTheBackyard.ui.gui.GuiManager;
import fr.cleanthebackyard.cleanTheBackyard.ui.integration.BetterHudBridge;
import fr.cleanthebackyard.cleanTheBackyard.ui.integration.ItemsAdderHudBridge;
import fr.cleanthebackyard.cleanTheBackyard.listener.*;
import fr.cleanthebackyard.cleanTheBackyard.event.*;
import fr.cleanthebackyard.cleanTheBackyard.progression.ProgressionSystem;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockProvider;
import fr.cleanthebackyard.cleanTheBackyard.provider.EntityProvider;
import fr.cleanthebackyard.cleanTheBackyard.provider.FurnitureProvider;
import fr.cleanthebackyard.cleanTheBackyard.provider.ProviderSystem;
import fr.cleanthebackyard.cleanTheBackyard.security.SecuritySystem;
import fr.cleanthebackyard.cleanTheBackyard.world.manager.CardboardZoneManager;
import fr.cleanthebackyard.cleanTheBackyard.world.manager.FurnitureShopManager;
import fr.cleanthebackyard.cleanTheBackyard.world.manager.HouseManager;
import fr.cleanthebackyard.cleanTheBackyard.world.manager.ZoneBorderManager;
import fr.cleanthebackyard.cleanTheBackyard.world.service.ZoneService;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.task.EnergyRegenTask;
import fr.cleanthebackyard.cleanTheBackyard.ui.hud.HudTask;
import fr.cleanthebackyard.cleanTheBackyard.ui.UiSystem;
import fr.cleanthebackyard.cleanTheBackyard.world.WorldSystem;
import org.bukkit.plugin.java.JavaPlugin;

public final class CleanTheBackyard extends JavaPlugin {
    private static CleanTheBackyard instance;

    // ── Sous-systèmes par domaine ──
    private CoreSystem        core;
    private ProviderSystem    providers;
    private GameplaySystem    gameplay;
    private AutomationSystem  automation;
    private ProgressionSystem progression;
    private SecuritySystem    security;
    private WorldSystem       world;
    private EventManager      events;
    private UiSystem          ui;

    // ── Tâches répétées (cycle de vie distinct) ──
    private HudTask         hudTask;
    private EnergyRegenTask energyRegenTask;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // ── 1. Fondations (ordre de dépendance respecté) ──
        var config = new PluginConfig(this);
        core = new CoreSystem(
                config,
                new PlayerDataManager(this),
                new EconomyManager(this));

        providers = new ProviderSystem(
                new BlockProvider(this),
                new EntityProvider(this),
                new FurnitureProvider(this));

        // ── 2. Domaines de gameplay ──
        gameplay    = GameplaySystem.create(this);
        automation  = AutomationSystem.create(this);
        progression = ProgressionSystem.create(this);
        security    = SecuritySystem.create(this);
        world       = WorldSystem.create(this);
        events      = new EventManager(this);

        // ── 3. Interface : tâches + bridges instanciés ici pour préserver
        //    leur cycle de vie, puis agrégés dans UiSystem ──
        hudTask         = new HudTask(this);
        energyRegenTask = new EnergyRegenTask(this);
        BetterHudBridge     betterHudBridge     = new BetterHudBridge(this);
        ItemsAdderHudBridge itemsAdderHudBridge = new ItemsAdderHudBridge(this);
        ui = UiSystem.create(this, hudTask, betterHudBridge, itemsAdderHudBridge);

        registerListeners();
        registerCommands();
        startTasks();
        startServices();

        // ── BetterHUD / ItemsAdder bridges (via PlaceholderAPI) ──
        betterHudBridge.tryRegister();
        itemsAdderHudBridge.tryRegister();

        getLogger().info("[CleanTheBackyard] Plugin chargé avec succès !");
    }

    @Override
    public void onDisable() {
        if (world != null && world.zone() != null) world.zone().stop();
        if (core != null && core.playerData() != null) core.playerData().stopAutoSave();
        if (automation != null && automation.drone() != null) automation.drone().shutdown();
        if (core != null && core.playerData() != null) core.playerData().saveAll();
        if (security != null && security.rat() != null) security.rat().shutdown();
        getLogger().info("[CleanTheBackyard] Plugin déchargé.");
    }

    // ════════════════════════════════════════════════════════════════
    //  ENREGISTREMENTS (identiques à l'original)
    // ════════════════════════════════════════════════════════════════

    private void registerListeners() {
        var pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerListener(this), this);
        pm.registerEvents(new BoxBreakListener(this), this);
        pm.registerEvents(new GuiListener(this), this);
        pm.registerEvents(new ConsumableListener(this), this);
        pm.registerEvents(new GoldenDroneListener(this), this);
        pm.registerEvents(new GameRuleListener(this), this);
        pm.registerEvents(new FallingBoxListener(this), this);
        pm.registerEvents(new WorldProtectionListener(this), this);
        pm.registerEvents(new RatListener(this), this);
        pm.registerEvents(new CollectibleListener(this), this);
        pm.registerEvents(new HouseProtectionListener(this), this);
        pm.registerEvents(new CardboardWallListener(this), this);
        pm.registerEvents(new GameWorldProtectionListener(this), this);
    }

    private void registerCommands() {
        var ctbCmd = getCommand("ctb");
        AdminCommand adminCommand = new AdminCommand(this);
        if (ctbCmd != null) {
            ctbCmd.setExecutor(adminCommand);
            ctbCmd.setTabCompleter(adminCommand);
        }
        PlayCommand playCommand = new PlayCommand(this);
        for (String name : new String[]{"ctbplay", "create", "go", "spawn",
                "setspawn", "setplayerspawn", "daily", "talent"}) {
            var c = getCommand(name);
            if (c != null) c.setExecutor(playCommand);
        }
    }

    private void startTasks() {
        hudTask.runTaskTimer(this, 0L, 4L);
        energyRegenTask.runTaskTimer(this, 20L, 20L);
    }

    private void startServices() {
        world.zone().start();
        core.playerData().startAutoSave();

        events.scheduleNextUfoEvent();
        events.scheduleNextGoldenDrone();
        events.scheduleNextBoxRain();
        events.scheduleNextBlackMarket();
    }

    // ════════════════════════════════════════════════════════════════
    //  ACCÈS AUX SOUS-SYSTÈMES (API cible)
    // ════════════════════════════════════════════════════════════════

    public static CleanTheBackyard getInstance() { return instance; }
    public CoreSystem        core()        { return core; }
    public ProviderSystem    providers()   { return providers; }
    public GameplaySystem    gameplay()    { return gameplay; }
    public AutomationSystem  automation()  { return automation; }
    public ProgressionSystem progression() { return progression; }
    public SecuritySystem    security()    { return security; }
    public WorldSystem       world()        { return world; }
    public EventManager      events()      { return events; }
    public UiSystem          ui()          { return ui; }

    // ════════════════════════════════════════════════════════════════
    //  PONTS DÉPRÉCIÉS — garantissent zéro régression.
    //  Tout le code existant (managers, GUIs, listeners, entités) continue
    //  d'appeler ces getters sans modification. À supprimer fichier par
    //  fichier une fois la migration vers les chemins de domaine terminée.
    // ════════════════════════════════════════════════════════════════

    @Deprecated public PluginConfig           getPluginConfig()           { return core.config(); }
    @Deprecated public PlayerDataManager getPlayerDataManager()      { return core.playerData(); }
    @Deprecated public EconomyManager getEconomyManager()         { return core.economy(); }

    @Deprecated public BlockProvider           getBlockProvider()          { return providers.block(); }
    @Deprecated public EntityProvider          getEntityProvider()         { return providers.entity(); }
    @Deprecated public FurnitureProvider       getFurnitureProvider()      { return providers.furniture(); }

    @Deprecated public BoxManager getBoxManager()             { return gameplay.box(); }
    @Deprecated public CollectibleManager getCollectibleManager()     { return gameplay.collectible(); }
    @Deprecated public CleaningGameManager getCleaningGameManager()    { return gameplay.cleaningGame(); }
    @Deprecated public CollectionBoardManager getCollectionBoardManager() { return gameplay.collectionBoard(); }

    @Deprecated public DroneManager getDroneManager()           { return automation.drone(); }
    @Deprecated public DroneModuleManager getDroneModuleManager()     { return automation.droneModule(); }

    @Deprecated public QuestManager getQuestManager()           { return progression.quest(); }
    @Deprecated public PrestigeManager getPrestigeManager()        { return progression.prestige(); }
    @Deprecated public TalentManager getTalentManager()          { return progression.talent(); }
    @Deprecated public DailyRewardManager getDailyRewardManager()     { return progression.dailyReward(); }
    @Deprecated public OfflineEarningsManager getOfflineEarningsManager() { return progression.offlineEarnings(); }

    @Deprecated public RatManager getRatManager()             { return security.rat(); }

    @Deprecated public ZoneService             getZoneService()            { return world.zone(); }
    @Deprecated public CardboardZoneManager getCardboardZoneManager()   { return world.cardboardZone(); }
    @Deprecated public ZoneBorderManager getZoneBorderManager()      { return world.zoneBorder(); }
    @Deprecated public HouseManager getHouseManager()           { return world.house(); }
    @Deprecated public FurnitureShopManager getFurnitureShopManager()   { return world.furnitureShop(); }

    @Deprecated public EventManager            getEventManager()           { return events; }

    @Deprecated public GuiManager              getGuiManager()             { return ui.gui(); }
    @Deprecated public HudTask                 getHudTask()                { return ui.hud(); }
    @Deprecated public BetterHudBridge         getBetterHudBridge()        { return ui.betterHud(); }
    @Deprecated public ItemsAdderHudBridge     getItemsAdderHudBridge()    { return ui.itemsAdderHud(); }
}
