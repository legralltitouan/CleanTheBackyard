package fr.cleanthebackyard.cleanTheBackyard;

import fr.cleanthebackyard.cleanTheBackyard.command.AdminCommand;
import fr.cleanthebackyard.cleanTheBackyard.command.PlayCommand;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.gui.GuiManager;
import fr.cleanthebackyard.cleanTheBackyard.listener.*;
import fr.cleanthebackyard.cleanTheBackyard.manager.*;
import fr.cleanthebackyard.cleanTheBackyard.task.*;
import org.bukkit.plugin.java.JavaPlugin;

public final class CleanTheBackyard extends JavaPlugin {

    private static CleanTheBackyard instance;

    // Managers
    private PluginConfig       pluginConfig;
    private PlayerDataManager  playerDataManager;
    private EconomyManager     economyManager;
    private BoxManager         boxManager;
    private SectorManager      sectorManager;
    private DroneManager       droneManager;
    private EventManager       eventManager;
    private GuiManager         guiManager;
    private QuestManager       questManager;
    private PrestigeManager    prestigeManager;

    // Tasks
    private HudTask            hudTask;
    private EnergyRegenTask    energyRegenTask;
    private SectorRegenTask    sectorRegenTask;

    @Override
    public void onEnable() {
        instance = this;

        saveDefaultConfig();
        pluginConfig = new PluginConfig(this);

        playerDataManager = new PlayerDataManager(this);
        economyManager    = new EconomyManager(this);
        boxManager        = new BoxManager(this);
        sectorManager     = new SectorManager(this);
        droneManager      = new DroneManager(this);
        eventManager      = new EventManager(this);
        guiManager        = new GuiManager(this);
        questManager      = new QuestManager(this);
        prestigeManager   = new PrestigeManager(this);

        // Listeners
        getServer().getPluginManager().registerEvents(new PlayerListener(this),     this);
        getServer().getPluginManager().registerEvents(new BoxBreakListener(this),   this);
        getServer().getPluginManager().registerEvents(new GuiListener(this),        this);
        getServer().getPluginManager().registerEvents(new ConsumableListener(this), this);
        getServer().getPluginManager().registerEvents(new GoldenDroneListener(this),this);
        getServer().getPluginManager().registerEvents(new GameRuleListener(this),   this);

        // Commands
        var ctbCmd = getCommand("ctb");
        AdminCommand adminCommand = new AdminCommand(this);
        if (ctbCmd != null) {
            ctbCmd.setExecutor(adminCommand);
            ctbCmd.setTabCompleter(adminCommand);
        }

        PlayCommand playCommand = new PlayCommand(this);
        for (String name : new String[]{"ctbplay", "create", "go", "spawn"}) {
            var c = getCommand(name);
            if (c != null) c.setExecutor(playCommand);
        }

        // Hook : suivi des achats au distributeur pour les quêtes
        getServer().getPluginManager().registerEvents(new VendingPurchaseListener(this), this);

        // Tasks
        hudTask         = new HudTask(this);
        energyRegenTask = new EnergyRegenTask(this);
        sectorRegenTask = new SectorRegenTask(this);

        hudTask.runTaskTimer(this, 0L, 4L);
        energyRegenTask.runTaskTimer(this, 20L, 20L);
        sectorRegenTask.runTaskTimer(this, 40L, 80L);

        eventManager.scheduleNextUfoEvent();
        eventManager.scheduleNextGoldenDrone();
        eventManager.scheduleNextBoxRain();
        eventManager.scheduleNextBlackMarket();

        getLogger().info("[CleanTheBackyard] Plugin chargé avec succès !");
    }

    @Override
    public void onDisable() {
        if (droneManager != null) droneManager.shutdown();
        if (playerDataManager != null) playerDataManager.saveAll();
        getLogger().info("[CleanTheBackyard] Plugin déchargé.");
    }

    public static CleanTheBackyard getInstance() { return instance; }
    public PluginConfig      getPluginConfig()     { return pluginConfig; }
    public PlayerDataManager getPlayerDataManager(){ return playerDataManager; }
    public EconomyManager    getEconomyManager()   { return economyManager; }
    public BoxManager        getBoxManager()       { return boxManager; }
    public SectorManager     getSectorManager()    { return sectorManager; }
    public DroneManager      getDroneManager()     { return droneManager; }
    public EventManager      getEventManager()     { return eventManager; }
    public GuiManager        getGuiManager()       { return guiManager; }
    public QuestManager      getQuestManager()     { return questManager; }
    public PrestigeManager   getPrestigeManager()  { return prestigeManager; }
    public HudTask           getHudTask()          { return hudTask; }
}
