package fr.cleanthebackyard.cleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.automation.AutomationSystem;
import fr.cleanthebackyard.cleanTheBackyard.command.AdminCommand;
import fr.cleanthebackyard.cleanTheBackyard.command.PlayCommand;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.core.CoreSystem;
import fr.cleanthebackyard.cleanTheBackyard.core.manager.EconomyManager;
import fr.cleanthebackyard.cleanTheBackyard.core.manager.PlayerDataManager;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.GameplaySystem;
import fr.cleanthebackyard.cleanTheBackyard.ui.integration.BetterHudBridge;
import fr.cleanthebackyard.cleanTheBackyard.listener.*;
import fr.cleanthebackyard.cleanTheBackyard.event.*;
import fr.cleanthebackyard.cleanTheBackyard.progression.ProgressionSystem;
import fr.cleanthebackyard.cleanTheBackyard.provider.ProviderSystem;
import fr.cleanthebackyard.cleanTheBackyard.security.SecuritySystem;
import fr.cleanthebackyard.cleanTheBackyard.gameplay.task.EnergyRegenTask;
import fr.cleanthebackyard.cleanTheBackyard.ui.hud.HudTask;
import fr.cleanthebackyard.cleanTheBackyard.ui.UiSystem;
import fr.cleanthebackyard.cleanTheBackyard.world.WorldSystem;
import org.bukkit.plugin.java.JavaPlugin;
public final class CleanTheBackyard extends JavaPlugin {
    private static CleanTheBackyard instance;
    private CoreSystem        core;
    private ProviderSystem    providers;
    private GameplaySystem    gameplay;
    private AutomationSystem  automation;
    private ProgressionSystem progression;
    private SecuritySystem    security;
    private WorldSystem       world;
    private EventManager      events;
    private UiSystem          ui;
    private HudTask         hudTask;
    private EnergyRegenTask energyRegenTask;
    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        var config = new PluginConfig(this);
        core = new CoreSystem(
                config,
                new PlayerDataManager(this),
                new EconomyManager(this));
        // Index spatial des cartons câblé dans BlockProvider via ProviderSystem.create.
        providers = ProviderSystem.create(this);
        gameplay    = GameplaySystem.create(this);
        automation  = AutomationSystem.create(this);
        progression = ProgressionSystem.create(this);
        security    = SecuritySystem.create(this);
        world       = WorldSystem.create(this);
        events      = new EventManager(this);
        hudTask         = new HudTask(this);
        energyRegenTask = new EnergyRegenTask(this);
        BetterHudBridge betterHudBridge = new BetterHudBridge(this);
        ui = UiSystem.create(this, hudTask, betterHudBridge);
        registerListeners();
        registerCommands();
        startTasks();
        startServices();
        // Verrouillage jour/météo une seule fois sur les mondes déjà chargés.
        GameRuleListener.lockAllLoadedWorlds(this);
        betterHudBridge.tryRegister();
        getLogger().info("[CleanTheBackyard] Plugin chargé avec succès !");
    }
    @Override
    public void onDisable() {
        if (world != null && world.zone() != null) world.zone().stop();
        if (core != null && core.playerData() != null) core.playerData().stopAutoSave();
        if (automation != null && automation.drone() != null) automation.drone().shutdown();
        if (core != null && core.playerData() != null) core.playerData().saveAll();
        if (security != null && security.rat() != null) security.rat().shutdown();
        getLogger().info("[CleanTheBackyard] Plugin déchargé.");
    }
    private void registerListeners() {
        var pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerListener(this), this);
        pm.registerEvents(new BoxBreakListener(this), this);
        pm.registerEvents(new GuiListener(this), this);
        pm.registerEvents(new ConsumableListener(this), this);
        pm.registerEvents(new GoldenDroneListener(this), this);
        pm.registerEvents(new GameRuleListener(this), this);
        pm.registerEvents(new FallingBoxListener(this), this);
        pm.registerEvents(new WorldProtectionListener(this), this);
        pm.registerEvents(new RatListener(this), this);
        pm.registerEvents(new CollectibleListener(this), this);
        pm.registerEvents(new HouseProtectionListener(this), this);
        // Mouvement fusionné (mur de zone + bounds + énergie) :
        pm.registerEvents(new WorldMovementListener(this), this);
        // Protections monde de jeu HORS mouvement (portes, drop, pickup) :
        pm.registerEvents(new GameWorldProtectionListener(this), this);
        pm.registerEvents(new HubProtectionListener(this), this);
        // NB : CardboardWallListener supprimé (fusionné dans WorldMovementListener).
    }
    private void registerCommands() {
        var ctbCmd = getCommand("ctb");
        AdminCommand adminCommand = new AdminCommand(this);
        if (ctbCmd != null) {
            ctbCmd.setExecutor(adminCommand);
            ctbCmd.setTabCompleter(adminCommand);
        }
        PlayCommand playCommand = new PlayCommand(this);
        for (String name : new String[]{"ctbplay", "create", "go", "spawn",
                "setspawn", "setplayerspawn", "daily", "talent"}) {
            var c = getCommand(name);
            if (c != null) c.setExecutor(playCommand);
        }
    }
    private void startTasks() {
        hudTask.runTaskTimer(this, 0L, 4L);
        energyRegenTask.runTaskTimer(this, 20L, 20L);
        // Plus de startDayLockTask : remplacé par lockAllLoadedWorlds + listeners.
    }
    private void startServices() {
        world.zone().start();
        core.playerData().startAutoSave();
        events.scheduleNextUfoEvent();
        events.scheduleNextGoldenDrone();
        events.scheduleNextBoxRain();
        events.scheduleNextBlackMarket();
    }
    public static CleanTheBackyard getInstance() { return instance; }
    public CoreSystem        core()        { return core; }
    public ProviderSystem    providers()   { return providers; }
    public GameplaySystem    gameplay()    { return gameplay; }
    public AutomationSystem  automation()  { return automation; }
    public ProgressionSystem progression() { return progression; }
    public SecuritySystem    security()    { return security; }
    public WorldSystem       world()        { return world; }
    public EventManager      events()      { return events; }
    public UiSystem          ui()          { return ui; }
}
