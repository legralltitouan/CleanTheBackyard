package fr.cleanthebackyard.cleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.command.AdminCommand;
import fr.cleanthebackyard.cleanTheBackyard.command.PlayCommand;
import fr.cleanthebackyard.cleanTheBackyard.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.gui.GuiManager;
import fr.cleanthebackyard.cleanTheBackyard.listener.*;
import fr.cleanthebackyard.cleanTheBackyard.manager.*;
import fr.cleanthebackyard.cleanTheBackyard.service.ZoneService;
import fr.cleanthebackyard.cleanTheBackyard.task.*;
import org.bukkit.plugin.java.JavaPlugin;
public final class CleanTheBackyard extends JavaPlugin {
    private static CleanTheBackyard instance;
    private PluginConfig       pluginConfig;
    private PlayerDataManager  playerDataManager;
    private EconomyManager     economyManager;
    private BoxManager         boxManager;
    private DroneManager       droneManager;
    private EventManager       eventManager;
    private GuiManager         guiManager;
    private QuestManager       questManager;
    private PrestigeManager    prestigeManager;
    private ZoneService        zoneService;
    private HudTask            hudTask;
    private EnergyRegenTask    energyRegenTask;
    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();
        pluginConfig = new PluginConfig(this);
        playerDataManager = new PlayerDataManager(this);
        economyManager    = new EconomyManager(this);
        boxManager        = new BoxManager(this);
        droneManager      = new DroneManager(this);
        eventManager      = new EventManager(this);
        guiManager        = new GuiManager(this);
        questManager      = new QuestManager(this);
        prestigeManager   = new PrestigeManager(this);
        zoneService       = new ZoneService(this);
        // Listeners
        var pm = getServer().getPluginManager();
        pm.registerEvents(new PlayerListener(this), this);
        pm.registerEvents(new BoxBreakListener(this), this);
        pm.registerEvents(new GuiListener(this), this);
        pm.registerEvents(new ConsumableListener(this), this);
        pm.registerEvents(new GoldenDroneListener(this), this);
        pm.registerEvents(new GameRuleListener(this), this);
        pm.registerEvents(new FallingBoxListener(this), this);
        pm.registerEvents(new WorldProtectionListener(this), this);
        // Commands
        var ctbCmd = getCommand("ctb");
        AdminCommand adminCommand = new AdminCommand(this);
        if (ctbCmd != null) {
            ctbCmd.setExecutor(adminCommand);
            ctbCmd.setTabCompleter(adminCommand);
        }
        PlayCommand playCommand = new PlayCommand(this);
        for (String name : new String[]{"ctbplay", "create", "go", "spawn"}) {
            var c = getCommand(name);
            if (c != null) c.setExecutor(playCommand);
        }
        // Tasks
        hudTask         = new HudTask(this);
        energyRegenTask = new EnergyRegenTask(this);
        hudTask.runTaskTimer(this, 0L, 4L);
        energyRegenTask.runTaskTimer(this, 20L, 20L);
        // Services
        zoneService.start();
        playerDataManager.startAutoSave();
        // Événements aléatoires
        eventManager.scheduleNextUfoEvent();
        eventManager.scheduleNextGoldenDrone();
        eventManager.scheduleNextBoxRain();
        eventManager.scheduleNextBlackMarket();
        getLogger().info("[CleanTheBackyard] Plugin chargé avec succès !");
    }
    @Override
    public void onDisable() {
        if (zoneService != null) zoneService.stop();
        if (playerDataManager != null) playerDataManager.stopAutoSave();
        if (droneManager != null) droneManager.shutdown();
        if (playerDataManager != null) playerDataManager.saveAll();
        getLogger().info("[CleanTheBackyard] Plugin déchargé.");
    }
    public static CleanTheBackyard getInstance() { return instance; }
    public PluginConfig      getPluginConfig()     { return pluginConfig; }
    public PlayerDataManager getPlayerDataManager(){ return playerDataManager; }
    public EconomyManager    getEconomyManager()   { return economyManager; }
    public BoxManager        getBoxManager()       { return boxManager; }
    public DroneManager      getDroneManager()     { return droneManager; }
    public EventManager      getEventManager()     { return eventManager; }
    public GuiManager        getGuiManager()       { return guiManager; }
    public QuestManager      getQuestManager()     { return questManager; }
    public PrestigeManager   getPrestigeManager()  { return prestigeManager; }
    public ZoneService       getZoneService()      { return zoneService; }
    public HudTask           getHudTask()          { return hudTask; }
}