package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;

/**
 * Bloque toutes les interactions destructrices hors mode Créatif.
 * Les cartons (normaux & OVNI) sont gérés en amont par {@link BoxBreakListener}.
 */
public class WorldProtectionListener implements Listener {

    private final CleanTheBackyard plugin;

    public WorldProtectionListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private boolean isCreative(Player player) {
        return player.getGameMode() == GameMode.CREATIVE;
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (isCreative(player)) return;

        BlockRef boxRef = plugin.getPluginConfig().getBoxBlockRef();
        BlockRef ufoRef = plugin.getPluginConfig().getUfoBlockRef();

        // Cartons normaux et OVNI : laissés à BoxBreakListener
        if (plugin.getBlockProvider().isCarton(event.getBlock(), boxRef)) return;
        if (plugin.getEventManager().isUfoBox(event.getBlock().getLocation())
                && plugin.getBlockProvider().isCarton(event.getBlock(), ufoRef)) return;

        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (isCreative(event.getPlayer())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (isCreative(player)) return;

        // Le Drone Doré et les rats restent frappables (gérés par leurs listeners dédiés)
        if (plugin.getEntityProvider().isCtbEntity(event.getEntity(), "golden-drone")) return;
        if (plugin.getEntityProvider().isCtbEntity(event.getEntity(), "rat")) return;

        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        if (!(event.getRemover() instanceof Player player)) return;
        if (isCreative(player)) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
        if (isCreative(event.getPlayer())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        if (isCreative(event.getPlayer())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (isCreative(event.getPlayer())) return;
        event.setCancelled(true);
    }
}
