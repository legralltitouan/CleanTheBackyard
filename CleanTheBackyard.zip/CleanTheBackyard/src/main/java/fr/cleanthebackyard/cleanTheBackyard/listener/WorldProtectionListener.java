package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.provider.BlockRef;
import org.bukkit.GameMode;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;
import org.bukkit.inventory.ItemStack;

/**
 * Bloque toutes les interactions destructrices hors mode Créatif,
 * SAUF dans les mondes-maison (ctb_house_*) où la maison gère ses propres règles
 * via {@link HouseProtectionListener}.
 *
 * Les cartons (normaux & OVNI) sont gérés en amont par {@link BoxBreakListener}.
 */
public class WorldProtectionListener implements Listener {

    private final CleanTheBackyard plugin;

    public WorldProtectionListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    private boolean isCreative(Player player) {
        return player.getGameMode() == GameMode.CREATIVE;
    }

    /** Skippe ce listener pour les mondes-maison : la protection y est gérée séparément. */
    private boolean isHouseWorld(Entity entity) {
        return entity != null && plugin.world().house().isAnyHouseWorld(entity.getWorld());
    }

    private boolean isHouseWorld(org.bukkit.block.Block block) {
        return block != null && plugin.world().house().isAnyHouseWorld(block.getWorld());
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (isCreative(player)) return;
        if (isHouseWorld(event.getBlock())) return; // maison : HouseProtectionListener décide

        BlockRef boxRef = plugin.core().config().getBoxBlockRef();
        BlockRef ufoRef = plugin.core().config().getUfoBlockRef();

        if (plugin.providers().block().isCarton(event.getBlock(), boxRef)) return;
        if (plugin.events().isUfoBox(event.getBlock().getLocation()) && plugin.providers().block().isCarton(event.getBlock(), ufoRef))
            return;

        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        if (isCreative(event.getPlayer())) return;
        if (isHouseWorld(event.getBlock())) return; // maison : HouseProtectionListener décide

        ItemStack inHand = event.getItemInHand();
        if (plugin.world().furnitureShop().isShopFurniture(inHand)) return;

        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (isCreative(player)) return;

        // ── Dans la maison : on protège explicitement les animaux (cochon, mouton, vache…) ──
        if (isHouseWorld(event.getEntity())) {
            if (event.getEntity() instanceof Animals) {
                event.setCancelled(true);
            }
            // Le reste de la maison est géré par HouseProtectionListener.
            return;
        }

        // Drone doré et rats restent frappables hors maison.
        if (plugin.providers().entity().isCtbEntity(event.getEntity(), "golden-drone")) return;
        if (plugin.providers().entity().isCtbEntity(event.getEntity(), "rat")) return;

        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        if (!(event.getRemover() instanceof Player player)) return;
        if (isCreative(player)) return;
        if (isHouseWorld(event.getEntity())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
        if (isCreative(event.getPlayer())) return;
        if (isHouseWorld(event.getRightClicked())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        if (isCreative(event.getPlayer())) return;
        if (isHouseWorld(event.getBlockClicked())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (isCreative(event.getPlayer())) return;
        if (isHouseWorld(event.getBlockClicked())) return;
        event.setCancelled(true);
    }
}
