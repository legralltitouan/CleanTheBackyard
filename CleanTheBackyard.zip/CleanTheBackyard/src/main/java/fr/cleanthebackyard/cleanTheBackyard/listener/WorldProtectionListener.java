package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.hanging.HangingBreakByEntityEvent;
import org.bukkit.event.player.PlayerArmorStandManipulateEvent;
import org.bukkit.event.player.PlayerBucketEmptyEvent;
import org.bukkit.event.player.PlayerBucketFillEvent;

/**
 * Bloque toutes les interactions destructrices dans TOUS les mondes,
 * sauf pour les joueurs en mode Créatif.
 *
 * Exceptions internes : les cartons (NOTE_BLOCK) et les boîtes OVNI (GLOWSTONE)
 * sont déjà gérés par BoxBreakListener — on les laisse passer ici aussi
 * pour que la mécanique fonctionne.
 */
public class WorldProtectionListener implements Listener {

    private final CleanTheBackyard plugin;
    private final Material boxMaterial;

    public WorldProtectionListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
        Material mat = Material.matchMaterial(plugin.getPluginConfig().getBoxBlock());
        this.boxMaterial = (mat != null) ? mat : Material.NOTE_BLOCK;
    }

    private boolean isCreative(Player player) {
        return player.getGameMode() == GameMode.CREATIVE;
    }

    /** Casser des blocs interdit hors créatif (sauf cartons + boîtes OVNI). */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        if (isCreative(player)) return;

        Material type = event.getBlock().getType();
        // Cartons : laissés à BoxBreakListener qui annule déjà
        if (type == boxMaterial) return;
        // Boîtes OVNI : idem
        if (type == Material.GLOWSTONE && plugin.getEventManager().isUfoBox(event.getBlock().getLocation())) {
            return;
        }
        event.setCancelled(true);
    }

    /** Poser des blocs interdit hors créatif. */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBlockPlace(BlockPlaceEvent event) {
        Player player = event.getPlayer();
        if (isCreative(player)) return;
        event.setCancelled(true);
    }

    /** Empêche d'attaquer les mobs et autres joueurs hors créatif. */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onEntityDamageByEntity(EntityDamageByEntityEvent event) {
        if (!(event.getDamager() instanceof Player player)) return;
        if (isCreative(player)) return;

        // Exception : le Drone Doré (Bat) reste frappable même hors créatif
        // → c'est géré par GoldenDroneListener qui s'exécute avant
        if (event.getEntity() instanceof org.bukkit.entity.Bat
                && plugin.getEventManager().isGoldenDroneSpawned()) {
            return;
        }
        event.setCancelled(true);
    }

    /** Empêche de casser cadres, tableaux, etc. */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onHangingBreak(HangingBreakByEntityEvent event) {
        if (!(event.getRemover() instanceof Player player)) return;
        if (isCreative(player)) return;
        event.setCancelled(true);
    }

    /** Empêche les manipulations d'armor stands. */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onArmorStandManipulate(PlayerArmorStandManipulateEvent event) {
        if (isCreative(event.getPlayer())) return;
        event.setCancelled(true);
    }

    /** Empêche d'utiliser des seaux (eau/lave). */
    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucketEmpty(PlayerBucketEmptyEvent event) {
        if (isCreative(event.getPlayer())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOW, ignoreCancelled = true)
    public void onBucketFill(PlayerBucketFillEvent event) {
        if (isCreative(event.getPlayer())) return;
        event.setCancelled(true);
    }
}
