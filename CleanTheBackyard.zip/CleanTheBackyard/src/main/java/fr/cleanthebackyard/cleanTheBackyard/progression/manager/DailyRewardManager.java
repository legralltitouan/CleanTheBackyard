package fr.cleanthebackyard.cleanTheBackyard.progression.manager;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import fr.cleanthebackyard.cleanTheBackyard.core.config.PluginConfig;
import fr.cleanthebackyard.cleanTheBackyard.data.PlayerData;
import fr.cleanthebackyard.cleanTheBackyard.util.ChatUtil;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import java.time.LocalDate;
import java.time.ZoneId;
public class DailyRewardManager {
    private final CleanTheBackyard plugin;
    public DailyRewardManager(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private long today() {
        return LocalDate.now(ZoneId.systemDefault()).toEpochDay();
    }
    /** Renvoie le jour 1..7 disponible aujourd'hui pour ce joueur. */
    public int getCurrentDay(PlayerData data) {
        long today = today();
        long last = data.getLastDailyClaimEpochDay();
        int streak = data.getDailyStreak();
        if (last == today) {
            // déjà réclamée
            return streak == 0 ? 1 : streak;
        }
        if (last == today - 1) {
            // continuité
            int next = streak + 1;
            if (next > 7) next = 1; // cycle
            return next;
        }
        // streak cassée (ou première connexion)
        return 1;
    }
    public boolean alreadyClaimedToday(PlayerData data) {
        return data.getLastDailyClaimEpochDay() == today();
    }
    public boolean claim(Player player) {
        PlayerData data = plugin.core().playerData().get(player);
        if (data == null) return false;
        if (alreadyClaimedToday(data)) {
            player.sendMessage(ChatUtil.color("&eTu as déjà réclamé ta récompense aujourd'hui."));
            return false;
        }
        int day = getCurrentDay(data);
        PluginConfig.DailyReward reward = plugin.core().config().getDailyReward(day);
        if (reward == null) {
            player.sendMessage(ChatUtil.color("&cAucune récompense configurée pour le jour " + day));
            return false;
        }
        long today = today();
        long last = data.getLastDailyClaimEpochDay();
        if (last == today - 1) {
            data.setDailyStreak(day);
        } else {
            data.setDailyStreak(1);
        }
        data.setLastDailyClaimEpochDay(today);
        if (reward.money() > 0) {
            data.addBalance(reward.money());
        }
        if (reward.doubleSellSeconds() > 0) {
            data.setDoubleSell(reward.doubleSellSeconds());
        }
        player.sendMessage(ChatUtil.color("&8[&6Récompense quotidienne&8] " + reward.message()));
        player.playSound(player.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 0.9f, 1.2f);
        return true;
    }
    /** Affiche un avertissement si la dernière réclamation date d'avant-hier (streak cassée). */
    public void maybeNotifyStreakBroken(Player player, PlayerData data) {
        long today = today();
        long last = data.getLastDailyClaimEpochDay();
        if (last == 0 || last == today || last == today - 1) return;
        if (data.getDailyStreak() > 1) {
            player.sendMessage(ChatUtil.color("&c⚠ Ta série de connexions a été interrompue. Tu repars du jour 1 !"));
        }
        data.setDailyStreak(0);
    }
}