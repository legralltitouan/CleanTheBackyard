package fr.cleanthebackyard.cleanTheBackyard.listener;

import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;

public class GuiListener implements Listener {

    private final CleanTheBackyard plugin;

    public GuiListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!plugin.ui().gui().isCtbView(event.getView())) return;

        // On annule toujours pour empêcher tout déplacement d'item non contrôlé.
        event.setCancelled(true);

        // On délègue au GUI le clic, qu'il soit dans le haut OU le bas.
        // Chaque GUI décide quoi faire (la plupart ignorent le bas ;
        // FurnitureInventoryGui l'exploite pour le restock).
        plugin.ui().gui().handleClick(player, event);
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (!plugin.ui().gui().isCtbView(event.getView())) return;
        event.setCancelled(true);
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        plugin.ui().gui().onClose(player, event.getInventory());
    }
}
