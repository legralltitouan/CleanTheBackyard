package fr.cleanthebackyard.cleanTheBackyard.listener;
import fr.cleanthebackyard.cleanTheBackyard.CleanTheBackyard;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.InventoryView;
public class GuiListener implements Listener {
    private final CleanTheBackyard plugin;
    public GuiListener(CleanTheBackyard plugin) {
        this.plugin = plugin;
    }
    private boolean isCtbInventory(InventoryView view) {
        if (view == null) return false;
        String title = view.getTitle();
        if (title == null) return false;
        return title.contains("Garage")
                || title.contains("Distributeur")
                || title.contains("Boutique")
                || title.contains("Upgrade")
                || title.contains("Quêtes")
                || title.contains("PRESTIGE");
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        if (!isCtbInventory(event.getView())) return;
        // CANCEL TOUJOURS, peu importe l'inventaire cliqué (haut OU bas)
        // Empêche shift-click depuis l'inventaire joueur vers le GUI
        event.setCancelled(true);
        // Routage uniquement si clic dans la partie haute (GUI CTB)
        if (event.getClickedInventory() != null
                && event.getClickedInventory().equals(event.getView().getTopInventory())) {
            plugin.getGuiManager().handleClick(player, event);
        }
    }
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (!isCtbInventory(event.getView())) return;
        event.setCancelled(true);
    }
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        plugin.getGuiManager().onClose(player, event.getInventory());
    }
}