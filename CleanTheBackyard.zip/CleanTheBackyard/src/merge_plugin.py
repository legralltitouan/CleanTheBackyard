import os

# On cible directement le dossier contenant ton code
PROJECT_ROOT = 'src'
OUTPUT_FILE = 'merged_plugin_source_en_cour_d_opti.txt'

# Extensions à capturer
TARGET_EXTENSIONS = ('.java', '.yml', '.yaml', '.json')

def merge_source_files(root_dir, output_path):
    if not os.path.exists(root_dir):
        print(f"❌ Erreur : Le dossier '{root_dir}' est introuvable au niveau du script.")
        return

    print(f"🔍 Analyse du dossier : {os.path.abspath(root_dir)}")
    file_count = 0

    with open(output_path, 'w', encoding='utf-8') as outfile:
        for root, dirs, files in os.walk(root_dir):
            for file in files:
                if file.endswith(TARGET_EXTENSIONS):
                    file_path = os.path.join(root, file)
                    relative_path = os.path.relpath(file_path, root_dir)

                    try:
                        with open(file_path, 'r', encoding='utf-8') as infile:
                            content = infile.read()

                            outfile.write("\n" + "="*80 + "\n")
                            outfile.write(f"📁 FILE: src/{relative_path.replace(os.sep, '/')}\n")
                            outfile.write("="*80 + "\n\n")

                            outfile.write(content)
                            outfile.write("\n")

                            print(f"✅ Ajouté : src/{relative_path.replace(os.sep, '/')}")
                            file_count += 1
                    except Exception as e:
                        print(f"❌ Erreur sur {file}: {e}")

    print(f"\n🚀 Terminé ! {file_count} fichiers fusionnés dans '{output_path}'.")

if __name__ == "__main__":
    merge_source_files(PROJECT_ROOT, OUTPUT_FILE)